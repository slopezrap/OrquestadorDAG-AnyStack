# SCREENS.md — plantilla del plano conductor

> Este archivo conduce la obra. Cada sección `SCR-*` debe poder convertirse en una entrada de `.orchestrator-state/features.json` durante `/init-build`.

## 0. Índice de pantallas y foundations

| Orden | ID | Tipo | Nombre | Plataforma | Ruta/deeplink | Depende de | Diseño | Estado |
|---:|---|---|---|---|---|---|---|---|
| 1 | SCR-FOUNDATION-SCHEMA | foundation | Esquema base | all | null | [] | null | draft |
| 2 | SCR-FOUNDATION-AUTH | foundation | Autenticación | all | null | [SCR-FOUNDATION-SCHEMA] | null | draft |
| 3 | SCR-FOUNDATION-SHELL | foundation | Shell compartida y design system | web/android/ios | null | [SCR-FOUNDATION-AUTH] | `design/screens/<archivo-shell>` | draft |
| 10 | SCR-001 | ui | `<NOMBRE_PANTALLA>` | web/android/ios | `<RUTA>` | [SCR-FOUNDATION-SHELL] | `design/screens/<archivo>` | draft |

## 1. Foundations recomendados

Las foundations no son pantallas visibles, pero sí unidades que el orquestador debe construir y aceptar antes de pantallas dependientes.

**Regla de decisión para foundations de motor/pipeline (derivable, sin CLARIFY):** un `ENG-*`/`PIPE-*` merece su propio foundation solo si su `module.consumed_by` (motores) o `related_screens`/`feeds` (pipelines) nombra MÁS DE UN `SCR-*`, o uno distinto del que lo introduce. Con un único consumidor, el motor o pipeline vive dentro de la vertical slice de esa pantalla — shared support code que necesita la unidad activa, no un foundation (YAGNI). Cuando aplique, declara `SCR-FOUNDATION-ENGINE-<NOMBRE>` / `SCR-FOUNDATION-PIPELINE-<NOMBRE>` con el mismo formato que `SCR-FOUNDATION-SHELL`, `after: [SCR-FOUNDATION-SCHEMA]` y `applies` citando el `ENG-*`/`PIPE-*` correspondiente (ver `blueprint-templates/SCREENS-template.md`).

**Corolario — vertical fina primero:** que un `ENG-*`/`PIPE-*` tenga más de un consumidor justifica declararlo como foundation, pero nunca justifica construirlo antes de que algo lo demuestre. Por cada `SCR-FOUNDATION-ENGINE-*`/`SCR-FOUNDATION-PIPELINE-*` que declares, declara en la misma pasada su unidad `SCR-WALKING-SKELETON-<NOMBRE>` (molde completo en `blueprint-templates/SCREENS-template.md`, sección 1): la porción real más delgada que atraviesa fuente → pipeline → motor → salida verificable → una ruta, con `order` inmediatamente detrás del foundation que prueba — nunca detrás de más foundations. Un foundation sin un consumidor real programado a pocos números de `order` de distancia es cimiento sin probar: nada en el plan lo ejercitará, que es exactamente cómo un esquema se reescribió 14 veces en el único proyecto real que ha corrido esta maquinaria, sin una sola línea de comportamiento de producto ejecutado.

### SCR-FOUNDATION-SCHEMA — Esquema de datos base

```screen
id: SCR-FOUNDATION-SCHEMA
slug: schema
kind: foundation
platforms: [all]
route: null
order: 1
after: []
applies: [CORE-001]
# NOT DATA-001, deliberately — citing a DATA-* makes this unit a data-bearing unit, and
# the gate then demands a full data_engine including a single_value_contract mapping
# store -> API -> client. A schema-only foundation has no API and no client yet, so it
# cannot fill that honestly. The schema still IMPLEMENTS DATA-001; it is the units that
# read and write through it that carry the contract. The golden-path reference does
# exactly this (.orchestrator/examples/golden-path/blueprint/SCREENS.md).
design_ref: null
acceptance:
  - Cuando se ejecutan las migraciones desde cero, el sistema creará el esquema requerido sin errores.
  - Cuando se consulta el esquema base, el sistema expondrá las tablas, colecciones o modelos definidos por DATA-001.
verify:
  tests:
    - "<COMANDO_TEST_SCHEMA>"
  commands:
    - "<COMANDO_MIGRACIONES>"
  ui_states: []
  data_check:
    db_query: "<QUERY_O_COMANDO_DE_ESQUEMA>"
    expect: "El esquema existe y coincide con DATA-001."
  evidence_required:
    - migration_log
    - schema_snapshot
```

### SCR-FOUNDATION-AUTH — Autenticación y sesión

```screen
id: SCR-FOUNDATION-AUTH
slug: auth
kind: foundation
platforms: [all]
route: null
order: 2
after: [SCR-FOUNDATION-SCHEMA]
applies: [PERM-001, DATA-002, ERR-001]
design_ref: null
acceptance:
  - Cuando un usuario se registra con credenciales válidas, el sistema creará una identidad persistida y una sesión válida.
  - Cuando un usuario inicia sesión con credenciales válidas, el sistema establecerá sesión autenticada.
  - Cuando un usuario no autenticado accede a un recurso protegido, el sistema bloqueará el acceso y registrará el intento según PERM-001.
verify:
  tests:
    - "<COMANDO_TEST_AUTH>"
  commands:
    - "<COMANDO_SMOKE_AUTH>"
  ui_states: []
  data_check:
    db_query: "<QUERY_AUTH>"
    expect: "La identidad, perfil y sesión cumplen DATA-002 y PERM-001."
  evidence_required:
    - auth_test_log
    - db_snapshot
```

### SCR-FOUNDATION-SHELL — Shell compartida y design system

Construye el contrato cross-pantalla UNA vez, antes de cualquier pantalla visible: la shell/layout dentro de la que renderiza toda pantalla, el esqueleto de navegación, el inventario inicial de componentes reutilizables y el cableado de tokens de diseño. Toda pantalla `kind: ui` debe listar esta foundation en `after` para que las pantallas, construidas de una en una, queden coherentes entre sí. El contrato vive en `blueprint/logic/shell.md` (`UI-SHELL-*`).

```screen
id: SCR-FOUNDATION-SHELL
slug: shell
kind: foundation
platforms: [web, android, ios]
route: null
order: 3
after: [SCR-FOUNDATION-AUTH]
applies: [UI-SHELL-001]
design_ref: "design/screens/<archivo-shell>"
acceptance:
  - Cuando se abre cualquier ruta de pantalla, el sistema la renderizará dentro de la shell compartida (header/navegación/footer según UI-SHELL-001), nunca una copia por pantalla.
  - Cuando se renderiza la navegación para un rol, el sistema mostrará exactamente las entradas que permiten sus permisos.
  - Cuando una pantalla necesita un patrón visual compartido, el sistema lo servirá desde el inventario de componentes con sus estados declarados.
  - Cuando un componente declara color/tipografía/espaciado, el sistema consumirá tokens de design/tokens.css, no valores hardcodeados.
verify:
  tests:
    - "<COMANDO_TEST_SHELL>"
  commands:
    - "<COMANDO_SMOKE_SHELL>"
  ui_states: [loading, success]
  data_check:
    db_query: null
    expect: "No aplica: la shell no renderiza datos de producto propios."
  evidence_required:
    - screenshot_or_recording
    - test_output
```

## 2. Plantilla de pantalla UI

Copia este bloque por cada pantalla visible. Una pantalla debe representar una vertical slice completa: datos, lógica, API, UI y verificación.

### SCR-001 — `<NOMBRE_VISIBLE_DE_LA_PANTALLA>`

#### Qué construye

`<DESCRIPCION_DE_LA_CAPACIDAD_VISIBLE_Y_DEL_VALOR_PARA_EL_USUARIO>`

#### Actor principal

`<ACTOR_O_ROL>`

#### Entrada del usuario

- Desde: `<PANTALLA_ORIGEN_O_EVENTO>`
- Con datos previos: `<DATOS_NECESARIOS>`
- Estado inicial esperado: `<LOADING_EMPTY_ERROR_SUCCESS_U_OTRO>`

#### Salida o resultado

- Persistencia esperada: `<QUE_DATOS_CAMBIAN>`
- Navegación siguiente: `<DESTINO>`
- Feedback visible: `<MENSAJE_TOAST_ESTADO_ETC>`

#### Reglas aplicadas

Lista solo IDs existentes en `PRODUCT.md` o `logic/*.md`.

- BR-001
- DOM-001
- UC-001
- APP-001
- PERM-001
- ST-001
- ERR-001
- INT-001
- UI-001
- DATA-001

#### Diseño y referencias

- Diseño visual: `design/screens/<archivo>`
- Tokens: `design/tokens.css`
- Notas de responsive: `<BREAKPOINTS_O_REGLAS>`
- Componentes existentes a reutilizar: `<COMPONENTES>`

#### Criterios observables

Usa formato EARS cuando sea posible.

- Cuando `<CONDICION>`, el sistema deberá `<RESULTADO_OBSERVABLE>`.
- Mientras `<ESTADO>`, el sistema deberá `<RESULTADO_OBSERVABLE>`.
- Si `<EVENTO_DE_ERROR>`, el sistema deberá `<RESULTADO_OBSERVABLE_Y_RECUPERACION>`.
- Donde `<CONTEXTO>`, el sistema deberá `<REGLA>`.

```screen
id: SCR-001
slug: "<slug-estable>"
kind: ui
platforms: [web, android, ios]
route:
  web: "/<ruta>"
  android: "app://<deeplink>"
  ios: "app://<deeplink>"
order: 10
after: [SCR-FOUNDATION-SCHEMA, SCR-FOUNDATION-AUTH, SCR-FOUNDATION-SHELL]
applies: [BR-001, DOM-001, UC-001, APP-001, PERM-001, ST-001, ERR-001, UI-001, DATA-001]
data_engine:
  engine_refs: [DATA-001, APP-001, UC-001, DOM-001, PERM-001]
  canonical_store:
    source_of_truth: database
    resources: ["<tabla_o_coleccion>"]
  pipeline:
    writes_to_database: true
    generation:
      required: true
      method: "<migration|seed|backfill|job|api_write|user_action>"
      no_frontend_fixtures: true
    write_path: ["APP-001", "repository", "<tabla_o_coleccion>"]
    read_path: ["database", "service/api", "frontend/mobile"]
  single_value_contract:
    - field: "<campo_de_negocio>"
      db_source: "<tabla>.<campo>"
      api_field: "<response.path>"
      ui_field: "<selector_o_widget>"
      invariant: "same value for the same user/tenant/permission context"
design_ref: "design/screens/<archivo>"
acceptance:
  - "Cuando el usuario abre la pantalla, el sistema deberá mostrar un estado de carga mientras obtiene datos reales."
  - "Cuando no existen datos para el usuario actual, el sistema deberá mostrar un estado vacío con una acción principal clara."
  - "Cuando la operación falla, el sistema deberá mostrar un mensaje recuperable y permitir reintento sin perder contexto."
  - "Cuando existen datos persistidos, el sistema deberá mostrar exactamente los registros autorizados para el usuario actual."
verify:
  test_level: e2e
  tests:
    - "<COMANDO_TEST_DE_ESTA_PANTALLA>"
  commands:
    - "<COMANDO_BACKEND_LOGS>"
    - "<COMANDO_DB_CHECK>"
  web:
    preferred_tools: [claude_chrome, chrome_devtools_mcp]
    required_evidence: [screenshot, console_log, network_log]
    viewports:
      - { name: desktop, width: 1440, height: 900 }
      - { name: mobile_web, width: 390, height: 844 }
  mobile:
    framework: flutter
    android:
      required_evidence: [screenshot, adb_logcat, flow_record]
      commands:
        - "adb devices"
        - "adb logcat -d"
    ios:
      required_evidence: [screenshot, idb_log, flow_record]
      commands:
        - "idb list-targets"
        - "xcrun simctl list devices"
  ui_states: [loading, empty, error, success]
  data_check:
    db_query: "<QUERY_REAL_QUE_COMPRUEBA_LO_VISIBLE>"
    expect: "Los datos visibles coinciden con la consulta y respetan permisos."
  logs_check:
    frontend: "No hay errores de consola/runtime."
    backend: "No hay errores 5xx ni excepciones no controladas."
    database: "No hay violaciones de constraints ni queries inválidas."
  evidence_required:
    - result_json
    - screenshot_or_recording
    - test_output
    - db_check_output
```

## 3. Plantilla de unidad backend/data sin UI

### SCR-002 — `<NOMBRE_DE_UNIDAD_BACKEND_O_DATA>`

```screen
id: SCR-002
slug: "<slug-estable>"
kind: backend
platforms: [all]
route: null
order: 20
after: [SCR-FOUNDATION-SCHEMA]
applies: [APP-002, DATA-002, ERR-002]
design_ref: null
acceptance:
  - "Cuando se invoca el caso con entrada válida, el sistema deberá persistir el resultado esperado."
  - "Cuando la entrada es inválida, el sistema deberá rechazarla con error controlado y sin efectos parciales."
verify:
  tests:
    - "<COMANDO_TEST_BACKEND>"
  commands:
    - "<COMANDO_LOGS_BACKEND>"
  ui_states: []
  data_check:
    db_query: "<QUERY_REAL>"
    expect: "El estado persistido cumple DATA-002."
  evidence_required:
    - test_output
    - db_snapshot
    - backend_log
```

## 4. Checklist antes de `/init-build`

- [ ] Cada sección tiene un único `id` `SCR-*`.
- [ ] `order` define una secuencia clara.
- [ ] `after` solo referencia pantallas o foundations existentes.
- [ ] `applies` solo referencia IDs existentes.
- [ ] Cada pantalla UI declara cómo verificar web, móvil o ambas si aplica.
- [ ] Cada pantalla UI incluye estados `loading`, `empty`, `error`, `success`, salvo justificación.
- [ ] Cada pantalla tiene criterios de aceptación observables.
- [ ] Cada pantalla tiene `data_check` o justificación de por qué no aplica.
- [ ] Cada pantalla con datos tiene `data_engine` (almacén canónico, pipeline, single_value_contract).
- [ ] Cada foundation tiene evidencias verificables.
- [ ] Si el producto tiene más de una pantalla UI, existe `SCR-FOUNDATION-SHELL`, toda pantalla UI lo lista en `after`, y `blueprint/logic/shell.md` define shell/navegación/componentes/rutas (`UI-SHELL-*`).
- [ ] Si un `ENG-*`/`PIPE-*` es consumido por más de una pantalla, existe su unidad `SCR-FOUNDATION-ENGINE-*`/`SCR-FOUNDATION-PIPELINE-*`, y cada pantalla consumidora lo lista en `after`.
- [ ] Cada `SCR-FOUNDATION-ENGINE-*`/`SCR-FOUNDATION-PIPELINE-*` tiene un consumidor real (`SCR-WALKING-SKELETON-*` o una unidad `kind: ui`/`kind: backend` delgada) programado a pocos números de `order` de distancia — nunca aplazado detrás de más foundations. Un cimiento que nada del plan ejercita no se prueba hasta que ya hay diez unidades encima.
