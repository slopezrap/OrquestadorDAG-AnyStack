---
name: arch-review
description: "Architecture gate at t=0: judge the blueprint DOCUMENTS before any code exists — architectural fit, data model, identity/tenancy, engine decomposition, pipeline guarantees, dominant failure mode. Reports and routes; a blocker becomes a SCR-FOUNDATION-* unit, never a wall."
argument-hint: [--report-only]
disable-model-invocation: true
model: inherit
effort: xhigh
---

# /arch-review

Run inline in the current main session. You are `orchestrator-flow`: the single writer. This is the architecture gate one layer BEFORE building starts — the mirror of `/audit-motores`: that gate judges code already built behind `verified`/`accepted` screens; this one judges the blueprint DOCUMENTS at t=0, when changing them is free. The family rule is literal: **`research-*` owns the ABSENCE, `arch-*` owns the ERROR.** A field not declared, or equal to its template default, is `n/a` — never a blocker.

Arguments: `$ARGUMENTS`

## When to run

**Automatically:** inside `/init-build`, after the COMPILE phase and before `features.json` is written — no project is born without it (`validate-state.py --init-gate`, invoked only by `/init-build`, enforces presence of the verdict). **From `/reslice`:** it relaunches when the stored `architecture_hash` differs from the current one (obtained with `python3 .orchestrator/scripts/validate-state.py --arch-hash`), before new state is written. **Manually:** any time on demand; `--report-only` produces the report and nothing else.

## Flow

1. Read `blueprint/PRODUCT.md`, `blueprint/SCREENS.md`, `blueprint/logic/*.md` and `.claude/rules/constitution.md`. Run `python3 .orchestrator/scripts/lint-blueprint.py --decidedness --json` to obtain `undecided_fields[]` — every scalar identical to its `blueprint-templates/` default is ABSENCE, not a decision. Do not review an undecided blueprint: the workflow fails LOUD before the fan-out (any unresolved `<PLACEHOLDER>` inside a judged ```logic/```screen block, an empty unit inventory, or a lens whose entire subject sits in `undecided_fields[]`) and writes no status — "the blueprint is not decided yet; fill it in before reviewing the architecture".
2. **Always launch the `arch-review` workflow** (mandatory, not a preference) — the file is `.claude/workflows/arch-review.js`; there is no workflow called `architecture-review`, and `audit-architecture` is the different, cross-product gate behind `/audit-motores`: a read-only loader resolves the blueprint from disk (the COMPILE digest arrives only as a hint), then all **6** `arch-*` lenses run in parallel — `arch-fit`, `arch-data-model`, `arch-identity`, `arch-engines`, `arch-pipelines`, `arch-risk` — and `arch-synthesizer` reduces them into one digest. Only if the Workflow capability is genuinely unavailable, run the same full lens set sequentially and record `inline-fallback`; never as a shortcut. A lens that returns nothing gets one bounded retry; if it still fails, run that lens inline yourself. `failed_lenses[]` non-empty ⇒ no terminal status is written and `--init-gate` fails with an explicit message.
3. **Blocker discipline.** A finding is a blocker ONLY if it is a one-way door AND carries `retrofit_cost` naming WHAT would have to be rewritten later; without `retrofit_cost` it downgrades to `major` and only reports. Every finding cites `doc_ref` (file + ID). Global cap: **3 blockers per run, 1 on a new project's first run**, ranked by `retrofit_cost`. A finding whose only support is an `undecided_fields[]` entry is not a finding — the synthesizer discards it and reports "N fields undecided" instead.
4. Consolidate (you are the writer) into `.orchestrator-state/evidence/APP-INTEGRATION/reports/arch-review.md`: scope, coverage per lens, `undecided_fields[]`, `findings[]` (severity, reversibility, `retrofit_cost`, `doc_refs`, `conditional` when downstream of an `arch-fit` blocker), `open_blockers[]`, `proposed_foundations[]`, `cross_cutting[]`, `recommendations[]`, `failed_lenses[]` and `unmerged[]`. Real documents, real citations only; a lens that could not run is reported in `failed_lenses[]`, never invented.
5. **Route every blocker through one of THREE human exits — none silent, no `--force`:**
   - **(a) FOUNDATION (primary exit):** the blocker becomes a `SCR-FOUNDATION-*` unit that you write into `blueprint/SCREENS.md` (with `after[]` and `applies[]`), record in `emitted_foundations[]`, and the blocker closes — the gate generates work, it does not raise a wall. Then `python3 .orchestrator/scripts/lint-blueprint.py`; inside `/init-build`, re-derive the unit inventory, `order` and `after[]` before state is written.
   - **(b) `accepted_with_risk`:** the trade-off is explicitly accepted — by the human, or by the arch-review risk policy in `.claude/rules/autonomy.md` when the blocker sits below its ceiling AND is reversible AND declares a low `retrofit_cost`. Record it as a `DEC-*` in `blueprint/DECISIONS.md` (`decided_by` a person or `auto:arch-review-risk-policy`, the why, the rejected alternative, a `trip_wire`, `written_to` the blueprint file that absorbs the trade-off plus its `written_to_sha256`), and `accepted_risks[]` references that `DEC-*`. Above the ceiling it waits for a human, always: accepting a high-severity architectural risk is exactly the decision that is cheap now and ruinous later, which is why this gate runs at t=0 at all. Exit (a) is preferred whenever the blocker can take it — it generates work instead of accepting a risk.
   - **(c) `deferred` with trip-wire:** the honest "I don't know yet"; the finding names the `DATA-*`/`ENG-*`/`PIPE-*` whose change reopens it, and the `architecture_hash` re-trigger in `/reslice` raises it again.
   A genuine product decision underneath a finding → CLARIFY with the human first; a finding against an already-compiled or `accepted` contract → recommend `/reslice`, never a silent patch.
6. Write `meta.architecture_review` into `.orchestrator-state/features.json` (never under `--report-only`): `{ status: clear|accepted_with_risk|deferred, ran_at, mode, lenses[], failed_lenses[], architecture_hash, report_sha256, undecided_fields_count, open_blockers[], accepted_risks[], deferred[], emitted_foundations[] }`. A terminal `status` requires `open_blockers[]` empty and `failed_lenses[]` empty; `report_sha256` is the on-disk counterproof of the report you just wrote.
7. Append an `ARCH_REVIEW` entry to `.orchestrator-state/progress.md`, push the checkpoint (`bash .orchestrator/scripts/phase-push.sh "ARCH_REVIEW" "APP-INTEGRATION"`), and print the verdict, emitted foundations, accepted risks, deferrals with their trip-wires, and the report path.

## Hard rules

- `research-*` owns the ABSENCE, `arch-*` owns the ERROR. A field not declared or equal to its template default is `n/a` — forbidden `pass` and forbidden `blocker` on it. All six lenses share one verdict vocabulary: `pass | fail | n/a` (the review's own terminal status — `clear`/`accepted_with_risk`/`deferred` — is a different axis and lives only in `meta.architecture_review`).
- `arch-*` findings NEVER enter the required `phase_runs[]` lens sets checked by `validate-state.py`, and this skill adds no required check to any `result.json`. The architecture review gates the project's birth, not any unit's evidence.
- This skill never moves any unit's status: not to `ready`, not to `blocked`, not out of anything. The STATE GATE and `/accept` remain the only anchors.
- `--report-only` NEVER writes `meta.architecture_review`.
- The lenses write nothing (`tools: Read, Grep, Glob` in their frontmatter — the synthesizer included): they propose; `orchestrator-flow` writes the report, `meta.architecture_review`, and every `SCREENS.md`/`DECISIONS.md` write-back under the constitution's write-back discipline.
- The real blocking is executed by `validate-state.py --init-gate`, which only `/init-build` invokes; the plain gate validates `meta.architecture_review` only when it exists, so legacy states without the key keep passing.
- No blocker without `retrofit_cost`; no finding without `doc_ref`; no status written while `failed_lenses[]` is non-empty.
