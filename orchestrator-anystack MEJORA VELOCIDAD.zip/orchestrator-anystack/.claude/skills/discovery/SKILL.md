---
name: discovery
description: "Universal intake gate at t=0: walk the discovery checklist (product, data, architecture, stack, infra, ux) over the blueprint BEFORE anything is compiled — every item gets an explicit disposition (already answered / default filled / one batched question round / not applicable), the answers are written into blueprint/**, stack.md and DECISIONS.md, and nothing is left in the inkwell."
argument-hint: [--report-only]
disable-model-invocation: true
model: inherit
effort: xhigh
---

# /discovery

Run inline in the current main session. You are `orchestrator-flow`: the single writer. This is the intake gate one layer BEFORE `/arch-review`: that gate judges whether the declared design is WRONG; this one makes sure the universal questions get DECLARED at all. The family rule is literal: **`discovery-*` owns the UNASKED, `research-*` owns the ABSENCE, `arch-*` owns the ERROR.** An empty or underspecified blueprint is the normal input here — this gate interrogates silence instead of refusing it.

Arguments: `$ARGUMENTS`

## When to run

**Automatically:** inside `/init-build`, after the preflight `lint-blueprint.py` and BEFORE the COMPILE fan-out — no project is born without it (`validate-state.py --init-gate`, invoked only by `/init-build`, enforces presence of `meta.discovery`). **Manually:** any time on demand — after growing the checklist, or to re-audit a mature blueprint; `--report-only` produces the report and nothing else.

## Flow

1. Read `.orchestrator/templates/discovery-checklist.md` (the single source of the question bank — its `checklist_version` goes into the machine record) and skim `blueprint/**` to build a short hint of what already exists.
2. **Always launch the `discovery` workflow** (mandatory, not a preference): all **6** `discovery-*` lenses in parallel — `discovery-product`, `discovery-data`, `discovery-architecture`, `discovery-stack`, `discovery-infra`, `discovery-ux` — then `discovery-synthesizer` reduces them into one digest. Only if the Workflow capability is genuinely unavailable, run the same full lens set sequentially and record `inline-fallback`; never as a shortcut. A lens that returns nothing gets one bounded retry; if it still fails, run that lens inline yourself. `failed_lenses[]` non-empty ⇒ no `meta.discovery` is written and `--init-gate` fails with an explicit message.
3. **Completeness discipline.** The digest's `missing_ids[]` lists checklist items no lens returned. Resolve every one yourself (re-run the owning lens once, then walk the leftovers inline) — an item without a disposition is exactly the forgotten question this gate exists to prevent. `meta.discovery.unresolved[]` must be empty; there is no third option.
4. **One batched CLARIFY round.** Ask the digest's `questions[]` in ONE round, grouped by category, each with its options and the recommended choice first (AskUserQuestion when available). The human may answer, pick the recommendation, or say "later" — `deferred`: record an open `DEC-*` naming what was postponed and what reopens it. Decide yourself whether any `overflow_questions[]` are worth asking; otherwise their recommended defaults become fills. Never re-ask an item the digest marked `answered`.
5. **Write-backs (you are the writer).** Execute `write_plan[]` under the constitution's write-back discipline: fills and answers go to their routed targets (`blueprint/PRODUCT.md`, `SCREENS.md`, `logic/*.md`, `design/tokens.css`, and deployment/infra + stack choices into `.claude/policy/stack-infra.md`); every decision the round took gets a `DEC-*` in `blueprint/DECISIONS.md` (`decided_by` a person, or `auto:<rule>` when `.claude/rules/autonomy.md` answered it — then also the rejected alternative and a `trip_wire`; Tier-3 items are never closed this way and stay asked), the why, `written_to`). Then `python3 .orchestrator/scripts/lint-blueprint.py` — the blueprint must stay referentially intact. If a write-back changes an already-compiled or `accepted` contract (manual re-runs on a mature project), stop and route through `/reslice`; never patch silently.
6. Consolidate into `.orchestrator-state/evidence/APP-INTEGRATION/reports/discovery.md`: the per-item disposition table (all of them, including `n/a` and `covered_by_orchestrator` with their reasons), the questions asked with the answers given, the fills applied with their targets, deferrals, `flags[]`, and `failed_lenses[]`/`unmerged[]`. Real citations only.
7. Write `meta.discovery` into `.orchestrator-state/features.json` (never under `--report-only`; on the first `/init-build` run, before features.json exists, hold the record and write it together with the compiled state): `{ status: "complete", ran_at, mode, lenses[], failed_lenses[], checklist_version, items_total, dispositions: {answered, filled, asked, na, deferred}, unresolved: [], report_sha256 }`. The counts must sum to `items_total`; `report_sha256` seals the record against the report on disk.
8. Append a `DISCOVERY` entry to `.orchestrator-state/progress.md`, push the checkpoint (`bash .orchestrator/scripts/phase-push.sh "DISCOVERY" "APP-INTEGRATION"`), and print: items answered/filled/asked/deferred/n-a, the files written, and the report path.

## Hard rules

- `discovery-*` owns the UNASKED. This gate never judges a declared design (that is `arch-*`) and never audits per-screen completeness (that is `research-*`); overlap in subject is fine, overlap in verdict is not.
- Every checklist item ends with exactly one disposition; `unresolved[]` empty is a precondition for writing `meta.discovery`. Fabricating a disposition for an item no lens walked is inventing evidence and is forbidden.
- Never re-ask what `blueprint/**`, `ORIGINAL.md` or a `DEC-*` already answers — cite it. A default that encodes a business choice is asked, never assumed; every `ask` carries a recommended option.
- The lenses and the synthesizer write nothing (`tools: Read, Grep, Glob` in their frontmatter): they propose; you write every fill, every `DEC-*`, the report and `meta.discovery` under the constitution's write-back discipline.
- `discovery-*` results NEVER enter `phase_runs[]` and this skill adds no required check to any `result.json` — it gates the project's birth, not any unit's evidence. It never moves any unit's status.
- `--report-only` NEVER writes `meta.discovery` and applies no write-backs.
- The real blocking is executed by `validate-state.py --init-gate`, which only `/init-build` invokes; the plain gate validates `meta.discovery` only when it exists, so legacy states without the key keep passing.
