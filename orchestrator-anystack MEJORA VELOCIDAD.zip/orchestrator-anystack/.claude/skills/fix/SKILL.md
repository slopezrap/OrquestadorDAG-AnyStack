---
name: fix
description: "Prompt-driven maintenance: take a free-form request (a bug seen while testing, a small improvement) and run the full screen pipeline on the affected unit(s) — triage, context (blueprint + EXPLORE fan-out), repair, re-VERIFY, re-VALIDATE, review — autonomously, stopping at the /accept human gate."
argument-hint: <free-form-prompt> [--report-only]
disable-model-invocation: true
model: inherit
effort: xhigh
---

# /fix

Run inline in the current main session. This command may write product code and orchestrator state. Do not use `context: fork` or call `Agent(orchestrator-flow)`.

Arguments: `$ARGUMENTS`

Use when screens are already built (`verified`/`accepted`) and manual testing surfaces a bug, or when the human wants a small targeted change — described in natural language, not as a unit ID. The prompt is the input; this skill finds the owning unit(s) and runs the same quality machinery `/next-pantalla` uses, scoped to the request.

Default mode repairs. With `--report-only`, stop after step 2 with the triage report and touch nothing.

**Autonomy.** This skill runs END-TO-END in one invocation — triage, context, repair, full re-proof, close — with no intermediate confirmations. It pauses only for: (a) one precise CLARIFY when product intent is genuinely ambiguous (*Think first, then ask*); (b) `blocked` at the iteration cap or on a missing runtime. It always STOPS at the human gate: a reopened unit ends back at `verified` with `Next: /accept <ID>` printed — it never accepts, and never starts unrelated work.

## 0. Rehydrate

1. Read `CLAUDE.md`, `.claude/rules/*.md`, `.orchestrator-state/spec.md`, `.orchestrator-state/progress.md` and `.orchestrator-state/features.json`; require `initialized:true`.
2. Run `python3 .orchestrator/scripts/validate-state.py`. If the state is already broken, fix the state problem first or stop and report — never build a fix on a red gate.

## 1. Triage the prompt into a fix contract

The prompt is free text; the fix contract is not. Extract:

- **Symptom/goal**: what is wrong or desired, where it was observed (screen, route, platform), expected vs observed behavior.
- **Owners**: map the request to its owning unit(s) by searching `features.json` (titles, slugs, routes, `applies[]`), `blueprint/**`, `evidence/<ID>/result.json` (`source_manifest` names the implementation files) and the code. Every fix belongs to a unit; "the app" is not a unit.
- **Classification** — exactly one per request:
  - `defect` — behavior contradicts the blueprint/acceptance as written. The contract is right; the code is wrong.
  - `product_change` — the request changes or extends product intent. The contract itself must change.
  - `tech_improvement` — no product-visible change (refactor, performance, robustness) within the existing contract.

Apply *Think first, then ask*: resolve ambiguity from blueprint/`ORIGINAL.md`/`DECISIONS.md`/code first; if the classification or the owner is still genuinely ambiguous, ask the human ONE precise question. Never guess product intent.

## 2. Route by classification and status

**`product_change`** → the blueprint absorbs the truth FIRST (single-writer write-back): write it into its layer, record the `DEC-*` (decided by the human whose prompt this is), run `python3 .orchestrator/scripts/lint-blueprint.py`. Then:
- if it changes an already-compiled or `accepted` contract → stop and hand off: `Next: /reslice "<reason>"` — never patch state silently;
- if it only affects not-yet-built units → the write-back IS the fix; report and stop.

**`defect` / `tech_improvement`** → branch on the owning unit's `status`:

- `building` → this is a debugger pass of the active `/next-pantalla` (§6): repair, increment `checkpoint.iteration`, re-run the affected phases.
- `verified` → use the reopen protocol (same as `/review-pantalla`): require no other unit `building`; set `status:"building"`, `passes:false`, `checkpoint:{"phase":"DEVELOP","iteration":<previous+1>}` and `total_repair_passes:<previous total_repair_passes, 0 when absent> + 1` — the LIFETIME counter `/next-pantalla` §7 never clears (the gate rejects `iteration > 3` per episode and `total_repair_passes > 12` across the unit's whole life; at either cap set `blocked` instead); write the failing check and `failures[]` into `result.json`; append `REOPENED <ID> (fix)` to progress; run `validate-state.py`. Then repair in THIS run — this skill owns the repair and the close (step 6), it does not hand off.
- `accepted` → **maintenance repair in place**. The status NEVER changes: reopening would strand `accepted` dependents (the gate requires an accepted unit's dependencies to be `accepted`), and `/accept` remains the only acceptance authority. The human's explicit `/fix` invocation is the authority to touch the code; the non-negotiable price is step 5 — full re-proof and a refreshed `source_manifest` before this run may end. Never leave an accepted unit with FAIL evidence or a stale manifest.
- `todo`/`ready` (not built yet) → do not build here: write the finding into the blueprint so `/next-pantalla` builds it right, then stop with `Next: /next-pantalla <ID>`.

Multiple owning units: process one at a time, smallest scope first; at most one unit reopened at any moment. A fix in shared/shell code belongs to the owning contract (`blueprint/logic/shell.md` inventory); each affected BUILT unit then gets its own step-5 re-proof pass.

## 3. Context — the expected behavior and the real code (before touching anything)

A repair without context reintroduces the bugs the pipeline already prevented. For each unit routed to repair:

1. **Blueprint side (expected behavior)** — read every layer the unit cites: its `SCREENS.md` block (acceptance, `data_engine`, `verify`), each ID in `applies[]` in its `logic/*.md`, and the relevant `DEC-*` entries. The expected behavior comes from these documents, never from memory or from the prompt alone. If the blueprint does not unambiguously define what SHOULD happen, that is a product gap: CLARIFY (one precise question) or reclassify as `product_change` — never repair toward a guessed expectation.
2. **Code side (EXPLORE fan-out)** — launch the `explore-fanout` workflow with `args: {screen_id: "<ID>"}` (mandatory, not a preference; `explore-scout` + all 8 `explore-*` lenses; `inline-fallback` only when Workflows are genuinely unavailable). Consume its `existing_files` (reuse/change — never reimplement what a sibling or foundation already provides), `duplication_risks`, `commands`, `block_signals` and `acceptance_rows`. Record the fresh EXPLORE entry in `result.json.phase_runs[]` like any other phase re-run.
3. **Plan** — from symptom to root cause to the SMALLEST vertical change, in layer order (`data/schema -> backend/API -> UI -> tests`). A `block_signal` follows *Think first, then ask*.

## 4. Repair

Wear the DEVELOP hats at senior level (architect + backend + frontend/mobile + DBA + data engineer + DevOps + security + QA). Discipline is identical to `/next-pantalla` §3:

- active-unit discipline — repair the diagnosed defect and necessary support, no scope creep into unrelated improvements;
- library coherence — reuse the existing stack, never introduce a competing dependency; record new ones in `stack.md`;
- no stubs, fake data, TODOs or mock paths; verification data flows through the unit's declared real generation path into the canonical store;
- blueprint write-back for anything the repair discovers (an error case, a state transition, a provider quirk): structural facts directly, product decisions via one precise CLARIFY; then `lint-blueprint.py`.

## 5. Re-prove (a fix without re-proof does not exist)

Re-run the quality phases for each repaired unit, full lens sets, recorded in `result.json.phase_runs[]` (update the phase's entry with the fresh run; `mode:"workflow"`, or `inline-fallback` only when Workflows are genuinely unavailable):

1. **VERIFY** — launch the `verify-fanout` workflow with `args: {screen_id: "<ID>"}` (the loader resolves an explicit id regardless of status — this is what makes maintenance on a non-`building` unit possible). All 10 `verify-*` lenses. Persist the digest's `expected_ui_values[]` verbatim into `result.json`.
2. **VALIDATE** — launch `validate-live` with `args: {screen_id: "<ID>"}` when the unit owns a UI surface or cites `ENG-*`/`PIPE-*`; skip only when it owns neither. Observed client values must derive from `expected_ui_values`; refresh `data_engine_assertions[]` with the observed literals when the fix touched the data path.
3. **REVIEW** — `Agent(pantalla-reviewer)` for one contractual verdict.
4. **Gates** — re-run `/verify-pipelines-data-ultracode <ID> --report-only` and `/production-code-review <ID> --report-only` by following `.claude/skills/verify-pipelines-data-ultracode/SKILL.md` and `.claude/skills/production-code-review/SKILL.md` inline (both are `disable-model-invocation: true` by design — `Read` the file and execute its protocol, never the `Skill` tool; see the inline-chaining rule in `constitution.md`). Report-only: their own status guards keep them read-only on `accepted`; the repair lives HERE. A FAIL from either keeps this fix open.
5. **Refresh `source_manifest`** — re-hash the unit's implementation files into `result.json.source_manifest`; the gate re-hashes and rejects stale evidence.

On any failure, loop repair → re-prove (steps 4→5). Maximum 3 iterations (tracked in `checkpoint.iteration` for `building`/`verified`; counted in the fix report for `accepted` in-place). At the cap:
- `building`/`verified` → `blocked` with `blocked_reason`, reproduction and next action;
- `accepted` in-place → REVERT the code changes (git) so the accepted PASS stays true of the code on disk, and report the failure with `Next: /reslice` or a human decision.

## 6. Evidence and close

Write `.orchestrator-state/evidence/<ID>/reports/fix-<slug>.md`: the prompt verbatim, the fix contract (owners, classification), files touched, phases re-run, iterations, and before/after proof. Merge a required check into `result.json`: id `CHK-<ID>-FIX-<slug>`, type `maintenance_fix`, artifact `reports/fix-<slug>.md`, `passed:true` only on a fresh PASS.

- Reopened (`verified` path): close exactly like `/next-pantalla` §7 — `status:"verified"` + `passes:true` in the same save, clear `checkpoint`, all §7 conditions hold.
- `accepted` in-place: `result.json` ends `verdict:"PASS"` with fresh artifacts and manifest; status untouched.

Then: append `FIX <ID> (<slug>) — <PASS|FAIL|BLOCKED>` to `progress.md`; run `python3 .orchestrator/scripts/validate-state.py --emit-status` (must pass) and `bash .orchestrator/scripts/validate-structure.sh`; push the checkpoint `bash .orchestrator/scripts/phase-push.sh "FIX" "<ID>"`.

Print:

```text
Fix: PASS|FAIL|BLOCKED|REPORT_ONLY
Units: <ID>=<status> ...
Report: .orchestrator-state/evidence/<ID>/reports/fix-<slug>.md
Next: /accept <ID> (reopened units) · /verify-app (when accepted screens of a completed journey were touched) · /reslice (contract changes)
```

Never move any unit to `accepted`.
