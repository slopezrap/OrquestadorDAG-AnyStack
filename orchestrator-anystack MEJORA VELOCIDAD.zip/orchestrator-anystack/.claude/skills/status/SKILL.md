---
name: status
description: Read-only summary of orchestrator state from disk.
disable-model-invocation: true
model: inherit
effort: xhigh
---

# /status

Run inline in the current main session. Read-only.

1. Read `.orchestrator-state/spec.md`, `.orchestrator-state/features.json` and `.orchestrator-state/progress.md`.
2. Run `python3 .orchestrator/scripts/validate-state.py --emit-status`; if it fails, show the exact failure. On success this also refreshes the machine-readable projections `.orchestrator-state/status.json` and `.orchestrator-state/evidence/index.json` (the stable read contract for dashboards and external surfaces).
3. Summarize counts by status, current `building` (with its `checkpoint.phase` when present), `verified` awaiting accept, next `ready`, blockers, data-engine coverage/gaps and last progress event.
3b. Read `.orchestrator-state/batch.json` when it exists (absent means no batch has ever run — say nothing). Report its `mode`, `status`, `stop_reason`, units built and blocked; under `--autonomous` also its `telemetry`.
   **Lead with `telemetry.units_left_for_human[]` when it is non-empty.** That is the human review queue — units that reached `verified` with real evidence but fall outside what `.claude/rules/autonomy.md` authorizes auto-accepting. It is the only part of an autonomous run that actually needs a person, and reporting it after a summary of ninety things that went fine is how it gets missed.
3c. Report `status.json.promotable_todo[]` whenever it is non-empty AND `next_ready` is null. That combination means units are promotable and nobody promoted them, so "nothing ready" must not be read as "project complete" — it is the one state in which the loop stops early and looks finished.
4. Recommend exactly one next command.
