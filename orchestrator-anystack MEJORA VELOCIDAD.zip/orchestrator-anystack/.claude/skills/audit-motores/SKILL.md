---
name: audit-motores
description: "Optional cross-architecture gate: audit the engines (ENG-*) and pipelines (PIPE-*) behind the already verified/accepted screens — module contracts, reuse vs re-implementation, blueprint drift, architecture debt. Turns architecture debt into SCR-FIX-* repair units; never changes an existing unit's status."
argument-hint: [ENG-ID|PIPE-ID|all]
disable-model-invocation: true
model: inherit
effort: xhigh
---

# /audit-motores

Run inline in the current main session. You are `orchestrator-flow`: the single writer. This is the anti-Frankenstein check one layer below `/verify-app` — per-screen VERIFY/VALIDATE proves each screen's slice of an engine or pipeline; this proves the engines and pipelines built screen by screen are still **one architecture**.

Arguments: `$ARGUMENTS`

## When to run

**Automatically:** `/accept` launches it when an acceptance completes a journey — the same trigger as `/verify-app` (see accept step 8): `/verify-app` crosses the seams the user walks, this one audits the engines and pipelines underneath them. **Manually:** any time on demand. Either way it needs at least one `verified`/`accepted` screen citing `ENG-*`/`PIPE-*`; otherwise it stops and says exactly which engines/pipelines have no shipped screen behind them yet.

## Flow

1. Read `.orchestrator-state/features.json`, `blueprint/logic/engine.md`, `blueprint/logic/pipeline.md` and `blueprint/logic/data.md` (the canonical-store contract the engines write through). Run `python3 .orchestrator/scripts/validate-state.py` first — do not audit a broken state.
2. **Always launch the `audit-architecture` workflow** (mandatory, not a preference): a read-only loader resolves from disk the `ENG-*`/`PIPE-*` actually implemented behind the screens already `verified`/`accepted` (`$ARGUMENTS` may pin one `ENG-ID`/`PIPE-ID`), then all **5** `audit-*` lenses run in parallel over that scope and `audit-synthesizer` reduces them into one digest. Only if the Workflow capability is genuinely unavailable, run the same full lens set sequentially and record `inline-fallback`; never as a shortcut.
3. Consolidate (you are the writer) into `.orchestrator-state/evidence/APP-INTEGRATION/reports/audit-motores.md`: the synthesizer's `findings_by_target[]` — per module/engine/pipeline, its two buckets, **blueprint write-back debt** (truth that must go back to `blueprint/**`) and **architecture debt** (debt that lives in the code) — each finding with severity, cited `ENG-*`/`PIPE-*`/`DATA-*`/`SCR-*` refs, file/paths and evidence, plus `cross_lens_contradictions[]`, `clarify_questions[]` and `unmerged[]`. Real code and real observations only; a lens that could not run is reported `n/a` with the reason, never invented.
4. **Route each finding to its owner. You never change an EXISTING unit's status here — but you do EMIT work:**
   - blueprint write-back debt that is structural/derivable → write it yourself into the file its ID family owns, then `python3 .orchestrator/scripts/lint-blueprint.py` and reflect it in `spec.md`;
   - **ARCHITECTURE DEBT → REPAIR UNIT (primary exit):** an engine implemented twice, a module built out of its `ENG-*` contract, a pipeline whose topology contradicts `pipeline.md`, a screen reading around the canonical store — becomes a `SCR-FIX-AUDIT-<nnn>` unit written into `blueprint/SCREENS.md` with `after[]` (the screens it touches), `applies[]` (the `ENG-*`/`PIPE-*`/`DATA-*` contract it must satisfy), `remediates[]` (the unit ids that drifted) and acceptance criteria taken verbatim from the finding. Record it in `emitted_fixes[]`, then `python3 .orchestrator/scripts/lint-blueprint.py`. The finding closes: **the gate generates work, it does not raise a wall** — the same exit `/arch-review` uses for its blockers.
   - the shared contract itself is wrong or outgrown (a write-back that touches an already-compiled or `accepted` contract) → recommend `/reslice`, never a silent patch;
   - a genuine product decision (which engine owns the rule, which pipeline owns the freshness SLA) → resolve it against `.claude/rules/autonomy.md`; CLARIFY with the human only when the policy does not cover it, and persist the answer in `blueprint/logic/engine.md` or `blueprint/logic/pipeline.md`.

   **Why emit instead of recommend.** "Reports and recommends" left architecture debt in a report that nothing downstream consumed. Unattended, nobody read it — so the one gate that can see the product as a single architecture produced findings that never became work. A repair unit re-enters the ordinary loop, earns the full evidence standard, and cannot be silently dropped.

   **This does not weaken the invariant below.** A `SCR-FIX-*` is a NEW unit, born `todo`; no existing unit's `status`, `passes` or evidence is touched. Reopening an `accepted` screen would strand its `accepted` dependents (the gate requires an accepted unit's dependencies to be accepted) — which is exactly why the exit is a new unit and why `constitution.md` routes accepted-code repair through `/fix` in place.

   **Idempotence is required, and it is not a judgement call.** Before emitting, compute a fingerprint for the finding — `sha256` over its sorted `remediates[]` + the `ENG-*`/`PIPE-*`/`DATA-*` refs it cites — and store it as `fix_fingerprint` in the unit's `screen` block and in `emitted_fixes[]`. Emit only when no existing `SCR-FIX-AUDIT-*` carries that fingerprint; otherwise update that unit and say so in the report.

   A fingerprint rather than "check whether it looks like the same finding" because this gate re-runs on every journey completion and WILL keep seeing the same debt until the repair lands. Two different wordings of one defect would each read as new, and each costs a full unit. Comparing prose is exactly the kind of judgement that drifts under repetition — the thing this repo does not leave to prose anywhere it can be computed.

   **TOPE POR EJECUCIÓN: 3 unidades, priorizadas por severidad.** Emite las 3 peores y deja el resto EN EL INFORME, nombrados, para la siguiente ejecución — que las volverá a ver, porque el defecto sigue ahí. Registra en `emitted_fixes[]` cuántas quedaron sin emitir.

   El tope existe porque sin él este gate es el mayor multiplicador de coste del sistema. Un primer pase sobre un producto ya construido encuentra con facilidad 10-15 defectos reales; a 45-60 subagentes por unidad, eso son 600-900 lanzamientos desde UNA invocación, y bajo `--autonomous` el bucle los recoge todos en la misma ronda sin que nadie mire por medio. `/arch-review` ya topa sus blockers a 3 por la misma razón. Un gate que puede multiplicar el coste del proyecto por sí solo no es un gate, es una fuga.

   Y el orden importa: emitir las 3 peores primero significa que si el presupuesto se agota, se gastó en lo que más dolía.
5. Write `meta.audit_motores` into `.orchestrator-state/features.json`: `{ ran_at, mode, lenses[], failed_lenses[], report_sha256, findings_total, emitted_fixes[], recommended_reslice[], clarify_open[] }`. `report_sha256` seals it to the report you just wrote; `emitted_fixes[]` is what makes the next run idempotent (step 4) and what lets `/build-loop --autonomous` tell a round that produced work from one that produced nothing. Then append an `AUDIT_MOTORES` entry to `.orchestrator-state/progress.md`, push the checkpoint (`bash .orchestrator/scripts/phase-push.sh "AUDIT_MOTORES" "APP-INTEGRATION"`), and print the report path plus the exact recommended next command.

## Hard rules

- Real code, real runtime artifacts, real observations — the evidence standard applies unchanged. The audit reads what was built; it never re-runs a screen's acceptance on its behalf.
- This skill never moves an EXISTING unit's lifecycle: not to `accepted`, not out of it, not into `building`. The STATE GATE and `/accept` remain the only anchors.
- It MAY give birth to a new `SCR-FIX-*` unit (step 4). That is not a lifecycle move: the new unit starts at `todo` like any other, and no existing unit's `status`, `passes` or evidence is touched. The distinction is load-bearing — reopening a `verified`/`accepted` screen from here would strand its `accepted` dependents, which is why the exit is a new unit and why accepted code is repaired in place by `/fix`.
- Its findings NEVER enter the required `phase_runs[]` lens sets checked by `validate-state.py`, and it adds no required check to any `result.json`. AUDIT is not a `/next-pantalla` phase: counting it would retroactively invalidate the evidence of every unit already `verified`.
- Write-backs are proposed here and written by `orchestrator-flow` under the constitution's write-back discipline — never by the lenses, never by the synthesizer, which propose only.
- Active-unit discipline does not apply here (this gate is cross-architecture by design), but write access stays limited to `.orchestrator-state/evidence/APP-INTEGRATION/**`, `progress.md`, `features.json`'s `meta.audit_motores`, the `blueprint/SCREENS.md` block of any `SCR-FIX-*` it emits, and the `blueprint/**` write-backs you decide to persist.
