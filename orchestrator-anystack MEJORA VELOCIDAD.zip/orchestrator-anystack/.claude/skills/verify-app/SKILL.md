---
name: verify-app
description: "Optional cross-screen gate: drive the completed journeys (JOUR-*) end-to-end across accepted screens in the real runtime — navigation seams, cross-screen value consistency, shell coherence. Turns concrete findings into SCR-FIX-* repair units; never changes an existing unit's status."
argument-hint: "[JOUR-ID|all] [--include-verified]"
disable-model-invocation: true
model: inherit
effort: xhigh
---

# /verify-app

Run inline in the current main session. You are `orchestrator-flow`: the single writer. This is the anti-Frankenstein seam check — per-screen VALIDATE proves each screen alone; this proves the screens work **together**.

Arguments: `$ARGUMENTS`

## When to run

**Automatically:** `/accept` launches it when an acceptance completes a journey (all its UI screens `accepted`) — see accept step 8. **Manually:** any time on demand, with the SAME criterion — a journey is runnable only when all its UI screens are `accepted`. A journey whose screens are merely `verified` has not passed the human gate: run it only with the explicit `--include-verified` flag, and then step 3's report MUST tag every such screen `(verified, not accepted)` and downgrade that journey's verdict to `provisional`. Otherwise it stops and says exactly which screens block which journeys.

## Flow

1. Read `.orchestrator-state/features.json`, `blueprint/logic/journey.md` and `blueprint/logic/shell.md`. Run `python3 .orchestrator/scripts/validate-state.py` first — do not drive a broken state.
2. **Always launch the `validate-journeys` workflow** (mandatory, not a preference): a read-only loader resolves the runnable journeys from disk (`$ARGUMENTS` may pin one `JOUR-ID`; `--include-verified` is passed to the workflow as `include_verified: true` — the loader defaults to `accepted`-only (the human gate) and this flag is the only way to widen it to `verified` screens; the workflow returns each journey's `provisional` flag and its `unaccepted_screens[]` so step 3 can label the report), then one `validate-journey` lens per journey drives the real runtime — navigation per `UI-SHELL-002`/`UI-SHELL-004`, same canonical value on every screen that shows it, shell coherence in motion, permission gates across hops — plus `validate-logs` once. Only if the Workflow capability is genuinely unavailable, run the same lenses sequentially and record `inline-fallback`; never as a shortcut.
3. Consolidate (you are the writer) into `.orchestrator-state/evidence/APP-INTEGRATION/reports/verify-app.md`: per journey — verdict, hops table, observed cross-screen literals, findings with `JOUR-*`/`UI-SHELL-*`/`SCR-*` refs and artifact paths. Real observations only; a journey that could not run is reported `n/a` with the reason, never invented; and a journey run under `--include-verified` is labelled `provisional (includes screens not yet accepted: <IDs>)`.
4. **Route each finding to its owner. You never change an EXISTING unit's status here — but you do EMIT work:**
   - **(a) REPAIR UNIT (primary exit):** a finding with a concrete, in-contract defect — a broken nav seam, a screen showing a value that disagrees with the canonical store, a shell element missing on one screen — becomes a `SCR-FIX-VERIFY-APP-<nnn>` unit that you write into `blueprint/SCREENS.md` with `after[]` (the screens it repairs), `applies[]` (the `JOUR-*`/`UI-SHELL-*`/`SCR-*` rules it must satisfy), `remediates[]` (the unit ids whose behaviour was wrong) and acceptance criteria taken verbatim from the finding. Record it in `emitted_fixes[]`, then run `python3 .orchestrator/scripts/lint-blueprint.py`. The finding closes: **the gate generates work, it does not raise a wall** — the same exit `/arch-review` already uses for its blockers.
   - the shared contract itself is wrong or outgrown → recommend `/reslice` (which propagates staleness to dependent screens);
   - a genuine product decision — a missing nav entry or component that no screen owns and the blueprint never decided — → resolve it against `.claude/rules/autonomy.md`; CLARIFY with the human only when the policy does not cover it, and persist the answer in `blueprint/logic/shell.md`.

   **Why emit instead of recommend.** "Reports and recommends" was a dead end: this gate produced findings that nothing downstream picked up, so the work existed only in a `.md` a human had to read and act on manually. Unattended, nobody ever read it. A repair unit is picked up by the ordinary loop like any other unit, gets the full pipeline and the full evidence standard, and cannot be silently dropped.

   **This does not weaken the invariant below.** Emitting a NEW unit is not moving an EXISTING one: `SCR-FIX-*` is born `todo`, no other unit's `status`, `passes` or evidence is touched, and reopening a `verified`/`accepted` screen is still not something this skill does. That distinction is the whole reason the exit is a new unit rather than a reopen — a reopen would strand `accepted` dependents, which is precisely why `constitution.md` repairs accepted code in place via `/fix` instead.

   **Idempotence is required, and it is not a judgement call.** Before emitting, compute a fingerprint for the finding — `sha256` over its sorted `remediates[]` + the `JOUR-*`/`UI-SHELL-*` refs it cites — and store it as `fix_fingerprint` in the unit's `screen` block and in `emitted_fixes[]`. Emit only when no existing `SCR-FIX-VERIFY-APP-*` carries that fingerprint; otherwise update that unit and say so in the report.

   A fingerprint rather than "check whether it looks like the same finding" because this gate re-runs on every journey completion and WILL keep seeing the same seam until the repair lands. Two different wordings of one defect would each read as new, and each costs a full unit. Comparing prose is exactly the kind of judgement that drifts under repetition — the thing this repo does not leave to prose anywhere it can be computed.

   **TOPE POR EJECUCIÓN: 3 unidades, priorizadas por severidad.** Emite las 3 peores y deja el resto EN EL INFORME, nombrados, para la siguiente ejecución — que las volverá a ver, porque el defecto sigue ahí. Registra en `emitted_fixes[]` cuántas quedaron sin emitir.

   El tope existe porque sin él este gate es el mayor multiplicador de coste del sistema. Un primer pase sobre un producto ya construido encuentra con facilidad 10-15 defectos reales; a 45-60 subagentes por unidad, eso son 600-900 lanzamientos desde UNA invocación, y bajo `--autonomous` el bucle los recoge todos en la misma ronda sin que nadie mire por medio. `/arch-review` ya topa sus blockers a 3 por la misma razón. Un gate que puede multiplicar el coste del proyecto por sí solo no es un gate, es una fuga.

   Y el orden importa: emitir las 3 peores primero significa que si el presupuesto se agota, se gastó en lo que más dolía.
5. Write `meta.verify_app` into `.orchestrator-state/features.json`: `{ ran_at, mode, lenses[], failed_lenses[], report_sha256, findings_total, emitted_fixes[], recommended_reslice[], clarify_open[] }`. `report_sha256` seals it to the report you just wrote; `emitted_fixes[]` is what makes the next run idempotent (step 4) and what lets `/build-loop --autonomous` tell a round that produced work from one that produced nothing. Then append a `VERIFY_APP` entry to `.orchestrator-state/progress.md`, push the checkpoint (`bash .orchestrator/scripts/phase-push.sh "VERIFY_APP" "APP-INTEGRATION"`), and print the report path plus the exact recommended next command.

## Hard rules

- Real runtime, real data (declared generation path), real observations — the evidence standard applies unchanged.
- This skill never moves an EXISTING unit's lifecycle: not to `accepted`, not out of it, not into `building`. The STATE GATE and `/accept` remain the only anchors.
- It MAY give birth to a new `SCR-FIX-*` unit (step 4). That is not a lifecycle move: the new unit starts at `todo` like any other, and no existing unit's `status`, `passes` or evidence is touched. The distinction is load-bearing — reopening a `verified`/`accepted` screen from here would strand its `accepted` dependents, which is why the exit is a new unit and why accepted code is repaired in place by `/fix`.
- Active-unit discipline does not apply here (this gate is cross-screen by design), but write access stays limited to `.orchestrator-state/evidence/APP-INTEGRATION/**`, `progress.md`, `features.json`'s `meta.verify_app` and the `blueprint/SCREENS.md` block of any `SCR-FIX-*` it emits.
