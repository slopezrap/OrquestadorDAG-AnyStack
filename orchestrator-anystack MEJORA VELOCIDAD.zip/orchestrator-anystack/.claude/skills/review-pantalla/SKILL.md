---
name: review-pantalla
description: "Manually review and optionally repair one UI screen against blueprint/design: required buttons, links, inputs, states, routes, permissions, copy, layout and live UX behavior."
argument-hint: <screen-id|slug|name> [--fix|--report-only]
disable-model-invocation: true
model: inherit
effort: xhigh
---

# /review-pantalla

Run inline in the current main session. Do not use `context: fork` or call `Agent(orchestrator-flow)`.

Arguments: `$ARGUMENTS`

Use after `/next-pantalla <ID>` and before `/accept <ID>` when you want to prove that the screen was created as it should be.

Default mode is report-only. Repair only when `$ARGUMENTS` contains `--fix`.

## 0. Rehydrate

1. Read `CLAUDE.md`, `.claude/rules/*.md`, `.orchestrator-state/spec.md`, `.orchestrator-state/progress.md` and `.orchestrator-state/features.json`.
2. Resolve the target by exact `SCR-*` ID first, then slug/title/name.
3. Require a UI surface from `kind`, `platforms`, route/deep link or `verify`. If not UI, stop with `NOT_APPLICABLE` and suggest `/verify-pipelines-data-ultracode <ID>` or `/production-code-review <ID>`.
4. Read the target title, routes, platforms, acceptance, `verify`, `applies[]`, source refs and evidence path.
5. Read referenced `blueprint/PRODUCT.md`, `blueprint/SCREENS.md`, relevant `blueprint/logic/*.md`, `design/` and `design/tokens.css` when present.
6. Run `python3 .orchestrator/scripts/validate-state.py`.

## Status guard (before any `--fix` edit and before writing any verdict)

Read the target's `status` from `.orchestrator-state/features.json` and branch:

- `accepted` -> run read-only even with `--fix`; recommend `/reslice` if the accepted contract must reopen. Never edit code under an accepted unit.
- `verified` -> its `result.json` is a PASS on the CURRENT code. A FAIL verdict or any `--fix` edit makes that evidence stale, and the STATE GATE rejects `verified` with `passes:false` and rejects a `verified` unit whose evidence verdict is not `PASS`. So do NOT write the FAIL or touch code first: reopen the unit through the protocol below, then fix. Never leave a failing or edited unit sitting at `verified`.
- `building` -> you are running as an auto-gate inside `/next-pantalla` §5.5, or the conductor already owns the unit. Do NOT reopen: record the failing check and continue; a fix here is a debugger pass (`/next-pantalla` §5.5 and §6 — increment `checkpoint.iteration`, re-run VERIFY, and VALIDATE when runtime behavior changed).
- any other status -> report-only.

### Reopen protocol (`verified` -> `building`)

Besides `/accept` and `/reslice`, this is the only legal exit from `verified`, and this skill may use it only in the two cases above (review FAIL, or a `--fix` repair). In order:

1. Check that no other unit is `building`: the STATE GATE allows at most one. If one is, stop, report the finding and hand it to the human.
2. In `features.json`: `status:"building"`, `passes:false`, `checkpoint:{"phase":"DEVELOP","iteration":<previous+1>}`. The gate rejects `iteration > 3`; at the cap set `blocked` with `blocked_reason`, reproduction and next action instead of reopening.
3. In `result.json`: `verdict:"FAIL"`, the failing check with `required:true, passed:false`, and the matching entry in `failures[]`.
4. Append `REOPENED <ID> (review-pantalla FAIL)` — or `(review-pantalla --fix)` when the reopen is for a repair — to `.orchestrator-state/progress.md`, run `python3 .orchestrator/scripts/validate-state.py` (it must pass in the reopened state) and stop with `Next: /next-pantalla <ID>`: its §6 debugger owns the repair and the re-VERIFY/re-VALIDATE.

Reopening drops the unit from the `verified_awaiting_accept` queue in `status.json`. That is intended: the PASS no longer describes the code on disk.

## 1. Build expected screen inventory

Create the inventory before opening the app:

```text
screen_id:
route/deeplink:
platforms:
expected regions:
expected controls:
  - name:
    type: button|link|input|tab|menu|gesture|other
    label/accessibility label:
    visible when:
    enabled when:
    action/navigation:
    acceptance refs:
expected states: loading, empty, error, success, permission/role variants
expected copy:
design refs:
```

Expected controls must come from blueprint, acceptance, journey/UI/permission/state/error/data logic or design refs. Do not add controls based on taste.

## 2. Inspect live UI

Run the `validate-live` workflow (or the `validate-{web,android,ios}` lens-agents) with the inventory; pick the runtime by surface:

- web -> Claude-in-Chrome / Chrome DevTools MCP / Playwright (fallback);
- mobile -> Android emulator+adb or iOS simulator+idb, plus the framework tooling the declared `Mobile framework` in `.claude/rules/stack.md` calls for;
- if the required runtime is absent, record the limitation and do not PASS.

Require real observations when possible: screenshots, DOM/widget tree or accessible labels, click/tap proof for each required control, route/navigation proof, frontend/browser/device logs, network/API evidence, and backend/DB evidence when visible data changes.


When the screen shows product data, require proof that each critical visible value comes from the selected unit's `data_engine` and canonical store value. A visually correct screen with local demo data fails.

## 3. Compare and optionally repair

Classify issues as `missing_control`, `wrong_label`, `wrong_state`, `wrong_action`, `wrong_permission`, `design_drift`, `data_drift` or `not_applicable`. Default to `FAIL` when a required control, state or action cannot be proven.


Classify `frontend_local_truth` when the UI uses constants, local JSON or mock responses instead of the canonical DB/API path. This is a blocking `data_drift` defect.

If `--fix` is absent, report only.

If `--fix` is present, apply the Status guard first, then repair only when the fix belongs to the selected unit, the expectation is clear, no new product decision/dependency is required and the fix can be verified now.

Allowed repairs: add missing declared controls; correct labels/accessibility; wire declared actions; implement declared states; fix role/permission visibility; align layout/tokens with referenced design; add focused checks. Maximum 3 repair iterations, rerunning the relevant validate-* lens after each repair.

## 4. Evidence

Create or update:

```text
.orchestrator-state/evidence/<ID>/reports/review-pantalla.md
.orchestrator-state/evidence/<ID>/screenshots/*
.orchestrator-state/evidence/<ID>/logs/*
.orchestrator-state/evidence/<ID>/traces/*
```

Merge a required check into `.orchestrator-state/evidence/<ID>/result.json` with type `screen_contract_review` and artifact `reports/review-pantalla.md`.

If the review fails, record that check as `passed:false` and add the failures, then close per the Status guard:

- unit `building` -> leave `verdict:"FAIL"`, `passes:false` and the failing check for the conductor; it is a debugger pass, not a reopen.
- unit `verified` -> run the reopen protocol so the FAIL lands on a `building` unit. Never write `status:"verified"` with `passes:false` or with `verdict:"FAIL"`: the STATE GATE rejects both, so the run would invalidate the state it just wrote.

Either way, do not proceed to `/accept`.

## 5. Close

Run:

```bash
python3 .orchestrator/scripts/validate-state.py
bash .orchestrator/scripts/validate-structure.sh
```

Append `REVIEW_PANTALLA <ID>` to `.orchestrator-state/progress.md`.

Print:

```text
Review pantalla: PASS|FAIL|BLOCKED|NOT_APPLICABLE
Report: .orchestrator-state/evidence/<ID>/reports/review-pantalla.md
Next: /verify-pipelines-data-ultracode <ID> or /production-code-review <ID> or /accept <ID>
```

Never move a screen to `accepted`.
