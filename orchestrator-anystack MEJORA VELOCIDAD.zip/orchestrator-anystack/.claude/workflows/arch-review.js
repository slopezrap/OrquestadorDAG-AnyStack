export const meta = {
  name: 'arch-review',
  description: 'ARCHITECTURE gate at time zero (documents only, no code yet). Runs inside /init-build after COMPILE and BEFORE features.json is written, so the loader does NOT read features.json: a read-only loader inventories blueprint/ directly (PRODUCT, SCREENS, logic layers, ORIGINAL/DECISIONS presence, unresolved stack placeholders). Then fan out 6 arch-* lens-agents in parallel (fit, data-model, identity, engines, pipelines, risk) over the blueprint documents, and a read-only synthesis reducer collapses their findings into ONE digest for orchestrator-flow, which writes the report and meta.architecture_review. research-* owns the ABSENCE, arch-* owns the ERROR. Reports and recommends; never emits a lifecycle verdict, never touches state, and its lenses NEVER enter phase_runs[].',
  phases: [
    { title: 'Load', detail: 'read-only loader inventories blueprint/ from disk (no features.json yet at time zero)' },
    { title: 'Lenses', detail: 'arch-* agents in parallel (fit/data-model/identity/engines/pipelines/risk)' },
    { title: 'Synthesize', detail: 'read-only reducer → one digest (open_blockers, findings, proposed_foundations, recommendations)' },
  ],
}

// ---------------------------------------------------------------------------------------------
// `args` NORMALISATION — do not remove, and do not assume it is an object.
//
// MEASURED IN THIS BUILD: `typeof args === "string"`. The harness hands the script a JSON
// STRING, not the object the tool contract describes. Every `args.screen_id`, `args.root`,
// `args.changed_files`, `args.scope_to` and `args.fail_fast` was therefore `undefined` —
// reading a property off a String silently yields undefined rather than throwing.
//
// It hid for as long as it did because the failure was INVISIBLE and pointed the safe way:
// each workflow fell back to its disk-first default ("the single unit in `building`") and ran
// correctly on the right unit, so nothing broke. What silently stopped working was every
// OPTIONAL argument — the whole repair-scoping optimisation of next-pantalla §5 never once
// took effect, and `fail_fast` never once stopped a chain.
//
// Parse defensively: a non-JSON string is not an error to throw on, it is an argument to
// ignore — the loader still resolves the truth from disk. But say so out loud, because an
// argument that vanishes without a word is exactly what produced this bug.
// ---------------------------------------------------------------------------------------------
const ARGS = (() => {
  if (args === undefined || args === null) return {}
  if (typeof args === 'object') return args
  if (typeof args === 'string') {
    const raw = args.trim()
    if (!raw) return {}
    try {
      const parsed = JSON.parse(raw)
      return (parsed && typeof parsed === 'object') ? parsed : {}
    } catch (e) {
      log(`arch-review: args arrived as a string that is not JSON (${raw.slice(0, 80)}); ignoring it. Everything load-bearing is read from disk, so this degrades to a default run rather than a wrong one.`)
      return {}
    }
  }
  return {}
})()

// Disk-first context: do NOT depend on the caller passing args correctly. args is only an
// optional hint (e.g. the COMPILE digest summary); correctness comes from blueprint/ on disk.
// This workflow runs at TIME ZERO: features.json does not exist yet, so blueprint/ is the subject.
const hint = ARGS.hint ? String(ARGS.hint) : null
const root = ARGS.root ? String(ARGS.root) : '.'

const CTX_SCHEMA = {
  type: 'object', additionalProperties: false,
  required: ['ok', 'layers', 'original_md', 'decisions_md', 'stack_placeholders'],
  properties: {
    ok: { type: 'boolean' },
    error: { type: 'string' },
    layers: { type: 'array', items: { type: 'string' } },
    original_md: { type: 'boolean' },
    decisions_md: { type: 'boolean' },
    stack_placeholders: { type: 'array', items: { type: 'string' } },
  },
}

phase('Load')
const ctx = await agent(
  `CONTEXT LOADER (read-only; read ONLY from disk under ${root}; never guess or invent). This runs at TIME ZERO inside /init-build, after COMPILE and BEFORE features.json exists — do NOT read .orchestrator-state/features.json; blueprint/ is the subject.\n` +
  `1. Check that blueprint/PRODUCT.md and blueprint/SCREENS.md exist and are non-empty. If either is missing set ok=false and error naming the missing file; otherwise set ok=true.\n` +
  `2. List the blueprint layers present as layers[]: every blueprint/logic/*.md file that exists (e.g. "logic/data.md", "logic/engine.md"), plus "PRODUCT.md" and "SCREENS.md".\n` +
  `3. Set original_md / decisions_md to whether blueprint/ORIGINAL.md and blueprint/DECISIONS.md exist.\n` +
  `4. Read .claude/rules/stack.md and return every unresolved <COMMAND_*> placeholder token still present as stack_placeholders[] (empty array if all are resolved).\n` +
  `Write nothing. Return the structured object.`,
  { label: 'load-blueprint', phase: 'Load', schema: CTX_SCHEMA, agentType: 'context-loader', model: 'haiku', effort: 'low' }
)

// Fail LOUD instead of silently reviewing an absent blueprint (a clear verdict over zero
// documents is worse than no review). Same discipline as audit-architecture/validate-live.
if (!ctx || !ctx.ok || !Array.isArray(ctx.layers) || ctx.layers.length === 0) {
  throw new Error(`arch-review: nothing to review — ${ctx && ctx.error ? ctx.error : 'blueprint/PRODUCT.md or blueprint/SCREENS.md is missing'}. Fill the blueprint and re-run /init-build; this gate does not degrade to an empty blueprint.`)
}

// 6 document lenses at time zero. They judge the DESIGN while changing it is still free:
// store/architecture fit, data-model retrofit traps, tenancy/identity, engine decomposition,
// pipeline guarantee semantics, and the one adversarial lens (dominant failure mode).
const LENSES = [
  'arch-fit', 'arch-data-model', 'arch-identity',
  'arch-engines', 'arch-pipelines', 'arch-risk',
]

const inventoryJson = JSON.stringify({
  layers: ctx.layers,
  original_md: ctx.original_md,
  decisions_md: ctx.decisions_md,
  stack_placeholders: ctx.stack_placeholders || [],
})

phase('Lenses')
// One definition, used by the first pass AND the retry below: a retry that rebuilt the
// prompt could quietly ask a different question than the pass it is repeating.
const runLens = a => agent(
  `ARCHITECTURE lens ${a} over the WHOLE blueprint at TIME ZERO (documents only — no code exists yet). Repo root: ${root}. Judge the blueprint documents per your spec. research-* owns the ABSENCE, arch-* owns the ERROR: a field that is undeclared or identical to its template default is ABSENCE — return n/a for it, never a blocker. You REPORT: you do not repair, you do not write state, and your findings NEVER enter phase_runs[] or any result.json. Every finding cites a doc_ref (file + ID). A blocker is ONLY a one-way door and MUST carry retrofit_cost (what would have to be rewritten later); without retrofit_cost it is major at most. Also return undecided_fields[]: the fields you consulted that are still template defaults or undecided — a finding whose only support is an undecided field is not a finding.\n\nBlueprint inventory: ${inventoryJson}${hint ? `\n\nCOMPILE hint (context only, disk wins): ${hint}` : ''}`,
  { label: a, phase: 'Lenses', agentType: a }
).then(r => ({ lens: a, result: r }))

const results = await parallel(LENSES.map(a => () => runLens(a)))
const lenses = results.filter(r => r && r.result)

// RETRY-ONCE, like every other fan-out (see research-fanout.js for the full rationale): a lens
// that returned nothing gets ONE re-launch with the identical prompt before this workflow
// reports it missing. constitution.md requires this in EVERY fan-out workflow; arch-review.js
// was one of the two (with discovery.js) that never implemented it — the retry lived in prose only.
const missing = LENSES.filter(a => !lenses.some(l => l.lens === a))
const retried = missing.length
  ? (await parallel(missing.map(a => () => runLens(a)))).filter(r => r && r.result)
  : []
lenses.push(...retried)
const retried_lenses = retried.map(r => r.lens)
// Still nothing after its second chance: now it is a real absence, and it must surface in
// unmerged[] rather than vanish. The conductor blocks on these — it does not retry them again.
const failed_lenses = LENSES.filter(a => !lenses.some(l => l.lens === a))

const DIGEST = {
  type: 'object', additionalProperties: false,
  required: ['scope', 'undecided_fields_count', 'open_blockers', 'findings', 'recommendations', 'proposed_foundations', 'source_refs', 'failed_lenses', 'unmerged'],
  properties: {
    scope: { type: 'object', additionalProperties: true },
    undecided_fields_count: { type: 'number' },
    open_blockers: { type: 'array', items: { type: 'object', additionalProperties: true } },
    findings: { type: 'array', items: { type: 'object', additionalProperties: true } },
    recommendations: { type: 'array', items: { type: 'object', additionalProperties: true } },
    proposed_foundations: { type: 'array', items: { type: 'object', additionalProperties: true } },
    source_refs: { type: 'array', items: { type: 'object', additionalProperties: true } },
    failed_lenses: { type: 'array', items: { type: 'string' } },
    unmerged: { type: 'array', items: { type: 'object', additionalProperties: true } },
  },
}

phase('Synthesize')
const digest = await agent(
  `You are a READ-ONLY synthesis reducer for the ARCHITECTURE gate at time zero. Consolidate the per-lens results below into ONE digest. You WRITE NOTHING (no files, no state, no result.json) and you emit NO lifecycle verdict — this gate REPORTS; orchestrator-flow writes the report and meta.architecture_review. research-* owns the ABSENCE, arch-* owns the ERROR.\nRules: scope = {layers, lenses run} actually covered — copy from the loader inventory, never widen it. Discard every finding whose ONLY support is an undecided field (a value still equal to its template default) and report those as undecided_fields_count instead — "N fields undecided" is the useful message, not 200 findings over defaults. open_blockers[]: ONLY one-way doors carrying retrofit_cost (what would have to be rewritten later); a blocker without retrofit_cost is demoted to a major finding; cap at 3 globally, ranked by retrofit_cost; mark every finding downstream of an arch-fit blocker with conditional:true. findings[]: merge all lens findings, sort blocker→nit, dedupe by (ref, detail), keep each finding's lens, severity, retrofit_cost when present and doc_refs (cited files + IDs); a finding without a concrete file/ID behind it is dropped, not softened. proposed_foundations[]: the SCR-FOUNDATION-* units the lenses propose {id, title, rationale, refs} — proposals only; orchestrator-flow writes SCREENS.md. recommendations: proposals for the conductor {action, target, rationale, refs}, phrased as options (foundation, CLARIFY, accepted_with_risk, deferred) — you decide nothing. source_refs[]: the blueprint files + IDs cited across the findings, a navigable index so orchestrator-flow can re-open the source. If any lens output is missing/unparseable, list it in unmerged[] rather than guessing. Copy the lens names below into failed_lenses[] verbatim and also list each in unmerged[] with reason "no result returned" — a degraded review must be visible in the report, never silently smaller.\n\nLenses that returned NO result: ${JSON.stringify(failed_lenses)}\n\nBlueprint inventory: ${inventoryJson}\n\nLens results:\n${JSON.stringify(lenses, null, 1)}`,
  { label: 'synthesize', phase: 'Synthesize', schema: DIGEST, agentType: 'arch-synthesizer' }
)


// A synthesizer that returns nothing must not travel on as `{digest: undefined}`: the
// conductor would consume an absent digest as if the phase had produced one.
if (!digest) {
  throw new Error(`arch-review: the synthesis reducer returned no digest for the architecture review. Re-run the workflow; a phase that produced no digest must not be reported as if it had.`)
}

// orchestrator-flow consumes `digest` and writes the report + meta.architecture_review. This
// workflow is advisory at time zero: it reports, it does not block, it changes no state, and
// its lenses NEVER enter phase_runs[] or add checks to any result.json. `lenses` kept for traceability.
return { inventory: JSON.parse(inventoryJson), digest, lenses, failed_lenses, retried_lenses }
