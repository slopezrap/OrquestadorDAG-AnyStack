export const meta = {
  name: 'explore-fanout',
  description: 'Phase 1 EXPLORE for one unit. Disk-first: a read-only loader reads .orchestrator-state/features.json and returns the single building unit’s context (args is only an optional hint). Stage 1: explore-scout lists the relevant code files/areas by scope. Stage 2: one explore-* lens-agent per scope audits its files in parallel. Returns the build context to orchestrator-flow (single writer). Thin orchestration; each lens contract lives in its agent.',
  phases: [
    { title: 'Load', detail: 'read-only loader resolves the active unit + feature_excerpt from disk' },
    { title: 'Scout', detail: 'explore-scout discovers relevant files by scope' },
    { title: 'Lenses', detail: 'explore-{data,backend,ui,existing,tests,engine,pipeline,config} audit their files in parallel' },
  ],
}

// Disk-first context: do NOT depend on the caller passing args correctly. args is only an
// optional hint for WHICH unit/root; correctness comes from .orchestrator-state on disk.
const hint = (args && (args.screen_id || args.id)) ? String(args.screen_id || args.id) : null
const root = (args && args.root) ? String(args.root) : '.'

const CTX_SCHEMA = {
  type: 'object', additionalProperties: false,
  required: ['ok', 'screen_id', 'feature_excerpt'],
  properties: {
    ok: { type: 'boolean' },
    error: { type: 'string' },
    screen_id: { type: 'string' },
    slug: { type: 'string' },
    title: { type: 'string' },
    feature_excerpt: { type: 'object', additionalProperties: true },
  },
}

phase('Load')
const ctx = await agent(
  `CONTEXT LOADER (read-only; read ONLY from disk under ${root}; never guess or invent).\n` +
  `1. Read .orchestrator-state/features.json (the screens[] array is the runtime plan).\n` +
  `2. Select the active unit: ${hint ? `the screen whose id === "${hint}"` : 'the single screen whose status === "building" (validate-state.py guarantees at most one)'}. ` +
  `If exactly one matches set ok=true; otherwise set ok=false, screen_id="" and error="<n> screens matched: <ids>".\n` +
  `3. Return its id (as screen_id), slug, title and a compact feature_excerpt {kind, platforms, acceptance, applies, data_engine, architecture} lifted VERBATIM from the unit.\n` +
  `Write nothing. Return the structured object.`,
  { label: 'load-context', phase: 'Load', schema: CTX_SCHEMA, agentType: 'context-loader', model: 'haiku', effort: 'low' }
)

// Fail LOUD instead of silently degrading to '<unit>'/{} (the scout would map the repo for a
// screen that does not exist, and all eight lenses would audit against an empty feature).
if (!ctx || !ctx.ok || !ctx.screen_id) {
  throw new Error(`explore-fanout: could not load the active unit from disk — ${ctx && ctx.error ? ctx.error : 'no unit is building'}. Leave exactly one unit in status:"building" (or pass args.screen_id) and re-run; this workflow no longer degrades to <unit>/{}.`)
}

const sid = ctx.screen_id

// The hint is honoured, not merely consulted. Without this, a loader that resolves a DIFFERENT
// unit than the one asked for returns ok:true and the whole fan-out runs looking perfectly
// healthy — on the wrong screen. That failure is silent by construction: every lens reports on
// the unit it was handed, so the evidence is internally consistent and simply about something
// else. Cheap to close, and the alternative is spending full phases before anyone notices.
if (hint && sid !== hint) {
  throw new Error(`explore-fanout: asked for "${hint}" but the loader resolved "${sid}". Refusing to run the phase on a unit that was not requested — re-check args.screen_id and the status of both units.`)
}
const featureJson = JSON.stringify(ctx.feature_excerpt)

phase('Scout')
const scout = await agent(
  `EXPLORE scout for screen ${sid} (${ctx.title || ctx.slug || ''}). Repo root: ${root}. List the relevant code files/areas by scope (data, backend, ui, existing-code, tests, engine, pipeline, config) — one key per explore-* lens, emitted even when empty. Feature: ${featureJson}`,
  { label: 'explore-scout', phase: 'Scout', agentType: 'explore-scout' }
)

// Fail LOUD when the scout returns nothing: every lens depends on its file map,
// so degrading silently would make all eight lenses audit blind.
if (!scout) {
  throw new Error(`explore-fanout: explore-scout returned no result for ${sid}; re-run the workflow (the lenses cannot audit without the scout's file map).`)
}

phase('Lenses')
const SCOPES = [
  'explore-data', 'explore-backend', 'explore-ui', 'explore-existing', 'explore-tests',
  // explore-engine/-pipeline map engines and pipelines ALREADY in the code so screen N does not
  // re-implement what screen 3 built. explore-config closes the 'config' scope explore-scout has
  // always discovered but no lens ever received (dependency manifest, lockfile, CI, env, stack.md).
  'explore-engine', 'explore-pipeline', 'explore-config',
]
// One definition, shared by the first pass and the retry: a retry that rebuilt the prompt
// could quietly ask a different question than the pass it is repeating.
const runLens = a => agent(
  `EXPLORE lens ${a} for screen ${sid}. Repo root: ${root}. Audit the files explore-scout assigned to your scope and map the build per your spec.\n\n` +
  `SCOPE FIRST, THEN DEPTH. Read the scout output for YOUR scope before anything else. If it assigned you no files and the repo has nothing in your scope yet (a green-field screen, an area this project does not use), say so as covered:"n/a" with that reason and STOP — do not sweep the repo to confirm emptiness. If it assigned you files, audit them fully.\n` +
  `The one thing the shortcut never covers: a block_signal. If what you CAN see contradicts the feature or leaves an owner undeclared, that is a finding and it is yours to raise, however few files you were given.\n\n` +
  `Scout output:\n${typeof scout === 'string' ? scout : JSON.stringify(scout)}\n\nFeature: ${featureJson}`,
  { label: a, phase: 'Lenses', agentType: a }
).then(r => ({ lens: a, result: r }))

const lenses = await parallel(SCOPES.map(a => () => runLens(a)))

// orchestrator-flow consolidates the acceptance_map, binds the verification_route, and blocks on block_signals.
const ok = lenses.filter(r => r && r.result)

// RETRY-ONCE inside the workflow (see research-fanout.js for the full rationale): the rule
// lived in prose and executed nowhere, so a transient miss blocked a unit that a second
// attempt would have completed. Once, and reported — never retried again downstream.
const missing = SCOPES.filter(a => !ok.some(l => l.lens === a))
const retried = missing.length
  ? (await parallel(missing.map(a => () => runLens(a)))).filter(r => r && r.result)
  : []
ok.push(...retried)
const retried_lenses = retried.map(r => r.lens)
// A lens that returned nothing twice is reported by name, never dropped silently.
const failed_lenses = SCOPES.filter(a => !ok.some(l => l.lens === a))
return { screen_id: sid, scout, lenses: ok, failed_lenses, retried_lenses }
