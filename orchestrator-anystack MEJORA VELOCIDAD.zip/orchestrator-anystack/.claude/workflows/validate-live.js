export const meta = {
  name: 'validate-live',
  description: 'Phase 4 VALIDATE (live, human-like) for one unit. Disk-first: a read-only loader reads .orchestrator-state/features.json + the unit evidence and returns the single building unit’s context (args is only an optional hint). Then fan out one specialized lens-agent per owned runtime (validate-web / validate-android / validate-ios) plus validate-logs, in parallel. Consumes expected_ui_values from VERIFY evidence; returns observed client literals + verdicts to orchestrator-flow. Thin orchestration; each lens contract lives in its agent.',
  phases: [
    { title: 'Load', detail: 'read-only loader resolves the active unit + platforms + expected_ui_values from disk' },
    { title: 'Drive', detail: 'validate-* lens-agents per owned runtime, one at a time (they share one backend and one canonical store), with validate-logs last so it reads finished logs' },
  ],
}

// ---------------------------------------------------------------------------------------------
// `args` NORMALISATION — do not remove, and do not assume it is an object.
//
// MEASURED IN THIS BUILD: `typeof args === "string"`. The harness hands the script a JSON
// STRING, not the object the tool contract describes. Every `args.screen_id`, `args.root`,
// `args.changed_files`, `args.scope_to` and `args.fail_fast` was therefore `undefined` —
// reading a property off a String silently yields undefined rather than throwing.
//
// It hid for as long as it did because the failure was INVISIBLE and pointed the safe way:
// each workflow fell back to its disk-first default ("the single unit in `building`") and ran
// correctly on the right unit, so nothing broke. What silently stopped working was every
// OPTIONAL argument — the whole repair-scoping optimisation of next-pantalla §5 never once
// took effect, and `fail_fast` never once stopped a chain.
//
// Parse defensively: a non-JSON string is not an error to throw on, it is an argument to
// ignore — the loader still resolves the truth from disk. But say so out loud, because an
// argument that vanishes without a word is exactly what produced this bug.
// ---------------------------------------------------------------------------------------------
const ARGS = (() => {
  if (args === undefined || args === null) return {}
  if (typeof args === 'object') return args
  if (typeof args === 'string') {
    const raw = args.trim()
    if (!raw) return {}
    try {
      const parsed = JSON.parse(raw)
      return (parsed && typeof parsed === 'object') ? parsed : {}
    } catch (e) {
      log(`validate-live: args arrived as a string that is not JSON (${raw.slice(0, 80)}); ignoring it. Everything load-bearing is read from disk, so this degrades to a default run rather than a wrong one.`)
      return {}
    }
  }
  return {}
})()

// Disk-first context: do NOT depend on the caller passing args correctly. args is only an
// optional hint for WHICH unit/root; correctness comes from .orchestrator-state on disk.
const hint = (ARGS.screen_id || ARGS.id) ? String(ARGS.screen_id || ARGS.id) : null
const root = ARGS.root ? String(ARGS.root) : '.'

const CTX_SCHEMA = {
  type: 'object', additionalProperties: false,
  required: ['ok', 'screen_id', 'platforms', 'expected_ui_values', 'engine_refs', 'pipeline_refs'],
  properties: {
    ok: { type: 'boolean' },
    error: { type: 'string' },
    screen_id: { type: 'string' },
    slug: { type: 'string' },
    title: { type: 'string' },
    kind: { type: 'string' },
    platforms: { type: 'array', items: { type: 'string' } },
    route: { type: 'object', additionalProperties: true },
    acceptance: { type: 'array', items: {} },
    feature_excerpt: { type: 'object', additionalProperties: true },
    expected_ui_values: { type: 'array', items: { type: 'object', additionalProperties: true } },
    engine_refs: { type: 'array', items: { type: 'string' } },
    pipeline_refs: { type: 'array', items: { type: 'string' } },
  },
}

phase('Load')
const ctx = await agent(
  `CONTEXT LOADER (read-only; read ONLY from disk under ${root}; never guess or invent).\n` +
  `1. Read .orchestrator-state/features.json (the screens[] array is the runtime plan).\n` +
  `2. Select the active unit: ${hint ? `the screen whose id === "${hint}"` : 'the single screen whose status === "building" (validate-state.py guarantees at most one)'}. ` +
  `If exactly one matches set ok=true; otherwise set ok=false, screen_id="" and error="<n> screens matched: <ids>".\n` +
  `3. Return its id (as screen_id), slug, title, kind, platforms[] (verbatim from the unit), route, acceptance[], and a compact feature_excerpt {kind, platforms, acceptance, applies, data_engine, architecture, design_ref}.\n` +
  `4. Read .orchestrator-state/evidence/<screen_id>/result.json if it exists and lift expected_ui_values[] VERBATIM from its top-level expected_ui_values field (canonical shape: {db_key, permission_context, api_field_path, expected_visible_value, ui_field, transform?} — written by orchestrator-flow after VERIFY). Only if that field is absent, fall back to deriving rows from data_engine_assertions[] (map db_value->expected_visible_value, ui_value->ui_field context) and say so in the returned rows; if neither exists, return [].\n` +
  `5. Return engine_refs[] = every ENG-* and pipeline_refs[] = every PIPE-* the unit cites, collected from its applies[], its top-level engine_refs/pipeline_refs and its data_engine block. These decide whether the engine/pipeline runtimes must be driven too.\n` +
  `Write nothing. Return the structured object.`,
  { label: 'load-context', phase: 'Load', schema: CTX_SCHEMA, agentType: 'context-loader', model: 'haiku', effort: 'low' }
)

// Fail LOUD instead of silently degrading to '<unit>'/[] (the old bug that skipped android/ios).
if (!ctx || !ctx.ok || !ctx.screen_id) {
  throw new Error(`validate-live: could not load the active unit from disk — ${ctx && ctx.error ? ctx.error : 'no unit is building'}. Leave exactly one unit in status:"building" (or pass args.screen_id) and re-run; this workflow no longer degrades to <unit>/[].`)
}

const sid = ctx.screen_id

// The hint is honoured, not merely consulted. Without this, a loader that resolves a DIFFERENT
// unit than the one asked for returns ok:true and the whole fan-out runs looking perfectly
// healthy — on the wrong screen. That failure is silent by construction: every lens reports on
// the unit it was handed, so the evidence is internally consistent and simply about something
// else. Cheap to close, and the alternative is spending full phases before anyone notices.
if (hint && sid !== hint) {
  throw new Error(`validate-live: asked for "${hint}" but the loader resolved "${sid}". Refusing to run the phase on a unit that was not requested — re-check args.screen_id and the status of both units.`)
}
const plats = (Array.isArray(ctx.platforms) ? ctx.platforms : []).map(p => String(p).toLowerCase())
const expected = ctx.expected_ui_values || []
const engineRefs = Array.isArray(ctx.engine_refs) ? ctx.engine_refs : []
const pipelineRefs = Array.isArray(ctx.pipeline_refs) ? ctx.pipeline_refs : []

// VALIDATE is no longer UI-only. A unit qualifies for the live phase through EITHER an owned UI
// surface OR a declared ENG-*/PIPE-* contract — because an engine that is only verified statically
// never actually ran, and "it does what it should" cannot be proven by reading code.
if (plats.length === 0 && engineRefs.length === 0 && pipelineRefs.length === 0) {
  throw new Error(`validate-live: unit ${sid} owns no runtime on disk — no platforms[] (web/android/ios) and no ENG-*/PIPE-* contract. A UI unit must declare platforms[]; a unit with neither surface should skip VALIDATE entirely. Refusing to run a degraded validation.`)
}

// Select live lens-agents by the unit's owned runtimes; always inspect runtime logs.
// The SELECTION RULE is unchanged — validate-state.py still requires this exact conditional set in
// phase_runs[]. Only the SCHEDULING below changed.
const LENSES = []
if (plats.includes('web')) LENSES.push('validate-web')
if (plats.includes('android') || plats.includes('mobile')) LENSES.push('validate-android')
if (plats.includes('ios') || plats.includes('mobile')) LENSES.push('validate-ios')
if (engineRefs.length) LENSES.push('validate-engine')
if (pipelineRefs.length) LENSES.push('validate-pipeline')
LENSES.push('validate-logs')

// ---------------------------------------------------------------------------------------------
// ISOLATION — VALIDATE is decided SEPARATELY from VERIFY, and lands on the opposite answer.
//
// In verify-fanout the partition pays off: about half the lenses are read-only, so serializing the
// executing half keeps real parallelism. Here it does not. Every validate-* lens drives a live
// runtime by definition — that is what the phase is — so "serialize the ones that execute" is the
// same instruction as "serialize the phase". None of them is read-only in the frontmatter sense
// either: all seven omit `tools:` precisely so they can drive browsers/emulators and save their own
// artifacts. Applying the VERIFY rule mechanically here would produce a partition with an empty
// parallel half, which is a serial phase wearing a parallel shape.
//
// Could anything still run concurrently? Only if the lenses owned disjoint resources — and they do
// not. Web, Android and iOS drive different CLIENTS, but they exercise the SAME backend and write
// through to the SAME canonical store; that shared store is the whole point of the phase (proving
// the same canonical value reaches every client), so it is the one thing that must not be mutated
// by a neighbour mid-observation. Two clients writing at once is exactly the cross-contamination
// this change exists to remove.
//
// DECISION: serialize the phase, and accept the cost — it is wall clock, and it is bounded (one
// unit's owned runtimes, typically 2-3 lenses). What it buys is that a VALIDATE failure means the
// product is wrong. A phase where any failure might belong to the neighbour compels nothing, and a
// signal nobody must act on is worth less than no signal at all.
//
// ORDER IS PART OF THE FIX, not a detail: validate-logs runs LAST, after every driver. Its job is
// to read the logs the drivers produced, so running it alongside them had it reading a file that
// was still being written — half-flushed traces that look like missing evidence. Sequencing it
// after the drivers is a correctness gain the old parallel form could not express.
// ---------------------------------------------------------------------------------------------
const DRIVERS = LENSES.filter(a => a !== 'validate-logs')
const ORDERED = [...DRIVERS, ...LENSES.filter(a => a === 'validate-logs')]

phase('Drive')
// One definition, shared by the first pass and the retry: a retry that rebuilt the prompt
// could quietly ask a different question than the pass it is repeating.
const runLens = async a => {
  try {
    const r = await agent(
      `VALIDATE (live) lens ${a} for screen ${sid}. Repo root: ${root}. Drive the real runtime like a human per your spec; assert observed client value derives from expected_ui_values; never PASS without the live runtime.\nYou have SOLE ownership of the working tree, the running app and the test store for the duration of this call — nothing else is driving them CONCURRENTLY. But you are not necessarily first: lenses run one at a time, and an earlier one may already have written to the store. Do NOT reset it (the conductor does that once before the phase); resetting here would erase rows an earlier lens already cited as evidence. Instead SCOPE YOURSELF: act on identifiers you generate, assert on those, and conclude nothing from a global count — a total is not yours to interpret when a neighbour also writes.\n\nexpected_ui_values: ${JSON.stringify(expected)}\nroute: ${JSON.stringify(ctx.route || {})}\nengine_refs: ${JSON.stringify(engineRefs)}\npipeline_refs: ${JSON.stringify(pipelineRefs)}\nFeature: ${JSON.stringify(ctx.feature_excerpt || { kind: ctx.kind, platforms: ctx.platforms, acceptance: ctx.acceptance })}`,
      { label: a, phase: 'Drive', agentType: a }
    )
    return { lens: a, result: r }
  } catch (e) {
    // A thrown lens must surface in failed_lenses[] exactly as parallel() would have reported it,
    // never abort the phase and never vanish.
    return { lens: a, result: null, error: String(e && e.message ? e.message : e) }
  }
}

const runs = []
for (const a of ORDERED) {
  runs.push(await runLens(a))
}

// orchestrator-flow consolidates the live verdict + observed ui_value/platform_values.
const ok = runs.filter(r => r && r.result)

// RETRY-ONCE inside the workflow (see research-fanout.js for the full rationale).
// SERIALIZED, like the first pass and for the same reason: these lenses drive one app, one
// set of ports and one canonical store. Retrying them concurrently would produce failures
// that belong to the neighbour — the precise signal-destroying outcome the serialization
// exists to prevent, and it would arrive disguised as a repaired lens.
// Also the phase where a retry earns the most: a live runtime is the flakiest thing here,
// and a browser or emulator that missed its window is exactly a transient worth one retry.
// Retry in ORDERED order, not LENSES order, and force validate-logs to the end again.
//
// `validate-logs` runs last in the first pass for a stated reason: it must read FINISHED
// logs, not half-written ones. A naive retry breaks that. If a driver failed and the log
// lens succeeded, retrying only the driver leaves a log artifact on disk that was captured
// BEFORE the retried driver acted — and result.json would then claim "logs clean" about a
// state that no longer exists. That is fabricated evidence arriving through a repair, which
// is exactly what this phase exists to prevent.
//
// So: if any DRIVER is retried, validate-logs is re-run after it, whether or not it failed.
// Its first-pass result is discarded — not because it was wrong, but because it is now stale.
const missing = ORDERED.filter(a => !ok.some(l => l.lens === a))
const retriedDrivers = missing.filter(a => a !== 'validate-logs')
const retried_lenses = []
for (const a of retriedDrivers) {
  const r = await runLens(a)
  if (r && r.result) { ok.push(r); retried_lenses.push(a) }
}
const logsNeedsRerun = LENSES.includes('validate-logs')
  && (retriedDrivers.length > 0 || missing.includes('validate-logs'))
if (logsNeedsRerun) {
  const r = await runLens('validate-logs')
  if (r && r.result) {
    const stale = ok.findIndex(l => l.lens === 'validate-logs')
    if (stale >= 0) ok.splice(stale, 1)
    ok.push(r)
    retried_lenses.push('validate-logs')
  }
}
// A lens that returned nothing twice is reported by name, never dropped silently.
const failed_lenses = LENSES.filter(a => !ok.some(l => l.lens === a))
return { screen_id: sid, platforms: plats, lenses: ok, failed_lenses, retried_lenses, executed_in_order: ORDERED }
