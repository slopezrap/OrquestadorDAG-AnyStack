# Autonomy policy

This file answers, IN ADVANCE, the questions the orchestrator would otherwise stop and ask
in the middle of a run. It is to product decisions what `stack.md` is to commands: a
placeholder scaffold that `/init-build` resolves per project, read from disk instead of
reconstructed from a conversation.

It exists because the orchestrator had exactly one way to handle not knowing something —
stop and ask a human — and that is fine at a keyboard and useless overnight. What it lacked
was a way to *continue*: a decision it was authorized to take, recorded well enough to be
audited and reversed later.

**Precedence.** The blueprint always wins. This file only ever governs SILENCE.

```text
blueprint/**  >  blueprint/DECISIONS.md (DEC-*)  >  blueprint/ORIGINAL.md  >  autonomy.md
```

A default here that contradicts something a layer declares is not a conflict — it is
irrelevant, and applying it would be inventing product intent. When `lint-blueprint.py
--decidedness` says a field is still at its template default, the layer is SILENT and this
file may speak.

**What this file does NOT relax.** The evidence standard is untouched. A default is a
*decision*, never a *measurement*: it may be written to `blueprint/**` and `DECISIONS.md`
because someone authorized it in advance, and that is a different act from claiming
something about the world. Every negative claim — *it does not exist*, *the provider has no
such endpoint*, *I tried it and it failed* — still carries the burden in `constitution.md`
("The burden of proof is symmetric"): exact command, literal output, artifact path. Autonomy
buys the right to DECIDE without asking. It never buys the right to ASSERT without proving.

---

## Tiers — what may be decided without asking

Every unresolved question lands in exactly one tier. When in doubt between two, take the
more conservative: the cost of one unnecessary question is a minute, the cost of a wrong
Tier-1 call discovered ten screens later is a `/reslice`.

### Tier 1 — decide silently

Reversible, contained inside one layer, no external effect, no cost. Apply the default,
write it to its blueprint layer, note the source. No `DEC-*` needed — the write-back itself
is the record.

- A field with an obvious default listed under **Product defaults** below.
- A structural or derivable fact (a state transition the code already implies, an error case
  VERIFY surfaced, a naming convention consistent with existing screens).
- Anything a competent engineer on this project would answer the same way without asking.

### Tier 2 — decide, record a `DEC-*`, set a trip-wire

Genuinely a choice, but reversible and containable. Decide, then leave a trail that makes it
findable and undoable:

- write the decision into its layer;
- append a `DEC-*` to `blueprint/DECISIONS.md` with `decided_by: "auto:<rule>"` naming the
  rule here that authorized it, the alternative it rejected, and a `trip_wire`;
- the `trip_wire` is the observable condition that invalidates the decision — the `DATA-*`,
  `ENG-*` or `PIPE-*` whose change reopens it, or the assumption that would have to hold.

The trip-wire is the load-bearing part. A decision taken without a human present is
acceptable exactly to the degree that a human can later find it, understand why it was taken
and see what would falsify it. Without one, this file is just permission to guess.

### Tier 3 — never decide; stop and ask

Irreversible, externally visible, or expensive to unwind. Ask, and if the human is not there,
`block` the unit with the exact question. A batch that stops with one precise question is a
good outcome; a batch that guessed here is not.

- anything that spends real money, sends to a third party, or touches production data;
- security and privacy posture: what is authenticated, who may see what, what is logged,
  what is retained, anything touching personal data;
- destructive or irreversible operations (dropping data, rewriting history, deleting files);
- the product's core value proposition, pricing, or legal/compliance commitments;
- changing a contract an already-`accepted` unit relies on — that is a `/reslice`, never a
  maintenance decision;
- anything listed under **Sensitive areas** below.

---

## Product defaults (`AUTO-*`)

Tier-1 answers for the questions that come up on almost every project. Resolve these during
`/init-build` — a field still left in angle-bracket form here means the question is NOT pre-answered
and falls back to asking, which is the safe direction.

### AUTO-001 — Language and locale
Product copy language: `<LANGUAGE>` · locale `<LOCALE>` · timezone `<TIMEZONE>` ·
dates ISO-8601 in storage and transport, localized only at the client.

### AUTO-002 — Pagination and limits
Default page size `<PAGE_SIZE>`, max `<MAX_PAGE_SIZE>`. Every list endpoint paginates; an
unbounded list is a defect, not a default.

### AUTO-003 — Deletion
`<soft-delete | hard-delete>`. Soft delete keeps the row with a `deleted_at`; every read
path filters it. Applies to product data only — Tier 3 still governs anything destructive
in production.

### AUTO-004 — Errors at boundaries
Validate at the boundary, return structured errors (`code`, `message`, `details`), never
leak stack traces, provider payloads or secrets to a client. Unhandled server error → 500
with a correlation id, and the detail goes to logs only.

### AUTO-005 — Timestamps and audit
Every durable product record carries `created_at`/`updated_at` in UTC. Who-changed-what
auditing is NOT a default — it is a Tier-2 decision per resource.

### AUTO-006 — Identifiers
`<uuid | ulid | sequential>` for product records. Stable, never reused, never derived from
user input.

### AUTO-007 — Empty, loading and error states
Every screen that renders data declares all three. A screen missing them is incomplete, and
the default content is `<DEFAULT_EMPTY_COPY_CONVENTION>`.

### AUTO-008 — Sorting
Lists default to `<DEFAULT_SORT>` when the blueprint declares no order. Sort must be
deterministic — ties broken by the identifier — or pagination silently repeats rows.

### AUTO-009 — Dependency choice
Reuse what the project already uses for that concern (`stack.md`). Never introduce a
competing library for a solved one. A genuinely new concern with an obvious ecosystem
default is Tier 2; anything else is Tier 3. Record every new dependency in `stack.md`.

### AUTO-010 — Test data
Generated through the unit's declared real generation path into the canonical store, scoped
to identifiers the test itself created. Never fixtures at a client layer — that is an
evidence-standard rule, not a preference.

---

## Arch-review risk-acceptance policy

How `/arch-review` blockers resolve when no human is present. Its three exits are unchanged;
this only says which may be taken automatically.

- **(a) foundation unit** — ALWAYS automatic. It generates work rather than deciding
  anything, so there is nothing to authorize. This is the preferred exit for any blocker
  that can take it.
- **(b) `accepted_with_risk`** — automatic ONLY for a blocker whose severity is below
  `<AUTO_ACCEPT_RISK_CEILING>` AND which is reversible AND whose `retrofit_cost` is declared
  low. Record the `DEC-*` with `decided_by: "auto:arch-review-risk-policy"` and a trip-wire.
  Anything else waits for a human: accepting a high-severity architectural risk is precisely
  the decision that is cheap now and ruinous later, which is why `/arch-review` exists at
  t=0 at all.
- **(c) `deferred` with trip-wire** — automatic when the blocker's own trip-wire is
  well-formed (it names the `DATA-*`/`ENG-*`/`PIPE-*` whose change reopens it). A deferral
  without a trip-wire is not a deferral, it is forgetting.

A blocker sitting entirely on `undecided_fields[]` is not a blocker at all — it is silence,
owned by `research-*`. Resolve the silence first (this file, then CLARIFY) and re-judge.

---

## Auto-accept policy

What `/accept --auto` checks beyond the mechanical preconditions in `accept/SKILL.md`. Those
preconditions do not move: the gate still requires `verdict:"PASS"`, `passes:true`, complete
`phase_runs[]`, real artifacts, falsifiable `data_engine_assertions[]`, and both `CHK-*`
gate checks. **Auto-accept changes who presses the button, not what is checked.**

A unit auto-accepts when ALL hold:

1. `python3 .orchestrator/scripts/validate-state.py` passes.
2. `result.json.verdict == "PASS"`, `failures` empty, both §5.5 `CHK-*` present and passed.
3. Its `after[]` dependencies are all `accepted` (the gate enforces this anyway).
4. It touches no **sensitive area** below.
5. No advisory finding at or above `<AUTO_ACCEPT_SEVERITY_CEILING>` is open against it.

Otherwise it stays `verified` and goes on the human review queue — which is a normal,
healthy outcome, not a failure. A batch that builds nine units, auto-accepts seven and hands
you two worth looking at has done its job.

### Sensitive areas — never auto-accept

Units touching these always wait for a human, however green their evidence:

- authentication, authorization, session handling, or any `PERM-*` gate;
- payments, billing, or anything that moves money;
- personal data: collection, retention, export, deletion;
- irreversible user-facing actions (deletion, sending, publishing);
- the shared shell (`UI-SHELL-*`) — one mistake here propagates to every screen;
- schema migrations that drop or rewrite existing columns/data;
- `<PROJECT_SPECIFIC_SENSITIVE_AREA>`.

These overlap Tier 3 by intent, from the other end: Tier 3 is about what may be DECIDED,
this is about what may be DECLARED DONE. A unit can be built entirely from Tier-1 decisions
and still deserve human eyes before it ships.

---

## Autonomous-run budget

Defaults for `/build-loop --autonomous` when the invocation names none. Written down because
an unattended loop with no ceiling is not autonomy, it is an unbounded spend.

Measured cost, for calibration: a clean unit is roughly **45–60 subagent launches**; one that
exhausts the debugger cap is **120–160**. Multiply by the number of units before choosing.

- `max_units`: `<MAX_UNITS>`
- `max_subagents`: `<MAX_SUBAGENTS>`
- `max_wall_clock_minutes`: `<MAX_WALL_CLOCK_MINUTES>`
- `max_rounds_without_new_units`: 2

---

## Design tension worth revisiting

**Sensitive areas** (above) and **Tier 3** are two lists of dangerous things, written from
different angles — one by what must not be auto-accepted, one by what must not be
auto-decided. They overlap heavily and are deliberately kept separate: a single merged list
would have to serve both questions and would answer neither cleanly. If they drift apart in
practice, that is the signal to revisit — not a reason to merge them mechanically now.
