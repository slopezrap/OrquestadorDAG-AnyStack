# DECISIONS.md — decision ledger template

> Every product decision taken AFTER the blueprint was first written. Append-only.
>
> This file exists because the *what* of a decision survives (it gets written into a `logic/*.md` layer) but the *why* does not: it stays in a chat that compaction erases. Three months later nobody can tell whether a rule is deliberate or drift.
>
> It is also what makes reconciliation falsifiable. Without it, "that part of the original was superseded" is a model's opinion. With it, superseding is a record with a signature: a `DEC-*` that names exactly what it replaces.

## Rules

- **Append-only.** A decision is never edited or deleted. It is reversed by a NEW decision that supersedes it — the old one stays as history.
- **The decision is not the truth, it is the record of the change.** The operative truth still lives in the layer (`logic/*.md`, `PRODUCT.md`, `SCREENS.md`). `written_to` says where it landed; if a decision has no `written_to`, it was not applied.
- **Written by `orchestrator-flow`; decided by a human — in person or in advance.** `decided_by` is either a person, or `auto:<rule>` naming the rule in `.claude/rules/autonomy.md` that authorized it. The conductor still never decides on its own account: an `auto:` entry is a human decision taken earlier, in writing, about a class of questions. A decision authorized by nothing is invented product intent, and that is still forbidden.
- **An `auto:` decision owes three extra things.** The rule that authorized it, the alternative it **rejected**, and a `trip_wire` — the observable condition that would invalidate it. Miss any one and it is a guess with a citation. This is the whole bargain of autonomy: the decision moves from *blocked until asked* to *taken and auditable*, and the audit trail is what makes that trade honest.
- **Tier 3 is never `auto:`.** Anything irreversible, externally visible, security- or money-related stops and asks, however confident the policy looks. If nobody is there to answer, the unit blocks with the question — that is the correct outcome, not a failure.
- **One decision, one entry.** If a conversation produced three decisions, write three.

## Index

| ID | Date | Decision | Supersedes | Written to |
|---|---|---|---|---|
| DEC-001 | YYYY-MM-DD | `<ONE_LINE>` | `<DEC-0NN \| —>` | `<LAYER_IDs>` |

## DEC-001 — `<DECISION_NAME>`

```logic
id: DEC-001
type: decision
status: applied
date: YYYY-MM-DD
decided_by: "<PERSON | auto:AUTO-00N | auto:arch-review-risk-policy>"
trigger: "<CLARIFY on a screen | conversation | build discovery | review gate finding>"
rejected_alternative: "<what was NOT chosen — REQUIRED when decided_by is auto:>"
trip_wire: "<the observable condition that invalidates this — REQUIRED when decided_by is auto:>"
supersedes: []                        # earlier DEC-* this one reverses
written_to: [<LAYER_ID>, <LAYER_ID>]  # the real IDs whose files now carry this truth
affects_screens: [<SCR_ID>]
reopens: []
```

**Decision:** `<WHAT_WAS_DECIDED, in product language>`

**Why:** `<THE_REASONING — this is the part that is otherwise lost>`

**What it replaces:** `<WHAT_WAS_TRUE_BEFORE, or "nothing — new ground">`

**Consequence:** `<WHAT_HAD_TO_CHANGE: layers edited, screens to re-verify, /reslice needed>`

## Fields

| Field | Meaning |
|---|---|
| `status` | `applied` (already written to its layers) · `pending` (decided, not yet written — must not stay pending) · `reversed` (a later `DEC-*` supersedes it) |
| `trigger` | What forced the decision. Most come from a CLARIFY the build raised, from something the human said unprompted, or from a review gate finding a real-world constraint. |
| `supersedes` | Earlier `DEC-*` this decision reverses. What it replaces from the original goes in prose under **What it replaces** — the original is free text, so there is nothing to point an ID at. |
| `written_to` | The IDs whose files now carry this truth. Empty means the decision was never applied. |
| `reopens` | Units already `verified`/`accepted` whose contract this decision changes — they need `/reslice`, not a silent patch. |
| `decided_by` | A person, or `auto:<rule>` citing the `.claude/rules/autonomy.md` rule that authorized it in advance. |
| `rejected_alternative` | What was not chosen. Required for `auto:`. A decision with no visible alternative reads as the only option there ever was, which is exactly what makes it hard to revisit. |
| `trip_wire` | Required for `auto:`. The observable condition that invalidates the decision — the `DATA-*`/`ENG-*`/`PIPE-*` whose change reopens it, or the assumption that must hold. It is what lets a human re-open a decision they were not present for. |

## Checklist

- [ ] Every decision names a person in `decided_by`, or an `auto:<rule>` that exists in `.claude/rules/autonomy.md`.
- [ ] Every `auto:` decision carries `rejected_alternative` AND `trip_wire`.
- [ ] No `auto:` decision covers a Tier-3 question.
- [ ] Every decision explains **why**, not only what.
- [ ] Every `applied` decision has a non-empty `written_to`.
- [ ] A decision that contradicts an earlier one declares it in `supersedes`.
- [ ] A decision that changes an already-`accepted` contract lists it in `reopens` and routes through `/reslice`.
- [ ] No decision was taken on the model's own account: either a human decided it, or a written policy authorized it in advance and the entry cites which rule.
