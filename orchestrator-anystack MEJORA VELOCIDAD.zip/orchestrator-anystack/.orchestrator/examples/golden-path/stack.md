# Stack and canonical commands — golden path "Notas rápidas"

Resolved commands for the worked example (web + SQLite). A real initialized project looks
like this: every `<COMMAND_*>` replaced with a runnable command. The smoke test mounts this
over `.claude/rules/stack.md` so the golden path exercises an already-resolved stack.

## Stack

- Runtime: Python 3
- Backend framework: Flask
- Frontend framework: vanilla HTML + fetch
- Mobile framework: n/a (web-only)
- Canonical store (database / event store / state store / ledger / external system / file store): SQLite (WAL)
- ORM / migrations / schema tooling (if any): stdlib sqlite3 + a plain SQL migration via manage.py
- Testing: pytest
- UI verification: Claude in Chrome → Chrome DevTools MCP
- Local URLs (web / API / other surfaces): http://localhost:3000 (web + API)

## Canonical commands

```bash
# install dependencies
python3 -m pip install -r requirements.txt

# prepare local environment
python3 manage.py setup

# start development server
python3 manage.py run

# apply migrations
python3 manage.py migrate

# load minimal verifiable seed
python3 manage.py seed

# reset the verifiable test-data store to a clean, reproducible state (COMMAND_RESET_TEST_DATA)
# Delegates to this project's already-declared commands: re-apply the schema, then reload the
# seed. Idempotent — running it twice leaves the same rows. Read by reset-test-data.sh, which
# the conductor runs once before VERIFY/VALIDATE.
python3 manage.py migrate && python3 manage.py seed

# lint/static checks
python3 -m ruff check .

# unit/integration tests
python3 -m pytest

# build
python3 manage.py build

# minimal smoke check
python3 manage.py smoke
```
