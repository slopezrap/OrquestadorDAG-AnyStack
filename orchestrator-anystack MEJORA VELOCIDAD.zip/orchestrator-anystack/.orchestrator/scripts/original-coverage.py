#!/usr/bin/env python3
"""Reconcile the free-text original against the blueprint layers — no LLM, stdlib only.

`blueprint/ORIGINAL.md` is OPTIONAL human intake: the document that already existed
outside the repo (a brief, an email, a transcript, notes), pasted as-is. The 14 layers
are the contract; the original is the receipt. This script answers one question a model
cannot answer honestly: **what did the human say that no layer carries?**

    python3 .orchestrator/scripts/original-coverage.py --extract   # index the claims
    python3 .orchestrator/scripts/original-coverage.py             # coverage report

It NEVER blocks (exit 0 even with gaps) — its output feeds the CLARIFY round, and a
blocking gate over free prose would be hostile. Exit 1 only on usage/IO errors.

Every state is a set difference, never a judgment:
  claimed           a block declares `origin: [ORIG-x]` and its seal matches the block body
  claimed_unsealed  same, without a seal (hand-written) — covered, but drift-blind
  superseded        a DEC-* in DECISIONS.md supersedes it, applied, signed and written_to resolves
  drifted           the block was edited after it was sealed against this claim
  unclaimed         no layer claims it and no decision superseded it  <- the finding that matters
  orphaned          the previous index had a claim whose text no longer exists (rewritten)
  unsourced         per LAYER: blocks carrying no origin at all (intent nobody sourced)

The original is never authoritative: it cannot win a contradiction, it is not cited from
applies[]/after[], and no build phase reads it.
"""
from __future__ import annotations

import hashlib
import json
import re
import sys
import unicodedata
from pathlib import Path

ROOT = Path.cwd()
BLUEPRINT = ROOT / "blueprint"
ORIGINAL = BLUEPRINT / "ORIGINAL.md"
DECISIONS = BLUEPRINT / "DECISIONS.md"
INDEX = ROOT / ".orchestrator-state" / "original-index.json"

FENCED_BLOCK = re.compile(r"```(screen|logic)\r?\n(.*?)```", re.DOTALL)
CODE_FENCE = re.compile(r"```.*?```", re.DOTALL)
LIST_ITEM = re.compile(r"^\s*(?:[-*+]|\d+[.)])\s+(.*\S)\s*$")
TABLE_ROW = re.compile(r"^\s*\|(.+)\|\s*$")
HEADING = re.compile(r"^\s*#{1,6}\s")
SENTENCE_SPLIT = re.compile(r"(?<=[.!?])\s+")
ORIGIN_REF = re.compile(r"^(ORIG-[0-9A-F]{8})(?:-([0-9A-F]{4}))?$")

# Layers that are structurally derived rather than stated by the human: not flagged as
# unsourced. shell/state/error come out of the other layers, not out of a product brief.
UNSOURCED_WHITELIST = {"shell.md", "state.md", "error.md"}
# A claim shorter than this is a fragment ("- sin pagos" is fine; "- ok" is noise).
MIN_CLAIM_CHARS = 12


def norm(text: str) -> str:
    """Lowercase, unaccented, punctuation-free, whitespace-collapsed."""
    text = unicodedata.normalize("NFKD", text)
    text = "".join(ch for ch in text if not unicodedata.combining(ch))
    text = re.sub(r"[^\w\s]", " ", text.lower())
    return re.sub(r"\s+", " ", text).strip()


def claim_id(text: str) -> str:
    return "ORIG-" + hashlib.sha256(norm(text).encode("utf-8")).hexdigest()[:8].upper()


def seal_of(body: str) -> str:
    return hashlib.sha256(norm(body).encode("utf-8")).hexdigest()[:4].upper()


def segment(markdown: str) -> list[dict[str, str]]:
    """Split free prose into atomic claims.

    Three units, not one. Segmenting only by sentence collapses the most normative
    section of any product doc — the scope list, where `- no social login` and
    `- no payments` are two decisions on two lines, with no full stop in sight.
    """
    text = CODE_FENCE.sub("\n", markdown)
    claims: list[dict[str, str]] = []
    seen: set[str] = set()

    def add(raw: str, kind: str, line: int) -> None:
        raw = raw.strip()
        if len(raw) < MIN_CLAIM_CHARS or not norm(raw):
            return
        cid = claim_id(raw)
        if cid in seen:
            return
        seen.add(cid)
        claims.append({"id": cid, "text": raw, "kind": kind, "line": line})

    for lineno, line in enumerate(text.splitlines(), 1):
        if HEADING.match(line) or not line.strip():
            continue
        item = LIST_ITEM.match(line)
        if item:
            add(item.group(1), "list_item", lineno)
            continue
        row = TABLE_ROW.match(line)
        if row:
            cells = [c.strip() for c in row.group(1).split("|")]
            if any(set(c) <= set("-: ") for c in cells) or not any(cells):
                continue  # separator row
            add(" — ".join(c for c in cells if c), "table_row", lineno)
            continue
        for sentence in SENTENCE_SPLIT.split(line.strip()):
            add(sentence, "sentence", lineno)
    return claims


def blueprint_blocks() -> list[dict[str, object]]:
    """Every ```logic/```screen block of the layers, with its declared origin and seal."""
    files = [BLUEPRINT / "PRODUCT.md", BLUEPRINT / "SCREENS.md"]
    files += sorted((BLUEPRINT / "logic").glob("*.md"))
    blocks: list[dict[str, object]] = []
    for path in files:
        if not path.is_file():
            continue
        text = path.read_text(encoding="utf-8", errors="replace")
        for _kind, body in FENCED_BLOCK.findall(text):
            bid = re.search(r"^\s*id:\s*([^\s#]+)\s*$", body, re.M)
            origin = re.search(r"^\s*origin:\s*\[(.*?)\]\s*$", body, re.M)
            refs = []
            if origin:
                refs = [t.strip().strip("\"'") for t in origin.group(1).split(",") if t.strip()]
            blocks.append({
                "file": path.name,
                "id": bid.group(1).strip().strip("\"'") if bid else None,
                "origins": refs,
                "seal": seal_of(body),
            })
    return blocks


def decisions() -> tuple[dict[str, list[str]], list[str]]:
    """ORIG-* superseded by an APPLIED, SIGNED decision whose written_to resolves.

    Cross-file by design: the decision lives in DECISIONS.md and must point at IDs that
    exist in the layers. That is what makes `superseded` a record instead of an opinion —
    a self-declared supersede with no landing place does not count.
    """
    if not DECISIONS.is_file():
        return {}, []
    known = {b["id"] for b in blueprint_blocks() if b["id"]}
    text = DECISIONS.read_text(encoding="utf-8", errors="replace")
    superseded: dict[str, list[str]] = {}
    problems: list[str] = []
    for _kind, body in FENCED_BLOCK.findall(text):
        def field(name: str) -> str:
            m = re.search(rf"^\s*{name}:\s*(.+?)\s*(?:#.*)?$", body, re.M)
            return m.group(1).strip().strip("\"'") if m else ""

        def listfield(name: str) -> list[str]:
            m = re.search(rf"^\s*{name}:\s*\[(.*?)\]\s*(?:#.*)?$", body, re.M)
            return [t.strip().strip("\"'") for t in m.group(1).split(",") if t.strip()] if m else []

        did = field("id")
        if not did.startswith("DEC-"):
            continue
        targets = [t for t in listfield("supersedes") if t.startswith("ORIG-")]
        if not targets:
            continue
        if field("status") != "applied":
            problems.append(f"{did} supersedes {targets} but status is '{field('status') or 'missing'}' (must be applied)")
            continue
        if not field("decided_by"):
            problems.append(f"{did} supersedes {targets} with no decided_by; a decision needs a person")
            continue
        written = listfield("written_to")
        if not written:
            problems.append(f"{did} supersedes {targets} but written_to is empty; the decision was never applied")
            continue
        missing = [w for w in written if w not in known]
        if missing:
            problems.append(f"{did}.written_to points at IDs no layer defines: {missing}")
            continue
        for target in targets:
            superseded.setdefault(target, []).append(did)
    return superseded, problems


def load_original() -> str:
    if not ORIGINAL.is_file():
        print("original-coverage: blueprint/ORIGINAL.md not present — nothing to reconcile "
              "(the original is optional intake, not a required layer).")
        raise SystemExit(0)
    return ORIGINAL.read_text(encoding="utf-8", errors="replace")


def do_extract() -> None:
    text = load_original()
    claims = segment(text)
    INDEX.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "schema_version": "orchestrator.original-index.v1",
        "source": "blueprint/ORIGINAL.md",
        "source_sha256": hashlib.sha256(text.encode("utf-8")).hexdigest(),
        "claim_count": len(claims),
        "claims": claims,
    }
    tmp = INDEX.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    tmp.replace(INDEX)
    kinds: dict[str, int] = {}
    for c in claims:
        kinds[c["kind"]] = kinds.get(c["kind"], 0) + 1
    print(f"extracted {len(claims)} claims -> {INDEX.relative_to(ROOT)}  ({kinds})")
    print("The index is DERIVED state: your prose is never edited and never carries IDs.")


def do_report() -> None:
    text = load_original()
    if not INDEX.is_file():
        print("original-coverage: no claim index yet — run with --extract first.", file=sys.stderr)
        raise SystemExit(1)
    index = json.loads(INDEX.read_text(encoding="utf-8"))
    stale = index.get("source_sha256") != hashlib.sha256(text.encode("utf-8")).hexdigest()

    claims = {c["id"]: c for c in index.get("claims", [])}
    current = {c["id"]: c for c in segment(text)}
    blocks = blueprint_blocks()
    superseded, dec_problems = decisions()

    claimed: dict[str, list[tuple[str, str, bool]]] = {}
    for block in blocks:
        for ref in block["origins"]:
            m = ORIGIN_REF.match(ref)
            if not m:
                continue
            claimed.setdefault(m.group(1), []).append(
                (str(block["file"]), str(block["id"]), m.group(2) == block["seal"] if m.group(2) else None)
            )

    rows: dict[str, list[str]] = {k: [] for k in
                                  ("claimed", "claimed_unsealed", "superseded", "drifted", "unclaimed", "orphaned")}
    for cid, claim in claims.items():
        if cid not in current:
            rows["orphaned"].append(cid)
            continue
        if cid in claimed:
            seals = [s for _f, _i, s in claimed[cid]]
            if any(s is False for s in seals):
                rows["drifted"].append(cid)
            elif any(s is None for s in seals):
                rows["claimed_unsealed"].append(cid)
            else:
                rows["claimed"].append(cid)
        elif cid in superseded:
            rows["superseded"].append(cid)
        else:
            rows["unclaimed"].append(cid)

    per_layer: dict[str, tuple[int, int]] = {}
    for block in blocks:
        total, sourced = per_layer.get(block["file"], (0, 0))
        per_layer[block["file"]] = (total + 1, sourced + (1 if block["origins"] else 0))

    print(f"== original coverage — {len(claims)} claims from blueprint/ORIGINAL.md ==")
    if stale:
        print("STALE: ORIGINAL.md changed since the last --extract; re-run --extract before trusting this.")
    for state in ("claimed", "claimed_unsealed", "superseded", "drifted", "orphaned"):
        if rows[state]:
            print(f"  {state:17} {len(rows[state])}")
    print(f"  {'unclaimed':17} {len(rows['unclaimed'])}"
          f"{'   <- no layer carries these' if rows['unclaimed'] else ''}")

    if rows["unclaimed"]:
        print("\n-- UNCLAIMED: said by the human, carried by no layer and superseded by no decision --")
        for cid in rows["unclaimed"]:
            c = claims[cid]
            print(f"  {cid}  (line {c['line']}, {c['kind']})  {c['text'][:150]}")
        print("  Route each: write it into its layer, or record a DEC-* that supersedes it,"
              "\n  or state it out of scope in PRODUCT.md. Silence is the only wrong answer.")

    if rows["drifted"]:
        print("\n-- DRIFTED: block edited after it was sealed against the claim --")
        for cid in rows["drifted"]:
            for f, bid, ok in claimed[cid]:
                if ok is False:
                    print(f"  {cid}  {f} ({bid})  re-read the claim and re-seal or re-word the block")

    if rows["orphaned"]:
        print("\n-- ORPHANED: indexed earlier, no longer in ORIGINAL.md (rewritten) --")
        for cid in rows["orphaned"]:
            still = " STILL CITED by " + ", ".join(f"{f}({b})" for f, b, _ in claimed.get(cid, [])) if cid in claimed else ""
            print(f"  {cid}  {claims[cid]['text'][:110]}{still}")

    unsourced = [(f, t, s) for f, (t, s) in sorted(per_layer.items())
                 if f not in UNSOURCED_WHITELIST and t and s == 0]
    if unsourced:
        print("\n-- UNSOURCED (per layer): blocks with no origin: at all --")
        for f, t, _s in unsourced:
            print(f"  {f}: {t}/{t} blocks carry no origin — product intent nobody sourced")

    if dec_problems:
        print("\n-- DECISION LEDGER PROBLEMS (these supersedes do NOT count) --")
        for p in dec_problems:
            print(f"  {p}")

    print("\nThis report never blocks: it is CLARIFY input. The layers are the contract;"
          "\nthe original is the receipt. Verifying that a claiming block really implements"
          "\nits claim is a human call — this script only says who claimed what.")


def main() -> None:
    args = set(sys.argv[1:])
    unknown = args - {"--extract"}
    if unknown:
        print(f"original-coverage: unknown argument(s) {sorted(unknown)}", file=sys.stderr)
        raise SystemExit(1)
    if not BLUEPRINT.is_dir():
        print("original-coverage: missing blueprint/ directory", file=sys.stderr)
        raise SystemExit(1)
    do_extract() if "--extract" in args else do_report()


if __name__ == "__main__":
    main()
