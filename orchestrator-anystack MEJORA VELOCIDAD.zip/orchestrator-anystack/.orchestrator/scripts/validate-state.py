#!/usr/bin/env python3
"""Validate .orchestrator-state without third-party dependencies.

This script is the AUTHORITATIVE enforcement layer for orchestrator state.
The JSON Schemas under .orchestrator/schemas/ are illustrative shape docs; the
checks below are what actually gate verified/accepted. If the two ever disagree,
this file wins (see the root README.md).
"""
from __future__ import annotations

import hashlib
import json
import re
import os
import sys
import tempfile
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath
from typing import Any

ROOT = Path.cwd()
ORQ = ROOT / ".orchestrator"
STATE = ROOT / ".orchestrator-state"
AGENTS = ROOT / ".claude" / "agents"
BLUEPRINT = ROOT / "blueprint"
FEATURES = STATE / "features.json"
VALID_STATUS = {"todo", "ready", "building", "verified", "accepted", "blocked", "deprecated"}
# A dependency is "built" once it holds real PASS evidence. That is enough to BUILD on top of it
# (so /build-loop can chain a whole product), but never enough to ACCEPT past it: acceptance
# still walks the after[] order, one human /accept at a time.
BUILT_STATUS = {"verified", "accepted"}
PASS_STATUSES = {"verified", "accepted"}
MOBILE_PLATFORMS = {"android", "ios", "mobile"}
# Lifetime repair cap: how many times ONE unit may be reopened+repaired across its whole life,
# summed over every `building` episode. Four times the per-episode debugger cap of 3, because a
# unit legitimately reopened by a late review gate should not trip it on the second visit — but
# a unit on its thirteenth repair is not being debugged, it is being ground at.
TOTAL_REPAIR_CAP = 12

# Standing project memory: the files Claude Code loads at the START of every session --
# CLAUDE.md and every .claude/rules/*.md (the docs enumerate exactly CLAUDE.md,
# .claude/CLAUDE.md, .claude/rules/*.md and CLAUDE.local.md; nothing else under .claude/).
# This is the one cost paid on EVERY turn of EVERY session, so it is the one worth watching.
#
# The threshold is on the TOTAL, not per file, and it is deliberately generous. The docs
# recommend under 200 lines per file, but this repo ships constitution.md at ~253 and
# autonomy.md at ~216 on purpose -- warning at 200 would fire on a healthy scaffold every
# single run, and a warning nobody can act on is worse than none. What actually hurts is
# unbounded GROWTH: one real project reached 1637 lines in stack.md alone, 28x its template,
# because a write-back rule routed infra decisions into a file that loads on every turn.
STANDING_MEMORY_MAX_LINES = 1200


# Advisory only. Which kinds count as a REAL consumer of a `kind: foundation` unit, and how many
# units may be built before one appears. The distance is POSITIONAL (how many units come first in
# the build order), never the arithmetic difference of the `order` field: projects reserve gaps in
# their numbering — one real plan jumps from order 33 to order 100 — so an arithmetic threshold
# measures a numbering convention rather than the thing that costs money, which is how much gets
# built before anything runs it. Measured: a healthy 3-unit fixture peaks at 2; the one real
# project that went wrong ranges 3..33 with 4 foundations nothing reaches at all. 8 sits well
# above the healthy ceiling and well below where the real failure lives.
FOUNDATION_CONSUMER_KINDS = {"ui", "backend"}
FOUNDATION_CONSUMER_MAX_DISTANCE = 8

# AnyStack: the canonical store is whatever the blueprint declares (relational DB,
# event store, ledger, external system of record, file store, read model, ...).
# The only hard rule is that the source of truth is NOT a client/frontend layer.
CLIENT_LAYERS = {
    "frontend", "front-end", "ui", "client", "clients", "web", "mobile", "android",
    "ios", "desktop", "cli", "tui", "browser", "localstorage", "local_storage",
    "local-storage", "fixture", "fixtures", "in-memory", "memory",
}
# Tokens that indicate a transport / read layer between the store and the client.
TRANSPORT_TOKENS = (
    "api", "service", "read", "read_model", "read-model", "rpc", "grpc", "graphql",
    "gateway", "query", "endpoint", "resolver",
)
# Observed-value key aliases per layer, so assertions are stack-neutral.
CANONICAL_VALUE_KEYS = ("db_value", "source_value", "store_value", "canonical_value", "record_value")
TRANSPORT_VALUE_KEYS = ("api_value", "service_value", "transport_value", "read_model_value", "response_value")
CLIENT_VALUE_KEYS = ("ui_value", "client_value", "visible_value", "mobile_value")

# Mandatory workflow cycle. The constitution makes launching each fan-out phase
# with its FULL lens set non-negotiable; the phase-coverage check below turns that
# from prose into a gate so a PASS cannot skip EXPLORE/VERIFY/VALIDATE or hand-pick
# a subset of lenses. inline-fallback is allowed but must carry the SAME full set.
RESEARCH_LENSES = {
    "research-domain", "research-application", "research-core", "research-journey",
    "research-permission", "research-state", "research-error", "research-integration",
    "research-ui", "research-shell", "research-data", "research-usecases",
    "research-engine", "research-pipeline",
    "research-product", "research-screens", "research-design",
}
EXPLORE_LENSES = {
    "explore-scout", "explore-data", "explore-backend", "explore-ui",
    "explore-existing", "explore-tests", "explore-engine", "explore-pipeline",
    "explore-config",
}
VERIFY_LENSES = {
    "verify-tests", "verify-conformance", "verify-design", "verify-frontend",
    "verify-engine", "verify-pipeline", "verify-logs", "verify-quality",
    "verify-coherence", "verify-blueprint-drift",
}
UI_PLATFORM_VALIDATORS = {"web": "validate-web", "android": "validate-android", "ios": "validate-ios"}
# VALIDATE stopped being UI-only: a unit that declares an engine/pipeline contract must prove it
# RAN for real, exactly as a UI unit must prove its screen was driven for real. Without this a
# rules/compute/agent engine would reach `verified` on static verification alone.
ENGINE_VALIDATORS = {"engine": "validate-engine", "pipeline": "validate-pipeline"}
# /arch-review: the t=0 architecture gate. Its lens set is deliberately NOT part of the
# required phase_runs[] sets — it audits the DESIGN before features.json exists, so wiring
# it into per-unit evidence would retroactively invalidate every verified unit.
ARCH_LENSES = {
    "arch-fit", "arch-data-model", "arch-identity", "arch-engines",
    "arch-pipelines", "arch-risk",
}
ARCH_REVIEW_STATUSES = {"clear", "accepted_with_risk", "deferred"}
# /discovery: the universal-intake gate at t=0 (before COMPILE). Like the arch lenses, its
# set is deliberately NOT part of the required phase_runs[] sets — it gates the project's
# birth (--init-gate), never a unit's evidence.
DISCOVERY_LENSES = {
    "discovery-product", "discovery-data", "discovery-architecture",
    "discovery-stack", "discovery-infra", "discovery-ux",
}
DISCOVERY_DISPOSITIONS = ("answered", "filled", "asked", "na", "deferred")
# The subset of the blueprint the arch lenses actually judge; /reslice re-triggers the
# gate when the hash over these files drifts from meta.architecture_review.architecture_hash.
ARCH_HASH_FILES = (
    "blueprint/PRODUCT.md", "blueprint/logic/data.md", "blueprint/logic/engine.md",
    "blueprint/logic/pipeline.md", "blueprint/logic/integration.md",
    "blueprint/logic/permission.md", "blueprint/logic/state.md",
    "blueprint/logic/core.md", "blueprint/logic/shell.md",
)
FANOUT_MODES = {"workflow", "inline-fallback"}


def fail(message: str) -> None:
    print(f"state invalid: {message}", file=sys.stderr)
    raise SystemExit(1)


def warn(message: str) -> None:
    """Non-fatal signal. Used where the state is not WRONG but is probably not what
    anyone intended — the class of defect that only hurts when nobody is watching.
    A `fail()` here would be worse than the defect: the conditions below have legal
    transient windows (mid-/init-build compile, between a unit closing and the next
    promotion), and a gate that refuses valid states teaches the conductor to route
    around the gate."""
    print(f"state warning: {message}", file=sys.stderr)


def load_json(path: Path) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError:
        fail(f"missing {path}")
    except json.JSONDecodeError as exc:
        fail(f"invalid JSON {path}: {exc}")


def schema_name(obj: dict[str, Any]) -> str | None:
    return obj.get("schema_version") or obj.get("schema")


def _norm(value: Any) -> str | None:
    """Normalize an observed cross-layer value for equality comparison."""
    if value is None:
        return None
    return str(value).strip()


_ID_IN_BLOCK = re.compile(r"^\s*id:\s*([A-Z][A-Z0-9-]*)\s*$", re.M)
_ID_IN_HEADING = re.compile(r"^#{2,4}\s+([A-Z][A-Z0-9-]*)\b", re.M)
REF_PREFIXES = ("BR-", "SCR-", "DOM-", "APP-", "CORE-", "JOUR-", "PERM-", "ST-",
                "ERR-", "INT-", "UI-", "DATA-", "UC-", "ENG-", "PIPE-")


def _blueprint_ids() -> set[str]:
    """Every ID the blueprint actually defines. Used to reject a plan that cites rules
    nobody wrote: traceability was prose until now — `applies: ["DATA-999"]` passed both
    the gate and the linter, and an ID-only reference is exactly what agents are told
    is NOT enough intent."""
    ids: set[str] = set()
    if not BLUEPRINT.is_dir():
        return ids
    for path in sorted(BLUEPRINT.rglob("*.md")):
        text = path.read_text(encoding="utf-8", errors="replace")
        ids |= set(_ID_IN_BLOCK.findall(text))
        ids |= set(_ID_IN_HEADING.findall(text))
    return ids


def _has_client_token(value: Any) -> bool:
    """True when any WORD of `value` names a client layer.

    Segmenting matters: the old check compared the whole string against CLIENT_LAYERS,
    so `source_of_truth: "UI store"` or `"browser localStorage"` sailed through and a
    frontend became the system of record — the one invariant the constitution calls
    non-negotiable."""
    # Collapse -/_ BEFORE tokenizing. The split treated both as separators, so every hyphenated
    # member of CLIENT_LAYERS ("front-end", "local-storage", "local_storage") was unreachable: it
    # could never be produced as a token, so it could never match. Measured: "front-end local
    # storage" as a source_of_truth passed the client check clean — the exact vocabulary the
    # constitution uses to name the forbidden case.
    raw = str(value).strip().lower()
    parts = {p for p in re.split(r"[^a-z0-9]+", raw.replace("-", "").replace("_", "")) if p}
    return bool(parts & CLIENT_LAYERS)


def _is_ui_surface(screen: dict[str, Any]) -> bool:
    """A screen owns a UI surface (and must therefore declare platforms[]) when any
    independent signal says so: kind 'ui', a UI primary_verifier, or a non-null client
    route. This catches a UI screen left with empty platforms — which would otherwise
    make the gate silently treat it as backend-only and skip the whole VALIDATE phase."""
    if str(screen.get("kind", "")).strip().lower() == "ui":
        return True
    verify = screen.get("verify")
    if isinstance(verify, dict):
        if str(verify.get("primary_verifier", "")).strip().lower() in {
            "validate-web", "validate-android", "validate-ios"
        }:
            return True
    route = screen.get("route")
    if isinstance(route, dict):
        if any(route.get(plat) for plat in ("web", "android", "ios")):
            return True
    return False


def _declared_engine_kinds(screen: dict[str, Any]) -> set[str]:
    """Which live engine validators a unit owes, derived from the contracts it cites.

    The engine/pipeline layers are optional per product: a unit that cites no ENG-*/PIPE-*
    owes nothing. But a unit that DOES cite one owes live proof it ran — there is no
    not_applicable escape once a contract is cited, mirroring how data_engine's escape is
    only legal when the unit cites no DATA-* at all. Otherwise an engine could reach
    `verified` on static verification alone, which is exactly the hole this closes."""
    refs: list[str] = []
    for key in ("applies", "engine_refs", "pipeline_refs"):
        value = screen.get(key)
        if isinstance(value, list):
            refs += [str(item) for item in value]
    data_engine = screen.get("data_engine")
    if isinstance(data_engine, dict):
        for key in ("engine_refs", "pipeline_refs"):
            value = data_engine.get(key)
            if isinstance(value, list):
                refs += [str(item) for item in value]
    kinds: set[str] = set()
    for ref in refs:
        token = ref.strip().upper()
        if token.startswith("ENG-"):
            kinds.add("engine")
        elif token.startswith("PIPE-"):
            kinds.add("pipeline")
    return kinds


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    digest.update(path.read_bytes())
    return digest.hexdigest()


def _collect_artifact_paths(result: dict[str, Any]) -> set[str]:
    paths: set[str] = set()
    for artifact in result.get("artifacts", []):
        if isinstance(artifact, dict) and isinstance(artifact.get("path"), str):
            paths.add(artifact["path"])
        elif isinstance(artifact, str):
            paths.add(artifact)
    for check in result.get("checks", []):
        if isinstance(check, dict):
            for artifact in check.get("artifacts", []):
                if isinstance(artifact, str):
                    paths.add(artifact)
    return paths


def acceptance_coverage_problems(screen: dict[str, Any], result: dict[str, Any]) -> list[str]:
    """Every acceptance criterion must be answered by a check that CITES IT BY ID.

    `conventions.md` has always said "result.json must connect checks to acceptance criteria",
    and nothing enforced it: `acceptance_ids` appeared nowhere in this file. So a unit could
    close with checks labelled by approximate topic — "tests", "data", "logs" — none of which
    can be traced back to the criterion it was supposed to answer. The evidence looked complete
    and proved something adjacent to what was asked.

    This is the cheap half of the problem and the only half a script can own. It cannot know
    whether a check really TESTS its criterion; it can know that no criterion was left without
    one, and that no check cites a criterion that does not exist. That is exactly the class of
    defect that was costing a full VERIFY fan-out to discover, and a fan-out is a very
    expensive way to be told an id is missing.

    Returns problems rather than calling fail(): the closing gate turns them into failures, the
    pre-flight lists them all at once while the unit is still in flight. One rule, one
    implementation, two moments.

    Criteria carrying no `id` are skipped, not failed: the schema never typed `acceptance`, so a
    project may legitimately write plain strings. What cannot be addressed cannot be required."""
    problems: list[str] = []
    sid = screen.get("id", "<unknown>")
    acceptance = screen.get("acceptance", [])
    if not isinstance(acceptance, list):
        return problems
    wanted = [a["id"] for a in acceptance
              if isinstance(a, dict) and isinstance(a.get("id"), str) and a["id"].strip()]
    if not wanted:
        return problems                    # string criteria: nothing addressable to cite
    cited: set[str] = set()
    for check in result.get("checks", []):
        if not isinstance(check, dict):
            continue
        refs = check.get("acceptance_ids") or check.get("acceptance_refs") or []
        if isinstance(refs, str):
            refs = [refs]
        if isinstance(refs, list):
            cited.update(str(r).strip() for r in refs if str(r).strip())
    # Escape valve, mirroring data_engine.not_applicable_reason: a criterion this unit genuinely
    # cannot prove on its own — a cross-screen consistency criterion only /verify-app can exercise
    # once the sibling units exist, say — is excused by NAMING it and saying why. Without this the
    # rule would force a fake check, which is the very defect it exists to stop, one level down.
    # An entry with no reason excuses nothing: silence is not a justification.
    deferred = {}
    raw_deferred = result.get("acceptance_deferred") or []
    if isinstance(raw_deferred, list):
        for entry in raw_deferred:
            if isinstance(entry, dict) and str(entry.get("id", "")).strip():
                reason = str(entry.get("reason", "")).strip()
                if reason:
                    deferred[str(entry["id"]).strip()] = reason
    uncovered = [a for a in wanted if a not in cited and a not in deferred]
    if uncovered:
        problems.append(
            f"{sid}: acceptance criteria with no check citing them: {uncovered}. Every "
            f"criterion needs a check whose `acceptance_ids` names it — label checks against "
            f"the criterion's literal id, never by approximate topic, or nothing connects the "
            f"proof to what was asked. A criterion this unit genuinely cannot prove goes in "
            f"result.json.acceptance_deferred[] as {{id, reason}}, named and justified")
    phantom = sorted(c for c in cited if c not in set(wanted))
    if phantom:
        problems.append(
            f"{sid}: checks cite acceptance ids the unit does not declare: {phantom}. A check "
            f"answering a criterion that does not exist is answering nothing")
    return problems


ADVISORY_SEVERITIES = {"blocker", "high", "medium", "low", "nit"}
ADVISORY_STATUSES = {"open", "accepted_as_debt", "fixed"}


def validate_advisory_findings(result: dict[str, Any], path: Path) -> None:
    """The second exit a finding needs, and the reason the loop could not end without it.

    A finding used to have exactly one way to be discharged: repair it. Any finding, of any
    severity, therefore forced a repair, which forced a re-VERIFY, which produced new surface for
    the next round to find. That is a loop with no fixed point — and measured on a real run it is
    where most of the rounds went: more than half of them did not fix code, they fixed the trail,
    and the reason a nit could cost a full round is that there was nowhere else to put it.

    `advisory_findings[]` was already in the schema and `/accept --auto` already reads it. Nothing
    WROTE it: the two §5.5 gates left their non-blocking findings in the prose of their report,
    tracked by nothing, so the only way to stop one from being forgotten was to repair it. This
    validates the field so the gates can be told to use it and the claim can be checked.

    The boundary is the load-bearing part, and it is why this does not weaken anything. A finding
    that blocks belongs in `checks[]`/`failures[]` and still blocks — `verified` still requires
    `verdict:"PASS"` with `failures` empty, exactly as before. Only a finding the gate itself
    classified as NON-blocking may live here, and it lives here NAMED, with a severity a human or
    `--auto` can weigh, instead of dying in a report nobody reads or eating a round nobody
    budgeted. Recording debt is not lowering the bar; pretending the debt was never found is."""
    findings = result.get("advisory_findings")
    if findings is None:
        return
    if not isinstance(findings, list):
        fail(f"{path}.advisory_findings must be an array")
    seen: set[str] = set()
    # failures[] is a list of OBJECTS in every real result.json ({check, acceptance_ref, repro,
    # fix_hint}), not of strings — an earlier version of this guard filtered for `isinstance(str)`
    # and therefore compared against an always-empty set: dead code that looked like a control,
    # and whose own smoke case passed only because it fed it a shape that never occurs. Accept
    # both, and pull the ids an object actually carries.
    blocking_refs: set[str] = set()
    for entry in result.get("failures", []) or []:
        if isinstance(entry, str) and entry.strip():
            blocking_refs.add(entry.strip())
        elif isinstance(entry, dict):
            for key in ("check", "acceptance_ref", "id"):
                value = entry.get(key)
                if isinstance(value, str) and value.strip():
                    blocking_refs.add(value.strip())
    for idx, finding in enumerate(findings):
        where = f"{path}.advisory_findings[{idx}]"
        if not isinstance(finding, dict):
            fail(f"{where} must be an object")
        fid = str(finding.get("id", "")).strip()
        if not fid:
            fail(f"{where} needs an id: an advisory finding nobody can name is a finding nobody "
                 f"can close")
        if fid in seen:
            fail(f"{where} duplicates id {fid!r}")
        seen.add(fid)
        severity = str(finding.get("severity", "")).strip().lower()
        if severity not in ADVISORY_SEVERITIES:
            fail(f"{where}.severity must be one of {sorted(ADVISORY_SEVERITIES)}, not "
                 f"{finding.get('severity')!r} — /accept --auto compares it against the ceiling in "
                 f".claude/rules/autonomy.md, so an unreadable severity silently disables that bar")
        if not str(finding.get("detail", "")).strip():
            fail(f"{where} needs a detail: a severity with no statement of what is wrong cannot be "
                 f"judged, only obeyed")
        status = str(finding.get("status", "open")).strip().lower()
        if status not in ADVISORY_STATUSES:
            fail(f"{where}.status must be one of {sorted(ADVISORY_STATUSES)}, not "
                 f"{finding.get('status')!r}")
        # THE boundary this whole mechanism rests on: a blocker is never debt. The severity enum
        # includes "blocker" precisely so a gate can raise one — and the moment one could be
        # waived by writing a status next to it, "non-blocking findings are recorded instead of
        # repaired" would become "any finding is recorded instead of repaired", which is not a
        # second exit, it is an exit from the evidence standard.
        if status == "accepted_as_debt" and severity == "blocker":
            fail(f"{where} is severity 'blocker' and status 'accepted_as_debt': a blocker is never "
                 f"debt. Either it does not block — then say so with a lower severity — or it does, "
                 f"and it belongs in checks[]/failures[] until it is repaired")
        # And the same defect may not be reported as handled here while blocking there.
        if status == "accepted_as_debt" and (fid in blocking_refs or any(
                isinstance(r, str) and r.strip() in blocking_refs for r in finding.get("refs", []) or [])):
            fail(f"{where} is accepted_as_debt while it (or something it refs) also appears in "
                 f"failures[]: a finding is either blocking or waived, never both")


def validate_expected_ui_values(result: dict[str, Any], path: Path, screen_status: str = "") -> None:
    """VALIDATE asserts that each observed client value DERIVES from an expected one — value
    plus transform — rather than matching it blindly. That is the only way a UI showing a
    formatted or translated version of the canonical value can be told from a UI showing the
    wrong value. `expected_ui_values[]` is what it derives from, written by the conductor after
    VERIFY and lifted from disk by validate-live's loader.

    Nothing checked it existed. When it was absent the loader returned [], every live lens was
    handed an empty list, and "assert the observed value derives from expected_ui_values"
    became vacuous — the lens could still PASS, and no output anywhere differed from a run
    where the check had actually happened.

    Required only where there is something to derive: a unit whose assertions carry an observed
    client value. A backend unit proves no client value and needs none."""
    if result.get("verdict") != "PASS":
        return
    assertions = result.get("data_engine_assertions")
    if not isinstance(assertions, list) or not assertions:
        return
    needs = [a for a in assertions if isinstance(a, dict) and any(
        a.get(k) not in (None, "") for k in ("ui_value", "client_field", "visible_value", "platform_values"))]
    if not needs:
        return
    expected = result.get("expected_ui_values")
    if isinstance(expected, list) and expected:
        return
    msg = (f"{path} is a PASS whose data_engine_assertions carry observed client values, but "
           f"expected_ui_values[] is absent or empty; VALIDATE then had nothing to derive from "
           f"and its derives-from assertion was vacuous. Persist the VERIFY digest's "
           f"expected_ui_values[] verbatim (next-pantalla §5)")
    # HARD for work still in flight, VISIBLE for history.
    #
    # An `accepted` unit was built and signed off before this rule existed, and its evidence
    # cannot be corrected: writing expected_ui_values[] now would describe a derivation that
    # never happened, which is fabricating evidence — the one thing this gate exists to stop.
    # Failing on it instead strands the whole project: a repo with one legacy unit can no
    # longer run ANY command, and the only ways out are to fake the field or to delete the
    # check. Both are worse than the defect.
    #
    # So it blocks exactly where blocking still buys something — a unit about to be accepted —
    # and warns where the only honest answer is "this one predates the rule". The distinction
    # is not leniency: a warning still makes an absent guard distinguishable from a satisfied
    # one, which was the entire point of adding the check.
    if screen_status == "accepted":
        warn(msg + " [unidad ya aceptada: se avisa, no se bloquea — su evidencia es histórica "
                   "y reescribirla ahora sería inventarla]")
        return
    fail(msg)


SPEC_PREFIXES = ("blueprint/", "design/", ".claude/", ".orchestrator/", ".orchestrator-state/")


def _is_spec_path(rel: str) -> bool:
    """A file whose change alters what the code is JUDGED AGAINST, not the code itself."""
    norm = str(rel).replace("\\", "/").lstrip("./")
    return norm.startswith(SPEC_PREFIXES)


def contract_fingerprint(screen: dict[str, Any]) -> str:
    """The unit's COMPILED contract: what its evidence claims to have proven.

    This is the piece that lets spec drift stop meaning "re-verify everything". A blueprint edit
    matters to a recorded PASS only when it changed what the unit must satisfy — its acceptance
    criteria, the rule IDs it applies, its dependencies, its verification plan. Those are compiled
    into `features.json`, so they can be hashed exactly, while the prose around them can be
    rewritten freely without moving anything a proof depends on.

    Deliberately NOT the whole screen entry: `status`, `passes`, `checkpoint`, `notes` and the
    rest change constantly during a normal build and have nothing to do with what was proven.
    Hashing them would recreate the same false alarm one field over."""
    # Every field here answers "would the evidence still prove what it claims?". `after[]` is
    # deliberately absent even though it is contractual elsewhere: dependencies decide BUILD
    # ORDER, not what this unit demonstrates about itself, so adding one would invalidate
    # perfectly good evidence — the exact false alarm this fingerprint exists to replace.
    material = {
        "acceptance": screen.get("acceptance", []),
        "applies": screen.get("applies", []),
        "verify": screen.get("verify", {}),
        "platforms": screen.get("platforms", []),
        "kind": screen.get("kind", ""),
        "route": screen.get("route", None),
        "data_engine": screen.get("data_engine", {}),
    }
    blob = json.dumps(material, sort_keys=True, ensure_ascii=False, separators=(",", ":"))
    return "sha256:" + hashlib.sha256(blob.encode("utf-8")).hexdigest()


def validate_contract_fingerprint(screen: dict[str, Any], result: dict[str, Any],
                                  path: Path) -> None:
    """Fail a PASS whose contract moved after the evidence was recorded.

    NOT retroactive: absent means a result written before this existed, and back-filling it would
    stamp a comparison nobody made. Present means it is checked, and a mismatch is the one case
    where a spec change really does invalidate a proof — the unit is now being asked for something
    different from what was demonstrated. That is a `/reslice`, not a debugger round."""
    recorded = str(result.get("contract_fingerprint", "")).strip()
    if not recorded:
        return
    actual = contract_fingerprint(screen)
    if recorded.split(":")[-1].lower() != actual.split(":")[-1].lower():
        sid = screen.get("id", "<unknown>")
        (warn if screen.get("status") == "accepted" else fail)(
            f"{path}.contract_fingerprint no longer matches {sid}'s compiled contract in "
            f"features.json (recorded {recorded.split(':')[-1][:12]}, now {actual.split(':')[-1][:12]}). "
            f"The acceptance criteria, applies[], after[], verify plan, platforms, kind, route or "
            f"data_engine changed after this evidence was produced, so the evidence proves a "
            f"contract the unit no longer has. This is the contractual tier: route it through "
            f"/reslice, not through another repair pass")


def validate_source_manifest(result: dict[str, Any], path: Path,
                             screen_status: str = "") -> None:
    """Stale-PASS guard. A PASS must declare a source_manifest, and every listed file
    must still exist and still hash the same. This converts the constitution's
    'evidence is stale after a fix' rule from policy into a mechanical check.

    PRESENCE IS REQUIRED, and that is the whole point. This used to return early when the
    field was absent — "backward compatible" — which meant the single most valuable guard in
    the gate could be switched off by simply not writing the field. Omission produced exactly
    the same result as a manifest whose files all still hash correctly: a clean PASS. An
    absent guard and a satisfied guard must never look alike.

    next-pantalla §7 has always required it for a PASS; only the enforcement was missing."""
    if result.get("verdict") != "PASS":
        return
    manifest = result.get("source_manifest")
    if manifest is None:
        fail(f"{path} is a PASS with no source_manifest; the stale-evidence guard cannot run "
             f"without it, and its absence is indistinguishable from a manifest that passes. "
             f"Record path + sha256 for the unit's implementation files (next-pantalla §7)")
    if not isinstance(manifest, list):
        fail(f"{path}.source_manifest must be array")
    if not manifest:
        # The same hole as an ABSENT manifest, one level down: an empty list iterates zero times,
        # so every hash check below is skipped and the unit passes looking fully guarded. A PASS
        # means code was written and proven; a unit that implemented nothing has nothing to prove.
        # Retroactivity split as elsewhere — hard while the unit can still fix it, a warning once
        # it is history.
        msg = (f"{path} is a PASS with an EMPTY source_manifest; an empty list skips every hash "
               f"check and is indistinguishable from a manifest that passed. List the unit's "
               f"implementation files with path + sha256 (next-pantalla §7)")
        if screen_status == "accepted":
            warn(msg + " [already accepted: warning, not a failure]")
        else:
            fail(msg)
    for entry in manifest:
        if not isinstance(entry, dict):
            fail(f"{path}.source_manifest entries must be objects")
        rel = entry.get("path")
        if not isinstance(rel, str) or not rel:
            fail(f"{path}.source_manifest entry missing path")
        if "<" in rel or ">" in rel:
            fail(f"{path}.source_manifest has unresolved placeholder path: {rel}")
        fp = ROOT / rel
        if not fp.is_file():
            fail(f"{path}.source_manifest references missing or non-file source file: {rel}")
        digest = entry.get("sha256")
        if not (isinstance(digest, str) and digest.strip()):
            # An entry with a path and no hash is the same defect one level down as an absent
            # manifest: it LOOKS verified and can never go stale, because there is nothing to
            # compare. next-pantalla §7 already says "path + sha256"; only the check was missing.
            #
            # Retroactivity is split exactly like validate_expected_ui_values() below, and for
            # the same reason: HARD for work still in flight (the next run can simply write the
            # hash), a WARNING for an already-`accepted` unit, whose manifest was written before
            # this rule existed. Back-filling a hash there would record a comparison that never
            # happened — inventing evidence, which is precisely what this guard exists to stop.
            msg = (f"{path}.source_manifest entry for {rel} has no sha256: a manifest without a "
                   f"hash cannot detect a later edit, so it is indistinguishable from one that "
                   f"was checked and matched. Record it (next-pantalla §7)")
            if screen_status == "accepted":
                warn(msg + " [already accepted: warning, not a failure]")
                continue
            fail(msg)
        want = digest.split(":")[-1].strip().lower()
        actual = _sha256(fp).lower()
        if actual == want:
            continue
        # NOT ALL DRIFT IS THE SAME DRIFT, and treating it as if it were is what made this guard
        # exhausting. A changed IMPLEMENTATION file means the code moved under the proof: the
        # evidence describes something that no longer exists, and re-proving is the only honest
        # move. A changed SPEC file does not mean that. §7 of next-pantalla has always said this
        # manifest holds "the unit's implementation files", but nothing enforced it, so blueprint
        # files ended up listed here — and then a typo in a `.md`, a clarified sentence, a new
        # example, all demanded a full re-VERIFY of working code.
        #
        # The constitution already decides what a spec edit costs, and it is not this: editorial
        # changes nothing downstream, additive re-runs only the doc<->code lenses, and only a
        # CONTRACTUAL edit invalidates a recorded PASS. That last case is caught precisely by
        # contract_fingerprint below, which watches the compiled contract rather than the prose
        # around it. So spec drift routes to that rule instead of pre-empting it with a hard fail.
        if _is_spec_path(rel):
            warn(f"{path}.source_manifest: {rel} changed since evidence was produced "
                 f"(expected {want[:12]}, got {actual[:12]}). This is a SPEC file, not an "
                 f"implementation file, so it does not by itself make the proof stale — classify "
                 f"the edit by the three tiers in constitution.md: editorial (nothing to re-run), "
                 f"additive (re-run the doc<->code lenses), contractual (/reslice, at any size). "
                 f"A contractual change shows up as contract_fingerprint drift, which DOES fail")
            continue
        fail(
            f"{path}.source_manifest stale: {rel} changed since evidence "
            f"was produced (expected {want[:12]}, got {actual[:12]}); re-verify"
        )


def validate_result(
    path: Path,
    feature_ids: set[str] | None = None,
    require_artifacts: bool = False,
    screen: dict[str, Any] | None = None,
) -> dict[str, Any]:
    result = load_json(path)
    if not isinstance(result, dict):
        fail(f"{path} root must be object")
    if schema_name(result) != "orchestrator.result.v1":
        fail(f"{path} schema_version must be orchestrator.result.v1")
    required = [
        "screen_id", "screen_title", "run_id", "attempt", "generated_at", "verdict",
        "verifier", "environment", "checks", "artifacts", "data_assertions",
        "data_engine_assertions", "logs", "failures", "summary",
    ]
    for key in required:
        if key not in result:
            fail(f"{path} missing {key}")
    sid = result["screen_id"]
    if feature_ids and sid not in feature_ids and not str(sid).startswith("SCR-TEMPLATE"):
        fail(f"{path} references unknown screen_id {sid}")
    # Evidence is bound to its owning screen by CONTENT, not just by path: a PASS
    # result.json copied/moved from another screen's evidence dir must not validate.
    if screen is not None and sid != screen.get("id"):
        fail(f"{path} screen_id {sid} does not match the screen that owns this "
             f"evidence_path ({screen.get('id')}); evidence cannot be borrowed across screens")
    if result["verdict"] not in {"PASS", "FAIL", "BLOCKED"}:
        fail(f"{path} verdict invalid")
    checks = result.get("checks", [])
    if not isinstance(checks, list):
        fail(f"{path}.checks must be array")
    failures = result.get("failures", [])
    if not isinstance(failures, list):
        fail(f"{path}.failures must be array")
    verdict_pass = result["verdict"] == "PASS"
    if verdict_pass:
        bad = [
            c.get("id", "<missing>")
            for c in checks
            if isinstance(c, dict) and c.get("required", True) and c.get("passed") is not True
        ]
        if bad:
            fail(f"{path} PASS with failing required checks: {bad}")
        if failures:
            fail(f"{path} PASS requires failures=[]")
        # Floor: a PASS may never have an empty/zero required-check set. Closes the
        # 'verified with checks:[]' hole for every screen, not just data screens.
        passed_required = [
            c for c in checks
            if isinstance(c, dict) and c.get("required", True) and c.get("passed") is True
        ]
        if not passed_required:
            fail(f"{path} PASS requires at least one passed required check")
        if screen is not None:
            for problem in acceptance_coverage_problems(screen, result):
                fail(f"{path} PASS: {problem}")
    if require_artifacts:
        artifact_paths = _collect_artifact_paths(result)
        # THE SAME HOLE, ONE LEVEL DOWN — the third time this file has had to close it, after an
        # absent source_manifest and an empty one. The loop below opens every path the result
        # CITES; it has nothing to say about a result that cites none. So a PASS with `artifacts:
        # []` and no per-check artifacts ran the artifact guard over ZERO paths and came out
        # looking fully checked. Found the hard way: a phantom artifact path survived many
        # iterations precisely because the collection it should have been in was empty, so
        # nothing ever tried to open it.
        #
        # An absent guard and a satisfied guard must never look alike. A PASS means something was
        # proven, and proving something in this orchestrator always leaves a file — a log, a
        # screenshot, a query output, a test run. A unit that produced none did not prove; it
        # asserted. Retroactivity split as everywhere else: hard while the unit can still fix it,
        # a warning once a human has already signed it.
        if verdict_pass and not artifact_paths:
            msg = (f"{path} is a PASS that cites NO artifacts at all: neither artifacts[] nor any "
                   f"check carries one. The existence check below then verifies zero paths and "
                   f"reports success, which is indistinguishable from a result whose every "
                   f"artifact was opened and found. Cite the files this unit's proof actually "
                   f"produced (conventions.md, 'Evidence names')")
            if screen is not None and screen.get("status") == "accepted":
                warn(msg + " [already accepted: warning, not a failure]")
            else:
                fail(msg)
        for rel in sorted(artifact_paths):
            if "<" in rel or ">" in rel:
                if verdict_pass:
                    fail(f"{path} PASS references unresolved placeholder artifact path: {rel}")
                continue
            if not rel:
                continue
            fp = ROOT / rel
            if not fp.is_file():
                fail(f"{path} references missing or non-file artifact: {rel} "
                     f"(a directory is not evidence)")
            if verdict_pass and fp.stat().st_size == 0:
                fail(f"{path} PASS references empty (0-byte) artifact: {rel}")
    validate_advisory_findings(result, path)
    validate_source_manifest(result, path, str(screen.get("status", "")) if screen else "")
    validate_expected_ui_values(result, path, str(screen.get("status", "")))
    if screen is not None and verdict_pass:
        validate_contract_fingerprint(screen, result, path)
        validate_evidence_floor(screen, result, path)
        validate_phase_coverage(screen, result, path)
    return result


def _phase_lenses(phase_run: dict[str, Any]) -> set[str]:
    lenses = phase_run.get("lenses", [])
    if not isinstance(lenses, list):
        return set()
    return {str(name).strip() for name in lenses if isinstance(name, str) and name.strip()}


def validate_phase_coverage(screen: dict[str, Any], result: dict[str, Any], path: Path) -> None:
    """Make the mandatory workflow cycle a hard gate, not a prose preference.

    A PASS must record, in phase_runs[], that every fan-out phase launched its
    workflow and fanned out to its FULL lens set. Skipping EXPLORE/VERIFY/VALIDATE
    — or hand-picking a subset of lenses, or verifying inline instead of via the
    fan-out — is rejected here. This closes the hole where the conductor 'did the
    work' but bypassed the independent multi-lens coverage the flow requires.
    inline-fallback is allowed (Workflows genuinely unavailable) but must still
    carry the same full lens set."""
    sid = screen.get("id", "<unknown>")
    runs = result.get("phase_runs")
    if not isinstance(runs, list) or not runs:
        fail(f"{sid} PASS requires phase_runs[] proving the full workflow cycle ran "
             f"(RESEARCH, EXPLORE, DEVELOP, VERIFY, VALIDATE when UI, REVIEW). "
             f"Skipping a fan-out workflow is not allowed.")
    # EVERY recorded entry is validated, not just the last one per phase. This used to be
    # `by_phase[name] = run`, which silently dropped all but the final entry of a repeated
    # phase — so a partial VERIFY recorded before a full one was invisible to the gate.
    # That mattered because a scoped/triage pass may never be recorded at all (see the
    # constitution's "Cost may be proportional; coverage may not" and verify-fanout.js's
    # full_set flag): if an entry is in phase_runs[], it is claiming a full lens set ran,
    # so every entry has to carry one. Accumulating also keeps the door open for reading
    # phase_runs[] as a record of how many passes happened — but note it is NOT a reliable
    # effort log and was never meant to be one: a phase that changes no files leaves no
    # checkpoint, so passes go unrecorded. Measure effort from the agent transcripts.
    by_phase: dict[str, list[dict[str, Any]]] = {}
    for run in runs:
        if not isinstance(run, dict):
            fail(f"{sid}.phase_runs entries must be objects")
        name = str(run.get("phase", "")).strip().upper()
        if not name:
            fail(f"{sid}.phase_runs entry missing phase")
        mode = str(run.get("mode", "")).strip().lower()
        if mode not in {"workflow", "inline-fallback", "inline", "agent"}:
            fail(f"{sid}.phase_runs[{name}].mode invalid: {run.get('mode')!r} "
                 f"(use workflow|inline-fallback for fan-out phases)")
        by_phase.setdefault(name, []).append(run)

    platforms = screen.get("platforms", [])
    plats = {str(p).lower() for p in platforms} if isinstance(platforms, list) else set()
    ui_plats = plats & (set(UI_PLATFORM_VALIDATORS) | MOBILE_PLATFORMS)

    engine_kinds = _declared_engine_kinds(screen)

    required_phases = ["RESEARCH", "EXPLORE", "DEVELOP", "VERIFY", "REVIEW"]
    if ui_plats or engine_kinds:
        required_phases.append("VALIDATE")
    for ph in required_phases:
        if ph not in by_phase:
            fail(f"{sid} PASS is missing phase_runs entry for {ph}; the full workflow "
                 f"cycle is mandatory and cannot be skipped")

    def require_full_fanout(phase: str, needed: set[str], label: str) -> None:
        entries = by_phase.get(phase, [])
        for idx, run in enumerate(entries):
            # Name the entry when there is more than one, so "VERIFY is incomplete" never
            # reads as "VERIFY is missing" on a unit that recorded several passes.
            where = f"{phase}" if len(entries) == 1 else f"{phase} entry #{idx + 1}/{len(entries)}"
            if str(run.get("mode", "")).strip().lower() not in FANOUT_MODES:
                fail(f"{sid}.phase_runs[{where}].mode must be 'workflow' (or 'inline-fallback' "
                     f"only when Workflows are genuinely unavailable), not "
                     f"{run.get('mode')!r}; verifying inline without the fan-out is not allowed")
            # VERIFY only: a non-closing entry MAY be a legal triage pass (full_set:false),
            # naming in carried_forward[] the lenses it relies on from an earlier full pass.
            # The DEFAULT -- full_set absent, exactly what every entry recorded before this field
            # existed looks like -- still demands the complete set: this is opt-in per entry, never
            # the default, and that default is load-bearing (it is what keeps every already-closed
            # unit's evidence meaning exactly what it always meant). The CLOSING entry (the last
            # one recorded for this phase) is exempt from nothing: full_set may never be false
            # there, whether or not it carries carried_forward.
            is_closing = (idx == len(entries) - 1)
            full_set_flag = run.get("full_set", True)
            # A fail-fast pass stopped the serialized chain at the first lens that reported a
            # failure, so by construction it proves that something FAILED and nothing else was
            # even asked. Two things follow, and both were promised in prose (next-pantalla §6,
            # constitution.md, result.schema.json) while nothing checked them — the same
            # prose-without-a-control defect this file exists to close.
            #
            # This is deliberately NOT folded into the full_set branch below: an entry that
            # declares fail_fast:true but forgets full_set:false would otherwise slip past every
            # check here, which is exactly the shape a hand-written entry takes.
            if phase == "VERIFY" and run.get("fail_fast") is True:
                if is_closing:
                    fail(f"{sid}.phase_runs[{where}] declares fail_fast:true but is the CLOSING "
                         f"VERIFY entry — the pass this PASS verdict rests on. A fail-fast pass "
                         f"stops at the first failure and never asks the remaining lenses, so it "
                         f"can never be the pass that closes a unit")
                verdict = str(run.get("verdict", "")).strip().lower()
                if verdict and verdict != "fail":
                    fail(f"{sid}.phase_runs[{where}] declares fail_fast:true but its verdict is "
                         f"{run.get('verdict')!r}; fail-fast only ever fires ON a reported failure, "
                         f"so an entry claiming it while reporting anything else is describing a "
                         f"run that cannot have happened")
            if phase == "VERIFY" and full_set_flag is False:
                if is_closing:
                    fail(f"{sid}.phase_runs[{where}] is the closing VERIFY entry with "
                         f"full_set:false; the closing VERIFY entry before a unit closes must be "
                         f"full_set:true and run the complete {label} lens set — a triage pass may "
                         f"not be the pass that closes the unit")
                # carried_forward[] is a list of {lens, from_iteration} objects. The CITATION is
                # the whole point and not decoration: carrying a lens forward is a CLAIM — "this
                # lens's verdict from pass N still holds" — and a claim nobody can check is exactly
                # what the evidence standard forbids. A bare lens name would assert that some
                # earlier complete pass exists without ever naming it, so the entry could cite a
                # pass that never happened and nothing would notice.
                carried = run.get("carried_forward")
                carried_map: dict[str, Any] = {}
                if isinstance(carried, list):
                    for c in carried:
                        if not isinstance(c, dict):
                            fail(f"{sid}.phase_runs[{where}].carried_forward entries must be "
                                 f"objects {{lens, from_iteration}}, got {type(c).__name__}; a bare "
                                 f"lens name claims an earlier complete pass without naming it")
                        lens_name = str(c.get("lens", "")).strip()
                        if not lens_name:
                            fail(f"{sid}.phase_runs[{where}].carried_forward entry has no lens")
                        carried_map[lens_name] = c.get("from_iteration")
                if not carried_map:
                    fail(f"{sid}.phase_runs[{where}] is a non-closing VERIFY with full_set:false "
                         f"but carries no carried_forward[]; a triage pass must name which lenses "
                         f"of the full {label} set it relies on from an earlier full pass, or it is "
                         f"indistinguishable from evidence that was simply never produced")
                ran = _phase_lenses(run)
                unknown = sorted((ran | set(carried_map)) - needed)
                if unknown:
                    fail(f"{sid}.phase_runs[{where}] triage VERIFY names lenses outside the "
                         f"{label} set: {unknown}")
                gap = sorted(needed - (ran | set(carried_map)))
                if gap:
                    fail(f"{sid}.phase_runs[{where}] triage VERIFY: lenses[] + carried_forward[] "
                         f"together do not cover the full {label} set; missing: {gap}")
                # The citation must resolve to a real, EARLIER, genuinely complete VERIFY entry.
                # "Complete" is the same bar the closing pass meets: the full native lens set, no
                # carried_forward, no fail_fast — so triage can never be carried forward from
                # triage, which would let coverage decay one pass at a time while every single
                # entry still looked individually accounted for.
                # A complete entry that declares no `iteration` is the unit's BASELINE pass, which
                # by definition happened at checkpoint.iteration 0 (that is the value /next-pantalla
                # writes when it opens the unit). Defaulting it here rather than demanding the field
                # keeps every VERIFY entry written before `iteration` existed carryable-from, which
                # is the difference between a new field and a breaking change.
                complete_iters = set()
                for prev in entries[:idx]:
                    if (prev.get("full_set", True) is not False
                            and not prev.get("carried_forward")
                            and not prev.get("fail_fast")
                            and not (needed - _phase_lenses(prev))):
                        prev_iter = prev.get("iteration")
                        complete_iters.add(0 if prev_iter is None else prev_iter)
                if not complete_iters:
                    fail(f"{sid}.phase_runs[{where}] carries lenses forward but no COMPLETE "
                         f"{label} VERIFY entry precedes it; there is nothing to carry forward "
                         f"from. Run the full set first, then triage against it")
                for lens_name, cited in sorted(carried_map.items(), key=lambda kv: kv[0]):
                    if cited not in complete_iters:
                        fail(f"{sid}.phase_runs[{where}].carried_forward[{lens_name}] cites "
                             f"iteration {cited!r}, which is not the iteration of any complete "
                             f"{label} VERIFY entry recorded before it (complete passes are at "
                             f"iterations {sorted(i for i in complete_iters if i is not None)}); "
                             f"a stale or invented citation is not evidence")
                continue  # legal partial pass — the full-set check below does not apply to it
            missing = sorted(needed - _phase_lenses(run))
            if missing:
                fail(f"{sid}.phase_runs[{where}] did not run its full {label} lens set; "
                     f"missing: {missing}. Launch the workflow with ALL lenses (no subset). "
                     f"A partial pass is triage and may not be recorded at all.")

    # A lens name that is not in the roster cannot have run: phase_runs[] was pure
    # string-matching, so an invented lens satisfied the "full fan-out" requirement.
    if AGENTS.is_dir():
        for phase_name in sorted(by_phase):
            for run in by_phase[phase_name]:
                for lens in sorted(_phase_lenses(run)):
                    if not (AGENTS / f"{lens}.md").is_file():
                        fail(f"{sid}.phase_runs[{phase_name}] cites lens {lens!r} that is not in the "
                             f"agent roster (.claude/agents/{lens}.md does not exist); phase_runs "
                             f"may not name agents that cannot run")

    require_full_fanout("RESEARCH", RESEARCH_LENSES, f"research-fanout ({len(RESEARCH_LENSES)})")
    require_full_fanout("EXPLORE", EXPLORE_LENSES, f"explore-fanout (scout + {len(EXPLORE_LENSES) - 1})")
    require_full_fanout("VERIFY", VERIFY_LENSES, f"verify-fanout ({len(VERIFY_LENSES)})")

    # EXPLORE must leave its plan on disk. The section that produces it is literally called
    # "Explore AND PLAN": the lenses map the code, and the conductor turns that map into a
    # vertical plan — an acceptance map (one row per criterion: the IDs that govern it, the
    # files it will touch, how it will be proven, which artifact), the layer order, and the
    # unit's declared consumer. That plan existed only in the conductor's context, and three
    # things followed from it. A compaction mid-DEVELOP re-derived it from scratch. Nothing
    # could ever ask "was what was built what was planned?" — pantalla-reviewer judges code
    # against acceptance[], which is a different question. And a criterion with no answer to
    # "how will this be proven?" stayed invisible until VERIFY spent a 12-launch fan-out
    # discovering it, when the cheapest moment to notice was before a line was written.
    #
    # Retroactivity follows validate_source_manifest above: a unit a human already ACCEPTED
    # is not invalidated by a requirement that did not exist when it was signed — reopening
    # `accepted` is forbidden elsewhere in this file, so failing here would leave no legal
    # move. Anything still in flight owes the artifact.
    explore_runs = by_phase.get("EXPLORE", [])
    # The unit's own evidence directory, derived from the evidence_path this same validator
    # already forces into canonical form. Everything below is checked against it.
    evidence_dir = str(PurePosixPath(str(screen.get("evidence_path", "")).strip()).parent)
    for idx, run in enumerate(explore_runs):
        where = "EXPLORE" if len(explore_runs) == 1 else f"EXPLORE entry #{idx + 1}"
        soft = screen.get("status") == "accepted"
        # `or ""` and not a get() default: a JSON `"plan": null` HAS the key, so the default
        # never applies and str(None) == "None" would sail past the emptiness test and fail
        # later with "points at None", which reads like a path problem instead of a missing plan.
        plan_rel = str(run.get("plan") or "").strip()
        if not plan_rel:
            (warn if soft else fail)(
                f"{sid}.phase_runs[{where}] has no `plan`: EXPLORE must persist its vertical "
                f"plan to {evidence_dir}/plan.md and cite it here. A plan that lives only in "
                f"the conductor's context cannot survive a compaction and cannot be compared "
                f"against what was actually delivered")
            continue
        # CONTAINMENT, and it is doing more work than it looks. Without it the check proves
        # only that SOME non-empty file exists somewhere: `ROOT / "/etc/hosts"` discards ROOT
        # entirely (pathlib drops the left operand for an absolute right one) and enough `../`
        # walks out of the tree, so any readable file on the machine satisfied "EXPLORE wrote
        # its plan". It also closes the borrowed-evidence hole `validate_result` already closes
        # for result.json by matching screen_id: citing a SIBLING unit's plan.md passed too.
        # A check that anything can satisfy is worse than no check — it reports coverage it
        # does not have, which is the exact defect the evidence standard exists to prevent.
        norm = PurePosixPath(plan_rel.replace("\\", "/"))
        if (not evidence_dir or evidence_dir == "." or norm.is_absolute()
                or ".." in norm.parts or not str(norm).startswith(evidence_dir + "/")):
            (warn if soft else fail)(
                f"{sid}.phase_runs[{where}].plan must be a repo-relative path inside this "
                f"unit's own evidence directory ({evidence_dir}/), not {plan_rel!r}. A plan "
                f"outside it proves nothing about THIS unit — an absolute path, a `..` escape "
                f"or a sibling unit's plan would all satisfy a bare existence check")
            continue
        plan_path = ROOT / norm
        if not plan_path.is_file():
            (warn if soft else fail)(
                f"{sid}.phase_runs[{where}].plan points at {plan_rel}, which is not a file")
        elif plan_path.stat().st_size == 0:
            (warn if soft else fail)(
                f"{sid}.phase_runs[{where}].plan is an empty (0-byte) file: {plan_rel}")

    if ui_plats or engine_kinds:
        validate_entries = by_phase.get("VALIDATE", [])
        for idx, run in enumerate(validate_entries):
            where = ("VALIDATE" if len(validate_entries) == 1
                     else f"VALIDATE entry #{idx + 1}/{len(validate_entries)}")
            if str(run.get("mode", "")).strip().lower() not in FANOUT_MODES:
                fail(f"{sid}.phase_runs[{where}].mode must be 'workflow' (or 'inline-fallback'), "
                     f"not {run.get('mode')!r}; driving the live runtime inline without the "
                     f"validate-live fan-out is not allowed")
            got = _phase_lenses(run)
            needed = {"validate-logs"}
            for plat in ui_plats:
                validator = UI_PLATFORM_VALIDATORS.get(plat)
                if validator:
                    needed.add(validator)
            # A declared engine/pipeline contract must be RUN, not merely read. This mirrors the
            # UI rule: static verification never substitutes for the live runtime.
            for kind in engine_kinds:
                needed.add(ENGINE_VALIDATORS[kind])
            if "mobile" in ui_plats and not ({"validate-android", "validate-ios"} & got):
                fail(f"{sid}.phase_runs[{where}] owns a mobile surface but ran no "
                     f"validate-android/validate-ios lens")
            missing = sorted(needed - got)
            if missing:
                fail(f"{sid}.phase_runs[{where}] missing required live validators: {missing} "
                     f"(validate-logs + validate-<owned platform> + validate-engine/pipeline "
                     f"for a declared ENG-*/PIPE-* contract)")

    review_entries = by_phase.get("REVIEW", [])
    for idx, run in enumerate(review_entries):
        if "pantalla-reviewer" not in _phase_lenses(run):
            where = ("REVIEW" if len(review_entries) == 1
                     else f"REVIEW entry #{idx + 1}/{len(review_entries)}")
            fail(f"{sid}.phase_runs[{where}] must record the pantalla-reviewer sign-off")


def validate_evidence_floor(screen: dict[str, Any], result: dict[str, Any], path: Path) -> None:
    """Minimum live-proof floor for declared UI surfaces. The data path already
    has a floor (data_engine_assertions); this mirrors it for web/mobile so a UI
    screen cannot pass with no screenshot/console/device-log evidence."""
    platforms = screen.get("platforms", [])
    plats = {str(p).lower() for p in platforms} if isinstance(platforms, list) else set()
    artifact_paths = [p.lower() for p in _collect_artifact_paths(result)]

    def has(predicate) -> bool:
        return any(predicate(p) for p in artifact_paths)

    def is_screenshot(p: str) -> bool:
        return "screenshot" in p or p.endswith((".png", ".jpg", ".jpeg", ".webp"))

    def is_console(p: str) -> bool:
        return "console" in p

    def is_network(p: str) -> bool:
        return "network" in p

    def is_device_log(p: str) -> bool:
        return any(tag in p for tag in ("logcat", "idb", "flutter", "ios-log", "ios_log"))

    sid = screen.get("id", "<unknown>")
    if "web" in plats:
        if not has(is_screenshot):
            fail(f"{sid} web PASS requires at least one screenshot artifact")
        if not (has(is_console) or has(is_network)):
            fail(f"{sid} web PASS requires a console or network evidence artifact")
    if plats & MOBILE_PLATFORMS:
        if not has(is_screenshot):
            fail(f"{sid} mobile PASS requires at least one screenshot artifact")
        if not has(is_device_log):
            fail(f"{sid} mobile PASS requires a device log artifact (logcat/idb/flutter)")


def _refs_from_feature(screen: dict[str, Any]) -> set[str]:
    refs: set[str] = set()
    for key in ["applies"]:
        for item in screen.get(key, []) if isinstance(screen.get(key, []), list) else []:
            if isinstance(item, str):
                refs.add(item)
    source = screen.get("source", {})
    if isinstance(source, dict):
        for key in ["logic_refs", "product_refs"]:
            for item in source.get(key, []) if isinstance(source.get(key, []), list) else []:
                if isinstance(item, str):
                    refs.add(item)
    for ac in screen.get("acceptance", []) if isinstance(screen.get("acceptance", []), list) else []:
        if isinstance(ac, dict):
            for item in ac.get("refs", []) if isinstance(ac.get("refs", []), list) else []:
                if isinstance(item, str):
                    refs.add(item)
    return refs


def arch_hash() -> str:
    """sha256 over the architecture-bearing blueprint files, order-stable."""
    digest = hashlib.sha256()
    for rel in ARCH_HASH_FILES:
        fp = ROOT / rel
        digest.update(rel.encode("utf-8") + b"\0")
        digest.update((fp.read_bytes() if fp.is_file() else b"<absent>") + b"\0")
    return "sha256:" + digest.hexdigest()


def validate_architecture_review(meta: dict[str, Any]) -> None:
    """Validate meta.architecture_review WHEN PRESENT — never require it here.

    Non-retroactive by design: requiring the key unconditionally would brick every
    already-initialized project the moment the gate shipped (the hook runs this whole
    validator on every features.json write). Presence is demanded only by --init-gate,
    which /init-build alone invokes: a project cannot be BORN without the gate, but no
    existing state dies because of it."""
    review = meta.get("architecture_review")
    if review is None:
        return
    if not isinstance(review, dict):
        fail("meta.architecture_review must be an object")
    status = str(review.get("status", "")).strip()
    if status not in ARCH_REVIEW_STATUSES:
        fail(f"meta.architecture_review.status invalid: {review.get('status')!r} "
             f"(must be one of {sorted(ARCH_REVIEW_STATUSES)})")
    if review.get("open_blockers"):
        fail(f"meta.architecture_review.open_blockers is non-empty: resolve each blocker "
             f"(emit a foundation unit, accept the risk via a DEC-*, or defer it with a "
             f"trip-wire) before the state is valid")
    if review.get("failed_lenses"):
        fail(f"meta.architecture_review.failed_lenses is non-empty: "
             f"{review.get('failed_lenses')}; re-run /arch-review with the full lens set")
    lenses = review.get("lenses")
    got = {str(x).strip() for x in lenses} if isinstance(lenses, list) else set()
    if got != ARCH_LENSES:
        fail(f"meta.architecture_review.lenses must be the full arch set "
             f"{sorted(ARCH_LENSES)}; got {sorted(got)}")
    # The architecture trip-wire, moved out of prose. reslice/SKILL.md already SAYS to compare
    # `--arch-hash` against this field before reusing an old review, but nothing checked it, so
    # the one mechanism that re-opens /arch-review automatically was a sentence somebody had to
    # remember. Two different failures, deliberately treated differently:
    #
    #  - ABSENT is a hard fail. A record with no seal cannot detect drift AT ALL, now or ever;
    #    it is the un-measurable case, not the changed one.
    #  - MISMATCH is a WARNING, not a failure, and that asymmetry is load-bearing. arch_hash()
    #    digests whole file bytes, so ANY edit moves it — including the editorial and additive
    #    tiers that constitution.md explicitly says do NOT route through /reslice. Failing here
    #    would make every routine blueprint write-back brick the gate until someone re-ran the
    #    architecture review, which would punish exactly the habit the living-spec rule exists
    #    to encourage. The drift still has to be SEEN; it just must not stop the build.
    stored_hash = str(review.get("architecture_hash", "")).strip().lower().removeprefix("sha256:")
    if not stored_hash:
        fail("meta.architecture_review.architecture_hash missing: the machine record must be "
             "sealed against the architecture-bearing blueprint files it reviewed (write it from "
             "`python3 .orchestrator/scripts/validate-state.py --arch-hash`), or drift after the "
             "review can never be detected")
    elif stored_hash != arch_hash().lower().removeprefix("sha256:"):
        warn("meta.architecture_review.architecture_hash no longer matches the "
             "architecture-bearing blueprint files: the design has changed since /arch-review "
             "ran. If the change was contractual, run /reslice (it re-triggers the review and "
             "re-seals this field); if it was editorial or additive, re-seal with "
             "`--arch-hash` so the next drift is visible against the current baseline")
    report_sha = str(review.get("report_sha256", "")).strip().lower().removeprefix("sha256:")
    report = STATE / "evidence" / "APP-INTEGRATION" / "reports" / "arch-review.md"
    if not report.is_file():
        fail("meta.architecture_review present but the report "
             ".orchestrator-state/evidence/APP-INTEGRATION/reports/arch-review.md does not exist")
    actual = hashlib.sha256(report.read_bytes()).hexdigest()
    if not report_sha:
        fail("meta.architecture_review.report_sha256 missing: the machine record must be "
             "sealed against the human-readable report")
    if report_sha != actual:
        fail("meta.architecture_review.report_sha256 does not match the report on disk; "
             "re-run /arch-review instead of editing either side by hand")
    for i, risk in enumerate(review.get("accepted_risks") or []):
        if not isinstance(risk, dict) or not all(
            str(risk.get(k, "")).strip() for k in ("finding_id", "rationale", "decided_by")
        ):
            fail(f"meta.architecture_review.accepted_risks[{i}] must carry finding_id, "
                 f"rationale and decided_by (a person) — an unsigned risk is not accepted")
    for i, item in enumerate(review.get("deferred") or []):
        if not isinstance(item, dict) or not str(item.get("trip_wire", "")).strip():
            fail(f"meta.architecture_review.deferred[{i}] must name a trip_wire "
                 f"(the DATA-*/ENG-*/PIPE-* whose change reopens the finding)")


def validate_discovery(meta: dict[str, Any]) -> None:
    """Validate meta.discovery WHEN PRESENT — never require it here.

    Non-retroactive for the same reason as meta.architecture_review: the hook runs this
    whole validator on every features.json write, so demanding the key unconditionally
    would brick every already-initialized project. Presence is demanded only by
    --init-gate, which /init-build alone invokes."""
    record = meta.get("discovery")
    if record is None:
        return
    if not isinstance(record, dict):
        fail("meta.discovery must be an object")
    if str(record.get("status", "")).strip() != "complete":
        fail(f"meta.discovery.status invalid: {record.get('status')!r} (must be \"complete\" — "
             f"a partial discovery is recorded nowhere, not half-recorded)")
    if record.get("failed_lenses"):
        fail(f"meta.discovery.failed_lenses is non-empty: {record.get('failed_lenses')}; "
             f"re-run /discovery with the full lens set")
    if record.get("unresolved"):
        fail(f"meta.discovery.unresolved is non-empty: {record.get('unresolved')}; every "
             f"checklist item needs a disposition — resolve them and re-run /discovery")
    lenses = record.get("lenses")
    got = {str(x).strip() for x in lenses} if isinstance(lenses, list) else set()
    if got != DISCOVERY_LENSES:
        fail(f"meta.discovery.lenses must be the full discovery set "
             f"{sorted(DISCOVERY_LENSES)}; got {sorted(got)}")
    total = record.get("items_total")
    if not isinstance(total, int) or total < 1:
        fail("meta.discovery.items_total must be a positive integer (the checklist is never empty)")
    counts = record.get("dispositions")
    if not isinstance(counts, dict) or set(counts) != set(DISCOVERY_DISPOSITIONS) or not all(
        isinstance(counts[k], int) and counts[k] >= 0 for k in DISCOVERY_DISPOSITIONS
    ):
        fail(f"meta.discovery.dispositions must carry non-negative integer counts for exactly "
             f"{list(DISCOVERY_DISPOSITIONS)}")
    if sum(counts[k] for k in DISCOVERY_DISPOSITIONS) != total:
        fail("meta.discovery.dispositions must sum to items_total — an item outside the "
             "counts is an item without a disposition")
    report = STATE / "evidence" / "APP-INTEGRATION" / "reports" / "discovery.md"
    if not report.is_file():
        fail("meta.discovery present but the report "
             ".orchestrator-state/evidence/APP-INTEGRATION/reports/discovery.md does not exist")
    report_sha = str(record.get("report_sha256", "")).strip().lower().removeprefix("sha256:")
    if not report_sha:
        fail("meta.discovery.report_sha256 missing: the machine record must be sealed "
             "against the human-readable report")
    if report_sha != hashlib.sha256(report.read_bytes()).hexdigest():
        fail("meta.discovery.report_sha256 does not match the report on disk; "
             "re-run /discovery instead of editing either side by hand")


def validate_feature_traceability(screen: dict[str, Any], blueprint_ids: set[str]) -> None:
    """Every rule ID a unit cites must exist in the blueprint.

    conventions.md promises traceability, but nothing enforced it: `applies: ["DATA-999"]`
    passed the gate AND the linter, and a phantom `DATA-` prefix even triggered the
    data_engine requirement while a phantom without a known prefix was inert. Skipped
    when the blueprint defines nothing (a bare scaffold) so /init-build can still run."""
    if not blueprint_ids:
        return
    sid = screen.get("id", "<unknown>")
    unknown = sorted(
        ref for ref in _refs_from_feature(screen)
        if ref.startswith(REF_PREFIXES) and ref not in blueprint_ids
    )
    if unknown:
        fail(f"{sid} cites rule IDs no blueprint file defines: {unknown}; a plan may not "
             f"reference intent that does not exist (fix the blueprint or the citation)")


def feature_has_data_contract(screen: dict[str, Any]) -> bool:
    refs = _refs_from_feature(screen)
    if any(ref.startswith("DATA-") for ref in refs):
        return True
    verify = screen.get("verify", {})
    if isinstance(verify, dict) and verify.get("data_checks"):
        return True
    engine = screen.get("data_engine")
    # An empty {} is NOT a data contract: a data engine must carry real shape.
    return isinstance(engine, dict) and bool(engine) and not engine.get("not_applicable_reason")


def validate_feature_data_engine(screen: dict[str, Any]) -> None:
    sid = screen.get("id", "<unknown>")
    if not feature_has_data_contract(screen):
        return
    engine = screen.get("data_engine")
    if not isinstance(engine, dict):
        fail(f"{sid} has data contract but missing data_engine")
    if engine.get("not_applicable_reason"):
        # not_applicable may not coexist with a cited DATA-* ref or declared data_checks.
        refs = _refs_from_feature(screen)
        if any(ref.startswith("DATA-") for ref in refs):
            fail(f"{sid}.data_engine.not_applicable_reason set but feature cites DATA-* refs")
        verify = screen.get("verify", {})
        if isinstance(verify, dict) and verify.get("data_checks"):
            fail(f"{sid}.data_engine.not_applicable_reason set but verify.data_checks[] is non-empty")
        return
    store = engine.get("canonical_store")
    if not isinstance(store, dict):
        fail(f"{sid}.data_engine.canonical_store must be object")
    kind = store.get("kind")
    if not isinstance(kind, str) or not kind.strip():
        fail(f"{sid}.data_engine.canonical_store.kind must be a non-empty string "
             f"(the stack's system of record: database, event_store, ledger, file_store, ...)")
    source_of_truth = store.get("source_of_truth")
    if not isinstance(source_of_truth, str) or not source_of_truth.strip():
        fail(f"{sid}.data_engine.canonical_store.source_of_truth must be a non-empty string")
    if _has_client_token(source_of_truth) or _has_client_token(kind):
        fail(f"{sid}.data_engine.canonical_store declares a client layer as system of record "
             f"(source_of_truth={source_of_truth!r}, kind={kind!r}); the source of truth must "
             f"never be a frontend/client")
    resources = store.get("resources")
    if not isinstance(resources, list) or not resources:
        fail(f"{sid}.data_engine.canonical_store.resources must be non-empty")
    pipeline = engine.get("pipeline")
    if not isinstance(pipeline, dict):
        fail(f"{sid}.data_engine.pipeline must be object")
    persists = pipeline.get("writes_to_canonical_store")
    if persists is None:
        persists = pipeline.get("writes_to_database")
    if persists is None:
        persists = pipeline.get("persists")
    if persists is not True:
        fail(f"{sid}.data_engine.pipeline must persist to the canonical store "
             f"(set writes_to_canonical_store/writes_to_database/persists = true)")
    read_path = pipeline.get("read_path")
    if not isinstance(read_path, list) or not read_path:
        fail(f"{sid}.data_engine.pipeline.read_path must be non-empty")
    steps = [str(step).lower() for step in read_path]

    def _step_matches(step: str, tokens: set[str]) -> bool:
        return any(tok in step for tok in tokens)

    # POSITIONAL, not "somewhere in the concatenation". The read path is a direction —
    # store -> transport -> client — so a reversed path used to pass, and a single step
    # could satisfy two layers at once. canonical_tokens deliberately does NOT include
    # source_of_truth itself: seeding it let the declaration bless its own read path.
    canonical_tokens = {
        kind.strip().lower(),
        "canonical", "source", "store", "database", "db", "event", "ledger", "log",
        "stream", "projection", "checkpoint", "file", "bucket", "object", "warehouse",
        "lake", "system-of-record", "system_of_record", "record",
    }
    if not _step_matches(steps[0], canonical_tokens):
        fail(f"{sid}.data_engine.pipeline.read_path must START at the canonical store "
             f"({source_of_truth}); first step is {read_path[0]!r}")
    transport_idx = next(
        (i for i, step in enumerate(steps) if _step_matches(step, TRANSPORT_TOKENS)), None
    )
    if transport_idx is None:
        fail(f"{sid}.data_engine.pipeline.read_path must include a transport/read layer "
             f"(api/service/read-model/...)")
    if transport_idx == 0:
        fail(f"{sid}.data_engine.pipeline.read_path step {read_path[0]!r} is both the canonical "
             f"store and the transport layer; they must be distinct steps")
    svc_contract = engine.get("single_value_contract")
    if not isinstance(svc_contract, list) or not svc_contract:
        fail(f"{sid}.data_engine.single_value_contract must be non-empty")
    for entry in svc_contract:
        if not isinstance(entry, dict):
            fail(f"{sid}.data_engine.single_value_contract entries must be objects")
        if not str(entry.get("field", "")).strip():
            fail(f"{sid}.data_engine.single_value_contract entry missing field")
        source_map = entry.get("db_source") or entry.get("source") or entry.get("store_source")
        client_map = entry.get("ui_field") or entry.get("client_field") or entry.get("visible_field")
        if not str(source_map or "").strip():
            fail(f"{sid}.data_engine.single_value_contract field '{entry.get('field')}' "
                 f"missing source mapping (db_source/source/store_source)")
        if not str(client_map or "").strip():
            fail(f"{sid}.data_engine.single_value_contract field '{entry.get('field')}' "
                 f"missing client mapping (ui_field/client_field/visible_field)")
    verify = screen.get("verify", {})
    data_checks = verify.get("data_checks") if isinstance(verify, dict) else None
    if not isinstance(data_checks, list) or not data_checks:
        fail(f"{sid} has data_engine but missing verify.data_checks[]")


def _layer_declared_absent(screen: dict[str, Any], layer: str) -> bool:
    """True when the FEATURE itself declares this layer n/a for every mapped field.

    The exemption below is anchored here on purpose. A unit must not be able to
    excuse itself in the result it writes ABOUT itself: the only way to skip a layer
    is for `data_engine.single_value_contract` — compiled from the blueprint and
    reviewed like the rest of the plan — to already say that field is not applicable.
    """
    engine = screen.get("data_engine")
    if not isinstance(engine, dict):
        return False
    contract = engine.get("single_value_contract")
    if not isinstance(contract, list) or not contract:
        return False
    field_keys = {
        "transport": ("api_field", "service_field", "transport_field", "read_model_field"),
        "client": ("ui_field", "client_field", "visible_field"),
    }.get(layer, ())
    declared = []
    for entry in contract:
        if not isinstance(entry, dict):
            return False
        value = next((entry[k] for k in field_keys if k in entry), None)
        if value is None:
            return False
        declared.append(str(value).strip().lower())
    return bool(declared) and all(v.startswith("n/a") for v in declared)


def validate_data_engine_assertions(screen: dict[str, Any], result: dict[str, Any]) -> None:
    """Make same_value FALSIFIABLE. Each assertion must carry the observed literal
    db_value/api_value/ui_value (plus optional platform_values); the validator
    recomputes equality from those literals instead of trusting the flag.

    A layer may be SKIPPED only when the feature's own `single_value_contract`
    declares it `n/a` AND the assertion names it in `layers_not_applicable` with a
    reason. That exists because the three-layer model could not express a canonical
    value that, by product rule, never reaches a client — `SCR-FOUNDATION-ENGINES`'
    matching trace is forbidden from being shown (BR-003), so demanding an
    `api_value` and a `ui_value` left only two options: fabricate two literals, or
    never pass. The first is the fabricated evidence this function exists to stop.
    The canonical layer is never skippable, and any layer that IS present is still
    compared literally, so the control is unchanged wherever a client exists.
    """
    sid = screen["id"]
    assertions = result.get("data_engine_assertions")
    if not isinstance(assertions, list) or not assertions:
        fail(f"{sid} PASS requires data_engine_assertions[]")
    for assertion in assertions:
        if not isinstance(assertion, dict):
            fail(f"{sid} data_engine_assertions entries must be objects")
        aid = assertion.get("id", "<missing>")
        exempt = assertion.get("layers_not_applicable")
        exempt = exempt if isinstance(exempt, dict) else {}
        observed: list[tuple[str, Any]] = []
        for label, keys in (
            ("canonical", CANONICAL_VALUE_KEYS),
            ("transport", TRANSPORT_VALUE_KEYS),
            ("client", CLIENT_VALUE_KEYS),
        ):
            present = [(k, assertion[k]) for k in keys if k in assertion]
            if not present:
                reason = str(exempt.get(label, "")).strip()
                if label != "canonical" and reason and _layer_declared_absent(screen, label):
                    continue
                if label != "canonical" and reason:
                    fail(f"{sid} data_engine_assertion {aid} declares {label} not applicable, but "
                         f"data_engine.single_value_contract does not mark that layer n/a")
                fail(f"{sid} data_engine_assertion {aid} missing observed {label} value (one of {list(keys)})")
            observed.extend(present)
        platform_values = assertion.get("platform_values")
        if isinstance(platform_values, dict):
            for plat, val in platform_values.items():
                observed.append((f"platform:{plat}", val))
        normalized: list[str] = []
        for key, value in observed:
            nv = _norm(value)
            if nv is None or nv == "":
                fail(f"{sid} data_engine_assertion {aid} has empty observed value for {key}")
            normalized.append(nv)
        if any(nv != normalized[0] for nv in normalized):
            shown = {k: v for k, v in observed}
            fail(f"{sid} data_engine_assertion {aid}: observed values differ across layers: {shown}")
        if assertion.get("same_value") is not True:
            fail(f"{sid} data_engine_assertion {aid} must set same_value=true when observed values match")


def validate_features(evidence_rows: list[dict[str, Any]] | None = None,
                      init_gate: bool = False) -> dict[str, Any]:
    data = load_json(FEATURES)
    if not isinstance(data, dict):
        fail("features.json root must be object")
    if schema_name(data) != "orchestrator.features.v1":
        fail("features.json schema_version must be orchestrator.features.v1")
    for key in ["version", "initialized", "project", "source_files", "rules_index", "screens"]:
        if key not in data:
            fail(f"features.json missing {key}")
    if not isinstance(data["initialized"], bool):
        fail("features.initialized must be boolean")
    screens = data["screens"]
    if not isinstance(screens, list):
        fail("features.screens must be array")
    meta = data.get("meta", {}) if isinstance(data.get("meta", {}), dict) else {}
    validate_architecture_review(meta)
    validate_discovery(meta)
    lifecycle = meta.get("lifecycle")
    if data["initialized"] is False:
        if screens:
            fail("initialized=false requires screens=[]")
        if lifecycle and lifecycle != "scaffold-placeholder":
            fail("initialized=false requires meta.lifecycle scaffold-placeholder")
        return data
    if not screens:
        fail("initialized=true requires screens[]")

    # Deterministic backstop for unresolved stack commands. Once the project is initialized,
    # every verifier depends on the real install/dev/test/migrate/seed/smoke/build commands
    # in stack.md. Detecting the <COMMAND_*> placeholders was prose-to-an-LLM-lens only
    # (explore-config/explore-scout); if that lens skipped it after a compaction, nothing
    # caught it. A built project that still carries placeholders cannot verify anything.
    stack = ROOT / ".claude" / "rules" / "stack.md"
    if stack.is_file():
        # [A-Z_]+, not [A-Z]+. The narrow class silently excused every multi-word key, and there
        # is exactly one: <COMMAND_RESET_TEST_DATA> — the command in the hot path, run before
        # VERIFY, before VALIDATE and before every debugger re-run. A project could be born with
        # it unresolved, the gate would say nothing, and no phase would ever reset the store.
        leftover = sorted(set(re.findall(r"<COMMAND_[A-Z_]+>", stack.read_text(encoding="utf-8"))))
        # One of them is legitimately optional, and stack.md says so in writing: a project with no
        # test-data store leaves it, and reset-test-data.sh "reports that distinctly and never
        # blocks". Failing on it would make the gate contradict the contract the scaffold ships,
        # so it warns — visible, never fatal — while the other nine stay hard failures.
        optional = {"<COMMAND_RESET_TEST_DATA>"}
        blocking = [x for x in leftover if x not in optional]
        if blocking:
            fail(f".claude/rules/stack.md still holds unresolved command placeholders {blocking} "
                 f"while features.json is initialized=true; /init-build must resolve every "
                 f"<COMMAND_*> (or the verifiers have no real commands to run)")
        for x in leftover:
            if x in optional:
                warn(f".claude/rules/stack.md leaves {x} unresolved. Legal only if this project "
                     f"genuinely has no test-data store; if it has one, every VERIFY and VALIDATE "
                     f"phase is running against whatever the previous phase left behind")

    # The two §5.5 auto-gates, checked BY ID.
    #
    # accept/SKILL.md has always required both of these in checks[] with passed:true, and the
    # rule has always been prose read by whoever ran /accept. Nothing verified it. A unit could
    # reach verified — and be accepted — having never run either gate, and the absence looked
    # exactly like a unit that ran them and passed: an empty checks[] is not distinguishable
    # from a complete one unless something knows the names to look for.
    #
    # It matters more now that /accept --auto exists: an automatic acceptance reading a rule
    # that nothing enforces is the whole failure mode this repo keeps closing. The names are
    # fixed by convention (conventions.md, "Evidence names"), so the check is deterministic.
    #
    # PIPELINES-DATA may legitimately be `required:false, passed:true, notes:"not applicable"`
    # for a unit with no data engine — present-but-not-applicable is a recorded decision;
    # missing is a gate that never ran.
    for screen in screens:
        if screen.get("status") not in {"verified", "accepted"}:
            continue
        sid = screen["id"]
        evidence = ROOT / str(screen.get("evidence_path") or "")
        if not evidence.is_file():
            continue
        checks = (load_json(evidence) or {}).get("checks") or []
        by_check = {c.get("id"): c for c in checks if isinstance(c, dict)}
        for suffix in ("PRODUCTION-CODE-REVIEW", "PIPELINES-DATA-ULTRACODE"):
            cid = f"CHK-{sid}-{suffix}"
            check = by_check.get(cid)
            if check is None:
                fail(f"{sid} is {screen['status']} but {evidence} has no check {cid}; the "
                     f"/next-pantalla §5.5 auto-gate never ran. A missing gate check is not "
                     f"the same as a passing one — run the gate, or the unit is not verifiable")
            if check.get("passed") is not True:
                fail(f"{sid} is {screen['status']} but {cid} is not passed:true; a failing "
                     f"auto-gate check keeps the unit un-verified")

    # Deterministic backstop for AUTOMATIC acceptance — the exact mirror of the <COMMAND_*>
    # check above, and for the same reason.
    #
    # /accept --auto may only run against a RESOLVED policy: accept/SKILL.md step 3b requires
    # that .claude/rules/autonomy.md carry no unresolved <PLACEHOLDER> in the sections it
    # relies on. That requirement was prose-to-an-agent, which is precisely the arrangement
    # this repo refuses to trust anywhere else. An unfilled policy has authorized nothing, and
    # reading `<AUTO_ACCEPT_SEVERITY_CEILING>` as permission is the one failure that would
    # make the whole mechanism dishonest — it would produce units marked "accepted by policy"
    # where no policy existed, and nothing downstream could tell them apart.
    #
    # Checked only when a unit actually claims automatic acceptance, so an unfilled autonomy.md
    # never blocks a project that only ever accepts by hand.
    auto_accepted = []
    for screen in screens:
        if screen.get("status") != "accepted":
            continue
        evidence = ROOT / str(screen.get("evidence_path") or "")
        if not evidence.is_file():
            continue
        try:
            gate = (load_json(evidence) or {}).get("human_gate") or {}
        except SystemExit:
            continue
        if gate.get("accepted_by") == "auto":
            auto_accepted.append((screen["id"], gate))

    if auto_accepted:
        policy = ROOT / ".claude" / "rules" / "autonomy.md"
        if not policy.is_file():
            fail(f"{[sid for sid, _ in auto_accepted]} were accepted by policy "
                 f"(human_gate.accepted_by='auto') but .claude/rules/autonomy.md does not "
                 f"exist; nothing authorized those acceptances")
        # NOTE: every real field in autonomy.md is written `<LIKE_THIS>`, backticks included, so
        # a backtick-aware regex cannot tell a field from a prose example — it would have to
        # exclude all of them. The fix therefore lives in the FILE, not here: autonomy.md no
        # longer quotes a placeholder-shaped token in its explanatory prose. Keep it that way;
        # this check is what stops an auto-accept resting on a policy nobody filled in.
        leftover = sorted(set(re.findall(r"<[A-Z][A-Z0-9_]{2,}>",
                                         policy.read_text(encoding="utf-8"))))
        if leftover:
            fail(f"{[sid for sid, _ in auto_accepted]} were accepted by policy "
                 f"(human_gate.accepted_by='auto') while .claude/rules/autonomy.md still "
                 f"holds unresolved placeholders {leftover[:6]}; an unfilled policy "
                 f"authorizes nothing — resolve it, or accept those units by hand")
        for sid, gate in auto_accepted:
            # accept --auto step 3b refuses a unit with an open finding at or above the
            # policy's severity ceiling, and reads advisory_findings[] to find out. An ABSENT
            # array is not "no findings" — it is "nobody wrote any down", and the two are
            # indistinguishable to a reader. An empty array IS a statement; omission is not.
            screen = next((s for s in screens if s["id"] == sid), {})
            evidence = ROOT / str(screen.get("evidence_path") or "")
            if evidence.is_file():
                res = load_json(evidence) or {}
                if not isinstance(res.get("advisory_findings"), list):
                    fail(f"{sid} was accepted by policy but its result.json has no "
                         f"advisory_findings[]; --auto must check findings against the severity "
                         f"ceiling and an absent array is not the same as an empty one. Record "
                         f"[] explicitly when the gates raised nothing")
            if not gate.get("policy_rule"):
                fail(f"{sid} has human_gate.accepted_by='auto' with no policy_rule; an "
                     f"automatic acceptance that cannot name the rule that authorized it "
                     f"is indistinguishable from one nobody authorized")

    blueprint_ids = _blueprint_ids()
    ids: list[str] = []
    counts: Counter = Counter()
    for idx, screen in enumerate(screens):
        if not isinstance(screen, dict):
            fail(f"screens[{idx}] must be object")
        for key in [
            "id", "slug", "title", "kind", "platforms", "order", "after", "status",
            "passes", "acceptance", "verify", "evidence_path", "blocked_reason", "notes",
        ]:
            if key not in screen:
                fail(f"screens[{idx}] missing {key}")
        sid = screen["id"]
        if not isinstance(sid, str) or not sid.startswith("SCR-"):
            fail(f"screens[{idx}].id must start with SCR-")
        ids.append(sid)
        status = screen["status"]
        counts[status] += 1
        if status not in VALID_STATUS:
            fail(f"{sid} status invalid: {status}")
        if not isinstance(screen["passes"], bool):
            fail(f"{sid}.passes must be boolean")
        if screen["passes"] and status not in PASS_STATUSES:
            fail(f"{sid} passes=true requires status verified or accepted")
        if status in PASS_STATUSES and not screen["passes"]:
            fail(f"{sid} status {status} requires passes=true")
        if status == "blocked" and not str(screen.get("blocked_reason", "")).strip():
            fail(f"{sid} is blocked without blocked_reason")
        if not isinstance(screen["after"], list):
            fail(f"{sid}.after must be array")
        if not isinstance(screen["acceptance"], list):
            fail(f"{sid}.acceptance must be array")
        if not isinstance(screen["verify"], dict):
            fail(f"{sid}.verify must be object")
        expected = f".orchestrator-state/evidence/{sid}/result.json"
        if screen["evidence_path"] != expected:
            fail(f"{sid}.evidence_path must be {expected}")
        plats = (
            {str(p).lower() for p in screen["platforms"]}
            if isinstance(screen["platforms"], list) else set()
        )
        if _is_ui_surface(screen) and not (plats & (set(UI_PLATFORM_VALIDATORS) | MOBILE_PLATFORMS)):
            fail(f"{sid} is a UI surface (kind 'ui' / UI primary_verifier / client route) but "
                 f"declares no UI platform in platforms[]; add web/android/ios so VALIDATE cannot "
                 f"be silently skipped. A genuine backend-only unit must not look like a UI surface.")
        # Optional per-screen checkpoint written by /next-pantalla: {phase, iteration}.
        # Turns the "maximum 3 debugger iterations" prose into a gate, and lets a
        # crashed/compacted session resume the active unit from disk.
        checkpoint = screen.get("checkpoint")
        if checkpoint is not None:
            if not isinstance(checkpoint, dict):
                fail(f"{sid}.checkpoint must be object {{phase, iteration}}")
            iteration = checkpoint.get("iteration", 0)
            if not isinstance(iteration, int) or iteration < 0:
                fail(f"{sid}.checkpoint.iteration must be a non-negative integer")
            # The cap is 3. Past it, constitution.md sanctions exactly two moves:
            # `blocked`, or A HUMAN DECISION. The gate could only express the first,
            # so a human who authorised one more pass had no way to say so and the
            # conductor's only representable option contradicted the rule it was
            # following. `cap_override` is that second move, and it is deliberately
            # expensive to write: an explicit reason naming who decided, so the cap
            # can never be exceeded silently — which is the only thing it was ever
            # protecting against. An override without a reason is still refused.
            override = checkpoint.get("cap_override")
            if iteration > 3:
                reason = override.get("reason") if isinstance(override, dict) else None
                decided_by = override.get("decided_by") if isinstance(override, dict) else None
                if not (isinstance(reason, str) and reason.strip()
                        and isinstance(decided_by, str) and decided_by.strip()):
                    fail(f"{sid}.checkpoint.iteration is {iteration}: the debugger loop cap is 3. "
                         f"Past it the only honest moves are `blocked` (with reason and "
                         f"reproduction) or an explicit human decision recorded as "
                         f"checkpoint.cap_override {{decided_by, reason}} — never a silent "
                         f"fourth pass")
        # LIFETIME repair counter — the cap that checkpoint.iteration is not.
        #
        # The cap above bounds ONE `building` episode. But §7 CLEARS `checkpoint` when a unit
        # closes, and each of the four REOPEN routes (/review-pantalla,
        # /verify-pipelines-data-ultracode, /production-code-review, /fix) then writes
        # `iteration: <previous+1>` onto that cleared field — which evaluates to 1. So a unit
        # bounced verified -> building -> verified never trips the per-episode cap, however many
        # times it goes round. Measured in a real project: one unit reached 14 VERIFY and 10
        # REVIEW runs under a nominal cap of 3.
        #
        # This field is OPTIONAL and defaults to 0, so every existing unit (and the whole
        # scaffold) stays valid; the four REOPEN routes increment it and nothing ever clears it.
        # Retroactivity is split as elsewhere in this file: HARD while the unit can still act on
        # it, a WARNING once `accepted` — a counter that never decreases would otherwise brick a
        # finished project's gate permanently, turning a cost guardrail into a dead end.
        total_repairs = screen.get("total_repair_passes", 0)
        if not isinstance(total_repairs, int) or isinstance(total_repairs, bool) or total_repairs < 0:
            fail(f"{sid}.total_repair_passes must be a non-negative integer")
        elif total_repairs > TOTAL_REPAIR_CAP:
            msg = (f"{sid}.total_repair_passes is {total_repairs}: this unit has been reopened and "
                   f"repaired {total_repairs} times over its whole life (cap {TOTAL_REPAIR_CAP}, "
                   f"four times the per-episode debugger cap). Repeated reopens mean the defect is "
                   f"not debugger-fixable — route it through /reslice or a human decision instead "
                   f"of another repair pass")
            # The cap must always leave a door open, and the door is the remedy the message
            # itself names. `blocked` IS stopping — a human has been told, the unit is parked and
            # nothing is being ground at any more; failing there would punish the exact response
            # the check asks for, and since this counter is never cleared there would be no way
            # out at all. On a FOUNDATION that is fatal: the gate fails for the whole project and
            # every unit depending on it is stranded. `accepted` is the same reasoning one step
            # later — history, not a decision anyone can still take.
            if str(screen.get("status", "")) in {"accepted", "blocked", "deprecated"}:
                warn(msg + " [unit already stopped or accepted: warning, not a failure]")
            else:
                fail(msg)
        validate_feature_data_engine(screen)
        validate_feature_traceability(screen, blueprint_ids)

    # Central sequential-build invariant: at most one unit may be building.
    if counts.get("building", 0) > 1:
        building_ids = sorted(s["id"] for s in screens if s.get("status") == "building")
        fail(f"more than one unit is building {building_ids}; exactly one may build at a time")

    dupes = sorted([sid for sid, n in Counter(ids).items() if n > 1])
    if dupes:
        fail(f"duplicate screen ids: {dupes}")
    known = set(ids)
    by_id = {screen["id"]: screen for screen in screens}
    for screen in screens:
        sid = screen["id"]
        for dep in screen.get("after", []):
            if dep not in known:
                fail(f"{sid}.after references unknown dependency {dep}")
        # Two different bars, deliberately. BUILDING on a dependency only needs that dependency
        # to exist and hold real PASS evidence (`verified`); PROMOTING past it needs the human.
        # Collapsing both into "accepted" is what made /build-loop advance a single DAG level per
        # run: the loop never accepts, so nothing downstream ever became ready. The human gate is
        # untouched — it moved from "permission to work" to "permission to call it done".
        if screen["status"] in {"ready", "building"}:
            for dep in screen.get("after", []):
                if by_id[dep]["status"] not in BUILT_STATUS:
                    fail(f"{sid} is {screen['status']} but dependency {dep} is "
                         f"{by_id[dep]['status']}; a dependency must be verified or accepted "
                         f"before its dependents can be built")
        if screen["status"] == "accepted":
            for dep in screen.get("after", []):
                if by_id[dep]["status"] != "accepted":
                    fail(f"{sid} is accepted but dependency {dep} is {by_id[dep]['status']}; "
                         f"acceptance follows the after[] order — accept {dep} first")

    # Backstop for the OTHER direction of the `ready` rule.
    #
    # The check above catches a unit wrongly promoted (marked ready with unbuilt deps).
    # Nothing caught a unit wrongly LEFT BEHIND: `todo`, every dependency already built,
    # and simply never promoted. The rule that governs it ("a todo unit whose after[] are
    # all BUILT becomes ready") lived only in prose, restated in three files, with no
    # mechanical backing at all.
    #
    # Its failure mode is the dangerous one because it is silent and it looks like success:
    # /build-loop recomputes `ready`, finds none, and reports "nothing ready" — which the
    # human reads as "the product is finished" while work is still sitting in `todo`. An
    # interactive operator notices. An autonomous run does not; it stops early and calls it done.
    #
    # Deliberately scoped, and deliberately non-fatal. Promotion is LAZY by design — the
    # conductor promotes at the start of a unit, not the instant a dependency closes — so a
    # promotable `todo` is perfectly legal whenever the conductor still has work in hand.
    # It is only suspicious when NOTHING is ready and NOTHING is building: that is precisely
    # the moment the loop decides it is done. Warning only there makes the signal fire when
    # it means something and stay quiet the rest of the time, which is what keeps it read.
    if not any(s.get("status") in {"ready", "building"} for s in screens):
        promotable = sorted(
            s["id"] for s in screens
            if s.get("status") == "todo"
            and all(by_id[dep]["status"] in BUILT_STATUS for dep in s.get("after", []))
        )
        if promotable:
            warn(f"no unit is ready or building, yet {promotable} are todo with every "
                 f"dependency already built; they should have been promoted to ready. "
                 f"Do not read 'nothing ready' as 'project complete' — recompute promotion "
                 f"before stopping a batch")

    summary = data.get("summary")
    if isinstance(summary, dict):
        if summary.get("total") != len(screens):
            fail("summary.total mismatch")
        for status in VALID_STATUS:
            if summary.get(status, 0) != counts.get(status, 0):
                fail(f"summary.{status} mismatch")

    visiting: set[str] = set()
    visited: set[str] = set()

    def dfs(node: str, stack: list[str]) -> None:
        if node in visited:
            return
        if node in visiting:
            fail("dependency cycle: " + " -> ".join(stack + [node]))
        visiting.add(node)
        stack.append(node)
        for dep in by_id[node].get("after", []):
            dfs(dep, stack)
        stack.pop()
        visiting.remove(node)
        visited.add(node)

    for sid in ids:
        dfs(sid, [])

    # ADVISORY: standing memory grown past what a turn should carry. Never fails -- how big a
    # project's rules are is a judgement, and a gate that refuses a valid state teaches the
    # conductor to route around it. One aggregated warning naming the worst file, so there is
    # something to actually do about it.
    memoria = []
    for rel in ["CLAUDE.md"] + sorted(
        str(q.relative_to(ROOT)) for q in (ROOT / ".claude" / "rules").glob("*.md")
    ):
        fp = ROOT / rel
        if fp.is_file():
            memoria.append((len(fp.read_text(encoding="utf-8").splitlines()), rel))
    total = sum(n for n, _ in memoria)
    if total > STANDING_MEMORY_MAX_LINES and memoria:
        peor_n, peor = max(memoria)
        warn(f"standing project memory is {total} lines across {len(memoria)} files "
             f"(CLAUDE.md + .claude/rules/*.md), over the {STANDING_MEMORY_MAX_LINES}-line mark; "
             f"largest is {peor} at {peor_n}. These load at the start of EVERY session, so this "
             f"is paid on every turn. Move what only a few moments need out of .claude/rules/ "
             f"(a file elsewhere costs one Read when it matters and nothing otherwise) -- "
             f"`.claude/policy/stack-infra.md` is the worked example")

    # ADVISORY: foundations nothing will run for a long time. Every check above can pass cleanly —
    # acyclic graph, every after[] real, every status legal — while the plan still has the shape
    # that produced the one measured disaster on this orchestrator: a blueprint classified 9 ENG-*
    # and 14 PIPE-* as `kind: foundation`, and the schema unit alone iterated 14 times (307 subagent
    # launches) before any product behaviour ever exercised it. A sibling unit that DID have a
    # consumer cost 78. Nothing in the gate could see it, because nothing was wrong — only late.
    #
    # A consumer is a `ui`/`backend` unit reachable TRANSITIVELY through after[], never a direct
    # citation: `SCHEMA <- SHELL(foundation) <- SCR-001(ui)` is the ordinary healthy shape of a
    # layered plan, and demanding a direct citation would misfire on every plan built that way.
    # Global reachability alone was measured too weak — it cleared 29 of 33 foundations on the real
    # project, including the one that iterated 14 times. Distance is what carries the signal.
    #
    # WARN in the ordinary gate; FAIL only under --init-gate. The asymmetry is the whole point.
    # Once a project is running, a wrong build order is a decision a human may legitimately have
    # taken for reasons the gate cannot see, and refusing a valid state teaches the conductor to
    # route around the gate. At BIRTH there is no such decision to defend: nothing is built, no
    # evidence exists, and reordering `order`/`after[]` costs one edit — the same argument that
    # puts /arch-review at t=0 ("the only moment the architecture can change for free"). It is
    # also the only moment where the cost is known in advance: this is the ONE defect in this
    # file backed by a measurement of what it cost when it went unnoticed (4x, above), and the
    # measurement was taken on a project that was warned and shipped anyway. A warning nobody
    # acted on is exactly what an unattended /build-loop will do with it.
    ordered = sorted(
        (s for s in screens if isinstance(s.get("order"), int)),
        key=lambda s: s["order"],
    )
    position = {s["id"]: i for i, s in enumerate(ordered)}
    consumers_exist = any(
        str(s.get("kind", "")).strip().lower() in FOUNDATION_CONSUMER_KINDS for s in screens
    )
    if consumers_exist:
        children: dict[str, list[str]] = {}
        for s in screens:
            for dep in s.get("after", []) or []:
                children.setdefault(str(dep), []).append(s["id"])
        late: list[tuple[Any, str]] = []
        for s in screens:
            if str(s.get("kind", "")).strip().lower() != "foundation":
                continue
            here = position.get(s["id"])
            if here is None:
                continue
            seen: set[str] = set()
            frontier = list(children.get(s["id"], []))
            best = None
            while frontier:
                node = frontier.pop()
                if node in seen:
                    continue
                seen.add(node)
                if str(by_id.get(node, {}).get("kind", "")).strip().lower() in FOUNDATION_CONSUMER_KINDS:
                    there = position.get(node)
                    if there is not None and (best is None or there - here < best):
                        best = there - here
                frontier.extend(children.get(node, []))
            if best is None or best > FOUNDATION_CONSUMER_MAX_DISTANCE:
                late.append((best, s["id"]))
        if late:
            orphans = sorted(sid for gap, sid in late if gap is None)
            distant = sorted(((gap, sid) for gap, sid in late if gap is not None), reverse=True)
            worst = ", ".join(f"{sid} (+{gap})" for gap, sid in distant[:5])
            message = (
                f"{len(late)} foundation unit(s) have no {sorted(FOUNDATION_CONSUMER_KINDS)} unit "
                f"exercising them within {FOUNDATION_CONSUMER_MAX_DISTANCE} units of build order"
                + (f"; unreachable by any consumer: {orphans}" if orphans else "")
                + (f"; furthest: {worst}" if worst else "")
                + ". Scaffolding nothing runs is not proven — its contract is first tested by "
                "whatever finally depends on it, many units later, and every defect found then "
                "costs a full repair round. Schedule a thin real consumer right behind each one "
                "(SCR-WALKING-SKELETON-*, blueprint-templates/SCREENS-template.md §1), or ask "
                "whether the unit is really the product wearing a foundation label."
            )
            if init_gate:
                fail("--init-gate: " + message + " Fix the order in blueprint/SCREENS.md and "
                     "re-compile — at birth this costs one edit, and it is the only moment it "
                     "ever will. If the order is deliberate, say so where it can be read: an "
                     "`accepted_with_risk` DEC-* in blueprint/DECISIONS.md naming the foundations "
                     "and why, which is a decision on the record rather than a warning nobody saw. "
                     "NOTE: this fires BEFORE the other --init-gate requirements "
                     "(meta.architecture_review, meta.discovery), which are checked once state "
                     "validation returns — re-run the gate after fixing this to see any that remain, "
                     "rather than reading a clean second failure as the last one.")
            warn(message)

    for screen in screens:
        if screen["status"] in PASS_STATUSES:
            result_path = ROOT / screen["evidence_path"]
            result = validate_result(result_path, known, require_artifacts=True, screen=screen)
            if result.get("verdict") != "PASS":
                fail(f"{screen['id']} is {screen['status']} but evidence verdict is not PASS")
            if feature_has_data_contract(screen):
                validate_data_engine_assertions(screen, result)
            if evidence_rows is not None:
                runs = result.get("phase_runs") or []
                evidence_rows.append({
                    "screen_id": screen["id"],
                    "status": screen["status"],
                    "verdict": result.get("verdict"),
                    "attempt": result.get("attempt"),
                    "generated_at": result.get("generated_at"),
                    "summary": result.get("summary"),
                    "result_path": screen["evidence_path"],
                    "phases": [
                        {"phase": r.get("phase"), "mode": r.get("mode"), "lenses": r.get("lenses", [])}
                        for r in runs if isinstance(r, dict)
                    ],
                    "artifacts": sorted(_collect_artifact_paths(result)),
                })
    return data


def _atomic_write_json(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=str(path.parent), prefix=path.name + ".", suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            json.dump(payload, handle, ensure_ascii=False, indent=2)
            handle.write("\n")
        os.replace(tmp, path)
    except BaseException:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise


def emit_status(data: dict[str, Any], evidence_rows: list[dict[str, Any]]) -> None:
    """Derived, machine-readable read contract for external surfaces (dashboards,
    CI, monitor screens). Written ONLY on --emit-status after a successful gate run,
    always atomically (write temp + rename), so concurrent readers never see a torn
    file. These files are projections: features.json stays the canonical plan and
    the single-writer rule is untouched — the conductor invokes this script."""
    screens = data.get("screens") if isinstance(data.get("screens"), list) else []
    screens = [s for s in screens if isinstance(s, dict)]
    counts = Counter(str(s.get("status")) for s in screens)
    building = [s["id"] for s in screens if s.get("status") == "building"]
    verified = [s["id"] for s in screens if s.get("status") == "verified"]
    # Since a unit may be BUILT on a merely-verified dependency but only ACCEPTED after that
    # dependency is accepted, "verified" no longer means "acceptable now". Split the list so the
    # human (and /accept) sees the legal order instead of guessing it.
    status_by_id = {s.get("id"): s.get("status") for s in screens}
    after_by_id = {s.get("id"): (s.get("after") or []) for s in screens}
    acceptable_now = [
        sid for sid in verified
        if all(status_by_id.get(dep) == "accepted" for dep in after_by_id.get(sid, []))
    ]
    blocked_by_accept = [
        {
            "id": sid,
            "waiting_on": sorted(
                dep for dep in after_by_id.get(sid, [])
                if status_by_id.get(dep) != "accepted"
            ),
        }
        for sid in verified if sid not in acceptable_now
    ]
    ready = sorted(
        (s for s in screens if s.get("status") == "ready"),
        key=lambda s: (s.get("order") is None, s.get("order")),
    )
    # `todo` units whose every dependency is already built: promotable now, not yet promoted.
    # Exposed so a batch runner can tell "nothing ready" apart from "nothing left to do"
    # without re-deriving the dependency graph. Empty on a healthy, fully-promoted plan.
    status_by_id_all = {s.get("id"): s.get("status") for s in screens}
    promotable_todo = sorted(
        s["id"] for s in screens
        if s.get("status") == "todo"
        and all(status_by_id_all.get(dep) in BUILT_STATUS for dep in s.get("after", []))
    )
    generated_at = datetime.now(timezone.utc).isoformat(timespec="seconds")
    project = data.get("project") if isinstance(data.get("project"), dict) else {}
    _atomic_write_json(STATE / "status.json", {
        "schema_version": "orchestrator.status.v1",
        "generated_at": generated_at,
        "initialized": data.get("initialized", False),
        "project": project.get("name"),
        "total": len(screens),
        "counts": {status: counts.get(status, 0) for status in sorted(VALID_STATUS)},
        "building": building[0] if building else None,
        "verified_awaiting_accept": verified,
        "acceptable_now": acceptable_now,
        "verified_blocked_by_accept_order": blocked_by_accept,
        "next_ready": ready[0]["id"] if ready else None,
        "promotable_todo": promotable_todo,
        "blocked": [
            {"id": s.get("id"), "reason": s.get("blocked_reason")}
            for s in screens if s.get("status") == "blocked"
        ],
        "screens": [
            {
                "id": s.get("id"), "slug": s.get("slug"), "title": s.get("title"),
                "kind": s.get("kind"), "platforms": s.get("platforms"),
                "order": s.get("order"), "after": s.get("after"),
                "status": s.get("status"), "passes": s.get("passes"),
                "checkpoint": s.get("checkpoint"),
                "evidence_path": s.get("evidence_path"),
            }
            for s in screens
        ],
    })
    _atomic_write_json(STATE / "evidence" / "index.json", {
        "schema_version": "orchestrator.evidence-index.v1",
        "generated_at": generated_at,
        "screens": evidence_rows,
    })
    print(f"status emitted: {STATE / 'status.json'} + {STATE / 'evidence' / 'index.json'}")


def validate_templates() -> None:
    candidates = [
        ORQ / "schemas" / "features.schema.json",
        ORQ / "schemas" / "result.schema.json",
        ORQ / "templates" / "features.empty.json",
        ORQ / "templates" / "evidence" / "result.json",
        ORQ / "examples" / "features.example.json",
        ORQ / "examples" / "result.example.json",
    ]
    for path in candidates:
        if not path.exists():
            fail(f"missing {path}")
        load_json(path)


def preflight(requested: str = "") -> None:
    """The DECIDABLE half of the closing gate, run while the unit is still in flight.

    WHY THIS EXISTS. Measured on a real run of this orchestrator: more than half the debugger
    rounds did not fix code, they fixed the TRAIL — and almost all of those were the same three
    clerical slips. An artifact path cited from memory that is not on disk. Checks labelled by
    approximate topic instead of against the criterion's literal id. An assertions array left
    empty when the unit's own contract makes it mandatory. All three are decidable by a script
    in milliseconds. All three were being found by a ten-lens adversarial fan-out, each of which
    then cost a repair pass, a re-VERIFY and a re-REVIEW.

    A lens is not a linter. Whatever a script can decide must never cost a fan-out — not because
    the lenses are wrong to catch it, but because by the time they do, the round is already paid.

    THE PROPERTY THAT MAKES THIS SAFE, stated precisely — an earlier version of this docstring
    claimed the looser and FALSE version, that a plain gate run on today's state would fail too.
    It would not: the gate only inspects a result.json once its unit reaches `verified`/`accepted`,
    so on a `building` unit it inspects nothing at all. What is true, and is the whole guarantee:
    **every check below is one the CLOSING gate will run on this same evidence, with the same
    verdict, the moment the unit reaches a PASS status.** So a pre-flight failure is not a new bar
    — it is the close failing early, while it is still cheap. Passing promises nothing beyond
    "these particular slips are not present": it is not a verdict, touches no state, is not
    evidence, and never enters phase_runs[].

    Retroactivity is inherited from the close, not reinvented: an already-`accepted` unit gets the
    same softening the gate gives it. A tool that failed where the gate warns would be telling the
    conductor to repair a unit that has no legal way to be reopened.

    It also reports EVERYTHING at once rather than stopping at the first problem, because its
    whole point is to spend one run instead of one round per slip."""
    if not FEATURES.exists():
        fail("--preflight: no .orchestrator-state/features.json")
    data = load_json(FEATURES)
    screens = data.get("screens", []) if isinstance(data, dict) else []
    if requested:
        matches = [s for s in screens if s.get("id") == requested]
        if not matches:
            fail(f"--preflight: no unit with id {requested}")
    else:
        matches = [s for s in screens if s.get("status") == "building"]
        if not matches:
            print("preflight: no unit is building; pass an ID to check one explicitly")
            return
    screen = matches[0]
    sid = screen.get("id", "<unknown>")
    problems: list[str] = []

    result_rel = str(screen.get("evidence_path", "")).strip()
    result_path = ROOT / result_rel if result_rel else None
    if not result_path or not result_path.is_file():
        print(f"preflight[{sid}]: no evidence yet at {result_rel or '<unset>'} — nothing to check")
        return
    result = load_json(result_path)
    if not isinstance(result, dict):
        fail(f"--preflight: {result_rel} is valid JSON but not an object; nothing here can be read "
             f"as a result. Start from .orchestrator/templates/evidence/result.json")
    # Inherited from the close, never reinvented: a unit a human already ACCEPTED gets the same
    # softening the gate gives it. Failing where the gate warns would order a repair on a unit
    # that has no legal way to reopen — see the reopen rules in constitution.md.
    soft = str(screen.get("status", "")).strip() == "accepted"

    # Structural, so it fails hard rather than joining the list: malformed advisory findings are
    # not a slip to fix later, they are a field that cannot be read. And this is the ONLY moment
    # the blocking/waived contradiction is reachable at all — at close, a PASS with a non-empty
    # failures[] is already rejected by an earlier and stronger check, so the guard would be dead
    # code there. In flight is exactly when someone marks as debt something that is still failing.
    validate_advisory_findings(result, result_path)

    # (E1) An artifact path written from memory. The closing gate rejects these; catching them
    # here costs a stat() instead of a fan-out.
    for rel in sorted(_collect_artifact_paths(result)):
        if not rel:
            continue
        if "<" in rel or ">" in rel:
            problems.append(f"artifact path still holds a placeholder: {rel}")
            continue
        fp = ROOT / rel
        if not fp.is_file():
            problems.append(f"artifact cited but not on disk: {rel}")
        elif fp.stat().st_size == 0:
            problems.append(f"artifact is a 0-byte file: {rel}")

    # NOTHING-YET IS NOT A DEFECT, and getting this wrong would sink the whole idea. The evidence
    # skeleton (.orchestrator/templates/evidence/result.json) starts as verdict FAIL with one
    # placeholder check, `acceptance_ids: []`, `artifacts: []` and no assertions — so a naive
    # pre-flight reports three "problems" on EVERY unit's first pass, which are not problems but
    # "not written yet". A warning that fires every time is a warning nobody reads, which is the
    # exact failure this tool exists to prevent, reproduced by the tool itself.
    #
    # The discriminator is whether the unit has begun CLAIMING anything: a check recorded as
    # passed is a claim about proof, and from that moment the trail has to hold up. Before it,
    # stay quiet. E1 needs no such guard — it only ever looks at paths already cited, so it is
    # vacuous on a skeleton by construction.
    claiming = any(isinstance(c, dict) and c.get("passed") is True
                   for c in result.get("checks", []) or [])
    if not claiming:
        if problems:
            print(f"preflight[{sid}]: {len(problems)} problem(s) in what is already written "
                  f"(the unit has not recorded a passed check yet, so criteria coverage and "
                  f"assertions are not judged):", file=sys.stderr)
            for problem in problems:
                print(f"  - {problem}", file=sys.stderr)
            raise SystemExit(1)
        print(f"preflight[{sid}]: nothing to check yet — no check recorded as passed, so there "
              f"is no claim whose trail could be wrong. Re-run after consolidating a phase.")
        return

    # (E2) Checks labelled by topic instead of against the criterion.
    problems.extend(acceptance_coverage_problems(screen, result))

    # (E3) The assertions array left empty on a unit whose own contract requires it.
    if feature_has_data_contract(screen):
        assertions = result.get("data_engine_assertions") or result.get("data_assertions") or []
        if not isinstance(assertions, list) or not assertions:
            problems.append(
                "data_engine_assertions[] is empty, but this unit declares a data contract "
                "(it cites DATA-*, or carries verify.data_checks, or a non-empty data_engine). "
                "The closing gate requires one assertion per single_value_contract field, each "
                "carrying the LITERAL value observed at every layer")

    # The plan EXPLORE owes. Same rule as the gate, same reason to catch it early.
    for run in result.get("phase_runs", []) or []:
        if isinstance(run, dict) and str(run.get("phase", "")).upper() == "EXPLORE":
            if not str(run.get("plan") or "").strip():
                problems.append("phase_runs[EXPLORE] has no `plan`: EXPLORE must persist its "
                                f"vertical plan to {result_rel.rsplit('/', 1)[0]}/plan.md")

    if problems:
        if soft:
            print(f"preflight[{sid}]: {len(problems)} problem(s), reported as WARNINGS because "
                  f"this unit is already accepted and the closing gate softens the same checks "
                  f"for it — failing here would order a repair on a unit with no legal way to "
                  f"reopen:", file=sys.stderr)
            for problem in problems:
                print(f"  - {problem}", file=sys.stderr)
            return
        print(f"preflight[{sid}]: {len(problems)} problem(s) a script can see. Fix them now — "
              f"each one left in place costs a full repair round when a lens finds it instead:",
              file=sys.stderr)
        for problem in problems:
            print(f"  - {problem}", file=sys.stderr)
        raise SystemExit(1)
    print(f"preflight[{sid}]: clean (artifacts on disk, criteria cited by id, assertions "
          f"present, plan recorded). This is not a verdict — it is the absence of the slips "
          f"a script can see.")


def main() -> None:
    args = sys.argv[1:]
    if "--arch-hash" in args:
        # Deterministic hash for /arch-review and /reslice; no state required.
        print(arch_hash())
        return
    if "--preflight" in args:
        # Cheap, in-flight, advisory-by-position: a strict subset of the closing gate, run
        # before the fan-out so a script catches what a lens would otherwise charge a round for.
        rest = [a for a in args if not a.startswith("--")]
        preflight(rest[0] if rest else "")
        return
    emit = "--emit-status" in args
    init_gate = "--init-gate" in args
    if not ORQ.exists():
        fail("missing .orchestrator")
    if not STATE.exists():
        fail("missing .orchestrator-state")
    for file in ["spec.md", "features.json", "progress.md"]:
        if not (STATE / file).exists():
            fail(f"missing .orchestrator-state/{file}")
    if not (STATE / "evidence").exists():
        fail("missing .orchestrator-state/evidence")
    validate_templates()
    evidence_rows: list[dict[str, Any]] = []
    data = validate_features(evidence_rows if emit else None, init_gate=init_gate)
    if init_gate:
        # /init-build only: a project cannot be born without its birth gates.
        meta = data.get("meta", {}) if isinstance(data.get("meta", {}), dict) else {}
        missing = []
        if meta.get("architecture_review") is None:
            missing.append("meta.architecture_review is missing — /init-build must run "
                           "/arch-review (all 6 arch-* lenses) before compiling features.json")
        if meta.get("discovery") is None:
            missing.append("meta.discovery is missing — /init-build must run "
                           "/discovery (all 6 discovery-* lenses) before compiling features.json")
        if missing:
            fail("--init-gate: " + "; ".join(missing))
    if emit:
        emit_status(data, evidence_rows)
    print("orchestrator state OK")


if __name__ == "__main__":
    main()
