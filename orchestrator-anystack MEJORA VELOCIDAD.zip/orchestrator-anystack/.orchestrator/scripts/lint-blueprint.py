#!/usr/bin/env python3
"""Deterministic blueprint linter — no LLM, stdlib only.

Runs BEFORE the research fan-out spends tokens (/init-build step 1,
/next-pantalla after CLARIFY writes, /reslice step 1) so the pipeline starts
from a referentially intact spec instead of discovering broken IDs mid-build.

ERRORS (exit 1) — structurally broken blueprint:
  - duplicate IDs (same ID defined in more than one ``` block)
  - dangling references (after/applies/depends_on/related_screens/product_refs/
    data_refs/engine_refs pointing to an ID no file defines)
  - dependency cycles in SCREENS after[]

WARNINGS (exit 0, printed) — incomplete but not broken; /init-build turns these
into CLARIFY questions instead of guessing:
  - leftover stubs ("Pendiente de definir", "TBD", unresolved <PLACEHOLDER> tokens)
  - screen blocks without acceptance criteria
  - non-ID tokens inside a reference list
  - references that resolve only to a heading (no ``` block defines them)

An ID counts as DEFINED only when a ```logic/```screen block declares it via
`id:`. A heading alone is a title, not a definition — otherwise an empty
section would satisfy referential integrity and duplicate detection (which
only sees blocks) would disagree with it.

DECIDEDNESS (--decidedness, never fatal) — a separate question from the above.
The checks above ask "is the blueprint internally consistent?". This one asks
"has anyone actually DECIDED anything?", and the two are independent: a
blueprint straight out of blueprint-templates/ is perfectly consistent and
entirely undecided.

It reports two kinds of silence:
  - `placeholder`       — the value is still a <SCAFFOLD_TOKEN>. Obviously absent.
  - `template_default`  — the value is byte-identical to what the template ships.
                          This is the dangerous one, because it does not LOOK
                          absent: `source_of_truth: database`, `replay_safe: true`,
                          `delivery: at_least_once` read exactly like decisions.

Consumed by /arch-review and the arch-* lenses, whose governing rule is
`research-* owns the ABSENCE, arch-* owns the ERROR`: a finding whose only
support is an undecided field is not a finding, it is silence. Without this
output that distinction cannot be drawn, so the lenses either raise template
defaults as blockers or the gate reviews a blueprint nobody has filled in.
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path

ROOT = Path.cwd()
BLUEPRINT = ROOT / "blueprint"
TEMPLATES = ROOT / "blueprint-templates"

ID_PATTERN = re.compile(r"^(?:BR|SCR|DOM|APP|CORE|JOUR|PERM|ST|ERR|INT|UI|DATA|UC|ENG|PIPE|DEC)-[A-Z0-9][A-Z0-9-]*$")
HEADING_ID = re.compile(r"^#{2,4}\s+((?:BR|SCR|DOM|APP|CORE|JOUR|PERM|ST|ERR|INT|UI|DATA|UC|ENG|PIPE|DEC)-[A-Z0-9][A-Z0-9-]*)\b")
FENCED_BLOCK = re.compile(r"```(screen|logic)\n(.*?)```", re.DOTALL)
REF_KEYS = ("after", "applies", "depends_on", "related_screens", "product_refs", "data_refs", "engine_refs",
            "pipeline_refs", "feeds", "writes", "consumed_by", "related_engines",
            "supersedes", "written_to", "affects_screens", "reopens", "remediates")
STUB_MARKERS = ("Pendiente de definir", "Pendiente.", "PENDIENTE", "por definir", "TBD", "TODO", "To be defined")
# <UPPER_SNAKE> scaffold tokens. The {2,} floor (4+ chars inside <>) avoids
# false positives on HTML (<b>, <br>) and generics (<T>).
PLACEHOLDER = re.compile(r"<[A-Z][A-Z0-9_]{2,}>")
PLACEHOLDER_SAMPLE = 5

errors: list[str] = []
warnings: list[str] = []


def parse_list(raw: str) -> list[str]:
    raw = raw.strip()
    if not (raw.startswith("[") and raw.endswith("]")):
        return []
    inner = raw[1:-1].strip()
    if not inner:
        return []
    return [tok.strip().strip("\"'") for tok in inner.split(",") if tok.strip()]


def blueprint_files() -> list[Path]:
    files = [BLUEPRINT / "PRODUCT.md", BLUEPRINT / "SCREENS.md", BLUEPRINT / "DECISIONS.md"]
    files += sorted((BLUEPRINT / "logic").glob("*.md"))
    return [f for f in files if f.exists()]


# --- decidedness ------------------------------------------------------------
# A scalar line inside a ``` block: `key: value`, no list, no empty value.
# Indentation is captured so nested keys can be reported by their real path
# (`canonical_store.source_of_truth`), which is what the arch-* lenses cite.
# The value group is OPTIONAL on purpose. A line that is just `canonical_store:` opens a
# nested mapping and carries no value of its own — but it is what gives its children their
# real path. An earlier version required a non-empty value here, which meant those lines
# never matched, the indentation stack never got pushed, and EVERY nested key was reported
# under its bare name: `source_of_truth` instead of `canonical_store.source_of_truth`. The
# branch that pushes onto the stack was unreachable code. Worse than cosmetic — two layers
# that both declare `source_of_truth` became indistinguishable in the report and collided
# in the defaults table, so a deliberately-decided field could be reported as untouched.
SCALAR_LINE = re.compile(r"^(\s*)([a-z_][a-z0-9_]*):[ \t]*(.*?)\s*$")
# Identity, addressing and classification — never decisions, so never absences.
# Every project's DATA-001 is called DATA-001; a business rule's `type` is
# `business_rule` because that is what it IS, not because nobody chose. Leaving
# these in drowns the real signal: the scaffold's SCREENS.md alone contributed 36
# such rows, which is exactly how a report stops being read.
#
# The bar for this set is "coinciding with the template carries no information".
# Keep anything a human could have decided differently and did not — `status`,
# `severity`, `source_of_truth`, `delivery`, `replay_safe` — however innocuous it
# looks. Those wired-looking defaults are the entire point of the check.
DECIDEDNESS_SKIP_KEYS = {"id", "slug", "type", "kind", "order", "route", "design_ref"}


def template_for(path: Path) -> Path | None:
    """blueprint/logic/data.md -> blueprint-templates/logic/data-template.md
       blueprint/PRODUCT.md    -> blueprint-templates/PRODUCT-template.md"""
    rel = path.relative_to(BLUEPRINT)
    candidate = TEMPLATES / rel.parent / f"{rel.stem}-template{rel.suffix}"
    return candidate if candidate.exists() else None


def parse_scalars(body: str) -> list[tuple[str, str]]:
    """Scalars of one ``` block as (dotted_key_path, value), preserving nesting."""
    out: list[tuple[str, str]] = []
    stack: list[tuple[int, str]] = []   # (indent, key)
    for line in body.splitlines():
        if not line.strip() or line.lstrip().startswith("#"):
            continue
        match = SCALAR_LINE.match(line)
        if not match:
            continue
        indent, key, value = len(match.group(1)), match.group(2), match.group(3)
        while stack and stack[-1][0] >= indent:
            stack.pop()
        # Strip a trailing comment only when something precedes it. A value that STARTS
        # with '#' is a value, not a comment (an unquoted hex colour is the obvious case),
        # and splitting there left it empty — which this parser then read as "opens a nested
        # mapping", corrupting the indentation stack for everything below it.
        if not value.startswith("#"):
            value = value.split("#", 1)[0]
        value = value.strip().strip("\"'")
        if not value:                      # `parent:` opening a nested mapping
            stack.append((indent, key))
            continue
        path = ".".join([k for _, k in stack] + [key])
        if value.startswith("[") or key in DECIDEDNESS_SKIP_KEYS:
            continue
        out.append((path, value))
    return out


def template_defaults(path: Path) -> dict[str, set[str]]:
    """Every scalar value the layer's template ships, as key_path -> {values}.

    Deliberately pooled across ALL blocks of the template rather than matched
    block-by-block: a real project renames and renumbers blocks, so pairing
    DATA-001 to DATA-001 would stop working the moment anyone adds DATA-007.
    What identifies an untouched default is the value itself, not its address.

    A key whose template blocks DISAGREE with each other is dropped. When the
    template shows `severity: must` in one block and `severity: should` in
    another, it is illustrating the options, not shipping a default — and
    matching one of them proves nothing about whether anyone chose. Keeping
    those turned the check into "did you pick a value the template ever
    mentions", which flags deliberate decisions as silence and is precisely
    the false positive the arch-* lenses must not be handed."""
    pooled: dict[str, set[str]] = {}
    template = template_for(path)
    if template is None:
        return {}
    for _, body in FENCED_BLOCK.findall(template.read_text(encoding="utf-8")):
        for key, value in parse_scalars(body):
            pooled.setdefault(key, set()).add(value)
    return {k: v for k, v in pooled.items() if len(v) == 1}


def main(argv: list[str] | None = None) -> None:
    parser = argparse.ArgumentParser(
        prog="lint-blueprint.py",
        description="Deterministic blueprint linter. With no flags, behaves exactly as "
                    "it always has: lint the blueprint and print human-readable output.",
    )
    parser.add_argument(
        "--decidedness", action="store_true",
        help="also report undecided_fields[]: scalars still at their blueprint-templates/ "
             "default or still a <PLACEHOLDER>. Never fatal — absence is not an error.",
    )
    parser.add_argument(
        "--json", action="store_true", dest="as_json",
        help="emit the result as JSON on stdout instead of human-readable lines.",
    )
    args = parser.parse_args(argv)

    if not BLUEPRINT.exists():
        print("lint-blueprint: missing blueprint/ directory", file=sys.stderr)
        raise SystemExit(1)

    undecided: list[dict[str, str]] = []
    defined: dict[str, list[str]] = {}   # id -> [locations of ``` block definitions]
    known_ids: set[str] = set()          # block ids only — the real definitions
    heading_ids: set[str] = set()        # ids seen as a title (checked only after known_ids)
    refs: list[tuple[str, str, str]] = []  # (source_location, key, token)
    after_edges: dict[str, list[str]] = {}

    for path in blueprint_files():
        rel = str(path.relative_to(ROOT))
        text = path.read_text(encoding="utf-8")
        defaults = template_defaults(path) if args.decidedness else {}

        placeholder_hits: dict[str, int] = {}
        for lineno, line in enumerate(text.splitlines(), 1):
            heading = HEADING_ID.match(line)
            if heading:
                heading_ids.add(heading.group(1))
            for marker in STUB_MARKERS:
                if marker in line:
                    warnings.append(f"{rel}:{lineno}: stub marker '{marker}' — still undefined")
                    break
            for token in PLACEHOLDER.findall(line):
                placeholder_hits[token] = placeholder_hits.get(token, 0) + 1

        # One warning per file, not per line: a fresh copy of the templates has
        # hundreds of these and /init-build needs the signal, not the noise.
        if placeholder_hits:
            distinct = sorted(placeholder_hits)
            sample = ", ".join(distinct[:PLACEHOLDER_SAMPLE])
            extra = len(distinct) - PLACEHOLDER_SAMPLE
            if extra > 0:
                sample += f", +{extra} more"
            warnings.append(
                f"{rel}: {sum(placeholder_hits.values())} unresolved placeholder token(s) "
                f"({len(distinct)} distinct: {sample}) — fill them in or turn them into CLARIFY questions"
            )

        for kind, body in FENCED_BLOCK.findall(text):
            block_id = None
            id_match = re.search(r"^id:\s*([^\s#]+)\s*$", body, re.MULTILINE)
            if id_match:
                block_id = id_match.group(1).strip().strip("\"'")
                if ID_PATTERN.match(block_id):
                    defined.setdefault(block_id, []).append(rel)
                    known_ids.add(block_id)
                elif "<" in block_id:
                    warnings.append(f"{rel}: block id '{block_id}' is an unresolved placeholder")
                else:
                    warnings.append(f"{rel}: block id '{block_id}' does not match any known ID prefix")
            else:
                warnings.append(f"{rel}: {kind} block without id:")

            if kind == "screen" and "acceptance:" not in body:
                warnings.append(f"{rel}: screen block {block_id or '<no-id>'} has no acceptance criteria")

            if args.decidedness:
                for key_path, value in parse_scalars(body):
                    if PLACEHOLDER.search(value):
                        reason = "placeholder"
                    elif value in defaults.get(key_path, ()):
                        reason = "template_default"
                    else:
                        continue
                    undecided.append({
                        "file": rel,
                        "block_id": block_id or "<no-id>",
                        "key": key_path,
                        "value": value,
                        "reason": reason,
                    })

            for key in REF_KEYS:
                for ref_match in re.finditer(rf"^\s*{key}:\s*(\[.*?\])\s*$", body, re.MULTILINE):
                    tokens = parse_list(ref_match.group(1))
                    for tok in tokens:
                        refs.append((f"{rel} ({block_id or kind})", key, tok))
                    if key == "after" and block_id and ID_PATTERN.match(block_id):
                        after_edges.setdefault(block_id, []).extend(
                            t for t in tokens if ID_PATTERN.match(t)
                        )

    for bid, locations in sorted(defined.items()):
        if len(locations) > 1:
            errors.append(f"duplicate ID {bid} defined in: {', '.join(locations)}")

    for source, key, tok in refs:
        if tok == "ALL":
            continue  # documented sentinel (shell rules: every ui screen)
        if "<" in tok or ">" in tok:
            warnings.append(f"{source}: {key} contains unresolved placeholder '{tok}'")
            continue
        if not ID_PATTERN.match(tok):
            warnings.append(f"{source}: {key} contains non-ID token '{tok}'")
            continue
        if tok not in known_ids:
            if tok in heading_ids:
                warnings.append(
                    f"{source}: {key} references {tok}, which only exists as a heading — "
                    "no ```logic/```screen block defines it"
                )
                continue
            errors.append(f"{source}: {key} references undefined ID {tok}")

    visiting: set[str] = set()
    visited: set[str] = set()

    def dfs(node: str, stack: list[str]) -> None:
        if node in visited:
            return
        if node in visiting:
            errors.append("after[] dependency cycle: " + " -> ".join(stack + [node]))
            return
        visiting.add(node)
        stack.append(node)
        for dep in after_edges.get(node, []):
            dfs(dep, stack)
        stack.pop()
        visiting.discard(node)
        visited.add(node)

    for node in sorted(after_edges):
        dfs(node, [])

    if args.as_json:
        # Machine contract for /arch-review and the arch-* lenses. Errors still set the
        # exit code, but they are IN the payload too: a consumer that only reads stdout
        # must not have to infer a broken blueprint from a status code it never saw.
        payload: dict[str, object] = {
            "schema_version": "orchestrator.blueprint-lint.v1",
            "errors": errors,
            "warnings": warnings,
            "counts": {"errors": len(errors), "warnings": len(warnings)},
        }
        if args.decidedness:
            payload["undecided_fields"] = undecided
            payload["counts"] = dict(payload["counts"], **{
                "undecided_fields": len(undecided),
                "undecided_placeholder": sum(1 for u in undecided if u["reason"] == "placeholder"),
                "undecided_template_default": sum(1 for u in undecided if u["reason"] == "template_default"),
            })
        print(json.dumps(payload, ensure_ascii=False, indent=2))
        raise SystemExit(1 if errors else 0)

    for warning in warnings:
        print(f"warning: {warning}")
    if args.decidedness:
        for item in undecided:
            print(f"undecided: {item['file']} ({item['block_id']}): {item['key']} = "
                  f"{item['value']!r} — {item['reason']}")
    if errors:
        for error in errors:
            print(f"error: {error}", file=sys.stderr)
        print(f"blueprint lint FAILED: {len(errors)} error(s), {len(warnings)} warning(s)", file=sys.stderr)
        raise SystemExit(1)
    tail = f", {len(undecided)} undecided field(s)" if args.decidedness else ""
    print(f"blueprint lint OK ({len(warnings)} warning(s){tail})")


if __name__ == "__main__":
    main()
