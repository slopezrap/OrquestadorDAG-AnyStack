#!/usr/bin/env bash
set -uo pipefail
# self-root to repo root so the commit/push is never cwd-relative
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
cd "$ROOT"

# Phase checkpoint: commit the work done in one /next-pantalla phase and push it
# to origin/main. Called by orchestrator-flow after every phase (RESEARCH,
# EXPLORE, DEVELOP, VERIFY, VALIDATE, REVIEW). This is a DevOps-role side effect,
# not a lifecycle transition: it never touches features.json status and the
# STATE GATE / human /accept remain the only trust anchors.
#
# It is non-fatal by design: when there is no git work tree or no 'origin'
# remote (the scaffold may run before the product repo is wired), it logs and
# exits 0 so building a screen is never blocked. Remote/branch are overridable
# via ORCH_PUSH_REMOTE / ORCH_PUSH_BRANCH.

phase="${1:-}"
unit="${2:-state}"
remote="${ORCH_PUSH_REMOTE:-origin}"
branch="${ORCH_PUSH_BRANCH:-main}"

if [ -z "$phase" ]; then
  echo "usage: bash .orchestrator/scripts/phase-push.sh <PHASE> [UNIT_ID]" >&2
  exit 2
fi

# 1. Require a git work tree, else skip (scaffold may run pre-init).
if ! git rev-parse --is-inside-work-tree >/dev/null 2>&1; then
  echo "phase-push[$phase]: not a git repository; push skipped." >&2
  exit 0
fi

# 2. Commit a checkpoint when there is something to record. Failure (e.g. a
#    product pre-commit hook) is non-fatal: keep going so the flow is not blocked.
git add -A || true
if git diff --cached --quiet; then
  echo "phase-push[$phase]: no changes to commit."
else
  if git commit -m "orchestrator($unit): $phase phase checkpoint" \
      -m "Automated checkpoint after the $phase phase of /next-pantalla."; then
    echo "phase-push[$phase]: committed checkpoint for $unit."
  else
    echo "phase-push[$phase]: commit failed (kept working tree); push skipped." >&2
    exit 0
  fi
fi

# 3. Push HEAD to <remote>/<branch> when the remote exists AND there is
#    something new for it to receive. Two independent, additive skips —
#    both leave the commit (the actual checkpoint) untouched, and both
#    default to OFF so a caller that sets nothing gets exactly today's
#    behavior: push after every phase.
#
#    (a) No-op skip, always on. A phase that wrote nothing to disk
#    (RESEARCH with no blueprint write-back, a triage re-run that only
#    re-confirms) leaves HEAD exactly where the LAST successful push
#    already left $remote/$branch: pushing again is a full network round
#    trip for zero new commits. Tracked with a local marker file, never a
#    remote call, so this never costs a round trip to find out it isn't
#    needed. Safe by construction: it can only skip a push whose sha was
#    already confirmed delivered by THIS script; it never suppresses a
#    push for a sha the marker has not seen succeed.
#
#    (b) Optional throttle, opt-in via ORCH_PUSH_MIN_INTERVAL_SECONDS
#    (unset/0 = current behavior, always push). A debugger loop can call
#    this script many times in a row for the SAME phase name
#    (constitution.md: "push a fresh checkpoint for each re-run phase, so
#    origin/main tracks every iteration"). The commit still lands locally
#    every single time — checkpoint/resume reads disk, not origin — but
#    when this var is set, a push within N seconds of the last successful
#    one is deferred instead of sent immediately. This trades "origin/main
#    updates within N seconds" for fewer round trips; it never trades away
#    the local checkpoint, and left unset it never fires.
if ! git remote get-url "$remote" >/dev/null 2>&1; then
  echo "phase-push[$phase]: remote '$remote' not configured; commit kept local, push skipped." >&2
  exit 0
fi

git_dir="$(git rev-parse --git-dir)"
marker="$git_dir/ORCH_LAST_PUSH_$(printf %s "${remote}_${branch}" | tr -c "A-Za-z0-9_" "_")"
head_sha="$(git rev-parse HEAD)"
last_sha=""
last_time=0
if [ -f "$marker" ]; then
  last_sha="$(sed -n 1p "$marker" 2>/dev/null)"
  last_time="$(sed -n 2p "$marker" 2>/dev/null)"
  case "$last_time" in ''|*[!0-9]*) last_time=0 ;; esac
fi

if [ "$head_sha" = "$last_sha" ]; then
  echo "phase-push[$phase]: HEAD already pushed as of the last checkpoint; push skipped."
  exit 0
fi

interval="${ORCH_PUSH_MIN_INTERVAL_SECONDS:-0}"
case "$interval" in ''|*[!0-9]*) interval=0 ;; esac
now="$(date +%s)"
if [ "$interval" -gt 0 ] && [ $(( now - last_time )) -lt "$interval" ]; then
  echo "phase-push[$phase]: within ORCH_PUSH_MIN_INTERVAL_SECONDS (${interval}s) of the last push; commit kept local, push deferred to the next checkpoint outside the window."
  exit 0
fi

if git push "$remote" "HEAD:$branch"; then
  printf '%s\n%s\n' "$head_sha" "$now" > "$marker"
  echo "phase-push[$phase]: pushed to $remote/$branch."
else
  echo "phase-push[$phase]: push to $remote/$branch failed; commit kept local, resolve and re-push." >&2
  exit 0
fi
