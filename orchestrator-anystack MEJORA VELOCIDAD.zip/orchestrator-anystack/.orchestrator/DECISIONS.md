# DECISIONS.md — decisiones sobre la MAQUINARIA del orquestador

> No confundir con `blueprint/DECISIONS.md`, que es el ledger de **producto** del proyecto que
> construyes con esto: nace vacío, lo llena tu proyecto, y `decided_by` es quien decide sobre
> tu producto. Este registra decisiones sobre el orquestador **mismo** — sus gates, sus
> contratos de evidencia, sus fases — y por eso vive en `.orchestrator/`, que es "definición
> estable, no estado vivo".
>
> Aquí solo entra lo **contractual**: un cambio que hace que un estado antes válido deje de
> serlo, o al revés. El resto del *porqué* de esta maquinaria vive donde siempre ha vivido, en
> los comentarios largos del código que lo implementa — un check no contractual se explica
> junto a su propio `if`, no en un fichero que nadie abre.
>
> Mismas reglas que el ledger de producto: **append-only**, una decisión por entrada, y el
> `trip_wire` es la parte que sostiene el peso — es lo que permite reabrir una decisión a quien
> no estuvo cuando se tomó.

## Índice

| ID | Fecha | Decisión | Supersede | Escrita en |
|---|---|---|---|---|
| DEC-ORCH-001 | 2026-08-15 | EXPLORE debe persistir su plan; el gate lo exige | — | `validate-state.py`, `next-pantalla/SKILL.md`, `constitution.md`, `conventions.md`, `result.schema.json` |
| DEC-ORCH-002 | 2026-08-15 | El orden de obra pasa de aviso a fallo duro en `--init-gate` | — | `validate-state.py`, `init-build/SKILL.md` |

---

## DEC-ORCH-001 — EXPLORE persiste su plan y el gate lo exige

```logic
id: DEC-ORCH-001
type: decision
status: applied
date: 2026-08-15
decided_by: "Sergio"
trigger: "auditoría del flujo contra el SDD canónico: la fase /plan era el único paso del ciclo specify→plan→tasks→implement sin equivalente aquí, y el plan que sí se escribía vivía solo en el contexto del conductor"
rejected_alternative: "PLAN como 7ª fase propia en phase_runs[]. Descartada tras el recon: obligaba a tocar 9 sitios de prosa que enumeran las fases, required_phases, dos schemas y el enum de checkpoint.phase, y volvía FALSA la frase de la constitución 'DEVELOP is the only phase with no workflow by design'. Además era ceremonia: la sección que produce el plan ya se llama 'Explore AND PLAN', así que el plan es el ENTREGABLE de EXPLORE, no una fase aparte"
trip_wire: "si alguna vez PLAN necesita fan-out propio (lentes que planifiquen en paralelo), deja de ser un artefacto de EXPLORE y vuelve a ser una fase — y entonces sí hay que pagar los 9 sitios de prosa. Mientras el conductor sea el único que lo escribe, esta forma es la correcta"
supersedes: []
written_to: [validate-state.py:validate_phase_coverage, next-pantalla/SKILL.md, constitution.md, conventions.md, result.schema.json, verify-conformance.md, pantalla-reviewer.md]
affects_screens: [TODAS las unidades no accepted]
reopens: []
```

**Decisión:** la entrada EXPLORE de `result.json.phase_runs[]` lleva `plan:
".orchestrator-state/evidence/<ID>/plan.md"`, y ese fichero tiene que existir y no pesar 0
bytes para que la unidad pueda cerrar en PASS. El plan contiene el **mapa de aceptación** (una
fila por criterio: IDs que lo rigen, ficheros a tocar, **cómo se probará**, artefacto
esperado), el orden vertical, el **consumidor declarado** de la unidad, y una sección
`## Delivery` que DEVELOP cierra declarando entregado / entregado-con-desviación / no
entregado.

**Por qué:** el plan existía —`next-pantalla` §2 siempre dijo "escribe el plan vertical"— pero
solo en el contexto del conductor. De ahí salían tres cosas, y la tercera es la que paga el
cambio. (1) Una compactación a mitad de DEVELOP lo re-derivaba, justo en el momento en que
peor se re-deriva, porque lo que se acaba de borrar es la memoria de lo que ya habías
decidido. (2) Nada podía preguntar *¿se construyó lo que se planeó?* — `pantalla-reviewer`
juzga código contra `acceptance[]` y `verify-conformance` contra el blueprint; ninguna de las
dos es esa pregunta. (3) Un criterio sin respuesta en la columna *cómo se probará* no se veía
hasta VERIFY, doce lanzamientos después, y costaba una iteración de debugger completa. Ahora
salta en EXPLORE por cero.

**Lo que reemplaza:** nada nuevo en intención — reemplaza un plan implícito por uno
falsable. Coste en lanzamientos de subagente: **cero**. Lo escribe el conductor inline, que
es también lo que impide que se convierta en auto-revisión: la sección `## Delivery` es una
DECLARACIÓN, y los dientes los ponen dos agentes independientes — `verify-conformance` la
audita desde el código (`plan_delivery[]`) y `pantalla-reviewer` nombra cada desviación
(`plan_deviations[]`, con `declared:false` como gap).

**Consecuencia:** **es un cambio contractual y rompe evidencia existente.** Cualquier unidad
en `verified` de un proyecto vivo falla el gate hasta que tenga su `plan.md`. Las `accepted`
solo avisan — deliberado: reabrir una unidad `accepted` está prohibido en la propia
constitución, así que fallar ahí no dejaría ninguna jugada legal; es el mismo carve-out de
retroactividad que ya usa `validate_source_manifest`. Los tres fixtures del golden-path se
actualizaron con su `plan.md` real, y el smoke ganó 3 casos (sin plan → falla; plan que no es
fichero → falla; `accepted` sin plan → solo avisa).

---

## DEC-ORCH-002 — El orden de obra bloquea al nacer, no solo avisa

```logic
id: DEC-ORCH-002
type: decision
status: applied
date: 2026-08-15
decided_by: "Sergio"
trigger: "el comentario de validate-state.py que empieza 'Global reachability alone was measured too weak' registra que la comprobación despejó 29 de 33 cimientos en el proyecto real, incluido el que iteró 14 veces; era el único defecto del fichero con coste medido y su única consecuencia era un warn (se cita por el TEXTO del comentario, no por número de línea: una cita fichero:línea envejece con el primer edit de arriba, y una cita rancia en un ledger de decisiones es el defecto que este fichero existe para evitar)"
rejected_alternative: "dejarlo en warn en todas las corridas (el estado anterior), y su opuesto: hacerlo fail SIEMPRE. Lo primero ya se probó y no funcionó — el proyecto que costó 4x fue avisado y siguió. Lo segundo es peor: una vez el proyecto está en marcha, un orden raro puede ser una decisión humana con razones que el gate no ve, y un gate que rechaza estados válidos acaba esquivado"
trip_wire: "FOUNDATION_CONSUMER_MAX_DISTANCE = 8 está calibrado con dos muestras (un fixture sano que llega a 2, un proyecto roto en el rango 3..33). Si un proyecto legítimo empieza a fallar --init-gate con cimientos que sí tienen consumidor razonable, la constante está mal, no la regla — recalíbrala antes de relajar el gate"
supersedes: []
written_to: [validate-state.py:validate_features, init-build/SKILL.md]
affects_screens: [ninguna existente — solo proyectos que nacen]
reopens: []
```

**Decisión:** la comprobación de cimiento-sin-consumidor sigue siendo `warn()` en toda corrida
normal del gate y pasa a `fail()` bajo `--init-gate`, que solo invoca `/init-build`.

**Por qué:** es el mismo argumento que pone `/arch-review` en t=0 — *el único momento en que
la arquitectura cambia gratis*. Al nacer no hay ninguna decisión humana que defender: nada
está construido, no hay evidencia, y reordenar `order`/`after[]` cuesta una edición. Una vez
el proyecto corre, la asimetría se invierte y el `warn` es lo correcto. Y es el único defecto
de este fichero con un precio medido: 307 lanzamientos contra 78 en la misma maquinaria, 4×,
porque un cimiento sin nada que lo ejecute no falla en su primera pasada — falla en la ronda
4, cuando algo por fin lo usa, y cada ronda es una reparación completa.

**Lo que reemplaza:** un `warn` que un `/build-loop --autonomous` no lee. La salida de escape
sigue existiendo y ahora queda escrita: si el orden es deliberado, se registra como un `DEC-*`
`accepted_with_risk` nombrando los cimientos y el porqué — una decisión en el registro en vez
de un aviso que nadie vio.

**Consecuencia:** `init-build/SKILL.md` documenta el orden de obra como disparador de CLARIFY
en el paso 3 y las **tres** cosas que `--init-gate` exige de más en el paso 6. Implementado
con un parámetro `init_gate` en `validate_features()`, no con una global: el script no tiene
ninguna variable global mutable y no es el sitio para estrenar la primera. Tres casos nuevos
de smoke (golden-path no dispara · gate normal avisa y sale 0 · `--init-gate` falla duro).
