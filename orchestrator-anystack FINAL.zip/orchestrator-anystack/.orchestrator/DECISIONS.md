# DECISIONS.md — decisiones sobre la MAQUINARIA del orquestador

> No confundir con `blueprint/DECISIONS.md`, que es el ledger de **producto** del proyecto que
> construyes con esto: nace vacío, lo llena tu proyecto, y `decided_by` es quien decide sobre
> tu producto. Este registra decisiones sobre el orquestador **mismo** — sus gates, sus
> contratos de evidencia, sus fases — y por eso vive en `.orchestrator/`, que es "definición
> estable, no estado vivo".
>
> Aquí solo entra lo **contractual**: un cambio que hace que un estado antes válido deje de
> serlo, o al revés. El resto del *porqué* de esta maquinaria vive donde siempre ha vivido, en
> los comentarios largos del código que lo implementa — un check no contractual se explica
> junto a su propio `if`, no en un fichero que nadie abre.
>
> Mismas reglas que el ledger de producto: **append-only**, una decisión por entrada, y el
> `trip_wire` es la parte que sostiene el peso — es lo que permite reabrir una decisión a quien
> no estuvo cuando se tomó.

## Índice

| ID | Fecha | Decisión | Supersede | Escrita en |
|---|---|---|---|---|
| DEC-ORCH-001 | 2026-08-15 | EXPLORE debe persistir su plan; el gate lo exige | — | `validate-state.py`, `next-pantalla/SKILL.md`, `constitution.md`, `conventions.md`, `result.schema.json` |
| DEC-ORCH-002 | 2026-08-15 | El orden de obra pasa de aviso a fallo duro en `--init-gate` | — | `validate-state.py`, `init-build/SKILL.md` |
| DEC-ORCH-003 | 2026-08-15 | Un set de lentes requerido es un historial ordenado; la evidencia completa bajo un set anterior avisa en vez de romper | — | `validate-state.py`, `smoke-golden-path.sh` |
| DEC-ORCH-004 | 2026-08-15 | Pre-flight determinista antes de cada abanico de VERIFY; `validate-structure.sh` exige dos scripts nuevos | — | `preflight-check.sh`, `lib/stack-command.sh`, `validate-structure.sh`, `next-pantalla/SKILL.md`, `constitution.md` |
| DEC-ORCH-005 | 2026-08-16 | `DEC-*` entra en el registro compartido del linter; `written_to` pasa a comprobarse contra disco | — | `lint-blueprint.py`, `smoke-golden-path.sh` |
| DEC-ORCH-006 | 2026-08-16 | Una pasada de VERIFY docs-only deriva su propio ámbito a las 4 lentes doc↔código | — | `verify-fanout.js`, `next-pantalla/SKILL.md`, `constitution.md` |
| DEC-ORCH-007 | 2026-08-16 | La racha de pasadas docs-only tiene tope 2; es el terminador que a DEC-ORCH-006 le faltaba | — | `validate-state.py`, `next-pantalla/SKILL.md`, `constitution.md`, `smoke-golden-path.sh` |
| DEC-ORCH-008 | 2026-08-16 | El adversario del diff: 4 preguntas de solo lectura entre la reparación y la prueba | — | `diff-adversary.js`, 4 agentes nuevos, `next-pantalla/SKILL.md`, `constitution.md`, `validate-structure.sh` |
| DEC-ORCH-009 | 2026-08-16 | El listón del adversario va en el hallazgo, no en el recuento: fuera toda expectativa de frecuencia | DEC-ORCH-008 (cláusula 5) | `diff-adversary.js`, los 4 agentes, `next-pantalla/SKILL.md`, `constitution.md` |
| DEC-ORCH-010 | 2026-08-16 | Un hallazgo es una INSTANCIA de una clase hasta que se barre: la reparación cierra la clase, no el punto | — | `repair-class-scan.md`, `next-pantalla/SKILL.md`, `constitution.md`, `conventions.md` |
| DEC-ORCH-011 | 2026-08-16 | El límite de la unidad gana diente: el gate avisa de todo fichero tocado que su propio `plan.md` no declara | — | `validate-state.py`, `next-pantalla/SKILL.md`, `smoke-golden-path.sh` |
| DEC-ORCH-012 | 2026-08-16 | El sintetizador NO agrupa por causa; un scan por hallazgo, lanzados en paralelo, ya responde esa pregunta con pruebas | — | `next-pantalla/SKILL.md` (§6) |
| DEC-ORCH-013 | 2026-08-17 | El adversario del diff deja de depender de que alguien se acuerde: un gate ejecutable impide lanzar el abanico caro sin él | — | `adversary-check.py`, `validate-structure.sh`, `smoke-golden-path.sh`, `next-pantalla/SKILL.md`, `fix/SKILL.md`, `constitution.md`, `orchestrator-flow.md`, `CLAUDE.md`, `README.md` |
| DEC-ORCH-014 | 2026-08-17 | `applies[]` gana comprobación de cobertura: toda regla citada la nombra algún check, o se declara diferida | — | `validate-state.py`, golden-path, `smoke-golden-path.sh` |
| DEC-ORCH-015 | 2026-08-17 | Lo que decide la salida de un hallazgo de lente es el VEREDICTO DE LA LENTE: si pasó, es advisory por defecto, con dueño y trip-wire | DEC-ORCH-008 (cláusula de las 10 lentes fuera del camino advisory) | `verify-fanout.js`, `verify-synthesizer.md`, `validate-state.py`, `constitution.md`, `next-pantalla/SKILL.md` |
| DEC-ORCH-016 | 2026-08-17 | Una VERIFY de cierre puede ser sólo-documental cuando la cadena entera desde la última completa lo es — y el gate lo camina (extiende DEC-ORCH-006/007, no las sustituye) | — | `validate-state.py`, `constitution.md`, `next-pantalla/SKILL.md`, `smoke-golden-path.sh` |
| DEC-ORCH-017 | 2026-08-17 | Una cifra en prosa se ata al comando que la deriva; y el class scan pregunta también por un hecho ESCRITO (amplía el sujeto de DEC-ORCH-010, no la sustituye) | — |
| DEC-ORCH-018 | 2026-08-17 | La memoria permanente deja de pagarse dos veces: fuera los `@import` de `.claude/rules/`, y el *porqué* de la constitución se va al ledger | — | `CLAUDE.md`, `constitution.md`, `smoke-golden-path.sh` | `derived-figures.py`, `repair-class-scan.md`, `validate-structure.sh`, `constitution.md`, `next-pantalla/SKILL.md` |
| DEC-ORCH-019 | 2026-08-18 | Un proyecto puede añadir un paso FATAL al checkpoint sin editar un fichero que el scaffold sobreescribe: el lanzador viaja con la maquinaria, la comprobación vive en `.orchestrator/hooks/pre-commit.d/`; y el ámbito de reparación lo escribe un script, no la memoria del conductor | — | `phase-push.sh`, `repair-scope.sh`, `hooks/pre-commit.d/README.md`, `next-pantalla/SKILL.md`, `smoke-golden-path.sh` |
| DEC-ORCH-020 | 2026-08-18 | El STATE GATE reporta TODOS los fallos independientes de una corrida, no solo el primero: descubrir de uno en uno era un multiplicador de rondas | — | `validate-state.py`, `smoke-golden-path.sh`, `CLAUDE.md`, `next-pantalla/SKILL.md` |
| DEC-ORCH-021 | 2026-08-18 | Las 4 lentes documentales de VERIFY pueden correr A LA VEZ que la cadena serializada, pero solo si el proyecto DECLARA que sus comandos de verificacion no reescriben fuentes | acota DEC-ORCH-004 | `verify-fanout.js`, `stack.md`, `golden-path/stack.md`, `smoke-golden-path.sh` |
| DEC-ORCH-022 | 2026-08-18 | `pantalla-reviewer` gana via advisory: un hallazgo cuya reparacion toca solo el REGISTRO se anota como deuda y no suspende; solo un defecto de PRODUCTO suspende | — | `pantalla-reviewer.md`, `smoke-golden-path.sh` |
| DEC-ORCH-023 | 2026-08-18 | El gate AVISA cuando un artefacto citado es anterior al codigo que dice certificar (por fecha de commit, nunca por mtime). Aviso y no fallo, a proposito | — | `validate-state.py`, `smoke-golden-path.sh` |
| DEC-ORCH-024 | 2026-08-18 | NO se construye politica de poda de evidencia: lo unico podable sin tocar una prueba es el 0,7-1,1% del arbol. El peso esta en artefactos CITADOS, que son intocables por definicion | — | `DECISIONS.md` (decision de NO construir) |

---

## DEC-ORCH-001 — EXPLORE persiste su plan y el gate lo exige

```logic
id: DEC-ORCH-001
type: decision
status: applied
date: 2026-08-15
decided_by: "Sergio"
trigger: "auditoría del flujo contra el SDD canónico: la fase /plan era el único paso del ciclo specify→plan→tasks→implement sin equivalente aquí, y el plan que sí se escribía vivía solo en el contexto del conductor"
rejected_alternative: "PLAN como 7ª fase propia en phase_runs[]. Descartada tras el recon: obligaba a tocar 9 sitios de prosa que enumeran las fases, required_phases, dos schemas y el enum de checkpoint.phase, y volvía FALSA la frase de la constitución 'DEVELOP is the only phase with no workflow by design'. Además era ceremonia: la sección que produce el plan ya se llama 'Explore AND PLAN', así que el plan es el ENTREGABLE de EXPLORE, no una fase aparte"
trip_wire: "si alguna vez PLAN necesita fan-out propio (lentes que planifiquen en paralelo), deja de ser un artefacto de EXPLORE y vuelve a ser una fase — y entonces sí hay que pagar los 9 sitios de prosa. Mientras el conductor sea el único que lo escribe, esta forma es la correcta"
supersedes: []
written_to: [validate-state.py:validate_phase_coverage, next-pantalla/SKILL.md, constitution.md, conventions.md, result.schema.json, verify-conformance.md, pantalla-reviewer.md]
affects_screens: [TODAS las unidades no accepted]
reopens: []
```

**Decisión:** la entrada EXPLORE de `result.json.phase_runs[]` lleva `plan:
".orchestrator-state/evidence/<ID>/plan.md"`, y ese fichero tiene que existir y no pesar 0
bytes para que la unidad pueda cerrar en PASS. El plan contiene el **mapa de aceptación** (una
fila por criterio: IDs que lo rigen, ficheros a tocar, **cómo se probará**, artefacto
esperado), el orden vertical, el **consumidor declarado** de la unidad, y una sección
`## Delivery` que DEVELOP cierra declarando entregado / entregado-con-desviación / no
entregado.

**Por qué:** el plan existía —`next-pantalla` §2 siempre dijo "escribe el plan vertical"— pero
solo en el contexto del conductor. De ahí salían tres cosas, y la tercera es la que paga el
cambio. (1) Una compactación a mitad de DEVELOP lo re-derivaba, justo en el momento en que
peor se re-deriva, porque lo que se acaba de borrar es la memoria de lo que ya habías
decidido. (2) Nada podía preguntar *¿se construyó lo que se planeó?* — `pantalla-reviewer`
juzga código contra `acceptance[]` y `verify-conformance` contra el blueprint; ninguna de las
dos es esa pregunta. (3) Un criterio sin respuesta en la columna *cómo se probará* no se veía
hasta VERIFY, doce lanzamientos después, y costaba una iteración de debugger completa. Ahora
salta en EXPLORE por cero.

**Lo que reemplaza:** nada nuevo en intención — reemplaza un plan implícito por uno
falsable. Coste en lanzamientos de subagente: **cero**. Lo escribe el conductor inline, que
es también lo que impide que se convierta en auto-revisión: la sección `## Delivery` es una
DECLARACIÓN, y los dientes los ponen dos agentes independientes — `verify-conformance` la
audita desde el código (`plan_delivery[]`) y `pantalla-reviewer` nombra cada desviación
(`plan_deviations[]`, con `declared:false` como gap).

**Consecuencia:** **es un cambio contractual y rompe evidencia existente.** Cualquier unidad
en `verified` de un proyecto vivo falla el gate hasta que tenga su `plan.md`. Las `accepted`
solo avisan — deliberado: reabrir una unidad `accepted` está prohibido en la propia
constitución, así que fallar ahí no dejaría ninguna jugada legal; es el mismo carve-out de
retroactividad que ya usa `validate_source_manifest`. Los tres fixtures del golden-path se
actualizaron con su `plan.md` real, y el smoke ganó 3 casos (sin plan → falla; plan que no es
fichero → falla; `accepted` sin plan → solo avisa).

---

## DEC-ORCH-002 — El orden de obra bloquea al nacer, no solo avisa

```logic
id: DEC-ORCH-002
type: decision
status: applied
date: 2026-08-15
decided_by: "Sergio"
trigger: "el comentario de validate-state.py que empieza 'Global reachability alone was measured too weak' registra que la comprobación despejó 29 de 33 cimientos en el proyecto real, incluido el que iteró 14 veces; era el único defecto del fichero con coste medido y su única consecuencia era un warn (se cita por el TEXTO del comentario, no por número de línea: una cita fichero:línea envejece con el primer edit de arriba, y una cita rancia en un ledger de decisiones es el defecto que este fichero existe para evitar)"
rejected_alternative: "dejarlo en warn en todas las corridas (el estado anterior), y su opuesto: hacerlo fail SIEMPRE. Lo primero ya se probó y no funcionó — el proyecto que costó 4x fue avisado y siguió. Lo segundo es peor: una vez el proyecto está en marcha, un orden raro puede ser una decisión humana con razones que el gate no ve, y un gate que rechaza estados válidos acaba esquivado"
trip_wire: "FOUNDATION_CONSUMER_MAX_DISTANCE = 8 está calibrado con dos muestras (un fixture sano que llega a 2, un proyecto roto en el rango 3..33). Si un proyecto legítimo empieza a fallar --init-gate con cimientos que sí tienen consumidor razonable, la constante está mal, no la regla — recalíbrala antes de relajar el gate"
supersedes: []
written_to: [validate-state.py:validate_features, init-build/SKILL.md]
affects_screens: [ninguna existente — solo proyectos que nacen]
reopens: []
```

**Decisión:** la comprobación de cimiento-sin-consumidor sigue siendo `warn()` en toda corrida
normal del gate y pasa a `fail()` bajo `--init-gate`, que solo invoca `/init-build`.

**Por qué:** es el mismo argumento que pone `/arch-review` en t=0 — *el único momento en que
la arquitectura cambia gratis*. Al nacer no hay ninguna decisión humana que defender: nada
está construido, no hay evidencia, y reordenar `order`/`after[]` cuesta una edición. Una vez
el proyecto corre, la asimetría se invierte y el `warn` es lo correcto. Y es el único defecto
de este fichero con un precio medido: 307 lanzamientos contra 78 en la misma maquinaria, 4×,
porque un cimiento sin nada que lo ejecute no falla en su primera pasada — falla en la ronda
4, cuando algo por fin lo usa, y cada ronda es una reparación completa.

**Lo que reemplaza:** un `warn` que un `/build-loop --autonomous` no lee. La salida de escape
sigue existiendo y ahora queda escrita: si el orden es deliberado, se registra como un `DEC-*`
`accepted_with_risk` nombrando los cimientos y el porqué — una decisión en el registro en vez
de un aviso que nadie vio.

**Consecuencia:** `init-build/SKILL.md` documenta el orden de obra como disparador de CLARIFY
en el paso 3 y las **tres** cosas que `--init-gate` exige de más en el paso 6. Implementado
con un parámetro `init_gate` en `validate_features()`, no con una global: el script no tiene
ninguna variable global mutable y no es el sitio para estrenar la primera. Tres casos nuevos
de smoke (golden-path no dispara · gate normal avisa y sale 0 · `--init-gate` falla duro).

---

## DEC-ORCH-003 — Un set de lentes requerido es un historial, no un set

```logic
id: DEC-ORCH-003
type: decision
status: applied
date: 2026-08-15
decided_by: "Sergio"
trigger: "revisión adversaria del propio orquestador: require_full_fanout era la ÚNICA función de cobertura del fichero sin la rama warn-si-accepted que el resto aplica sistemáticamente, y compara toda entrada histórica contra la constante ACTUAL. Consecuencia medida sobre el golden-path: crecer VERIFY de 10 a 11 lentes hace fail() duro en la primera unidad ya verified, el hook corre el gate en cada escritura de features.json, y la reabertura que lo arreglaría es ella misma una escritura que el gate bloquea — el proyecto ENTERO queda sin jugada legal, no solo la unidad"
rejected_alternative: "grabar un campo nuevo por entrada (lens_set_size / lens_set_version) y comparar cada entrada contra lo que ELLA declaró. Descartada: toda entrada ya escrita carece del campo, así que su ausencia habría que interpretarla de todos modos — se paga un campo nuevo, un cambio de schema y una cosa más que el conductor debe acordarse de escribir, para acabar necesitando igual la misma regla de grandfathering. La otra descartada: fallar duro y reabrir a mano cada unidad afectada, que es exactamente la jugada que la constitución prohíbe sobre accepted"
trip_wire: "el mecanismo NO distingue una entrada genuinamente vieja de una nueva que registró un set viejo — nada en la entrada dice cuándo cambió el set. El respaldo es que validate-structure.sh fuerza a cada fan-out .js a coincidir con el set ACTUAL, así que una corrida nueva lanza físicamente todas las lentes de hoy. Si alguna vez ese respaldo se afloja (un workflow que elija su set en runtime, o un .js que deje de compararse), este grandfathering pasa de red de seguridad a agujero y hay que sustituirlo por la alternativa descartada arriba. Segundo trip-wire: si covered_set() llegara a aceptar un set que nunca fue completo bajo ninguna versión histórica, la regla está rota, no relajada"
supersedes: []
written_to: [validate-state.py:require_full_fanout, validate-state.py:RESEARCH_LENS_SETS, validate-state.py:EXPLORE_LENS_SETS, validate-state.py:VERIFY_LENS_SETS, smoke-golden-path.sh]
affects_screens: [ninguna existente — solo amplía lo que el gate acepta]
reopens: []
```

**Decisión:** `RESEARCH_LENSES` / `EXPLORE_LENSES` / `VERIFY_LENSES` dejan de ser el argumento de
`require_full_fanout` y pasan a serlo `*_LENS_SETS`, una tupla ordenada con el set vigente al
final. Tres resultados: cubre el set actual → pasa igual que siempre; cubre uno **superseded** →
`warn()` que nombra el remedio; no cubre **ninguno** → `fail()` con el mensaje de siempre. Crecer
un set es añadir una entrada a la tupla y no tocar las anteriores.

**Por qué:** un `phase_runs[]` registra lo que corrió **cuando la unidad corrió**, y medirlo
contra la constante de hoy convierte cada crecimiento del set en una invalidación retroactiva de
todo lo ya construido. El resultado no era un gate estricto sino un gate que **no se puede
evolucionar**: el orquestador no podía añadir una lente a ninguna de sus tres fases de fan-out
sin abandonar cualquier proyecto con historial. Y era una asimetría accidental, no una postura:
`validate_source_manifest`, el guard de artefactos y el de `plan.md` ya tenían su carve-out; esta
función se quedó sin él.

**Lo que reemplaza:** un fallo duro por un aviso **solo** en el caso en que la evidencia fue
completa bajo las reglas de su momento. Un set genuinamente parcial —que no cubre ningún set que
esta fase haya requerido nunca— sigue siendo `fail()` con el mismo mensaje: esto no relaja el
estándar, distingue *incompleto* de *anterior*.

**Consecuencia — y el defecto que el propio cambio introdujo.** Mientras "completa" significó
"cubre el único set actual", una entrada completa había corrido **toda** lente del set, así que
`carried_forward[]` podía citar solo la **iteración**. El grandfathering rompe esa implicación: una
entrada puede ser completa para un set superseded, y una cita por iteración dejaba entonces que un
triage arrastrase una lente **añadida después** de la pasada que cita — una lente que esa pasada
provablemente nunca ejecutó, sin `warn` ni `fail`. Lo encontraron dos revisores independientes con
control A/B sobre la misma evidencia fabricada. La cita se comprueba ahora contra las **lentes
realmente corridas** por la entrada citada, no contra su número de iteración. El smoke ganó tres
casos (superseded avisa y no rompe · parcial sigue fallando · carrear una lente que la pasada
citada nunca corrió falla), los tres verificados por mutación: revertir el arreglo los pone en
rojo.

---

## DEC-ORCH-004 — Un pre-flight determinista precede a cada abanico de VERIFY

```logic
id: DEC-ORCH-004
type: decision
status: applied
date: 2026-08-15
decided_by: "Sergio"
trigger: "verify-fanout.js espera sus 4 lentes documentales al completo antes de arrancar la mitad serializada, y la lente que prueba el build (verify-frontend) es la PRIMERA de esa mitad. En una pasada donde el codigo no compila se pagan 5 lanzamientos de subagente para saber lo que <COMMAND_BUILD> dice en segundos — y como un VERIFY fallido es una pasada de reparacion, una errata puede gastar un tercio de las 3 iteraciones de la unidad. El conductor nunca corria los comandos del stack por su cuenta: solo setup/smoke al rehidratar, una vez por unidad"
rejected_alternative: "solapar las 4 documentales con la cadena serie dentro de verify-fanout.js (ahorra reloj sin script nuevo). Descartada: hoy las documentales leen un arbol EN REPOSO, y solaparlas las expone a leer fuentes mientras un lint --fix o unos snapshots las reescriben — reintroduce la clase de fallo que pertenece-al-vecino que la serializacion existe para eliminar. La otra descartada: meter COMMAND_TEST en el set por defecto; verify-tests ya corre la suite entera de forma incondicional en cada pasada, asi que pagaria el comando mas lento dos veces en el camino feliz"
trip_wire: "el pre-flight NO es evidencia y jamas entra en phase_runs[]: si algun dia una entrada de phase_runs cita el pre-flight, o si verify-frontend/verify-tests dejan de correr porque 'el pre-flight ya lo comprobo', la regla esta rota y hay que revertir. Segundo trip-wire: el tope de 2 intentos vive solo en el contexto del conductor (una compactacion lo reinicia); si aparece un caso real de bucle de pre-flight que no llega a blocked, ese contador necesita un campo en disco"
supersedes: []
written_to: [preflight-check.sh, lib/stack-command.sh, validate-structure.sh, smoke-golden-path.sh, next-pantalla/SKILL.md, fix/SKILL.md, orchestrator-flow.md, constitution.md, stack.md, CLAUDE.md, README.md]
affects_screens: [ninguna existente — no cambia ninguna evidencia ya escrita]
reopens: []
```

**Decision:** antes de CADA lanzamiento de `verify-fanout` —incluidas todas las re-corridas del debugger— el conductor ejecuta `preflight-check.sh`, que corre `COMMAND_LINT` y `COMMAND_BUILD` de `stack.md`. Non-zero: reparar y re-correr **sin lanzar el abanico y sin incrementar `checkpoint.iteration`**, parando tras el segundo fallo consecutivo. Ademas, cuando una pasada de VERIFY devuelve varios fallos, se reparan en orden de causalidad (build → tests → engine → pipeline → logs → quality → las 4 documentales).

**Por que es CONTRACTUAL y entra en este ledger.** No por el pre-flight en si —que es prosa de conductor— sino porque `validate-structure.sh` ahora exige `preflight-check.sh` y `lib/stack-command.sh` en su `required[]`: un checkout que antes pasaba la validacion de estructura, sin esos dos ficheros, ya no pasa. Eso es exactamente "un cambio que hace que un estado antes valido deje de serlo".

**Lo que reemplaza:** el parser de `stack.md` estaba embebido en `reset-test-data.sh`; se extrajo a `lib/stack-command.sh` para que ambos scripts lean el fichero igual, en vez de duplicar un awk que habria divergido en cuanto uno de los dos aprendiera algo. Y `stack.md` gano los marcadores `(COMMAND_LINT)`/`(COMMAND_BUILD)`/`(COMMAND_TEST)`: sin ellos el parser —que trata el marcador como la declaracion, no el texto del comentario— no encontraba nada.

**Consecuencia, incluido lo que la revision adversaria encontro roto.** El script nacio sin el guard de `BASH_SOURCE` que su hermano si tiene, y por tanto, invocado por un shell que no lo define, degradaba a `exit 0 / nothing to check`: **exito silencioso en el unico script cuyo trabajo entero es avisar de un fallo**. Cerrado con `exit 2` propio (ni "no aplica" ni "un comando fallo", sino "no se pudo comprobar") y dos casos de smoke que ningun test cubria. El smoke paso de 92 a 99 casos.

---

## DEC-ORCH-005 — `DEC-*` entra en la maquinaria de integridad, y `written_to` deja de ser una promesa

```logic
id: DEC-ORCH-005
type: decision
status: applied
date: 2026-08-16
decided_by: "Sergio"
trigger: "medido en el proyecto real maser-invariant-chronicle: dos '## DEC-062' distintos con sus dos filas de índice y lint-blueprint.py salía 0. Lo cazaron TRES lentes de VERIFY — la inversión exacta de 'lo que un script puede decidir no debe costar nunca un fan-out' — al precio de una vuelta completa de depurador. En el mismo proyecto, `written_to` estuvo mal 4 veces en 2 ciclos (un fichero declarado que nunca se escribió, otro escrito que nunca se declaró) pese a que autonomy.md ya lo advertía en prosa"
rejected_alternative: "arreglar la FRASE en vez del código — constitution.md promete 'lint-blueprint.py catches dangling refs, duplicate IDs, cycles and stubs' y para DEC-* eso era falso, así que degradar la promesa era una salida legal. Descartada: la cobertura es barata (una línea de aritmética) y la promesa es lo que sostiene los tiers baratos de edición del blueprint; rebajarla habría empujado ediciones editoriales hacia /reslice. La otra descartada: enseñar a cada regla a leer DECISIONS.md — arregla el duplicado de hoy y ninguna regla futura"
trip_wire: "la aritmética `occurrences[len(defined.get(dec_id, [])):]` es lo único que separa este arreglo de sus tres trampas medidas (el `|=` con 314 errores espurios, el falso 'duplicate ID DEC-001' sobre la forma canónica, y la guarda `if id not in defined` que desactiva la detección entera). Si alguien la 'simplifica', los tres casos de smoke añadidos aquí se ponen rojos: son la red, no la decoración. Segundo trip-wire, y el que de verdad importa: si `family_coverage` deja de emitirse bajo --json, o si el aviso de familia-fuera-del-registro se silencia, vuelve el defecto de CLASE — un linter que cubre 15 de 16 familias sin decirlo"
supersedes: []
written_to: [.orchestrator/scripts/lint-blueprint.py, .orchestrator/scripts/smoke-golden-path.sh]
affects_screens: [ninguna existente — solo proyectos con blueprint/DECISIONS.md poblado]
reopens: []
```

**Decisión:** tres cambios en `lint-blueprint.py`, uno por capa del defecto.

1. **Las cabeceras `## DEC-*` entran en el registro compartido** (`defined`), en el número que EXCEDE a los bloques que ya definen ese id. Con eso, la regla de duplicados que siempre existió pasa a cubrir el ledger sin tocar la regla, y cubre también cualquier regla que se añada después. Se añade el defecto espejo que encontró la sonda: las filas del índice se recogían con `set()`, así que una fila repetida también salía 0.
2. **Invariante meta:** el linter calcula ahora su propia tabla de cobertura por familia (`family_coverage` bajo `--json`) y AVISA cuando una familia entera vive fuera del registro. Esto es lo que impide la recurrencia; el punto 1 arregla `DEC-*`, este arregla la clase.
3. **`written_to` se comprueba contra el disco**, en las dos direcciones: lo declarado existe (ERROR si una ruta no resuelve) y lo escrito está declarado (WARNING si una capa cita una decisión que su `written_to` no nombra).

**Por qué:** toda la integridad referencial de este fichero opera sobre ids declarados en bloques cercados, y `DEC-*` es la única familia cuyas entradas se escriben rutinariamente como cabecera + fila. Medido: 15 de 16 familias 100% cubiertas (315 ids), `DEC-*` con 1 bloque —el ejemplo de la plantilla— y 62 entradas invisibles. La cobertura no era del 94%: era del 94% **en silencio**, que es lo que la hizo durar. Y el sub-defecto que salió al leerlo: el bloque de `DECISIONS.md` REASIGNABA `heading_ids`, la variable de alcance global llena con las cabeceras de todo el blueprint, así que la rama "esto solo existe como cabecera" del comprobador de referencias colgantes trabajaba con 63 ids en vez de 376 y estaba muerta para todas las demás familias — una referencia a un `DOM-*` solo-cabecera daba error duro en vez del aviso previsto. Confirmado por mutación A/B sobre el mismo fixture.

**Lo que reemplaza:** una promesa de `constitution.md` que para `DEC-*` era falsa, y una advertencia en prosa de `autonomy.md` que falló cuatro veces seguidas. Cuatro fallos de la misma advertencia escrita no son información sobre quien la escribe, son información sobre la regla — el mismo razonamiento que este orquestador ya aplicó al frontmatter `tools:`.

**Consecuencia:** **es contractual y rompe estados antes válidos.** Un `blueprint/DECISIONS.md` con ids duplicados, filas repetidas o un `written_to` que apunta a un fichero inexistente pasaba el lint y ahora sale 1. El coste en lanzamientos de subagente es **cero**. La salida sobre un blueprint sano es byte a byte idéntica al baseline (verificado con `diff`). El smoke pasó de 113 a 119 casos, los seis verificados por mutación: desactivando el arreglo, los seis se ponen rojos.

---

## DEC-ORCH-006 — Una pasada de VERIFY docs-only deriva su propio ámbito

```logic
id: DEC-ORCH-006
type: decision
status: applied
date: 2026-08-16
decided_by: "Sergio"
trigger: "si una pasada de reparación no tocó código, motores/pipelines/tests/build siguen probados y lanzar las 10 lentes paga seis subagentes que no tienen nada que mirar. La regla ya estaba escrita en constitution.md ('re-run the doc<->code lenses and stop') y en next-pantalla §5.5, pero solo como prosa que el conductor debía recordar y traducir a mano a scope_to=..., así que en la práctica no corría nunca"
rejected_alternative: "un flag `docs_only` nuevo en la entrada de phase_runs[] que relajase, solo para él, la prohibición de que la entrada de cierre lleve full_set:false. Descartada por dos razones: el gate no puede contrastar ese flag contra nada objetivo (no lee changed-files.txt), así que sería el conductor autocertificándose; y el mecanismo que ya existe —full_set:false + carried_forward[]— es ESTRICTAMENTE mejor, porque obliga a nombrar de qué pasada completa se hereda cada veredicto en vez de afirmar que seis lentes no hacían falta. La otra descartada: encoger VERIFY_LENSES, que habría roto el sync .js<->.py de validate-structure.sh y cambiado `needed` para todas las unidades"
trip_wire: "el clasificador es la pieza frágil. Hoy solo cuentan como documentación las extensiones de prosa (.md/.mdx/.markdown/.txt/.rst/.adoc) y el propio árbol .orchestrator-state/; un .py/.js/.sh/.css/.sql basta para forzar la pasada completa. Si alguien amplía esa lista a extensiones que SÍ ejecutan (.json de configuración fuera del estado, .yaml de CI, .css de tokens), el derivador empezará a saltarse lentes que sí tenían algo que mirar y el fallo será silencioso en la dirección mala. Segundo trip-wire: si validate-state.py dejara de rechazar una entrada de CIERRE con full_set:false, esto pasaría de ahorro a agujero — esa prohibición es lo único que impide que una unidad cierre con 4 lentes"
supersedes: []
written_to: [.claude/workflows/verify-fanout.js, .claude/skills/next-pantalla/SKILL.md, .claude/rules/constitution.md]
affects_screens: [ninguna existente — no invalida ninguna evidencia ya escrita]
reopens: []
```

**Decisión:** cuando TODAS las rutas de `evidence/<ID>/logs/changed-files.txt` son documentación, blueprint, informe o evidencia, `verify-fanout.js` deriva su ámbito a las cuatro lentes doc↔código (`DOCUMENTARY_LENSES`) y no lanza las otras seis. No se pide y no se puede olvidar. Nunca dispara en una pasada baseline, nunca contra un `scope_to` explícito, y `# triage: full_verify` (o `args.full_verify`) lo desactiva para la pasada que se pretende de cierre.

**Por qué el conjunto derivado es `DOCUMENTARY_LENSES` y no una lista nueva:** "las lentes doc↔código" y "las lentes restringidas a herramientas de solo lectura" son los mismos cuatro agentes, y esa igualdad ya la impone fuera de banda `validate-structure.sh` contra el frontmatter `tools:` de cada agente. Una segunda lista escrita a mano sería una tercera fuente de verdad y derivaría en cuanto se re-scope una lente. El acoplamiento es deliberado.

**Por qué no puede fabricar un PASS**, que es la única dirección que importaría: devuelve `full_set:false`, y `validate-state.py` rechaza duro una entrada de CIERRE con `full_set:false`, y rechaza una no-de-cierre cuyo `lenses[]` ∪ `carried_forward[]` no cubra el set completo citando una pasada anterior genuinamente completa. El peor caso es una re-corrida desperdiciada, avisada a gritos. Nunca una unidad cerrando con cuatro lentes.

**Consecuencia:** un `blueprint/**.md` en la lista SÍ deriva — una edición de spec es el cambio más consecuente de este repositorio, no el menos, y las cuatro lentes a las que deriva son exactamente las que juzgan el código contra la spec. Una edición **contractual** sigue siendo `/reslice`, no una iteración de depurador. El clasificador se probó con 11 casos (incluidos `.css`, `.sh`, `.js`, `.sql` y `package.json`, todos → pasada completa).

---

## DEC-ORCH-007 — La racha docs-only tiene tope: el terminador que faltaba

```logic
id: DEC-ORCH-007
type: decision
status: applied
date: 2026-08-16
decided_by: "Sergio"
trigger: "el dueño pidió revisar que los VERIFY no entren en bucle infinito 'o que solo cambien texto y se lance el verify otra vez'. Tres lentes Sonnet independientes trazaron las 7 aristas que relanzan VERIFY y coincidieron: SEIS están acotadas por checkpoint.iteration (3) o total_repair_passes (12), impuestos por validate-state.py. La séptima —la pasada docs-only que introdujo DEC-ORCH-006— no consume ninguno de los dos POR DISEÑO, y grep de 'docs_only' en validate-state.py y en los schemas devolvía cero: no existía ningún otro tope. El bucle es el que la propia constitución ya nombra: una lente pide escribir en el blueprint, la escritura es docs-only, la pasada docs-only relanza esas mismas 4 lentes, y una puede pedir la siguiente escritura"
rejected_alternative: "que la pasada docs-only SÍ consuma checkpoint.iteration. Descartada porque anula entero el ahorro que motivó DEC-ORCH-006 y devuelve el problema original: gastar una de las 3 iteraciones del depurador escribiendo una frase en blueprint/logic/error.md. La otra descartada: un campo nuevo checkpoint.docs_only_streak en features.json — un contador que solo vive en un campo que el conductor debe acordarse de mantener reproduce la misma clase de fallo que obligó a mover el retry-once y la propia derivación docs-only DENTRO del workflow ('prose is not a control'). La racha se DERIVA de derived_scope, que el conductor ya está obligado a registrar en phase_runs[], así que no hay nada nuevo que recordar y no se puede gastar el presupuesto sin dejar el rastro"
trip_wire: "el tope se cuenta sobre `derived_scope:\"docs_only\"` en las entradas VERIFY de phase_runs[]. Si alguna vez el conductor deja de registrar ese campo —o si verify-fanout.js deja de devolverlo— el contador ve cero rachas y el bucle vuelve a no tener cota, en silencio. Segundo trip-wire, distinto y no cerrado aquí: al congelar checkpoint.iteration durante una racha, la guarda de frescura de changed-files.txt (que identifica la pasada solo por '# iteration:') pierde la unicidad por pasada. Con el tope en 2 la ventana es corta, pero si alguien sube el tope hay que darle a la cabecera un segundo valor que sí avance"
supersedes: []
written_to: [.orchestrator/scripts/validate-state.py, .claude/skills/next-pantalla/SKILL.md, .claude/rules/constitution.md, .orchestrator/scripts/smoke-golden-path.sh]
affects_screens: [ninguna existente — ningún proyecto tiene hoy rachas registradas]
reopens: []
```

**Decisión:** como máximo **2 pasadas docs-only consecutivas**. La tercera corre el set completo y cuesta una iteración como cualquier reparación, o la unidad va a `blocked`. `validate-state.py` cuenta la racha desde `derived_scope` en `phase_runs[]`; `DOCS_ONLY_STREAK_CAP = 2`.

**Por qué 2 y no otro número:** una pasada propaga la escritura que la lente pidió, una segunda absorbe lo que esa escritura implicó, y una tercera seguida es la firma de un bucle que se alimenta a sí mismo en vez de converger. No es una constante nueva sacada de la nada: es el mismo razonamiento que el tope de 3 del depurador, aplicado a una clase de pasada más barata.

**Lo que reemplaza:** una exención sin cota. DEC-ORCH-006 demostró que la derivación docs-only no puede fabricar un PASS —y sigue siendo cierto— pero eso es ausencia de FALSO POSITIVO, no TERMINACIÓN. Nunca contempló una cadena de pasadas consecutivas. Esta entrada cierra esa mitad.

**Consecuencia:** **es contractual.** Un `phase_runs[]` con 3 o más entradas VERIFY `docs_only` seguidas pasaba el gate y ahora sale 1 (aviso, no fallo, si la unidad ya está `accepted` — el mismo carve-out de retroactividad del resto del fichero). El smoke pasó de 122 a **124 casos**, ambos verificados por mutación: subiendo el tope a 999 el caso rojo deja de detectar.

---

## DEC-ORCH-008 — El adversario del diff: la pregunta que las diez lentes no pueden hacer

```logic
id: DEC-ORCH-008
type: decision
status: applied
date: 2026-08-16
decided_by: "Sergio"
trigger: "propuesta del dueño: 'cuando salte el develop (para reparar) lo suyo seria que hubiera 3 agentes... reparación (DEVELOP) → adversario del DIFF → arreglar → verify-fanout'. Su caso canónico, medido en su propio proyecto: 'mi arreglo no rompió nada visible, volvió inalcanzable la denegación auditada. Pasó las 10 lentes estáticas.' Es una clase de defecto que el fan-out no puede ver por construcción — las diez lentes preguntan si algo ESTÁ, ninguna puede preguntar si algo DEJÓ DE SER ALCANZABLE"
rejected_alternative: "un hook PostToolUse sobre Edit/Write. Descartado por tres límites duros y documentados del harness, no por gusto: PostToolUse NO bloquea ('the tool already ran', solo PreToolUse bloquea); los agent-hooks 'cannot spawn nested subagents', así que no pueden abanicar a cuatro; y la granularidad no encaja — PostToolUse dispara por CADA edición, no por 'la reparación terminó', que es un límite semántico que solo el conductor conoce. La otra descartada: hacerlo una fase con su lens set en validate-state.py — lo convertiría en un fan-out obligatorio con set completo, que es exactamente el generador de vueltas que su carta prohíbe"
trip_wire: "la carta es todo el diseño. Si alguna de estas cinco cláusulas se afloja, esto pasa de ahorrar vueltas a fabricarlas: (1) no es evidencia — nunca phase_runs[]/checks[]/advisory_findings[]; (2) no gasta iteración; (3) el hallazgo se pliega en la MISMA pasada, nunca abre una ronda; (4) corre como mucho UNA vez por pasada y jamás se re-invoca sobre su propio arreglo; (5) nothing_found es la respuesta esperada. Segundo trip-wire, y es medible: si alguien añade ADVERSARY_LENSES a validate-state.py 'por coherencia con los demás fan-outs', la pieza queda convertida en su contrario. Hay un caso de smoke que lo prohíbe explícitamente. Tercero: el punto de equilibrio medido es que debe cazar algo real en un 30-40% de las REPARACIONES para salir a cuenta en subagentes (4 contra los ~18 de una vuelta completa); en reloj sale a cuenta mucho antes, porque los 4 corren en paralelo y comparten prefijo de caché. Nadie lo mide todavía"
supersedes: []
written_to: [.claude/workflows/diff-adversary.js, .claude/agents/diff-adversary-regression.md, .claude/agents/diff-adversary-incomplete.md, .claude/agents/diff-adversary-unreachable.md, .claude/agents/diff-adversary-edge.md, .claude/skills/next-pantalla/SKILL.md, .claude/rules/constitution.md, .orchestrator/scripts/validate-structure.sh, .orchestrator/scripts/smoke-golden-path.sh]
affects_screens: [ninguna existente — solo pasadas de reparación futuras]
reopens: []
```

**Decisión:** en toda pasada de REPARACIÓN —nunca en el primer DEVELOP, nunca en una pasada docs-only— el conductor vuelca el diff a `evidence/<ID>/logs/repair-diff.patch` y lanza `diff-adversary.js`: cuatro agentes de solo lectura, cuatro preguntas fijas, en paralelo, entre la reparación y la prueba.

**La tercera pregunta es la razón de existir del resto.** *¿Qué ha vuelto inalcanzable, muerto o no ejecutado este diff — incluida una comprobación que antes se alcanzaba?* Ninguna de las diez lentes puede formularla: todas comprueban presencia. Una guarda de permiso que deja de evaluarse compila, pasa la suite, satisface las diez y se despliega.

**Por qué es contractual:** `validate-structure.sh` gana dos comprobaciones nuevas y un fichero requerido, así que un checkout que antes pasaba la validación de estructura —sin `diff-adversary.js`, o con uno de los cuatro agentes con `Bash`— ya no pasa.

**Lo que deliberadamente NO se hizo:** no hay `ADVERSARY_LENSES` en `validate-state.py`, y hay un caso de smoke que comprueba su ausencia. Las dos garantías que sí tiene son mecánicas: los cuatro existen, y los cuatro son de solo lectura. La tercera —"corrieron todos"— no se puede exigir sin convertirlo en fase, así que se resuelve en el retorno: `clean` solo es cierto si los cuatro RESPONDIERON y ninguno encontró nada; un adversario muerto nunca se lee como una pasada limpia. El smoke pasó de 124 a **127 casos**, los tres verificados por mutación.

---

## DEC-ORCH-009 — El listón va en el hallazgo, no en el recuento

```logic
id: DEC-ORCH-009
type: decision
status: applied
date: 2026-08-16
decided_by: "Sergio"
trigger: "el dueño, leyendo la carta que yo acababa de escribir: 'y esto no es así: debe devolver nada casi siempre. porque puede que encuentre algo pero tampoco obligar a acertar sino la realidad'. DEC-ORCH-008 formulaba su quinta cláusula como una expectativa de FRECUENCIA ('nothing_found es la respuesta esperada', 'la mayoría de las veces deberías') y el propio informe de coste añadía por el otro lado un umbral de acierto del 30-40%. Son dos cuotas apuntando en direcciones opuestas, y ambas caen sobre la RESPUESTA en vez de sobre el ESTÁNDAR"
rejected_alternative: "dejarlo como estaba argumentando que el sesgo hacia 'nada' es el conservador y por tanto el seguro. Es falso, y es el error más caro de los dos: la clase de defecto que motivó toda la pieza —una denegación auditada vuelta inalcanzable— es RARA y fácil de descartar dudando. Un adversario al que se le ha dicho que normalmente no encuentra nada tiene un motivo escrito para callarse justo en el caso para el que existe. La otra descartada: convertir el 30-40% en objetivo del agente — fabricaría hallazgos, que es el fallo simétrico"
trip_wire: "cualquier frase futura en estos ficheros que hable de CUÁNTAS veces debe encontrar algo —en cualquiera de las dos direcciones— reintroduce el defecto. La formulación correcta se reconoce por dónde cae el listón: sobre el hallazgo (concreto, falsable, causado por ESTE diff), nunca sobre el número. Segundo trip-wire: el umbral de rentabilidad del 30-40% sigue siendo real y sigue sin medirse, pero es una pregunta del DUEÑO sobre si la pieza compensa, no una instrucción al agente; si alguna vez aparece dentro de un prompt, se ha cruzado la línea"
supersedes: [DEC-ORCH-008]
written_to: [.claude/workflows/diff-adversary.js, .claude/agents/diff-adversary-regression.md, .claude/agents/diff-adversary-incomplete.md, .claude/agents/diff-adversary-unreachable.md, .claude/agents/diff-adversary-edge.md, .claude/skills/next-pantalla/SKILL.md, .claude/rules/constitution.md]
affects_screens: [ninguna]
reopens: []
```

**Decisión:** la quinta cláusula de la carta deja de ser *"`nothing_found` es la respuesta esperada"* y pasa a ser **el listón va en el hallazgo, no en el recuento**. `nothing_found` es una respuesta completa y correcta; un hallazgo real también. Ninguno de los dos es el objetivo, y no se espera ninguna tasa. Lo que un hallazgo debe superar es el listón: concreto, falsable y causado por ESE diff.

**Por qué es una corrección y no un matiz.** Una expectativa de frecuencia no informa al agente sobre su trabajo: le da un número que gestionar. Y las dos direcciones fallan distinto. *"Casi siempre nada"* **suprime**, y suprime precisamente la clase rara para la que se construyó la pieza — un revisor que ya sabe cuál es la respuesta normal encuentra siempre una razón para dudar de la anormal. *"Debes acertar un 30-40%"* **fabrica**. Ninguna de las dos habla del diff, que es lo único que el adversario tiene delante.

**Lo que NO cambia:** las otras cuatro cláusulas siguen intactas, y la protección contra el ruido tampoco se toca — sigue prohibido el estilo, el nombrado, la preferencia, la cobertura de tests que nadie pidió y los diseños alternativos. Lo que se quita no es la exigencia, es la cuota: la exigencia pasa de *"cuántos"* a *"cuál"*.

**Sobre el 30-40%:** sigue siendo el punto de equilibrio real (4 agentes contra los ~18 de una vuelta completa) y sigue sin medirse. Pero es una pregunta del dueño sobre si la pieza compensa, **nunca una instrucción al adversario** — el día que ese número aparezca dentro de un prompt, esta decisión se ha revertido sin que nadie lo note.

---

## DEC-ORCH-010 — Un hallazgo es una instancia de una clase, no un punto

```logic
id: DEC-ORCH-010
type: decision
status: applied
date: 2026-08-16
decided_by: "Sergio"
trigger: "diagnóstico del dueño, literal: 'cuando una lente encuentra un defecto, nada dice «esto es una INSTANCIA de una clase — busca las demás». Cada hallazgo se trata como un punto. Así que reparo la instancia, la lente encuentra la siguiente en la vuelta siguiente, y parece que «siempre aparece algo» cuando en realidad es el mismo algo tres veces.' Verificado contra el repo: la lección ya estaba aprendida TRES veces y generalizada NINGUNA — el reordenado de la cosecha ('piecemeal never converges'), la gradación de severidad de verify-coherence ('a flat major on every omission is what made this lens unable to converge') y el traslado de lo mecánicamente decidible al STATE GATE. Tres parches locales, una sola forma"
rejected_alternative: "seguir parcheando por caso, que es lo que llevaba haciéndose. Y una segunda, más tentadora: dejarlo como regla en prosa sin mecanismo — descartada porque este repo ya ha demostrado tres veces que sabe enunciar la lección y aun así no la aplica fuera del caso donde la aprendió; 'buscar las demás instancias' es además una tarea de BÚSQUEDA, que es exactamente lo que un subagente hace bien y barato"
trip_wire: "la frontera es lo único que separa esto de una refactorización del repositorio, y es estructural, no de criterio: el scan busca SOLO en el mapa de aceptación de plan.md, en los changed-files de esta pasada, y en el módulo del hallazgo citado si ya está en ese ámbito. Si alguna vez se amplía a 'todo el repo', o si un miembro out_of_scope se repara dentro del diff activo en vez de emitirse como SCR-FIX-CLASS-*, la disciplina de unidad activa queda rota. Segundo trip-wire: si el ámbito del scan se limita a código y deja fuera blueprint/**, no generaliza el caso que lo motivó (la cosecha de shell.md, que es puramente documental) y quedan dos mecanismos paralelos en vez de uno. Tercero: una afirmación de clase sin `matches_check` re-ejecutable por miembro es un parecido, no una clase, y barrer sobre un parecido edita ficheros que no compartían la causa"
supersedes: []
written_to: [.claude/agents/repair-class-scan.md, .claude/rules/constitution.md, .claude/rules/conventions.md, .claude/skills/next-pantalla/SKILL.md, .orchestrator/scripts/validate-structure.sh, .orchestrator/scripts/smoke-golden-path.sh]
affects_screens: [ninguna existente — solo pasadas de reparación futuras]
reopens: []
```

**Decisión:** antes de escribir el cambio de producto, el conductor lanza `Agent(repair-class-scan)` sobre el hallazgo: cuál es la causa raíz, dónde más se da, y con qué comprobación re-ejecutable se confirma cada miembro. Todos los miembros dentro del ámbito se reparan **en esa misma pasada**.

**No añade un cuarto paso a la reparación.** Hace que el paso 1 signifique *cerrar la clase en la superficie acotada* en vez de *arreglar la línea citada*; propagación y prueba quedan igual.

**La frontera, que es lo que hace esto viable:** el scan busca solo en lo que la unidad ya declaró. Un miembro fuera de esa superficie es real y se registra, pero **nunca entra en el diff activo** — sale como `SCR-FIX-CLASS-*`, el mismo exit que `/verify-app` y `/audit-motores` ya usan para un defecto fuera de su alcance.

**Aritmética.** Punto de equilibrio en **N≥2**: con el defecto actual, una clase de N instancias cuesta N vueltas (~12 subagentes cada una más la cola); con el scan cuesta 1 vuelta más 1 agente, plano para cualquier N. El impuesto sobre un hallazgo genuinamente puntual (`class_size: 1`) es **+1 subagente**. Para N=9 —el número que el dueño midió en un proyecto real— la diferencia no es de coste sino de convergencia: hoy agota el tope de 3 iteraciones sin terminar.

**Lo que NO se toca, y es deliberado:** ni `checkpoint.iteration` (3) ni `total_repair_passes` (12) ni el tope de racha docs-only (2) se bajan. La métrica a vigilar es cuántas veces se ALCANZA el tope, no su valor, y bajarlo antes de medir repetiría el error que originó todo esto: fijar una cifra por intuición. La frecuencia real de "hallazgo = clase" **no se sabe** — hay que instrumentarla, no suponerla.

---

## DEC-ORCH-011 — El límite de la unidad deja de ser prosa

```logic
id: DEC-ORCH-011
type: decision
status: applied
date: 2026-08-16
decided_by: "Sergio"
trigger: "el dueño enuncia el requisito en dos mitades: 'lo que no quiero es que arregle cosas que no toca de la unidad, y que arregle lo que las lentes del verify encuentren y cosas más que pueda que en el siguiente verify encuentre'. La segunda mitad ya estaba (tabla de §3, class scan, adversario). La primera estaba escrita en tres sitios y comprobada en NINGUNO: `changed_files` no aparecía ni una vez en validate-state.py, y ninguna lente contiene forma alguna de 'out of scope' / 'not in the plan' / 'unrequested' — verificado por grep antes de escribir nada"
rejected_alternative: "(a) dejarlo en prosa, argumentando que el scan es read-only y no puede ensanchar por sí mismo — falso consuelo: el scan no escribe, pero ENTREGA al conductor un out_of_scope[] de defectos reales y confirmados, que es exactamente la tentación que antes no existía. (b) hacerlo FALLAR el cierre: la autoridad es la columna 'ficheros a tocar' de plan.md, escrita en prosa antes de que el código exista; un fichero legítimo que no anticipó (una util compartida, una migración, un cliente generado) tumbaría una unidad correcta, y un gate que hace eso se aprende a rodear, llevándose por delante la señal buena"
trip_wire: "la asimetría que esto corrige es estructural y puede volver: TODO el aparato (10 lentes, plan_delivery[], plan_deviations[]) pregunta si lo PROMETIDO se entregó, y este aviso es lo único que pregunta si se entregó DE MÁS. Si alguna vez se silencia, se convierte en fail, o se le añaden exenciones más allá de la propagación obligatoria (blueprint/**, blueprint-templates/**, design/**, .orchestrator/**, .orchestrator-state/**), la mitad que falta vuelve a faltar. `.claude/**` NO está exento a propósito, el mismo carve-out que hace el clasificador docs-only: un fichero de agente es la definición de comportamiento de una lente, no documentación"
supersedes: []
written_to: [.orchestrator/scripts/validate-state.py, .claude/skills/next-pantalla/SKILL.md, .orchestrator/scripts/smoke-golden-path.sh]
affects_screens: [ninguna existente — solo pasadas futuras]
reopens: []
```

**Decisión:** `advise_unit_scope()` compara `changed-files.txt` contra los ficheros que el `plan.md` de esa unidad declara, y **avisa** de los que no salen en ninguna parte del plan. Nunca falla. Se salta las unidades ya `accepted` (su evidencia es historia) y calla cuando falta cualquiera de los dos ficheros — antes de EXPLORE, o en una pasada baseline sin ámbito en disco, no hay nada que comparar.

**Por qué avisa y no bloquea, que es la parte que hace que se lea:** un aviso que salta sobre trabajo correcto se aprende a ignorar, y con él se va la señal verdadera. Por eso la comparación es **generosa a propósito** — vale la ruta exacta, un directorio que el plan nombró, o el basename suelto (`notas.js` en el plan contra `web/notas.js` en git son el mismo fichero, y acertar ahí importa más que cazar una colisión).

**La propagación está exenta porque es obligatoria**, no porque sea tolerable: el paso 2 de una reparación barre los hechos de `blueprint/` / `shell.md` / `stack.md` que el cambio implica. Marcarla dispararía en toda reparación correcta.

**Por qué justo ahora.** `DEC-ORCH-010` existe para hacer una reparación MÁS ANCHA. Darle un acelerador y dejar su límite en prosa es la forma exacta de fallo que este repo ya ha pisado varias veces, y que él mismo enuncia: *prose is not a control*.

**Corrección de un hecho que yo tenía mal:** no existe ningún `--preflight` en `validate-state.py` (lo tenía anotado y era falso). El pre-flight real es `preflight-check.sh`, bash, lint+build, y corre **antes** de que `changed-files.txt` exista. De ahí que el aviso viva en la corrida normal del gate: no hay flag que se pueda olvidar, y siendo advisory no puede romper ninguna corrida existente.

---

## DEC-ORCH-012 — El sintetizador no agrupa por causa; un scan por hallazgo sí

```logic
id: DEC-ORCH-012
type: decision
status: applied
date: 2026-08-16
decided_by: "Sergio"
trigger: "dos cabos sueltos que dejó DEC-ORCH-010, señalados por el dueño. (1) `verify-synthesizer` dedupa `findings[]` por (acceptance_ref, detail) —el MISMO hallazgo dicho por dos lentes— pero nunca agrupa por CAUSA, y es el único punto del flujo que tiene todos los hallazgos de una VERIFY delante a la vez. (2) `next-pantalla` §6 decía lanzar el scan «with the finding as returned», en singular, y «runs once per repair pass»: con N hallazgos no estaba dicho cuál de los N se escanea"
rejected_alternative: "añadir un campo `possible_shared_cause[]` / `finding_groups[]` al schema DIGEST de `verify-fanout.js` para que el sintetizador proponga grupos candidatos. Descartado por su propia carta, no por su tooling: `verify-synthesizer.md` dice «Flag, don't adjudicate» y «Only relay/structure what the lenses found», y declarar que dos hallazgos son una clase ES adjudicar. Tiene `tools: Read, Grep, Glob` y por tanto PODRÍA leer código —el argumento fácil de «no ve el código» es falso y no se usa aquí— pero su prompt solo le entrega el JSON de las lentes, así que agruparía por cómo SUENAN dos informes. Y ese es el daño real: un grupo propuesto desde la redacción llega sin `matches_check` y con aspecto de asunto ya resuelto, que es exactamente la invitación a saltarse el scan que DEC-ORCH-010 existe para imponer"
trip_wire: "esto se reabre el día que haya una MEDICIÓN, no antes: cuántas veces, en una misma VERIFY, dos hallazgos resultan compartir causa raíz. Nadie lo ha medido —el mismo hueco que DEC-ORCH-010 dejó abierto para `class_size`— y hasta que exista ese número, agrupar por texto es cambiar una pregunta con respuesta probada por una con respuesta plausible. Segundo trip-wire, sobre la mitad que SÍ se hizo: si alguna vez se aplican los `members` en el orden en que respondieron los scans en vez del orden de reparación, o se edita un miembro sin re-ejecutar su `matches_check` justo antes, la corrección se pierde — se estaría editando contra un estado que una reparación anterior de la misma pasada ya movió"
supersedes: []
written_to: [.claude/skills/next-pantalla/SKILL.md]
affects_screens: [ninguna existente — solo pasadas de reparación futuras]
reopens: []
```

**Decisión, en dos mitades opuestas a propósito:**

**No se toca el sintetizador.** Ni `DIGEST`, ni `verify-synthesizer.md`, ni `result.schema.json`. La pregunta *«¿cuáles de estos hallazgos comparten causa?»* es legítima; lo que no es legítimo es contestarla leyendo informes.

**Sí se cierra la cardinalidad del scan:** una pasada que repara N hallazgos lanza **N llamadas a `repair-class-scan`, en paralelo, antes de escribir ninguna reparación**. Nunca una llamada por pasada, nunca una llamada con varios hallazgos dentro — el contrato del agente es UN hallazgo y su retorno trae un solo `root_cause`.

**La clave que hace que esto funcione es separar lanzar de aplicar.** Las N llamadas salen a la vez contra el mismo estado de partida (así ningún scan pierde ámbito por lo que otro arregló). Los miembros se aplican después, en el orden de reparación ya fijado, **re-ejecutando el `matches_check` de cada miembro justo antes de editarlo**: si una reparación anterior de la misma pasada ya lo resolvió, el check falla y es un no-op, no un error.

**Y así el cabo 1 queda contestado sin maquinaria nueva:** dos hallazgos que de verdad compartan causa devuelven dos respuestas que coinciden, cada una confirmada contra ficheros reales. La agrupación emerge de la evidencia en vez de proponerse desde la redacción. Cuesta +1 subagente de solo lectura por hallazgo — precio ya fijado por `DEC-ORCH-010`, contra las ~18 llamadas de una vuelta completa.

---

## DEC-ORCH-013 — El adversario del diff pasa de regla escrita a paso que devuelve non-zero

```logic
id: DEC-ORCH-013
type: decision
status: applied
date: 2026-08-17
decided_by: "Sergio"
trigger: "medido en una corrida real: el adversario del diff, obligatorio por DEC-ORCH-008 en next-pantalla §6 y en constitution.md, corrio en 1 de 5 pasadas de reparacion, y NADA lo detecto. Al menos dos hallazgos que la pregunta literal del adversario habria producido en ~3 minutos aparecieron despues en la VERIFY cara (~28 min, 12 subagentes), cada uno costando ademas una ronda entera. La causa raiz no es olvido y es lo que decide el arreglo: en esas mismas pasadas SI corrieron otras comprobaciones previas, y la diferencia entre ellas es el disparador. Las que corren las dispara un EVENTO que llega al agente —un hallazgo, y el hallazgo es su propio recordatorio—; esta la dispara un ESTADO en el que el agente esta ('acabas de producir un diff'), que nadie anuncia. Los eventos se notan; los estados se olvidan, y mas cuanto mas cerca del cierre, que es justo cuando los diffs son mas apresurados"
rejected_alternative: "(a) otro parrafo, otra checklist, otro recordatorio en la SKILL: la regla YA estaba escrita en dos sitios y se incumplio 4 de 5 veces — la prosa no es un control, y este repo lo tiene enunciado como principio. (b) Meter el adversario en validate-state.py como set de lentes obligatorio: lo convertiria en fase con set completo, evidencia y veredicto, que es exactamente el generador de vueltas que su carta prohibe (y hay un caso de smoke que exige que NO aparezca ahi). (c) Colocarlo despues de la VERIFY que falla, en vez de antes: leeria un diff que las diez lentes acaban de juzgar — llega tarde y solapa con lo ya medido, justo la ronda que existia para ahorrar. (d) Bloquear cuando un adversario muere o cuando no encuentra nada: seria convertirlo en bloqueante de un veredicto y en una cuota; el gate pregunta si las cuatro preguntas SE HICIERON, nunca que contestaron"
trip_wire: "esto se reabre si el gate empieza a gritar en falso, porque un control que salta sobre trabajo correcto es un control que alguien acaba borrando —y eso es peor que no tenerlo—. Las dos exenciones son las unicas legitimas (primera pasada de construccion, pasada solo-documental) y ambas se DERIVAN de estado que el procedimiento ya lleva: si alguna vez se convierten en un campo que el conductor declara, se convierten en una salida que puede declarar mal. Segundo trip-wire: el clasificador docs-only NO vive aqui, se extrae de isDocPath en verify-fanout.js; el dia que alguien escriba una segunda copia, la pasada que VERIFY trata como documental y la que este gate exime dejan de ser la misma, y la exencion se vuelve un agujero. El self-check de validate-structure.sh existe para que ese dia falle alto"
supersedes: []
written_to: [.orchestrator/scripts/adversary-check.py, .orchestrator/scripts/validate-structure.sh, .orchestrator/scripts/smoke-golden-path.sh, .claude/skills/next-pantalla/SKILL.md, .claude/skills/fix/SKILL.md, .claude/rules/constitution.md, .claude/agents/orchestrator-flow.md, CLAUDE.md, README.md]
affects_screens: [ninguna existente — solo pasadas de reparacion futuras]
reopens: []
```

**Decisión:** `adversary-check.py` corre como ÚLTIMO paso antes de cada lanzamiento de
`verify-fanout` en una pasada de reparación, justo detrás de escribir `changed-files.txt`. Sale
non-zero y para el flujo cuando esa pasada no tiene una corrida de `diff-adversary` registrada
**contra ese diff**. Mismo sitio, mismo contrato de salida (`0` limpio o no aplica · `1` esta pasada
lo debe · `2` no se pudo comprobar) y mismo tono que `preflight-check.sh`, con una diferencia que no
es cosmética: **el mensaje trae los comandos exactos que desbloquean**, en orden. Un gate que dice
"no" sin decir "haz esto" se rodea antes que se obedece.

**La colocación, dicha en una frase porque no es indiferente:** los adversarios leen un DIFF, y
puestos entre la reparación y la prueba leen uno que nadie ha mirado todavía —que es donde un
hallazgo se PLIEGA en la pasada en curso—, mientras que puestos detrás de una VERIFY que falla
leerían el diff que las diez lentes acaban de juzgar: llegan tarde, solapan con lo ya medido y ya no
ahorran la ronda que justificaba el paso.

**Cuándo NO aplica importa tanto como cuándo aplica**, y las dos exenciones se derivan, no se
declaran:

- **primera pasada de construcción** — `checkpoint.iteration == 0`, que es la definición que el
  propio procedimiento ya usa (§1 abre la unidad en 0, §6 incrementa en cada reparación). No hay
  reparación previa que leer. La excepción es `/fix` reparando una unidad `accepted` in place: su
  estado no cambia y no lleva checkpoint, pero ahí toda pasada repara código ya probado y no hay
  primera construcción que eximir;
- **pasada sólo-documental** — clasificada con `isDocPath` de `verify-fanout.js`, **extraído de
  allí, nunca reimplementado**. Es la única manera de que sean la MISMA regla y no dos que hoy
  coinciden: un Workflow no tiene acceso a disco, así que no puede leer un módulo compartido, y una
  segunda copia haría que la pasada que VERIFY trata como documental y la que este gate exime se
  separaran en silencio. Si la extracción deja de encajar, el gate se niega a clasificar (exit 2) en
  vez de adivinar, y `validate-structure.sh` lo caza antes por su `--self-check`.

**El registro no es evidencia, y esa frontera es la que mantiene barato el paso.** La corrida se
anota en un marcador lateral, `evidence/<ID>/logs/adversary-<iteration>.json`, en el mismo `logs/`
donde ya viven los otros dos ficheros de trabajo no-evidencia de una reparación
(`changed-files.txt`, `repair-diff.patch`). No entra en `phase_runs[]`, `checks[]` ni
`advisory_findings[]`; `validate-state.py` no lo lee ni sabe que existe (hay un caso de smoke que lo
exige). **`nothing_found` en los cuatro levanta el gate igual que un hallazgo**: el listón sigue en
el hallazgo y no en el recuento (DEC-ORCH-009), y un adversario que murió dos veces también lo
levanta —con aviso a gritos—, porque su carta dice seguir a VERIFY y este paso no bloquea unidades.

**Por qué es CONTRACTUAL y entra en este ledger:** `validate-structure.sh` exige ahora
`adversary-check.py` en su `required[]` y corre su `--self-check`, así que un checkout que antes
pasaba la validación de estructura, sin ese fichero, ya no pasa. Mismo criterio que DEC-ORCH-004 con
el pre-flight.

**Lo que este gate NO puede hacer, dicho en voz alta:** no prueba que el workflow corriera, sólo que
hay una corrida registrada contra ese diff. Un conductor decidido a falsificar el marcador puede.
Ese no es el fallo que se cierra — el fallo medido fue una OMISIÓN, un estado del que nadie avisaba,
y una omisión es exactamente lo que caza un paso obligatorio. Convertir un estado olvidable en una
mentira deliberada es toda la ganancia que se buscaba aquí.

---

## DEC-ORCH-014 — `applies[]` deja de ser una lista que nadie contrasta

```logic
id: DEC-ORCH-014
type: decision
status: applied
date: 2026-08-17
decided_by: "Sergio"
trigger: "medido: una unidad declaraba JOUR-005 en applies[], no lo tocaba, y el defecto sobrevivio OCHO abanicos (diez lentes cada uno) y dos puertas antes de que lo viera la REVIEW. La causa es estructural: TODAS las lentes se ACOTAN a applies[], asi que una regla citada que nadie implementa no falla ninguna lente — no la mira nadie desde la direccion que ensenaria la ausencia. `applies` aparecia dos veces en validate-state.py, ambas para derivar que validadores de motor debe una unidad; nada preguntaba jamas si las reglas de esa lista quedaron contestadas"
rejected_alternative: "(a) pedirselo a una lente: es exactamente lo que la constitucion prohibe — cuando un hallazgo lo podria haber producido un script, el defecto no es solo el hallazgo, es que lo produjera una lente, y aqui el precio medido de que lo produjera una fueron ocho abanicos. (b) Avisar en vez de fallar, como advise_unit_scope: alli la autoridad es la columna *ficheros a tocar* de un plan escrito en prosa antes de existir el codigo, y un fichero legitimo no anticipado tumbaria una unidad correcta. Aqui la autoridad es applies[], que la propia unidad declara y que ya gobierna el alcance de todas sus lentes: si la unidad la escribio, responder de ella no es una sorpresa"
trip_wire: "la valvula `applies_deferred[]` es lo unico que impide que esta regla fabrique un check falso, que es el defecto que combate un nivel abajo. Si alguna vez se acepta una entrada sin `reason`, o si empieza a usarse para reglas que la unidad SI deberia probar, la comprobacion se ha convertido en tramite. Segundo trip-wire: la mitad `phantom` (un check que nombra una regla fuera de applies[]) asume que un id de regla se reconoce por la forma FAMILIA-NNN; un proyecto con otra convencion de ids la vuelve muda"
supersedes: []
written_to: [.orchestrator/scripts/validate-state.py, .orchestrator/examples/golden-path/state/evidence/SCR-001/result.json, .orchestrator/examples/golden-path/state/evidence/SCR-FOUNDATION-SCHEMA/result.json, .orchestrator/examples/golden-path/state/evidence/SCR-FOUNDATION-SHELL/result.json, .orchestrator/scripts/smoke-golden-path.sh]
affects_screens: [ninguna existente — unidades en vuelo desde hoy]
reopens: []
```

**Decisión:** `applies_coverage_problems()` exige que toda regla de `applies[]` sea nombrada por
algún `checks[].applies_ids` (o `applies_refs`/`applies`/`rule_ids`/`doc_refs`, y también desde un
criterio de aceptación), o esté declarada en `result.json.applies_deferred[] {id, reason}`. Espejo
exacto de `acceptance_coverage_problems`, una columna más allá, con la misma retroactividad: falla
en una unidad en vuelo, avisa en una ya `accepted` — reabrir `accepted` está prohibido, así que
fallar allí no dejaría jugada legal.

**Coste de migración, corregido por la revisión adversarial de esta misma tanda.** Mi primera
versión leía sólo `checks[]` y declaró que todo proyecto vivo fallaría hasta reescribir sus checks.
Era falso, y el revisor señaló por qué: un criterio de aceptación **ya** lleva sus reglas en `refs`
(`{id, critical, refs:[...], ears_type}`, la forma que compila `/init-build`). Medido en el propio
golden path: **13 de 19 reglas citadas quedan cubiertas sin tocar nada** (68%). `APPLIES_REF_KEYS`
incluye ahora `refs`, así que lo que un proyecto debe nombrar es sólo el resto. Exigir una segunda
grafía de algo que todo proyecto compilado ya registra es cómo una regla nueva se convierte en
trámite sobre trabajo correcto — el modo de fallo que este repo tiene enunciado.

**Y la mitad `phantom` mira sólo `checks[]`, nunca `acceptance[].refs`.** Fundirlas hacía saltar el
aviso sobre datos correctos y preexistentes (en el golden path, los criterios de
`SCR-FOUNDATION-SCHEMA` referencian `DOM-001` mientras su `applies[]` es `[CORE-001]`): un check que
nombra una regla fuera de `applies[]` es una afirmación de la unidad y merece aviso; la
trazabilidad de un criterio, escrita al compilar, no.

---

## DEC-ORCH-015 — El veredicto de la lente decide la salida de su propio hallazgo

```logic
id: DEC-ORCH-015
type: decision
status: applied
date: 2026-08-17
decided_by: "Sergio"
trigger: "reportado como el mayor motor estructural de vueltas que quedaba: las dos puertas de §5.5 pueden mandar un hallazgo no bloqueante a advisory_findings[]; las diez lentes de VERIFY no. Asi que cuando un verify-* devuelve `pass` con tres `minor`, esos tres no tienen ruta — ni failures[] (la lente paso) ni advisory (estaban vetadas) — y por defecto se tratan como trabajo: una reparacion, un re-VERIFY, y superficie nueva para la vuelta siguiente"
rejected_alternative: "(a) dejarlo como estaba apelando a la clausula que excluia a las diez lentes: esa clausula protege una MEDICION de ser perdonada por politica, y aqui no se perdona ninguna — la lente ya dictamino, dijo `pass`. Confundir las dos cosas es lo que dejaba el hallazgo sin salida. (b) Un techo de severidad (todo `minor` es advisory): pone el criterio en una etiqueta que escribe el mismo agente que decide, y desacopla la salida del veredicto que de verdad la gobierna. (c) Que el sintetizador CLASIFIQUE que es advisory: su carta dice `flag, don't adjudicate`; lo que hace ahora es un JOIN de datos que ya tiene (findings[].lens contra verdict_by_lens[]), que no es lo mismo que juzgar"
trip_wire: "la frontera entera descansa en que `advisory_candidates[]` sea un JOIN y no un criterio. El dia que un hallazgo de una lente con veredicto `fail` aparezca ahi, o que el sintetizador empiece a decidir por severidad, esto ha dejado de ser una ruta para un hallazgo ya dictaminado y se ha convertido en el perdon por politica que la constitucion prohibe. Segundo trip-wire: `owner` + `trip_wire` son el precio de la ruta; si se relajan, este campo pasa a ser el sitio donde los hallazgos se olvidan con una severidad al lado, que es peor que el bucle que sustituye porque parece contabilidad"
supersedes: [DEC-ORCH-008]
written_to: [.claude/workflows/verify-fanout.js, .claude/agents/verify-synthesizer.md, .orchestrator/scripts/validate-state.py, .claude/rules/constitution.md, .claude/skills/next-pantalla/SKILL.md, .orchestrator/scripts/smoke-golden-path.sh]
affects_screens: [ninguna existente]
reopens: []
```

**Decisión, en tres piezas:** el `DIGEST` de `verify-fanout.js` gana `advisory_candidates[]`
—requerido, emitido aunque esté vacío— con los hallazgos cuya **lente emisora devolvió `pass`**; el
sintetizador lo construye como JOIN, sin clasificar nada por su cuenta; y `validate-state.py` exige
`owner` y `trip_wire` a toda entrada de `advisory_findings[]` cuyo `source` sea una lente.

**Lo que NO se relaja, porque es la línea que alguien buscará:** una lente que devuelve `fail` sigue
fallando, todo hallazgo colgado de un veredicto `fail` sigue yendo a `checks[]`/`failures[]`, y
`verified` sigue exigiendo `verdict:"PASS"` con `failures` vacío. Las dos puertas de §5.5 no ganan
ningún requisito nuevo: su formato de siempre sigue pasando.

**Por qué el precio es dueño + trip-wire y no una severidad más:** es el mismo listón que
`autonomy.md` pone a una decisión Tier-2 `auto:`, y por la misma razón — registrar algo en vez de
hacerlo es aceptable exactamente en la medida en que un humano pueda encontrarlo después y ver qué
lo reabre.

---

## DEC-ORCH-016 — Una VERIFY de cierre puede ser sólo-documental, y el gate lo camina

```logic
id: DEC-ORCH-016
type: decision
status: applied
date: 2026-08-17
decided_by: "Sergio"
trigger: "medido: una correccion documental descubierta al final —un hecho de blueprint que pide una lente, una linea de informe— obligaba a elegir entre registrar una entrada NO de cierre (que no puede cerrar la unidad) y pagar diez lentes para re-juzgar codigo que no se ha movido. La regla que lo produce es correcta en general; su premisa es 'el codigo puede haberse movido desde la ultima pasada completa'"
rejected_alternative: "(a) dejarlo prohibido: la letra de hoy, y su coste medido es 28 minutos y diez lentes por una correccion de prosa, o una entrada que no cierra. (b) Permitirlo confiando en que el conductor declare que la pasada fue documental: seria la autocertificacion que este repo ya rechazo al disenar DEC-ORCH-006 — el gate no puede contrastar un flag contra nada objetivo. (c) Permitirlo mirando `source_manifest`: se escribe en §7, al cerrar, asi que hashea el codigo ACTUAL y no puede probar que sea el mismo que juzgaron las diez"
trip_wire: "lo unico que hace segura esta excepcion es que `derived_scope` lo DERIVA verify-fanout.js de la lista de ficheros cambiados, no lo declara el conductor. El dia que ese campo se pueda escribir a mano sin que la lista lo respalde, la excepcion se convierte en la autocertificacion que (b) rechazaba. Segundo trip-wire: el tope de racha docs-only (2) es lo que acota cuantas pasadas pueden colgar de una completa; si sube, esta cadena se alarga con el"
supersedes: []
written_to: [.orchestrator/scripts/validate-state.py, .claude/rules/constitution.md, .claude/skills/next-pantalla/SKILL.md, .orchestrator/scripts/smoke-golden-path.sh]
affects_screens: [ninguna existente]
reopens: []
```

**Decisión:** una entrada de cierre de VERIFY puede llevar `full_set:false` **si y sólo si** es
`derived_scope:"docs_only"` y **toda** la cadena de entradas VERIFY hasta la última COMPLETA es
también docs-only. `validate-state.py` camina la cadena hacia atrás y la corta en la primera entrada
que no lo sea; la pasada de la que hereda debe ser genuinamente completa (set nativo entero, nada
arrastrado, sin fail-fast), así que **un cierre docs-only nunca hereda de un triage**. La primera
VERIFY de una unidad no puede serlo: no hay prueba anterior que heredar.

**El suelo de la cita, que a mi primera versión le faltaba y encontró la revisión adversarial.**
Caminar la cadena probaba que el cierre docs-only llega a una pasada completa, pero la validación de
`carried_forward[]` aceptaba **cualquier** pasada completa anterior. Reproducido: completa@0,
completa@1 (una reparación real, o sea código movido) y cierre docs-only citando la 0 — todas las
comprobaciones individuales pasaban y la unidad cerraba con seis veredictos anteriores a la
reparación, que es exactamente la decadencia que esta excepción dice impedir. Ahora el paseo hacia
atrás registra la iteración del ancla y **toda** cita del cierre debe igualarla. Igualdad y no `>=`:
entre el ancla y el cierre todo es docs-only por construcción, así que no puede existir una pasada
completa posterior a la que citar.

**Por qué esto no debilita nada:** la premisa que protege la regla original es que el código puede
haberse movido, y aquí esa premisa es DECIDIBLE. `derived_scope` no es una afirmación del conductor
—lo deriva el workflow de los ficheros cambiados—, así que la cadena establece que ninguna
implementación ni test se movió desde que las diez corrieron nativamente. Las seis lentes heredadas
siguen juzgando exactamente el mismo código. Nada se toma por confianza: se camina.

---

## DEC-ORCH-017 — Una cifra en prosa se ata a su comando; y el class scan pregunta por lo escrito

```logic
id: DEC-ORCH-017
type: decision
status: applied
date: 2026-08-17
decided_by: "Sergio"
trigger: "dos mitades de un mismo defecto, medidas la misma noche. (1) Las cifras de stack.md son cuatro celdas ACOPLADAS y se corrigieron en cuatro pasadas, dejando tres mintiendo cada vez; tres enumeraciones distintas del mismo conjunto (una regla diciendo 'las cinco', un docstring del modulo con 3 de 7 salidas, un guard diciendo 'TODAS') fueron tres rondas de la misma forma. (2) `repair-class-scan` pregunta 'donde mas se sostiene esta causa' sobre un hallazgo de CODIGO; nada hace esa pregunta sobre DOCUMENTACION, y ahi se fue el 85% del volumen"
rejected_alternative: "(a) mas prosa pidiendo cuidado al escribir cifras: es la forma exacta de fallo que este repo ya tiene enunciada. (b) Un indice lateral que declare 'en el fichero X la cifra Y sale del comando Z': se separa de lo que describe y se queda rancio igual que la segunda copia que pretende vigilar; el marcador va PEGADO a la cifra justamente para que se mueva con ella. (c) Comprobar toda cifra de todo documento: gritaria en falso sobre cada numero escrito y acabaria borrado — sin marcador no hay comprobacion, y eso es una decision, no una limitacion"
trip_wire: "el limite honesto del linter es que comprueba que el valor correcto APARECE en la linea, no que la frase signifique lo que dice: una linea que contiene el numero correcto por otra razon pasa. Si alguna vez se le pide juzgar prosa, se ha pasado de su clase de problema. Y la forma `sh:` ejecuta un comando de un fichero del repo — misma postura que las ordenes declaradas en stack.md, y el mismo cuidado: si alguna vez se ejecutan ficheros que no son del repo, esto deja de ser un linter"
supersedes: []
written_to: [.orchestrator/scripts/derived-figures.py, .claude/agents/repair-class-scan.md, .orchestrator/scripts/validate-structure.sh, .claude/rules/constitution.md, .claude/skills/next-pantalla/SKILL.md, .orchestrator/scripts/smoke-golden-path.sh]
affects_screens: [ninguna existente]
reopens: []
```

**Decisión, las dos mitades del mismo mecanismo:**

**El script.** `derived-figures.py` re-deriva toda cifra marcada `<!-- derived: <spec> -->` y falla
las que no cuadran. Tres formas: `jsarray:<fichero>:<CONST>`, `glob:<patrón>`, `sh:<comando>`, las
tres con caso de smoke — una rama que se envía sin ejercitar es código muerto que parece cobertura.
Varios marcadores por línea, que es el caso que lo motiva (las celdas acopladas viven juntas), y con
**atadura posicional**: cada marcador se comprueba contra el texto que lo precede, no contra la
línea entera. Lo señaló la revisión adversarial y tenía razón: casar cada valor en cualquier parte
de la línea hace que un par **intercambiado** pase, que es la propia celda acoplada reproducida por
la herramienta que existe para cazarla. Dos marcadores apilados al final de una línea no se pueden
atar a su figura, así que el linter **se niega** y dice dónde ponerlos, en vez de degradar en
silencio a la comprobación floja. Corre
dentro de `validate-structure.sh`, que es donde ya se exige exactamente esta disciplina a los sets
de lentes `.js`↔`.py` — cada restatement en prosa de esos mismos números era una tercera copia sin
nada detrás, y ahora hay ocho marcadas.

**El agente.** `repair-class-scan` acepta `subject_kind: written_fact` y contesta la pregunta desde
el otro extremo: *¿en qué otros sitios es FALSO este hecho que acabo de escribir?* Se lanza en el
paso 2 de una reparación (la propagación), una llamada por hecho escrito. Cuando el hecho es una
cifra o una lista, el miembro vuelve con `derivable_by` y la reparación correcta **no es un quinto
arreglo a mano**: es ponerle el marcador. Una cifra atada a su fuente deja de ser una clase que
pueda reaparecer.

**Por qué van juntas en una sola entrada:** son la misma observación por los dos lados. El agente
encuentra la clase; el script impide que la clase vuelva a formarse.

---

## DEC-ORCH-018 — La memoria permanente se paga una vez, y el porqué vive donde se lee una vez

```logic
id: DEC-ORCH-018
type: decision
status: applied
date: 2026-08-17
decided_by: "Sergio"
trigger: "medido en dos barridas con doc oficial en mano. (1) DOBLE CARGA: los cuatro ficheros de .claude/rules/ no llevan frontmatter `paths:`, asi que Claude Code los auto-carga al arrancar con la misma prioridad que CLAUDE.md — y CLAUDE.md ADEMAS importaba tres de ellos con `@`. La doc lo dice literalmente: 'Splitting into @path imports helps organization but doesnt reduce context, since imported files load at launch'. Resultado: 85.802 caracteres duplicados en cada sesion Y en cada subagente, por cero cobertura. El propio validate-state.py llevaba tiempo avisando y nadie lo habia tocado. La prueba de que la auto-carga basta estaba delante: `autonomy.md` nunca se importo y siempre funciono. (2) TAMANO: la seccion 'Workflows are mandatory' era 27.382 de los 64.105 caracteres del fichero (42%), y buena parte era narrativa retrospectiva con porcentajes medidos que .orchestrator/DECISIONS.md ya posee con trigger/rejected_alternative/trip_wire — dos versiones independientes, en dos idiomas, sin nada que las mantuviera en sync"
rejected_alternative: "(a) dejar los `@import` 'por si acaso --setting-sources no incluye project': ese caso ya estaba analizado y es el unico donde importarian; contra el, 85.802 caracteres por subagente en TODOS los demas. La eleccion se documenta ahora EN CLAUDE.md para que no se re-anadan por costumbre. (b) Recortar la constitucion a una frase operativa por bullet, como estimaba la lente (27.534 -> 5.000-7.000): descartado tras hacer el inventario — la seccion contiene mas contrato del que ese numero supone, y llegar ahi exigia borrar clausulas operativas. Lo que se corto es el POR QUE que el ledger ya tiene; lo que se quedo nombra campos, umbrales y puntos de aplicacion. Resultado real 27.382 -> 20.477, y decirlo asi importa: la estimacion de la lente era optimista y perseguirla habria costado reglas"
trip_wire: "si alguien vuelve a anadir una linea `@.claude/rules/*.md` a CLAUDE.md, la doble carga vuelve — y ahora hay dos casos de smoke que la MONTAN a proposito para probar que el aviso sigue vivo, en vez de depender de que el repo venga roto. Segundo trip-wire, sobre el recorte: la constitucion sigue siendo el 57% de la memoria permanente. Si vuelve a crecer con narrativa, el sitio de esa narrativa es una entrada de este fichero, no un parrafo mas ahi; y si alguna vez se borra un DEC-ORCH al que la constitucion apunta, el puntero queda colgando y nadie lo comprueba"
supersedes: []
written_to: [CLAUDE.md, .claude/rules/constitution.md, .orchestrator/scripts/smoke-golden-path.sh]
affects_screens: [ninguna]
reopens: []
```

**Decisión, dos mitades:**

**Fuera los tres `@import`.** `CLAUDE.md` ya no importa `constitution.md`, `conventions.md` ni
`stack.md`: los cuatro ficheros de `.claude/rules/` se auto-cargan solos. Y el fichero ahora explica
por qué no están, para que no vuelvan por costumbre. **Memoria permanente cargada: 189.780 → 97.150
caracteres por sesión y por subagente.**

**El porqué se va al ledger.** La sección `## Workflows are mandatory` conserva todas sus cláusulas
operativas y cambia la narrativa por un puntero al `DEC-ORCH-*` que ya la posee. 27.382 → 20.477
caracteres; el fichero, 64.105 → 57.200.

**Método, porque es el que hay que repetir:** inventario exhaustivo de cláusulas operativas ANTES de
tocar nada (23 grupos), reescribir contra ese inventario, y comprobar después que los cuatro
verificadores y los 192 casos siguen verdes. Es el mismo método con el que se reescribió
`next-pantalla/SKILL.md`, y existe porque una condensación pierde cláusulas por omisión, no por
error — y una cláusula perdida no falla, simplemente deja de aplicarse.

**Efecto secundario que arreglé de paso, y que es una lección por sí solo:** los dos casos de smoke
del aviso de doble carga usaban el propio `CLAUDE.md` del repo como fixture. Se pusieron ROJOS al
borrar los imports — es decir, al hacer exactamente lo que el aviso pedía. Un caso que sólo pasa
mientras el repo está mal se invierte en cuanto lo arreglas. Ahora montan ellos la condición.

## DEC-ORCH-019 — El punto de extensión del checkpoint, y el ámbito de reparación deja de escribirse a mano

```logic
id: DEC-ORCH-019
type: decision
status: applied
date: 2026-08-18
decided_by: "Sergio"
trigger: "medido en un proyecto consumidor real (maser-onda). (1) EL CONTROL QUE UNA ACTUALIZACION BORRA: el proyecto habia cableado scripts/verify/scan-evidence-secrets.sh dentro de phase-push.sh — el sitio correcto, el estrangulamiento que todo artefacto cruza — despues de DOS incidentes con JWT vivos y refresh_token en claro llegando a origin/main (137 commits reescritos, tokens revocados). El resync de maquinaria 0d86a3b copio .orchestrator/** entero y se llevo por delante TRES personalizaciones en un solo commit sobre otra cosa: el escaner FATAL, la paridad ARB que suplia a un CI caido, y el tagging [skip ci] (226 commits lo llevaban antes, 0 despues). Estuvo ausente desde 0d86a3b hasta que esta decision lo restauro — `git rev-list --count 0d86a3b..HEAD` daba 124 al detectarlo y sigue creciendo hasta que el arreglo se comprometa, que es justo por que la cifra se cita con su comando y no como un numero suelto (DEC-ORCH-017) — mientras .claude/rules/stack.md seguia declarandolo activo en negrita. (2) EL TRIAGE QUE NUNCA DISPARA: verify-fanout.js ya trae proporcionalidad completa y triplemente guardada (scope rancio se rechaza, >150 ficheros se rechaza, toda pasada estrechada se marca full_set:false y el STATE GATE no la acepta como cierre). Medido sobre 20 unidades: 93 de 93 corridas de VERIFY corrieron el set COMPLETO. No por rota, sino porque la alimenta un fichero que un modelo tiene que acordarse de REESCRIBIR en cada iteracion — se escribio una vez en la iteracion 2, la unidad llego a la 7, y desde la tercera pasada la guarda de frescura lo descarto en silencio. Siete re-corridas completas, 84 subagentes, el 42% del coste de esa unidad"
rejected_alternative: "(a) volver a pegar la llamada del escaner dentro de phase-push.sh: es lo que ya fallo, y fallaria una tercera vez en el siguiente resync — la propagacion copia .orchestrator/** sin preguntar. (b) Sacar phase-push.sh de la lista de ficheros que se propagan: entonces el proyecto deja de recibir cualquier mejora del checkpoint, y se paga el problema inverso. (c) Un flag ORCH_SKIP_HOOKS para emergencias: descartado a proposito — el comentario del propio escaner ya lo razona ('un guardia que da falsas alarmas ensena a todos a tirar de --no-verify'), y el control existe precisamente porque 'solo por esta vez' es como una credencial llega a un remoto. (d) Para el triage: relajar la guarda de frescura para que un scope viejo valga igual. Descartado: §5 lo dice literal, 'un scope incompleto es peor que ninguno, porque diez lentes se van a fiar de el'. Lo que estaba mal no era la guarda, era quien escribia la cabecera"
trip_wire: "(1) el lanzador de hooks vive en phase-push.sh, que el scaffold posee y sobreescribe: eso es lo que hace que cada resync lo RESTAURE, pero tambien significa que si alguien lo borra del scaffold, desaparece de todos los proyectos a la vez y ninguno se entera. La senal observable: `grep -c pre-commit.d .orchestrator/scripts/phase-push.sh` debe dar 2; si da 0, todos los hooks de todos los proyectos han dejado de correr en silencio. (2) El hook del escaner ABORTA si el script no esta, en vez de salir 0: si alguna vez se cambia ese `exit 1` por un `exit 0` 'para no bloquear', se reintroduce exactamente el modo de fallo silencioso que costo los dos incidentes. (3) Sobre repair-scope.sh: si vuelve a haber una unidad con mas de dos re-corridas de VERIFY donde TODAS declaren full_set, el ambito ha vuelto a escribirse a mano o no se esta escribiendo — comprobable contando full_set:false en phase_runs[]"
supersedes: []
written_to: [.orchestrator/scripts/phase-push.sh, .orchestrator/hooks/pre-commit.d/README.md, .orchestrator/scripts/repair-scope.sh, .claude/skills/next-pantalla/SKILL.md, .orchestrator/scripts/smoke-golden-path.sh, .claude/rules/constitution.md, .claude/agents/orchestrator-flow.md, .orchestrator/scripts/validate-state.py, CLAUDE.md, README.md, USO.md]
affects_screens: [ninguna]
reopens: []
```

**Decisión, tres piezas.**

**1. El punto de extensión.** `phase-push.sh` ejecuta todo `*.sh` de
`.orchestrator/hooks/pre-commit.d/` en orden lexicográfico, con el árbol ya en staging y **antes
del commit**, pasando `$phase` y `$unit`. Una salida distinta de 0 **aborta**: no hay commit y no
hay push. Es el único paso deliberadamente fatal de un script que por lo demás nunca bloquea.

El reparto es lo que hace que sobreviva, y es deliberadamente al revés de lo intuitivo: **el
lanzador vive en el fichero que el scaffold sobreescribe** — así cada resincronización futura lo
*restaura* en vez de borrarlo — **y la comprobación vive en el directorio donde el scaffold no
envía nada más que un README**, así que una resincronización no tiene ningún fichero que pisar ahí.
Lo que se perdió no fue el escáner: fue su *llamada*, por vivir en territorio ajeno.

**2. El tagging de CI deja de ser una personalización.** Un checkpoint intermedio lleva
`[skip ci]`; `VERIFIED`, `ACCEPTED` y `BLOCKED` no. Una unidad produce ~20 checkpoints, así que sin
esto una pantalla dispara la matriz de CI ~20 veces y entierra las corridas que alguien leería. El
commit y el push ocurren igual — lo único que cambia es el disparador de CI. Se apaga con
`ORCH_PUSH_SKIP_CI=0`.

**3. El ámbito de reparación lo calcula un script.** `repair-scope.sh <UNIT_ID>` lee
`checkpoint.iteration` de `features.json` — la misma fuente contra la que el abanico va a comparar
la cabecera — y escribe `evidence/<ID>/logs/changed-files.txt` con la iteración correcta y las
directivas de triage que se le pidan. No inventa cobertura: alimenta el mecanismo que
`verify-fanout.js` ya trae, con sus tres guardas intactas. Es la constitución aplicada a su propio
procedimiento: *«cuando un hallazgo podría haberlo producido un script, el defecto no es sólo el
hallazgo: es que fuera una lente quien lo produjera.»* Aquí no era una lente, era una cabecera —
y el resultado fue el mismo.

## DEC-ORCH-020 — Un gate que esconde el segundo fallo cobra dos rondas por un problema

```logic
id: DEC-ORCH-020
type: decision
status: applied
date: 2026-08-18
decided_by: "Sergio"
trigger: "buscando de donde salen las RONDAS, no el coste de cada ronda. Medido: `fail()` hacia `raise SystemExit(1)` en las 160 comprobaciones del gate, asi que cada corrida reportaba EXACTAMENTE UN problema. Una unidad con cinco defectos de registro necesitaba cinco corridas para enterarse de los cinco — y cualquiera de ellos descubierto DESPUES de un abanico costaba una pasada de reparacion completa (18-21 subagentes; el propio registro del repo pone una VERIFY completa en ~28 minutos) para volver a saber algo que un script ya sabia. El sintoma estaba escrito desde el lado humano en el procedimiento de un proyecto real ('el gate se ensaya entero, nunca por funciones sueltas: la primera comprobacion que falla oculta a todas las demas... perdi tres rondas descubriendo de una en una lo que el gate completo dice de golpe'), pero la respuesta que se propuso era DISCIPLINA. La disciplina no es un mecanismo: esto mueve el mismo arreglo al codigo"
rejected_alternative: "(a) dejarlo y confiar en rehearse-close.py, que ya corre el gate real sobre una copia: no basta — rehearse-close hereda el mismo fail() y por tanto el mismo problema, asi que ensayar el cierre tambien contaba de uno en uno. (b) Acumular en TODAS partes, dentro de cada funcion: descartado por peligroso — el codigo que sigue a un fail() suele asumir precisamente lo que acaba de fallar (un campo que no existe, un indice fuera de rango), asi que seguir ejecutando ahi dentro cambia fallos claros por excepciones opacas. Por eso se acumula SOLO en fronteras independientes (por fichero de evidencia, por unidad, por validador de nivel superior) y dentro de una comprobacion el primer fallo la sigue cortando. (c) Hacerlo opt-in con --all: seria repetir el patron que este mismo repo se cansa de encontrar — la herramienta existe, el procedimiento no la nombra, nadie la usa. Va por defecto, y la escotilla es --first-failure"
trip_wire: "el valor entero descansa en que las fronteras sean INDEPENDIENTES. Si alguna vez se envuelve en _guard una comprobacion cuyo resultado condiciona a la siguiente, el gate empezara a reportar fallos derivados del primero como si fueran problemas distintos — ruido que ensena a ignorar la lista, que es peor que la lista corta que sustituye. La senal observable: dos entradas de FAILURES sobre la MISMA unidad donde la segunda solo existe porque la primera fallo. Segundo trip-wire: si aparece un `_GateStop` como traceback, hay un fail() fuera de toda frontera instrumentada y falta un _guard ahi — la red de seguridad de __main__ lo convierte en un fallo normal, pero que se active significa que el mapa de fronteras se quedo corto"
supersedes: []
written_to: [.orchestrator/scripts/validate-state.py, .orchestrator/scripts/smoke-golden-path.sh, CLAUDE.md, .claude/skills/next-pantalla/SKILL.md]
affects_screens: [ninguna]
reopens: []
```

**Decisión.** `fail()` deja de salir en el acto: registra el problema y lanza `_GateStop`, que se
recoge en las fronteras **independientes** — cada fichero de evidencia, cada unidad, cada validador
de nivel superior. Al final, el gate imprime **todos** los problemas y, si hay más de uno, lo dice:
*«N problems found and listed above. Fix them in ONE pass: each one you leave for the next run is a
round you pay twice.»*

**El veredicto no cambia**: cualquier fallo sigue siendo `exit 1`. Lo único que cambia es cuánto
aprendes por corrida. `--first-failure` devuelve el comportamiento histórico.

**El alcance exacto, porque la primera versión de esta entrada lo exageró y una auditoría lo
midió.** La granularidad es **por unidad**, no por comprobación: dentro de una misma unidad, el
primer fallo sigue cortando el resto de SUS comprobaciones, a propósito — el código que sigue a un
`fail()` suele asumir precisamente lo que acaba de fallar, y reportar los síntomas derivados del
primero sería el ruido que el `trip_wire` prohíbe. Lo que se recupera es todo lo demás: los
defectos de las **otras** unidades, que antes quedaban invisibles. Con dos unidades rotas, antes se
veía una y ahora se ven las dos.

**Y lo que el colector no alcanza, lo dice.** Un `fail()` anterior a los bucles por unidad
(estructura de `features.json`, ficheros de estado ausentes) detiene la validación antes de mirar
ninguna unidad. Como en ese caso `n == 1`, tampoco saldría la línea de resumen, y quien lo arregle
se quedaría creyendo que era el único problema — el multiplicador de rondas reapareciendo justo
donde el mecanismo no llega. Por eso el reporte añade ahí una línea explícita diciendo que la
validación se detuvo antes de comprobar ninguna unidad y que puede haber más.

**Y se lee agrupado por unidad, con rutas relativas.** Tres líneas sobre la misma unidad, cada una
precedida de la misma ruta absoluta de 60 caracteres, se leen como tres desastres distintos. Una
lista que nadie puede recorrer de un vistazo es una lista que nadie arregla en una pasada, que era
el objetivo entero.

**Por qué esto y no verificar menos.** Las 229 comprobaciones del smoke siguen pasando, incluidas
las ~100 que afirman un mensaje de fallo concreto: no se ha relajado ni una regla. Lo que se ha
quitado es la parte del procedimiento que hacía que un problema conocido se descubriera en cuatro
tiempos. Es la constitución aplicada otra vez a su propio gate: *«cuando un hallazgo podría haberlo
producido un script, el defecto no es sólo el hallazgo: es que fuera una lente quien lo produjera»*
— aquí ni siquiera hacía falta una lente, sólo dejar de tirar las respuestas que el script ya
tenía calculadas.

## DEC-ORCH-021 — La condición que DEC-ORCH-004 dio por supuesta ahora se declara

```logic
id: DEC-ORCH-021
type: decision
status: applied
date: 2026-08-18
decided_by: "Sergio"
trigger: "buscando reloj, no subagentes. VERIFY corre 4 lentes documentales en parallel() y SOLO DESPUES arranca la cadena de 6 ejecutoras, una a una. El coste de ese orden es el lote documental ENTERO sobre el camino critico de CADA pasada de VERIFY —la de linea base y cada reparacion—, y en una unidad de 7 pasadas se paga 7 veces. DEC-ORCH-004 evaluo solaparlas y lo RECHAZO, con una razon correcta: las documentales leen un arbol EN REPOSO, y solaparlas las expone a leer fuentes mientras un `lint --fix` o unos snapshots las reescriben. Lo que esa decision no dijo es que su premisa no es universal: es una afirmacion sobre lo que hacen los comandos de UN proyecto, y el unico que lo sabe es el proyecto"
rejected_alternative: "(a) solapar sin condicion, revirtiendo DEC-ORCH-004: seria cambiar una clase de fallo real (un hallazgo que pertenece al vecino, llegando disfrazado de hallazgo propio) por unos minutos, y encima sin poder detectarlo — una lente que cita una linea que ya no existe tras el fix parece un hallazgo, no un accidente de concurrencia. (b) Deducirlo inspeccionando los comandos declarados en stack.md (buscar --fix, --write, fmt): descartado por frágil en la direccion peligrosa — un comando que hoy es de solo lectura crece un `--fix` manana y ningun grep se entera; el fallo silencioso volveria justo cuando nadie lo mira. (c) Ponerlo tras un flag de entorno: nadie lo activaria, que es el patron que este repo ya se ha encontrado varias veces (la herramienta existe, el procedimiento no la nombra, nadie la usa). Una linea en stack.md, junto a los comandos de los que habla, es donde alguien la ve al rellenar el resto"
trip_wire: "la promesa la hace el proyecto y nada la verifica, a proposito. El dia que alguien anada `--fix` a COMMAND_LINT sin devolver esta linea a `no`, las documentales volveran a leer un arbol en movimiento y el sintoma sera exactamente el que DEC-ORCH-004 describe: un hallazgo documental que cita una linea o un fragmento que ya no coincide con el fichero. Si aparece uno de esos, esta linea es lo primero que hay que mirar. Segundo trip-wire: las 6 ejecutoras siguen serializadas ENTRE SI pase lo que pase — si alguna vez aparece un parallel() sobre EXEC_LENSES, esta decision se ha leido mal, y hay un caso de smoke que lo vigila"
supersedes: []
written_to: [.claude/workflows/verify-fanout.js, .claude/rules/stack.md, .orchestrator/examples/golden-path/stack.md, .orchestrator/scripts/smoke-golden-path.sh]
affects_screens: [ninguna]
reopens: []
```

**Decisión.** `stack.md` gana una línea: `COMMAND_VERIFY_READONLY: <yes|no>`. Declarada `yes`, las
cuatro lentes documentales de VERIFY se lanzan **a la vez** que la cadena serializada y se recogen
al final, en vez de bloquearla. Ausente, sin resolver o `no` — el comportamiento de hoy, intacto.

**El default es el de siempre porque el default tiene que sobrevivir a un proyecto que nunca leyó
esto.** Solo el booleano `true` que devuelve el cargador tras leer la línea literal activa el
solape; cualquier otra cosa cae al lado seguro, y hay casos de smoke que lo ejecutan en vez de
grepearlo.

**Lo que ninguna declaración relaja.** Las seis lentes ejecutoras siguen corriendo **una a una**
entre ellas, siempre. Esa serialización las protege unas de otras sobre un único árbol, un único
almacén y un único juego de puertos, y no hay promesa que haga seguro correr dos a la vez.

**Esto no revierte `DEC-ORCH-004`: lo acota.** Aquella decisión midió bien el riesgo y eligió bien
el default con la información que tenía. Lo único que cambia es quién responde a la pregunta: antes
la respondía el orquestador por todos, suponiendo el peor caso; ahora la responde cada proyecto,
que es el único que puede saberla — y sigue suponiendo el peor caso mientras nadie conteste.

## DEC-ORCH-022 — El único gate sin sitio donde anotar cobraba una ronda entera por una cita mal puesta

```logic
id: DEC-ORCH-022
type: decision
status: applied
date: 2026-08-18
decided_by: "Sergio"
trigger: "medido en una unidad real de un proyecto consumidor, con los diffs leidos uno a uno y no las notas del registro: SEIS pasadas de REVIEW, SEIS veredictos FAIL, y las CUATRO primeras no encontraron ni un solo defecto de producto — el propio registro las describe como exclusivamente de registro. Cada una costo reabrir la unidad, reparar, re-correr VERIFY, re-correr VALIDATE y volver a revisar. Cuatro rondas completas compradas por contabilidad. La asimetria era estructural y estaba a la vista: las diez lentes de VERIFY tienen advisory_candidates[], las dos puertas de §5.5 tienen advisory_findings[], y pantalla-reviewer tenia FAIL y nada mas. Un defecto de registro le costaba exactamente lo mismo que un producto roto"
rejected_alternative: "(a) dejarlo y confiar en que el conductor clasifique: es lo que ya pasaba, y produjo 4 de 6 FAIL sin defecto de producto — el reviewer es quien tiene el contexto para clasificar, y no tenia donde escribirlo. (b) Un techo de severidad (todo lo `low` es advisory): pone el criterio en una etiqueta que escribe el mismo agente que decide, y desacopla la salida del hecho que de verdad la gobierna, que es QUE TOCA la reparacion — un defecto de registro puede ser grave y uno de producto puede ser menor. (c) Darle la via sin extender el liston de owner/trip_wire: lo advertia el propio informe que motivo esto, y con razon — la comprobacion estaba atada al set VERIFY_LENSES, asi que anadir el reviewer sin tocarla le habria dado una via advisory con un liston MAS BAJO que el de las diez lentes. Se cerro ANTES que la via, en la misma sesion, precisamente para que no existiera esa ventana"
trip_wire: "la frontera entera descansa en QUE TOCA la reparacion, no en como de grave suene. El dia que aparezca en advisory[] un hallazgo cuyo arreglo toque implementacion, tests o conducta en runtime, esta via ha dejado de ser una ruta para lo barato y se ha convertido en el perdon por politica que la constitucion prohibe. Senal observable: una advisory de pantalla-reviewer cuyo `trip_wire` describa un comportamiento del producto en vez de una condicion del registro. Segundo trip-wire: si vuelve a medirse una unidad con REVIEW suspendiendo repetidamente sin defecto de producto, la via existe pero el reviewer no la esta usando, que es un fallo distinto y peor — el mecanismo estaria ahi para tranquilizar, no para funcionar"
supersedes: []
written_to: [.claude/agents/pantalla-reviewer.md, .orchestrator/scripts/smoke-golden-path.sh]
affects_screens: [ninguna]
reopens: []
```

**Decisión.** `pantalla-reviewer` gana `advisory[]` en su salida. Un hallazgo cuya reparación toca
**solo el registro** se anota ahí con `owner` y `trip_wire`, y el veredicto puede seguir siendo
`PASS`. Uno cuya reparación toca implementación, tests o conducta en runtime sigue siendo `gap` y
sigue suspendiendo.

**La regla de desempate está escrita del lado caro:** cuando no se puede distinguir, es `gap`. La
vía existe para dejar de pagar el caso barato, no para hacer desaparecer la decisión difícil.

**Y el precio de la ruta ya estaba cobrándose antes de abrirla.** El STATE GATE exige `owner` y
`trip_wire` a cualquier hallazgo cuya fuente sea el reviewer, al mismo listón que a las diez lentes
— eso se cerró primero, deliberadamente, para que la vía no naciera con una puerta más baja. Una
advisory sin esos dos campos hace que el gate rechace la unidad, que es el resultado correcto:
sin ellos esto sería el sitio donde los hallazgos se olvidan con una severidad al lado.

## DEC-ORCH-023 — Una prueba fechada antes que aquello que prueba

```logic
id: DEC-ORCH-023
type: decision
status: applied
date: 2026-08-18
decided_by: "Sergio"
trigger: "medido en una unidad real de un proyecto consumidor, leyendo los diffs: la clase «el registro afirma algo del disco que un momento posterior desmiente» costo ~9 iteraciones de 16, y su forma peor fue esta — un artefacto que registraba una corrida de tests en ROJO, citado por CINCO checks como prueba de un pase. En el mismo episodio, una puerta dio veredicto en sesion y nunca reescribio su informe: el unico que habia en disco era QUINCE HORAS anterior al codigo que decia haber juzgado, y costo el par de commits final entero mas una re-validacion completa. Se repitio en las iteraciones 5, 8, 11 y 13. No existia NINGUNA comprobacion mecanica de esta clase"
rejected_alternative: "(a) confiar en source_manifest, que ya existe: no cubre este caso — pregunta si el CODIGO se movio despues de tomar la evidencia (re-hashea las fuentes al cerrar), mientras que esto pregunta lo contrario, si el ARTEFACTO se escribio ANTES del codigo que cita. Una unidad puede tener el manifiesto perfecto (nada se movio desde el cierre) y descansar sobre un artefacto de hace dos dias. Misma palabra, flecha opuesta. (b) Usar mtime, que es lo primero que uno escribe: descartado y comprobado — git clone y cualquier checkout la reescriben, y la evidencia esta versionada, asi que el chequeo seria SILENCIOSAMENTE INERTE en CI y en todo clon nuevo, justo donde mas falta hace; medido con un repo de prueba, un fichero comiteado con fecha de 2020 conserva 2020 en git log tras clonar mientras su mtime pasa a ser la hora del clon. (c) Hacerlo FALLAR: empujaria al conductor a regenerar todo artefacto en cada pasada, y el mismo informe que midio este defecto midio tambien ese coste — 124 artefactos por iteracion, 6.937 lineas, practicamente ninguna podada jamas. Ascenderlo a fallo sin una politica de retencion antes seria cambiar un problema por otro"
trip_wire: "es un AVISO, y eso lo hace ignorable: si aparece corrida tras corrida sin que nadie lo mire, no esta comprando nada y hay que decidir entre ascenderlo a fallo (con politica de poda delante) o quitarlo. Segundo trip-wire: compara contra el fichero de fuente MAS NUEVO del manifiesto, excluyendo blueprint/** a proposito — un write-back de blueprint no es «el codigo se movio», y si alguna vez se incluye, cada edicion documental marcara como rancio un artefacto de runtime perfectamente valido y el aviso se volvera ruido en una semana"
supersedes: []
written_to: [.orchestrator/scripts/validate-state.py, .orchestrator/scripts/smoke-golden-path.sh]
affects_screens: [ninguna]
reopens: []
```

**Decisión.** Al cerrar, el gate compara la fecha del último commit de cada artefacto citado contra
la del fichero de fuente más reciente del `source_manifest`. Si el artefacto es **anterior**, lo
dice: nombra cuántos, cuáles y cuántas horas de desfase.

**Una sola llamada a git, y esto casi sale mal.** La primera versión preguntaba `git log -1` **por ruta**. Medido sobre un proyecto consumidor real antes de reescribirlo: 2.932 rutas entre su evidencia, a ~32 ms por invocación — unos **94 segundos añadidos a cada corrida del gate**, que corre tras cada fase. Una comprobación escrita para ir más rápido habría ido dramáticamente más lenta. Un solo recorrido del log cuesta 0,83 s en ese mismo repo y responde por todas las rutas a la vez, cacheado en el proceso. Hay un caso de smoke que fija esa propiedad.

**Por fecha de commit, nunca por `mtime`** — un `mtime` sobrevive mal a un `clone`, y la evidencia
está versionada. Sin git, el chequeo **calla**: un scaffold recién copiado no tiene historia y una
sospecha sin datos no es un hallazgo.

**Y avisa en vez de fallar, por una razón medida y no por prudencia genérica.** Fallar empujaría a
regenerar cada artefacto en cada pasada, y el mismo episodio que produjo este defecto acumuló 124
artefactos por iteración que nadie podó nunca. Ascenderlo a fallo pide antes una política de
retención; hasta entonces, esto nombra el defecto y deja que un humano lo pese — que es exactamente
lo que no existía cuando cinco checks citaron una corrida en rojo como prueba de un pase.

## DEC-ORCH-024 — La poda que no se construye, y por qué medirla fue más barato que escribirla

```logic
id: DEC-ORCH-024
type: decision
status: applied
date: 2026-08-18
decided_by: "Sergio"
trigger: "DEC-ORCH-023 dejo escrito que ascender su aviso a fallo exigia «una politica de poda delante», citando la medicion de un proyecto real: 124 artefactos por iteracion, 6.937 lineas, practicamente ninguna podada jamas, mas 295 KB en 19 capturas casi identicas. Sonaba a la pieza que faltaba. Antes de escribirla se midio que podria borrar de verdad"
rejected_alternative: "escribir el script de poda. La idea era buena y barata de derivar: el repo ya declara textualmente que ciertos ficheros NO son evidencia —logs/adversary-<n>.json, logs/changed-files.txt, logs/repair-diff.patch—, con la etiqueta repetida en cuatro sitios y reforzada por un caso de smoke que prohibe que validate-state.py conozca siquiera la palabra `adversary`. Una regla de poda derivada de esa declaracion seria imposible de equivocar: solo borraria lo que el propio repo ya dice que no prueba nada. Medido sobre los dos proyectos consumidores: maser-invariant-chronicle, 22 ficheros, 83.953 de 7.418.471 bytes = 1,13%. maser-onda, 22 ficheros, 278.443 de 39.351.309 bytes = 0,71%. Los tres ficheros mas grandes de cada arbol son capturas y logs de runtime CITADOS por checks[] —una captura de iOS pesa 3,4 MB ella sola— y esos son intocables por definicion del gate: `_collect_artifact_paths` los exige presentes y no vacios para todo PASS. Un mecanismo nuevo, con su script, su contrato de flags, su smoke y su mantenimiento, para recuperar menos del 1% del arbol y ni un byte de lo que pesa"
trip_wire: "esta decision caduca si cambia la proporcion, no si cambia la opinion. La medida a repetir es exactamente la de arriba: bytes de los tres patrones no-evidencia contra bytes totales de .orchestrator-state/evidence/. Si alguna vez pasa del 10%, la aritmetica cambia y merece reabrirse. Y una segunda condicion, distinta: si alguien introduce un artefacto no-evidencia GRANDE y por iteracion —un volcado, una traza completa, un perfil— este calculo deja de valer aunque el porcentaje de hoy siga igual"
supersedes: []
written_to: [.orchestrator/DECISIONS.md]
affects_screens: [ninguna]
reopens: []
```

**Decisión: no se construye.** Y se registra precisamente porque no se construye — para que el
siguiente que lea `DEC-ORCH-023` y vea la frase *«con política de poda delante»* no gaste el día en
escribirla sin medir antes lo que borraría.

| | evidencia total | podable | % |
|---|---:|---:|---:|
| maser-invariant-chronicle | 7.418.471 B | 83.953 B (22 fich.) | **1,13 %** |
| maser-onda | 39.351.309 B | 278.443 B (22 fich.) | **0,71 %** |

**Dónde está el peso de verdad:** capturas y logs de runtime **citados por `checks[]`**. Una
captura de iOS son 3,4 MB; el `result.json` mayor son 185 KB. El gate exige que cada artefacto
citado exista y no esté vacío para todo PASS, así que son intocables por definición — y son el
99 % del árbol.

**Lo que sí queda en pie de `DEC-ORCH-023`.** Su aviso sigue siendo aviso, y por la misma razón de
antes, que esta medición no toca: ascenderlo a fallo empujaría a **regenerar** artefactos en cada
pasada, y lo que se multiplicaría son las capturas de megas, no los marcadores de kilobytes. La
poda nunca habría contenido eso. El razonamiento era correcto; el remedio que nombraba, no.

**Nota sobre el método, que es la parte reutilizable.** Derivar la regla de lo que el repo ya
declara —en vez de inventar una taxonomía de retención— fue lo que permitió medirla en minutos: si
la regla es «borra solo lo que ya está etiquetado como no-evidencia», el conjunto es enumerable y
su tamaño, contable. Una política inventada habría necesitado discutirse antes de poder medirse.
