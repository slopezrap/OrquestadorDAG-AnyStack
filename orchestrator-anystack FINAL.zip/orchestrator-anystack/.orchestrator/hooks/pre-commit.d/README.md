# `pre-commit.d` — tus comprobaciones en el punto de salida

Todo artefacto que sale de esta máquina cruza `phase-push.sh`. Este directorio es el
único sitio donde un proyecto puede poner una comprobación **ahí**, y el único trozo de
`.orchestrator/` que una resincronización del orquestador **no** te va a pisar.

## Por qué existe

Un proyecto consumidor necesitó un escáner de secretos en este punto — dos credenciales
vivas ya habían llegado a `origin/main` — y lo cableó editando `phase-push.sh`. La
siguiente actualización del orquestador copió `.orchestrator/**` entero y se llevó por
delante la llamada, en silencio, dentro de un commit sobre otra cosa. Con ella se fueron
un control de seguridad fatal, una comprobación de paridad de traducciones y el tagging
de CI. 124 commits después, las reglas del proyecto seguían declarando el escáner activo.

**Un control que una actualización rutinaria puede borrar sin decírtelo no es un control.**

Por eso el *lanzador* vive en `phase-push.sh` (que el scaffold sí posee y sobreescribe —
así cada resincronización lo **restaura**) y las *comprobaciones* viven aquí (donde el
scaffold no envía nada más que este README, así que una resincronización nunca tiene
motivo para tocarlas).

## Contrato

- Se ejecuta **todo `*.sh`** de este directorio, en **orden lexicográfico**. Numéralos
  (`10-`, `20-`, …) si el orden importa.
- Cada hook recibe `$1 = <FASE>` y `$2 = <UNIT_ID>`.
- Corre con el árbol **ya en staging** (`git add -A` ya pasó) y **antes del commit**.
  Lo que hay que inspeccionar es `git diff --cached`, no el working tree.
- **Salida distinta de 0 = ABORTA**: no se hace commit y no se hace push.
- El `cwd` es la raíz del repositorio.
- **No hay flag para saltárselos.** El caso de uso que creó este mecanismo existe
  precisamente porque «solo por esta vez» es como una credencial llega a un remoto.
- **Si este directorio existe pero no se puede listar, el checkpoint ABORTA.** Sin permiso
  de lectura el glob no expande y los hooks se saltarían en silencio — que es justo la
  forma del incidente que creó todo esto. Un directorio con los permisos mal habría sido
  ese «flag para saltárselos» que la línea de arriba dice que no existe.
- **Hay un perro guardián de 300 s por hook** (`ORCH_HOOK_TIMEOUT_SECONDS`, `0` lo apaga).
  Un hook que no termina no puede responder por nada, así que se le mata y se aborta. Está
  escrito en bash puro: `timeout(1)` es de GNU coreutils y no viene ni en macOS ni en BSD.
- **El árbol de trabajo es de SOLO LECTURA para un hook.** Inspecciona `git diff --cached`;
  no escribas. Los hooks corren después de `git add -A`, así que lo que escribas queda
  fuera de este commit, se cuela en el siguiente bajo un mensaje que no lo describe, y —lo
  peor— hace que lo comprobado deje de ser lo commiteado. Si un hook toca el árbol, el
  checkpoint aborta y te lo dice.

## Ejemplo

```bash
#!/usr/bin/env bash
# 10-scan-secrets.sh — nada con forma de credencial sale de aquí.
set -uo pipefail
phase="${1:-}"

# Solo los ficheros de ESTE checkpoint, no el árbol entero.
files="$(git diff --cached --name-only --diff-filter=ACM 2>/dev/null)"
[ -z "$files" ] && exit 0

if printf '%s\n' "$files" | xargs -r grep -l 'eyJ[A-Za-z0-9_-]\{8,\}\.' 2>/dev/null; then
  echo "hook[$phase]: token con forma de JWT en el árbol staged." >&2
  exit 1
fi
exit 0
```

## Qué NO poner aquí

Un hook corre en **cada** checkpoint de fase — unos 20 por unidad. Una comprobación que
tarde minutos multiplica ese coste por 20. Si lo tuyo es caro, **acótalo a las rutas que
de verdad cambiaron** en este checkpoint (mira `git diff --cached --name-only` primero y
sal 0 cuando no te toca), o llévalo a un gate del pipeline en vez de al checkpoint.
