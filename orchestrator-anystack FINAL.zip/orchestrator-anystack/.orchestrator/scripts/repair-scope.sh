#!/usr/bin/env bash
set -uo pipefail
# Write the repair scope that VERIFY's triage reads — with the iteration header
# that is the whole reason it is honoured.
#
# WHY THIS IS A SCRIPT AND NOT A PARAGRAPH.
#
# verify-fanout.js already ships a complete, safe proportionality mechanism: give
# it the list of files this repair pass touched and it narrows the fan-out, and if
# every changed path is documentation it derives the four documentary lenses on its
# own. It is guarded three ways — a stale scope is refused, a diff over 150 files is
# refused, and any narrowed pass is stamped full_set:false so the STATE GATE will
# not accept it as a CLOSING entry. None of that can fabricate a PASS.
#
# It also, measured across one real project, produced savings in exactly ZERO of 93
# VERIFY runs. Not because it is broken: because it is fed by a file a model has to
# remember to REWRITE on every iteration. It got written once, at iteration 2, and
# the unit went on to iteration 7 — so from the third pass on, the freshness guard
# discarded it (correctly, and silently) and every single pass ran all ten lenses.
# Seven complete re-runs, 84 subagents, 42% of that unit's entire cost.
#
# The constitution already names this failure: "when a finding could have been
# produced by a script, the defect is not only the finding, it is that a lens was
# the one to produce it." The same holds for a header. So the header is computed
# here, from the checkpoint the unit actually declares, and the conductor stops
# being the thing that has to remember.
#
# usage: bash .orchestrator/scripts/repair-scope.sh <UNIT_ID> [ITERATION] [triage...]
#   ITERATION  omitted -> read from features.json's checkpoint.iteration for the unit
#   triage     any of: fail_fast | full_verify | scope_to=<lens>,<lens>
#
# exit 0 = scope written (or nothing to scope, which it says out loud)
# exit 2 = could not determine the unit or the iteration; writes NOTHING, because a
#          scope with the wrong header is worse than no scope at all.
#
# Not evidence. Never enters phase_runs[] or checks[]. The STATE GATE never reads it.

if [ -z "${BASH_SOURCE[0]:-}" ]; then
  echo "repair-scope: must be run with bash. Use: bash .orchestrator/scripts/repair-scope.sh <UNIT_ID>" >&2
  exit 2
fi
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
cd "$ROOT"

unit="${1:-}"
if [ -z "$unit" ]; then
  echo "usage: bash .orchestrator/scripts/repair-scope.sh <UNIT_ID> [ITERATION] [fail_fast|full_verify|scope_to=a,b]" >&2
  exit 2
fi

shift
iteration=""
triage_lines=""
for arg in "$@"; do
  case "$arg" in
    ''|*[!0-9]*)
      case "$arg" in
        fail_fast|full_verify) triage_lines="$triage_lines# triage: $arg
" ;;
        scope_to=*)            triage_lines="$triage_lines# triage: $arg
" ;;
        *) echo "repair-scope: unknown argument '$arg'." >&2; exit 2 ;;
      esac
      ;;
    *) iteration="$arg" ;;
  esac
done

# ITERATION FROM DISK, not from the caller's memory. features.json is the same
# source /next-pantalla resumes from, so the header can never disagree with the
# checkpoint the fan-out is about to compare it against.
if [ -z "$iteration" ]; then
  iteration="$(python3 - "$unit" <<'PY' 2>/dev/null
import json, sys, pathlib
uid = sys.argv[1]
f = pathlib.Path(".orchestrator-state/features.json")
if not f.exists():
    sys.exit(1)
try:
    data = json.loads(f.read_text())
except Exception:
    sys.exit(1)
for s in data.get("screens", []):
    if s.get("id") == uid:
        # No default. An absent checkpoint.iteration means the unit is not in a repair
        # episode, and guessing 0 would write a header that names an iteration nobody
        # declared. Refusing sends the caller to pass it explicitly, which is the only
        # way the header can be true.
        cp = s.get("checkpoint") or {}
        if "iteration" not in cp:
            sys.exit(1)
        print(int(cp["iteration"]))
        sys.exit(0)
sys.exit(1)
PY
)"
  if [ -z "$iteration" ]; then
    echo "repair-scope: could not read checkpoint.iteration for '$unit' from .orchestrator-state/features.json." >&2
    echo "  Pass it explicitly: bash .orchestrator/scripts/repair-scope.sh $unit <ITERATION>" >&2
    echo "  Nothing was written — a scope whose header names the wrong iteration is worse than none." >&2
    exit 2
  fi
fi

if ! git rev-parse --is-inside-work-tree >/dev/null 2>&1; then
  echo "repair-scope: not a git repository; cannot derive a scope." >&2
  exit 2
fi

# Every refusal is checked BEFORE this point, so "exit 2 writes nothing" is true of the
# directory too, not just of the file.
out_dir=".orchestrator-state/evidence/$unit/logs"
out="$out_dir/changed-files.txt"
mkdir -p "$out_dir" || { echo "repair-scope: cannot create $out_dir." >&2; exit 2; }

git add -A || true
# No --diff-filter and --no-renames, both deliberate, both learned from an audit of the
# first version of this script.
#
# Filtering to ACM drops DELETED paths. A repair that removes an implementation file and
# edits only a document then produces a list that is 100% documentation — and
# verify-fanout derives docs_only from exactly that, dropping to the four documentary
# lenses. The pass would look narrow because the scope LIED, not because the work was
# small. A deletion is a code change; it belongs in the list.
#
# --no-renames for the same reason in the other direction: a rename reported as one R
# entry hides both paths from a consumer that filters, and the whole point of this file is
# that ten lenses trust it.
files="$(git diff --cached --name-only --no-renames 2>/dev/null)"

{
  printf '# iteration: %s\n' "$iteration"
  printf '# command: git add -A && git diff --cached --name-only --no-renames\n'
  printf '%s' "$triage_lines"
  [ -n "$files" ] && printf '%s\n' "$files"
} > "$out"

count="$(printf '%s' "$files" | grep -c . || true)"
echo "repair-scope: wrote $out — iteration $iteration, $count file(s)."

# The two outcomes worth saying out loud, because both look like success in a log.
if [ "$count" -eq 0 ]; then
  echo "  NOTE: the staged range is empty. VERIFY will run as a BASELINE (all lenses)," >&2
  echo "  which is correct: a repair that changed nothing has nothing to narrow to." >&2
elif [ "$count" -gt 150 ]; then
  echo "  NOTE: $count files exceeds verify-fanout's CHANGED_CAP of 150, so the scope will be" >&2
  echo "  discarded and the pass runs complete. That is the designed behaviour, not a failure." >&2
fi
exit 0
