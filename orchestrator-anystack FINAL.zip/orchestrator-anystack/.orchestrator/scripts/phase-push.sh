#!/usr/bin/env bash
set -uo pipefail
# self-root to repo root so the commit/push is never cwd-relative
# Without the check, ROOT is empty and the script reports 'not a git repository; push skipped' in a
# real git repo — indistinguishable from the documented non-fatal no-op, so a checkpoint silently
# stops happening and nobody notices.
if [ -z "${BASH_SOURCE[0]:-}" ]; then
  echo "phase-push: must be run with bash (BASH_SOURCE unavailable). Use: bash .orchestrator/scripts/phase-push.sh <PHASE> [UNIT_ID]" >&2
  exit 2
fi
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
cd "$ROOT"

# Phase checkpoint: commit the work done in one /next-pantalla phase and push it
# to origin/main. Called by orchestrator-flow after every phase (RESEARCH,
# EXPLORE, DEVELOP, VERIFY, VALIDATE, REVIEW). This is a DevOps-role side effect,
# not a lifecycle transition: it never touches features.json status and the
# STATE GATE / human /accept remain the only trust anchors.
#
# It is non-fatal by design: when there is no git work tree or no 'origin'
# remote (the scaffold may run before the product repo is wired), it logs and
# exits 0 so building a screen is never blocked. Remote/branch are overridable
# via ORCH_PUSH_REMOTE / ORCH_PUSH_BRANCH.

phase="${1:-}"
unit="${2:-state}"
remote="${ORCH_PUSH_REMOTE:-origin}"
branch="${ORCH_PUSH_BRANCH:-main}"

if [ -z "$phase" ]; then
  echo "usage: bash .orchestrator/scripts/phase-push.sh <PHASE> [UNIT_ID]" >&2
  exit 2
fi

# 1. Require a git work tree, else skip (scaffold may run pre-init).
if ! git rev-parse --is-inside-work-tree >/dev/null 2>&1; then
  echo "phase-push[$phase]: not a git repository; push skipped." >&2
  exit 0
fi

# 2. Commit a checkpoint when there is something to record. Failure (e.g. a
#    product pre-commit hook) is non-fatal: keep going so the flow is not blocked.
git add -A || true

# 2a. PROJECT HOOKS on the staged tree, BEFORE the commit. This is the ONE
#     deliberately FATAL step in an otherwise non-fatal script, and the only
#     extension point the scaffold offers.
#
#     Why it exists, and why it is generic instead of naming any one check:
#     a consumer project needed a secret scanner here (two live credentials had
#     already reached origin/main), so it edited THIS file to call it. The next
#     time the scaffold was re-synced, .orchestrator/** was copied over wholesale
#     and the call vanished — silently, inside a commit about something else,
#     taking a fatal security control, an l10n parity check and the CI tagging
#     with it. 124 commits later the project's own rules still declared the
#     scanner active. A control that a routine upgrade can delete without saying
#     so is not a control.
#
#     So the RUNNER lives here, in the file the scaffold owns and overwrites —
#     which means every future re-sync RESTORES it — and the CHECKS live in
#     .orchestrator/hooks/pre-commit.d/, where the scaffold ships nothing but a
#     README: files you add there have names the scaffold does not own, so a
#     re-sync never has a reason to touch them.
#
#     Contract: every executable *.sh in that directory runs in lexical order
#     (prefix them 10-, 20-, ... to order them), receives "$phase" and "$unit"
#     as $1 and $2, and inherits a fully staged tree — `git diff --cached` is
#     the thing to inspect. A non-zero exit ABORTS: nothing is committed and
#     nothing is pushed. There is deliberately NO skip flag; the check this
#     mechanism was built for exists precisely because "just this once" is how
#     a credential reaches a remote.
hook_dir="$ROOT/.orchestrator/hooks/pre-commit.d"
if [ -d "$hook_dir" ]; then
  # FAIL CLOSED IF THE DIRECTORY CANNOT BE LISTED. `[ -d ]` only needs stat, so a
  # directory with no read permission passes it — and then the glob cannot expand,
  # bash leaves the literal `*.sh`, `[ -f ]` rejects it, and every hook is skipped in
  # SILENCE while the commit succeeds. That is the precise shape of the incident this
  # mechanism exists to prevent: a control that stops running without saying so. The
  # README promises "no flag to skip them"; an unreadable directory would have been
  # exactly that flag, reachable by an aggressive umask or a copy that dropped modes.
  if ! ls "$hook_dir" >/dev/null 2>&1; then
    echo "phase-push[$phase]: ABORTED — $hook_dir exists but cannot be listed, so its" >&2
    echo "  hooks could not run and this checkpoint cannot claim they passed. Fix the" >&2
    echo "  directory permissions (chmod +rx) and run the checkpoint again." >&2
    exit 1
  fi

  # A hung hook must not hold the build forever, and the watchdog is written in plain
  # bash ON PURPOSE: `timeout(1)` is GNU coreutils and ships on neither stock macOS nor
  # stock BSD — measured on the machine this was written on, where both `timeout` and
  # `gtimeout` are absent. A guard that only exists on the platform you are not using is
  # not a guard, so this one depends on nothing but the shell. 0 disables it.
  hook_timeout="${ORCH_HOOK_TIMEOUT_SECONDS:-300}"
  case "$hook_timeout" in ''|*[!0-9]*) hook_timeout=300 ;; esac

  run_hook() {  # <hook> -> exit code, or 124 when it outlives the deadline
    bash "$1" "$phase" "$unit" &
    _pid=$!
    if [ "$hook_timeout" -eq 0 ]; then wait "$_pid"; return $?; fi
    _waited=0
    while kill -0 "$_pid" 2>/dev/null; do
      if [ "$_waited" -ge "$hook_timeout" ]; then
        kill -TERM "$_pid" 2>/dev/null
        sleep 1
        kill -KILL "$_pid" 2>/dev/null
        wait "$_pid" 2>/dev/null
        return 124
      fi
      sleep 1
      _waited=$((_waited + 1))
    done
    wait "$_pid"
    return $?
  }

  for hook in "$hook_dir"/*.sh; do
    [ -f "$hook" ] || continue
    run_hook "$hook"; hook_rc=$?
    if [ "$hook_rc" -eq 124 ]; then
      echo "phase-push[$phase]: ABORTED — $(basename "$hook") outlived ${hook_timeout}s and was" >&2
      echo "  killed. A hook that cannot finish cannot vouch for anything, so nothing is" >&2
      echo "  committed. Scope it to the staged paths, or raise ORCH_HOOK_TIMEOUT_SECONDS" >&2
      echo "  (0 disables the watchdog)." >&2
      exit 1
    fi
    if [ "$hook_rc" -ne 0 ]; then
      echo "phase-push[$phase]: ABORTED by $(basename "$hook"); nothing committed or pushed." >&2
      exit 1
    fi
  done

  # WHAT WAS CHECKED MUST BE WHAT IS COMMITTED. Hooks run after `git add -A`, so a hook
  # that writes to the working tree leaves changes OUTSIDE this commit — they sit there
  # dirty and get swept into the NEXT phase's checkpoint, under a message describing
  # different work. Worse for a scanner: hook A inspects the staged tree, hook B edits
  # it, and the commit no longer matches what was inspected. Hooks inspect; they do not
  # mutate. Refusing here keeps the staged tree and the proof about it the same object.
  if ! git diff --quiet 2>/dev/null; then
    echo "phase-push[$phase]: ABORTED — a hook modified the working tree after staging." >&2
    echo "  Hooks must inspect (git diff --cached), never write: what a hook checked has to" >&2
    echo "  be what gets committed, and changes made now would land in a later checkpoint" >&2
    echo "  under someone else's message. Move the change into the build, then re-run." >&2
    exit 1
  fi
fi

# 2b. CI trigger shaping. One unit produces ~20 phase checkpoints (every phase,
#     every debugger re-run, every gate), so tagging them all would fire a full
#     CI matrix ~20 times for one screen — noise that buries the runs anyone
#     would actually read. Intermediate checkpoints therefore carry [skip ci],
#     which GitHub honours; the three states where a clean-machine verification
#     is genuinely worth having do not. The commit and the push happen either
#     way: the checkpoint's whole purpose is untouched, only the CI trigger
#     changes. Opt out entirely with ORCH_PUSH_SKIP_CI=0.
case "${ORCH_PUSH_SKIP_CI:-1}" in
  0|false|no) ci_tag="" ;;
  *)
    case "$phase" in
      VERIFIED|ACCEPTED|BLOCKED) ci_tag="" ;;
      *)                         ci_tag=" [skip ci]" ;;
    esac
    ;;
esac

if git diff --cached --quiet; then
  echo "phase-push[$phase]: no changes to commit."
else
  if git commit -m "orchestrator($unit): $phase phase checkpoint${ci_tag}" \
      -m "Automated checkpoint after the $phase phase of /next-pantalla."; then
    echo "phase-push[$phase]: committed checkpoint for $unit."
  else
    echo "phase-push[$phase]: commit failed (kept working tree); push skipped." >&2
    exit 0
  fi
fi

# 3. Push HEAD to <remote>/<branch> when the remote exists AND there is
#    something new for it to receive. Two independent, additive skips —
#    both leave the commit (the actual checkpoint) untouched, and both
#    default to OFF so a caller that sets nothing gets exactly today's
#    behavior: push after every phase.
#
#    (a) No-op skip, always on. A phase that wrote nothing to disk
#    (RESEARCH with no blueprint write-back, a triage re-run that only
#    re-confirms) leaves HEAD exactly where the LAST successful push
#    already left $remote/$branch: pushing again is a full network round
#    trip for zero new commits. Tracked with a local marker file, never a
#    remote call, so this never costs a round trip to find out it isn't
#    needed. Safe by construction: it can only skip a push whose sha was
#    already confirmed delivered by THIS script; it never suppresses a
#    push for a sha the marker has not seen succeed.
#
#    (b) Optional throttle, opt-in via ORCH_PUSH_MIN_INTERVAL_SECONDS
#    (unset/0 = current behavior, always push). A debugger loop can call
#    this script many times in a row for the SAME phase name
#    (constitution.md: "push a fresh checkpoint for each re-run phase, so
#    origin/main tracks every iteration"). The commit still lands locally
#    every single time — checkpoint/resume reads disk, not origin — but
#    when this var is set, a push within N seconds of the last successful
#    one is deferred instead of sent immediately. This trades "origin/main
#    updates within N seconds" for fewer round trips; it never trades away
#    the local checkpoint, and left unset it never fires.
if ! git remote get-url "$remote" >/dev/null 2>&1; then
  echo "phase-push[$phase]: remote '$remote' not configured; commit kept local, push skipped." >&2
  exit 0
fi

git_dir="$(git rev-parse --git-dir)"
marker="$git_dir/ORCH_LAST_PUSH_$(printf %s "${remote}_${branch}" | tr -c "A-Za-z0-9_" "_")"
head_sha="$(git rev-parse HEAD)"
last_sha=""
last_time=0
if [ -f "$marker" ]; then
  last_sha="$(sed -n 1p "$marker" 2>/dev/null)"
  last_time="$(sed -n 2p "$marker" 2>/dev/null)"
  case "$last_time" in ''|*[!0-9]*) last_time=0 ;; esac
fi

if [ "$head_sha" = "$last_sha" ]; then
  echo "phase-push[$phase]: HEAD already pushed as of the last checkpoint; push skipped."
  exit 0
fi

interval="${ORCH_PUSH_MIN_INTERVAL_SECONDS:-0}"
case "$interval" in ''|*[!0-9]*) interval=0 ;; esac
now="$(date +%s)"
if [ "$interval" -gt 0 ] && [ $(( now - last_time )) -lt "$interval" ]; then
  echo "phase-push[$phase]: within ORCH_PUSH_MIN_INTERVAL_SECONDS (${interval}s) of the last push; commit kept local, push deferred to the next checkpoint outside the window."
  exit 0
fi

if git push "$remote" "HEAD:$branch"; then
  printf '%s\n%s\n' "$head_sha" "$now" > "$marker"
  echo "phase-push[$phase]: pushed to $remote/$branch."
else
  echo "phase-push[$phase]: push to $remote/$branch failed; commit kept local, resolve and re-push." >&2
  exit 0
fi
