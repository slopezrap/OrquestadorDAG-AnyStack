# Stack and canonical commands

This file must contain real project commands. Placeholders are allowed in the scaffold but must be resolved during `/init-build` before implementation starts.

## Stack

- Runtime:
- Backend framework:
- Frontend framework:
- Mobile framework:
- Canonical store (database / event store / state store / ledger / external system / file store):
- ORM / migrations / schema tooling (if any):
- Testing:
- UI verification:
- Local URLs (web / API / other surfaces):

## Where the rest lives

Deployment/infra decisions and log targets are NOT here: they are in `.claude/policy/stack-infra.md`,
outside `.claude/rules/` so they never load as standing memory. Read that file when `/discovery`
fills `Q-INFRA-*`, when VALIDATE needs a log source, or when `/verify-app` / `/audit-motores` judge
runtime behaviour. Write infra facts THERE, never back into this file.

## Canonical commands

```bash
# install dependencies
<COMMAND_INSTALL>

# prepare local environment
<COMMAND_SETUP>

# start development server
<COMMAND_DEV>

# apply migrations
<COMMAND_MIGRATE>

# load minimal verifiable seed
<COMMAND_SEED>

# reset the verifiable test-data store to a clean, reproducible state (COMMAND_RESET_TEST_DATA)
# Read by .orchestrator/scripts/reset-test-data.sh, which the CONDUCTOR runs ONCE before any
# phase that executes the suite (VERIFY / VALIDATE and their debugger re-runs). Lenses never
# call it. MUST be idempotent: running it twice leaves the same state. Compose it from the
# commands above when that is what a reset means for this stack (typically migrate + seed);
# whatever this project's canonical store is, this is the one command that returns it to a
# known baseline. Leave the placeholder if the project genuinely has no test-data store —
# the script reports that distinctly and never blocks.
#
# MAKE IT CHEAP — this command sits in the hot path. It runs before VERIFY, before VALIDATE
# and before every debugger re-run, so it is multiplied by the number of repair rounds a unit
# takes, not paid once. Re-running the full migrate+seed chain is the obvious way to write it
# and usually the slowest: it rebuilds a known state that a previous run already computed.
# Prefer RESTORING a prepared baseline over recomputing it, whenever the declared store can:
# a template/seeded database cloned per run, a snapshot or dump restored, a filesystem-level
# copy of a data directory, a container volume reset to an image. Build the baseline once
# (migrate+seed into it) and refresh it only when the schema or the seed actually changes.
# The contract is unchanged — idempotent, returns the store to a known baseline, stack-agnostic
# (the orchestrator never learns which store this is). Only the cost changes. Keep the slow
# composed form if this project's store offers no restore path; correctness first, then speed.
<COMMAND_RESET_TEST_DATA>

# lint/static checks (COMMAND_LINT)
<COMMAND_LINT>

# unit/integration tests (COMMAND_TEST)
<COMMAND_TEST>

# build (COMMAND_BUILD)
<COMMAND_BUILD>

# minimal smoke check
<COMMAND_SMOKE>
```

## Do your verification commands rewrite source files?

```text
COMMAND_VERIFY_READONLY: <yes|no>
```

Answer `yes` only if `COMMAND_LINT`, `COMMAND_BUILD` and `COMMAND_TEST` **never write into the
source tree** — no `--fix`, no autoformat-on-run, no codegen, no snapshot rewriting, no lockfile
churn. If you are not sure, the answer is `no`, and `no` is what an unanswered line means.

**What it buys.** VERIFY runs four documentary lenses (read-only) and six executing ones. The six
must run one at a time — they share one tree, one store and one set of ports — but the four are
only forced to wait because a lens reading a file while `lint --fix` rewrites it produces a finding
that belongs to its neighbour (`DEC-ORCH-004`). Answer `yes` and that worry does not apply to your
project, so the four run **alongside** the chain instead of before it and leave the critical path
of every VERIFY pass — the baseline one and every repair.

**What it does not buy.** The six executing lenses stay serialized with respect to each other
whatever you answer. No declaration makes two of them safe to run at once.

**It is a promise, not a guess.** Nothing inspects your commands to check it, deliberately: a
command that is read-only today grows a `--fix` tomorrow and nothing would notice. If you add one,
change this line back to `no` in the same edit.

## Verification tool defaults

- Web: Claude in Chrome when active; otherwise Chrome DevTools MCP/plugin; Playwright only as explicit fallback.
- Mobile: the OS-level tooling is framework-agnostic and always applies — Android Emulator/ADB/logcat, or iPhone Simulator/IDB/simctl. Framework tooling is added only when the declared `Mobile framework` above calls for it (for a Dart/Flutter project, the Dart/Flutter MCP; for a native or cross-platform project of another kind, whatever that ecosystem provides). Do not launch framework tooling a project does not use.
  - **Where a project adds it:** the scaffold ships `validate-android`/`validate-ios`/`validate-journey` with no framework MCP declared, because the orchestrator cannot know your stack. Once `/init-build` resolves `Mobile framework`, add that framework's MCP server to those agents' `mcpServers:` frontmatter (an `mcpServers:` key with one entry per server, as `validate-journey` already does for the browser). This is a one-time `/init-build` step, and it is why the agents ship silent rather than assuming: a declared server for a framework you do not use is launched anyway.
- Backend/data: real test commands, real endpoints, real logs and real DB/API checks.
- Provider/integration: real adapter probe, SDK/CLI call or explicit degraded/not-applicable reason.

## Runtime evidence policy

- The setup command must be idempotent. The dev command may be long-running and should be used only when a live runtime is needed.
- Verifiers must prefer these commands over invented alternatives.
- If a command is unknown, `/init-build` must ask CLARIFY or mark init blocked; `/next-pantalla` must not guess.
- Do not use orchestrator reset/clean commands as acceptance evidence for an active screen.
- Do not accept tests that pass only because the real backend, DB, provider, emulator or browser runtime is absent when that runtime is required.
- Use isolated test data, disposable local state or safe cleanup when a verification mutates persistence.
- Redact secrets from command output before storing evidence.

