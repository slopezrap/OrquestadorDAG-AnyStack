# logic/engine.md — engine template

> Defines the product's engines as modules with a contract: rules engines, compute engines and agent graphs. Each `ENG-*` declares its module boundary, typed inputs/outputs, determinism, versioning, observability, failure mode and evidence, so an engine is consumed through its contract instead of being re-implemented screen by screen. Polymorphic by `kind`, the same way the orchestrator is AnyStack for the canonical store.

## Non-negotiable principle

```text
BR-*/DOM-* -> ENG-* engine module -> declared outputs -> DATA-*/read model -> API/service -> screens
```

- An engine is the single place where its decision or calculation lives. Commands, use cases and screens call it; they never re-implement it inline.
- Every engine is consumed through `inputs`/`outputs`. Nothing reaches into engine internals.
- Every engine declares `determinism`, because the required evidence shape depends on it.

**Boundaries (explicit):**

- `ENG-*` does **not** own durable schema, ownership, indexes or retention — that is `DATA-*`.
- `ENG-*` does **not** own the orchestration of a concrete command (input validation, transaction, effects) — that is `APP-*`. A command calls an engine; the engine never becomes the command.
- `ENG-*` does **not** own system-wide invariants (identity, tenant, audit, time, idempotency) — that is `CORE-*`.

## Index

| ID | Kind | Name | Determinism | Consumed by | Status |
|---|---|---|---|---|---|
| ENG-001 | rules_engine | `<RULES_ENGINE_NAME>` | deterministic | [UC-001, APP-001] | draft |
| ENG-002 | compute_engine | `<COMPUTE_ENGINE_NAME>` | deterministic | [APP-002, SCR-001] | draft |
| ENG-003 | agent_graph | `<AGENT_GRAPH_NAME>` | non_deterministic | [APP-002] | draft |

## ENG-001 — `<RULES_ENGINE_NAME>`

```logic
id: ENG-001
type: engine
kind: rules_engine
status: draft
summary: "<THE_ONE_DECISION_THIS_ENGINE_RESOLVES>"
product_refs: [BR-001]
related_screens: [SCR-001]
depends_on: [DOM-001, DATA-001, CORE-001, PERM-001]
severity: must
module:
  boundary: "<WHAT_IS_INSIDE_THIS_MODULE_AND_NOTHING_ELSE>"
  owns: ["<rule_evaluation>", "<precedence_and_conflicts>", "<decision_explanation>"]
  does_not_own: ["durable schema (DATA-001)", "command orchestration (APP-001)", "system invariants (CORE-001)"]
  consumed_by: [UC-001, APP-001, SCR-001]
inputs:
  - { from: DATA-001, field: "<field>", contract: "<logical_type_and_rule>" }
  - { from: INT-001, field: "<field>", contract: "<logical_type_and_rule>" }
outputs:
  - { to: DATA-001, field: "<decision_field>", contract: "<enum_or_type>" }
  - { to: event, field: "<decision_event>", contract: "<payload_shape>" }
determinism: deterministic
versioning:
  version: "1.0.0"
  migration_on_change: "<recompute|backfill|pin_existing_records|none>"
observability:
  decision_trace: true
  log_target: "<REAL_LOG_SOURCE>"
failure:
  on_error: ERR-001
  degraded_mode: "<safe_default|deny|block_operation>"
rules_engine:
  rules: [ENG-001-R1, ENG-001-R2]
  precedence: [ENG-001-R1, ENG-001-R2]
  conflict_resolution: "<first_match|highest_precedence|deny_wins|explicit_priority>"
  explainability: "<every decision returns matched_rule_id, evaluated inputs and outcome>"
verification:
  observable_by: [test, db, api, log]
  evidence: [test_output, db_query, decision_trace]
```

**Rules:**

| Rule | Cites | Condition | Outcome | Priority |
|---|---|---|---|---:|
| ENG-001-R1 | BR-001 / DOM-001 | `<CONDITION>` | `<OUTCOME>` | 1 |
| ENG-001-R2 | BR-001 | `<CONDITION>` | `<OUTCOME>` | 2 |

**Precedence and conflicts:**

- Evaluation order: `<ORDER>`. Resolution when two rules match: `<RULE>`.
- A decision with no matching rule resolves to `<EXPLICIT_DEFAULT>`; there is no implicit fallthrough.

**Edge cases:**

| Case | Input | Expected outcome | Cites |
|---|---|---|---|
| `<BOUNDARY_VALUE>` | `<INPUT>` | `<OUTCOME>` | DOM-001 |
| `<MISSING_OPTIONAL_INPUT>` | `<INPUT>` | `<OUTCOME>` | ERR-001 |

## ENG-002 — `<COMPUTE_ENGINE_NAME>`

```logic
id: ENG-002
type: engine
kind: compute_engine
status: draft
summary: "<THE_ONE_NUMBER_OR_DERIVED_SET_THIS_ENGINE_PRODUCES>"
product_refs: [BR-001]
related_screens: [SCR-001]
depends_on: [DOM-001, DATA-001, CORE-001]
severity: must
module:
  boundary: "<THE_CALCULATION_AND_ITS_INVARIANTS>"
  owns: ["<transforms>", "<windowing_and_aggregation>", "<numeric_exactness>"]
  does_not_own: ["durable schema (DATA-001)", "command orchestration (APP-002)", "system invariants (CORE-001)"]
  consumed_by: [APP-002, UC-001, SCR-001]
inputs:
  - { from: DATA-001, field: "<detail_field>", contract: "<logical_type_and_unit>" }
outputs:
  - { to: read_model, field: "<aggregate_field>", contract: "<logical_type_and_unit>" }
  - { to: DATA-002, field: "<persisted_aggregate>", contract: "<logical_type_and_unit>" }
determinism: deterministic
versioning:
  version: "1.0.0"
  migration_on_change: "<recompute_all|recompute_open_periods|pin_closed_periods>"
observability:
  decision_trace: true
  log_target: "<REAL_LOG_SOURCE>"
failure:
  on_error: ERR-001
  degraded_mode: "<serve_last_good_value|no_value|block_operation>"
compute_engine:
  transforms: [ENG-002-T1, ENG-002-T2]
  window: "<none|rolling_30d|calendar_month|since_inception>"
  aggregation: "<sum|avg|weighted_avg|last_value|count_distinct>"
  reprocess: "<idempotent_recompute|append_only|full_rebuild>"
  numeric_exactness:
    representation: "<decimal(18,2)|integer_minor_units|float64>"
    rounding: "<half_up|half_even|truncate>"
    rounding_stage: "<per_item|at_aggregate>"
    currency: "<ISO_CODE|n/a>"
  invariants: ["aggregate == sum(detail)", "<INVARIANT>"]
verification:
  observable_by: [test, db, api, ui]
  evidence: [test_output, db_query, api_response, screenshot]
```

**Transforms:**

| Transform | Input | Formula | Output | Unit/precision |
|---|---|---|---|---|
| ENG-002-T1 | DATA-001.`<field>` | `<FORMULA>` | `<field>` | `<UNIT_AND_PRECISION>` |
| ENG-002-T2 | ENG-002-T1.`<field>` | `<FORMULA>` | `<aggregate_field>` | `<UNIT_AND_PRECISION>` |

**Invariants and reprocessing:**

- `aggregate == sum(detail)` for every window, before and after a recompute.
- Recomputing the same window with the same inputs produces the same value (`reprocess` is idempotent unless declared otherwise).
- Rounding happens once, at the declared `rounding_stage`; no intermediate re-rounding.

**Worked example for verification:**

```yaml
worked_example:
  window: "<WINDOW>"
  input_values:
    - { id: "<id>", field: "<value>" }
    - { id: "<id>", field: "<value>" }
  engine_value: "<COMPUTED_VALUE>"
  stored_value: "<PERSISTED_VALUE>"
  expect: "engine_value == stored_value, literally and recomputable by the gate from input_values."
```

## ENG-003 — `<AGENT_GRAPH_NAME>`

```logic
id: ENG-003
type: engine
kind: agent_graph
status: draft
summary: "<THE_TASK_THE_GRAPH_RESOLVES_AND_ITS_OUTPUT>"
product_refs: [BR-001]
related_screens: [SCR-001]
depends_on: [DATA-001, INT-001, CORE-001, PERM-001]
severity: must
module:
  boundary: "<THE_GRAPH_ITS_STATE_AND_ITS_TOOL_BOUNDARY>"
  owns: ["<nodes_and_edges>", "<graph_state>", "<prompts_and_stop_criteria>"]
  does_not_own: ["durable schema (DATA-001)", "command orchestration (APP-002)", "external provider contracts (INT-001)"]
  consumed_by: [APP-002, UC-001]
inputs:
  - { from: DATA-001, field: "<field>", contract: "<logical_type_and_rule>" }
  - { from: INT-001, field: "<field>", contract: "<logical_type_and_rule>" }
outputs:
  - { to: DATA-002, field: "<result_field>", contract: "<logical_type_and_rule>" }
  - { to: event, field: "<run_completed_event>", contract: "<payload_shape>" }
determinism: non_deterministic
versioning:
  version: "1.0.0"
  migration_on_change: "<re_run_golden_set|pin_prompt_version|replay_checkpoints>"
observability:
  decision_trace: true
  log_target: "<REAL_LOG_SOURCE>"
failure:
  on_error: ERR-001
  degraded_mode: "<deterministic_fallback|human_handoff|no_result>"
agent_graph:
  nodes: [ENG-003-N1, ENG-003-N2, ENG-003-N3]
  edges: [ENG-003-E1, ENG-003-E2]
  state_schema:
    "<key>": "<logical_type>"
    "<key>": "<logical_type>"
  checkpointer:
    store: "<state_store_or_checkpointer_name>"
    canonical: true
    resource: "<table|collection|stream|checkpoint>"
    thread_key: "<CORRELATION_KEY>"
  tools: [INT-001]
  prompts:
    - { id: PROMPT-001, version: "1.0.0" }
  stop_criteria: "<goal_reached|max_steps=<N>|human_handoff>"
  eval:
    golden_set: "<PATH_TO_GOLDEN_SET>"
    criteria: ["<CRITERION>", "<CRITERION>"]
    threshold: 0.9
  fallback: "<THE_DETERMINISTIC_PATH_WHEN_THE_GRAPH_FAILS_OR_MISSES_THE_THRESHOLD>"
verification:
  observable_by: [test, db, log]
  evidence: [eval_output, checkpoint_snapshot, backend_log]
```

**Nodes:**

| Node | Role | Reads from state | Writes to state | Tools |
|---|---|---|---|---|
| ENG-003-N1 | `<ROLE>` | `<key>` | `<key>` | — |
| ENG-003-N2 | `<ROLE>` | `<key>` | `<key>` | INT-001 |
| ENG-003-N3 | `<ROLE>` | `<key>` | `<key>` | — |

**Edges:**

| Edge | From | To | Condition |
|---|---|---|---|
| ENG-003-E1 | ENG-003-N1 | ENG-003-N2 | `<CONDITION>` |
| ENG-003-E2 | ENG-003-N2 | ENG-003-N3 | `<CONDITION_OR_LOOP_GUARD>` |

**State and persistence:**

- The checkpointer is the canonical store for graph state (`canonical_store.kind: state_store`). Graph state is never held only in client or process memory.
- Every run is resumable from its persisted checkpoint using `thread_key`.
- The product result the screens read still lives in `DATA-*`; the checkpointer holds the run, not the product record.

**Non-determinism:**

- This engine is `non_deterministic`: acceptance never claims literal equality between two runs.
- Proof is the golden-set evaluation at or above `threshold`, a persisted checkpoint, and a fallback that has actually been exercised.

## Engine evidence (`engine_assertions[]`)

Engine evidence lives in `.orchestrator-state/evidence/<ID>/result.json` as `engine_assertions[]`, next to `data_engine_assertions[]`. The shape depends on `determinism`.

**Deterministic engines (`rules_engine`, `compute_engine`) — literal equality:**

```json
{
  "id": "ENG-<ID>-001",
  "engine_refs": ["ENG-001", "DOM-001", "DATA-001"],
  "kind": "rules_engine",
  "determinism": "deterministic",
  "input_value": "<observed input literal>",
  "engine_value": "<observed engine output literal>",
  "stored_value": "<observed canonical persisted literal>",
  "input_evidence": "<path>", "engine_evidence": "<path>", "stored_evidence": "<path>",
  "same_value": true
}
```

- The three literals must be present and observed, so the gate can recompute the equality instead of trusting `same_value`.
- `engine_value` must be reproducible from `input_value` by the engine's declared rules/transforms and version.

**Non-deterministic engines (`agent_graph`) — evaluation, not equality:**

```json
{
  "id": "ENG-<ID>-002",
  "engine_refs": ["ENG-003", "DATA-001", "INT-001"],
  "kind": "agent_graph",
  "determinism": "non_deterministic",
  "eval_result": { "golden_set": "<PATH>", "passed": 18, "total": 20, "threshold": 0.9 },
  "checkpoint_value": "<observed persisted graph state literal>",
  "checkpoint_evidence": "<path>",
  "fallback_tested": true,
  "fallback_evidence": "<path>"
}
```

- Literal equality between runs is NOT required and must not be claimed for an `agent_graph`.
- A PASS requires `passed / total >= threshold`, a persisted checkpoint read back from the canonical state store, and a fallback that was really triggered.
- Golden sets, checkpoints and fallback runs use real data through the declared generation path. Mocked engine output cannot satisfy an `ENG-*` acceptance criterion.

## Checklist

- [ ] Every engine declares a module `boundary` with `owns`, `does_not_own` and `consumed_by`.
- [ ] Every engine declares typed `inputs` and `outputs`; consumers never reach into internals.
- [ ] Every engine declares `determinism`, and its evidence shape matches it.
- [ ] Rules cite `BR-*`/`DOM-*`, and precedence plus conflict resolution leave no ambiguity.
- [ ] Compute engines declare representation, rounding, rounding stage and currency, plus at least one invariant.
- [ ] Agent graphs declare a canonical checkpointer, stop criteria, prompt versions, a golden set with a threshold and a fallback.
- [ ] No engine owns durable schema (`DATA-*`), command orchestration (`APP-*`) or system invariants (`CORE-*`).
- [ ] Every engine has a `versioning` policy and maps failures to `ERR-*`.
- [ ] Engine output is observable in a decision trace, log, store or eval output — not only in the UI.
