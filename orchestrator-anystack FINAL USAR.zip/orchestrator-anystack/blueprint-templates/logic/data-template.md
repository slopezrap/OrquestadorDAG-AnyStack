# logic/data.md — data engine template

> Defines the data engine that feeds screens and processes: persistence, models, ownership, queries, constraints, seeds/generators, migrations, pipelines, retention and privacy. Must make it verifiable that all frontends read the same canonical value from the database.

## Non-negotiable principle

```text
PRODUCT/SCREENS/logic -> DATA-* engine -> pipeline/generator -> database -> API/read model -> web/android/ios
```

- The database is the canonical source after every write or pipeline run.
- The UI cannot close acceptance with local constants, demo JSON, frontend fixtures or API mocks.
- Every critical visible field must be mapped to `db_source`, `api_field` and `ui_field`.

## Index

| ID | Type | Resource | Persistence | Screens | Status |
|---|---|---|---|---|---|
| DATA-001 | data_engine | `<RESOURCE>` | `<table/collection>` | [SCR-001] | draft |

## DATA-001 — `<ENGINE_OR_RESOURCE_NAME>`

```logic
id: DATA-001
type: data_engine
status: draft
summary: "<WHAT_DATA_IS_GENERATED_STORED_AND_READ>"
product_refs: [BR-001]
related_screens: [SCR-FOUNDATION-SCHEMA, SCR-001]
depends_on: [DOM-001, APP-001, UC-001, PERM-001, CORE-001]
severity: must
canonical_store:
  source_of_truth: database
  storage: "<sql|nosql>"
  resources: ["<table_or_collection>"]
ownership: "<user|tenant|global|system>"
pii: false
retention: "<RETENTION>"
pipeline_ref: PIPE-001          # the pipeline that feeds this resource lives in logic/pipeline.md
pipeline:                        # summary ONLY — PIPE-001 is the single source of truth for it
  generation_method: "<migration|seed|backfill|job|api_write|user_action|event_replay|state_transition>"
  writes_to_database: true
  write_path: ["APP-001", "repository", "<table_or_collection>"]
  read_path: ["database", "service/api", "frontend/mobile"]
  cache_or_projection: "<none|name_and_invalidation_rule>"
verification:
  observable_by: [migration, db, api, ui]
  evidence: [schema_snapshot, db_query, api_response, screenshot]
```

**Logical model / canonical schema:**

| Canonical field | Logical type | Required | Unique | Default | Rule |
|---|---|---:|---:|---|---|
| `id` | identifier | yes | yes | generated | `<RULE>` |
| `<field>` | `<type>` | yes/no | yes/no | `<default>` | `<RULE>` |

**Single-value contract:**

| Business field | DB source | API/read-model field | UI/mobile field | Invariant |
|---|---|---|---|---|
| `<field>` | `<table>.<field>` | `<response.path>` | `<selector/widget>` | `same value for the same user/tenant/permission context` |

**Constraints and invariants:**

- `<CONSTRAINT>`

**Expected indexes/queries:**

| Query | Usage | Filter | Order | Screen |
|---|---|---|---|---|
| `<QUERY_NAME>` | `<USAGE>` | `<FILTER>` | `<ORDER>` | SCR-001 |

**Minimum seed/generation for development/verification:**

```yaml
seed_or_generator:
  required: true
  source: "engine"
  scenarios:
    - name: "empty"
      records: []
    - name: "success"
      writes_to_database: true
      records:
        - { id: "<id>", owner_id: "<user>", field: "<value>" }
    - name: "permission_denied"
      writes_to_database: true
      records:
        - { id: "<other_user_id>", owner_id: "<other>", field: "<value>" }
```

**Expected migration/pipeline:**

- Create: `<TABLES_COLLECTIONS>`
- Modify: `<CHANGES>`
- Backfill/job: `<IF_APPLICABLE>`
- Rollback: `<IF_APPLICABLE>`
- Cache/projection invalidation: `<IF_APPLICABLE>`

**Privacy and retention:**

- PII: yes/no. Fields: `<FIELDS>`
- Deletion: `<RULE>`
- Export: `<RULE>`
- Audit: `<RULE>`

**Required data check on screens:**

```yaml
data_check:
  engine_refs: [DATA-001, APP-001, UC-001]
  db_query: "<REAL_QUERY>"
  api_probe: "<ENDPOINT_OR_SERVICE>"
  visible_selector_or_finder: "<SELECTOR_OR_WIDGET>"
  expect: "The visible value matches the DB and API/read model, respecting ownership, filters and order."
```

## DATA-002 — `<QUERY_OR_READ_VIEW_NAME>`

```logic
id: DATA-002
type: read_model
status: draft
summary: "<AGGREGATED_DATA_OR_LISTING>"
product_refs: [BR-001]
related_screens: [SCR-001]
depends_on: [DATA-001, PERM-001]
severity: must
canonical_store:
  source_of_truth: database
  resources: ["<table_or_collection_or_view>"]
verification:
  observable_by: [db, api, ui]
  evidence: [db_query, api_response, screenshot]
```

**Exposed fields:**

| Visible/API field | DB origin | Transformation | Permission rule |
|---|---|---|---|
| `<field>` | DATA-001.`<field>` | `<transformation>` | PERM-001 |

## Checklist

- [ ] Every visible piece of data has a persisted origin or a justification.
- [ ] Every model defines ownership.
- [ ] Every query defines filters, order and permissions.
- [ ] A seed/generator exists for empty/success/permission scenarios when UI applies.
- [ ] Privacy/retention rules are defined when PII is present.
- [ ] Screens can verify data with DB + API + UI/mobile.
- [ ] No local frontend data is required to close acceptance.
- [ ] Every resource with a non-trivial feed cites its `pipeline_ref: PIPE-*`; trigger, idempotency, backfill, freshness, scale and failure runbook are defined THERE, not duplicated here.
- [ ] Derived/computed values cite the `ENG-*` that produces them instead of re-stating the rule.
