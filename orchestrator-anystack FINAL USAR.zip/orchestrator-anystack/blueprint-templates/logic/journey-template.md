# logic/journey.md — journey template

> Defines complete user journeys. A journey connects screens, states, decisions, errors and the final outcome.

## Index

| ID | Actor | Goal | Screens | Status |
|---|---|---|---|---|
| JOUR-001 | `<ACTOR>` | `<GOAL>` | [SCR-001, SCR-002] | draft |

## JOUR-001 — `<JOURNEY_NAME>`

```logic
id: JOUR-001
type: journey
status: draft
summary: "<JOURNEY_GOAL>"
product_refs: [BR-001]
related_screens: [SCR-001, SCR-002]
depends_on: [UC-001, PERM-001, ST-001, ERR-001]
severity: must
actor: "<ACTOR_OR_ROLE>"
entry_points: ["<ORIGIN_ROUTE>"]
success_end_state: "<FINAL_STATE>"
verification:
  observable_by: [e2e, screenshot, log, db]
  evidence: [flow_recording, screenshot, db_snapshot, backend_log]
```

**Goal:** `<WHAT_THE_USER_IS_TRYING_TO_COMPLETE>`

**Initial context:**

- User: `<ROLE_STATE_PERMISSIONS>`
- Existing data: `<SEED_OR_PRIOR_DATA>`
- Initial screen: `SCR-001`

**Main flow:**

| Step | Screen | User/system action | Expected result | Applied IDs |
|---:|---|---|---|---|
| 1 | SCR-001 | `<ACTION>` | `<RESULT>` | [UI-001, APP-001] |
| 2 | SCR-002 | `<ACTION>` | `<RESULT>` | [DATA-001, ST-001] |

**Alternative branches:**

| Branch | Condition | Behavior | Recovery | IDs |
|---|---|---|---|---|
| A1 | `<CONDITION>` | `<BEHAVIOR>` | `<RECOVERY>` | [ERR-001] |

**Success criterion:**

- `<FINAL_OBSERVABLE_RESULT>`

**Controlled abandonment criterion:**

- `<WHAT_HAPPENS_IF_THE_USER_CANCELS_OR_LEAVES>`

## Checklist

- [ ] The journey starts and ends in clear states.
- [ ] Each step cites an existing screen.
- [ ] Each error branch cites `ERR-*`.
- [ ] Success is verified with real UI and data.
- [ ] There are no impossible steps due to missing permissions or data.
