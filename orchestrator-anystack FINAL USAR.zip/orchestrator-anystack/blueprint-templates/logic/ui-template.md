# logic/ui.md — UI/UX template

> Defines visible behavior, accessibility, responsiveness, microcopy, states and interaction rules. Must not hide business rules that belong to `domain`, `application` or `permission`.

## Index

| ID | Area | Name | Screens | Status |
|---|---|---|---|---|
| UI-001 | state | `<UI_RULE>` | [SCR-001] | draft |

## UI-001 — `<UI_RULE_NAME>`

```logic
id: UI-001
type: ui_rule
area: "<layout|state|form|navigation|accessibility|copy|responsive|feedback>"
status: draft
summary: "<VISIBLE_BEHAVIOR>"
product_refs: [BR-001]
related_screens: [SCR-001]
depends_on: [ST-001, ERR-001, DATA-001]
severity: must
platforms: [web, android, ios]
verification:
  observable_by: [screenshot, e2e, accessibility, console]
  evidence: [screenshot, flow_recording, accessibility_report, console_log]
```

**Visible rule:** `<WHAT_THE_USER_MUST_SEE_OR_BE_ABLE_TO_DO>`

**Required states:**

| State | What is shown | Available action | Data used |
|---|---|---|---|
| loading | `<SKELETON_SPINNER_ETC>` | `<ACTION>` | `<DATA>` |
| empty | `<MESSAGE>` | `<CTA>` | `<DATA>` |
| error | `<MESSAGE>` | `<RETRY>` | `<DATA>` |
| success | `<CONTENT>` | `<ACTIONS>` | `<DATA>` |

**Responsive/adaptation:**

| Platform/viewport | Rule |
|---|---|
| web desktop | `<RULE>` |
| web mobile | `<RULE>` |
| Android | `<RULE>` |
| iOS | `<RULE>` |

**Accessibility:**

- Keyboard navigable: yes/no/NA
- Control labels: `<RULE>`
- Minimum contrast: `<RULE>`
- Screen readers: `<RULE>`
- Minimum touch target size on mobile: `<RULE>`

**Microcopy:**

| Context | Recommended text | Prohibited text |
|---|---|---|
| `<CONTEXT>` | `<TEXT>` | `<PROHIBITED_TEXT>` |

**Web verification:**

- Use a real browser with Claude in Chrome or Chrome DevTools MCP when available.
- Capture screenshots of key states.
- Review console, network and runtime errors.

**Mobile verification:**

- For Flutter, use the Dart/Flutter MCP if available.
- Android: verify on emulator/device with ADB/logcat.
- iOS: verify on simulator/device with IDB or `xcrun simctl`.

## Checklist

- [ ] Each screen has loading, empty, error and success states, unless justified.
- [ ] Each visual rule can be verified with a screenshot, flow or test.
- [ ] The UI does not invent data; it consumes `DATA-*` or real state.
- [ ] The UI displays errors defined by `ERR-*`.
- [ ] The UI respects permissions from `PERM-*`.
- [ ] Web and mobile declare differences where they exist.
