# logic/pipeline.md — pipeline template

> Defines every pipeline as a first-class executable artifact: trigger, source, transform, sink, delivery guarantees, backfill/replay, retries, freshness SLA, scale profile, failure runbook and observability. A pipeline is what turns a source into canonical data that engines, read models and screens can trust. IDs use the `PIPE-*` family.

## Non-negotiable principle

```text
source -> PIPE-* -> canonical store -> ENG-*/read model -> screens
```

- A pipeline is the only sanctioned way to produce or move product data into the canonical store.
- Everything a pipeline writes is generated through a REAL path (`migration|seed|backfill|job|api_write|user_action|event_replay|state_transition`). Never fixtures, mocks, stubs or invented values, in any layer.
- A pipeline that cannot be proven to have run (run log + output check in the canonical store) has not run.
- `PIPE-*` owns HOW data moves and WHEN. It does not own the schema of what it writes (`DATA-*`), nor the rules it applies (`ENG-*`/`DOM-*`).
- In `logic/data.md` the nested `pipeline:` block becomes a single `pipeline_ref: PIPE-00X` so there are never two sources of truth for the same pipeline.

## Index

| ID | Type | Name | Trigger | Feeds | Writes | Screens | Status |
|---|---|---|---|---|---|---|---|
| PIPE-001 | pipeline | `<SCHEDULED_PIPELINE>` | schedule | [ENG-001] | [DATA-001] | [SCR-001] | draft |
| PIPE-002 | pipeline | `<EVENT_PIPELINE>` | event | [ENG-002] | [DATA-002] | [SCR-002] | draft |

## PIPE-001 — `<SCHEDULED_PIPELINE_NAME>`

```logic
id: PIPE-001
type: pipeline
status: draft
summary: "<WHAT_IT_MOVES_ON_A_SCHEDULE_AND_WHICH_ENGINE_IT_FEEDS>"
product_refs: [BR-001]
feeds: [ENG-001]
writes: [DATA-001]
related_screens: [SCR-001]
severity: must
trigger:
  kind: schedule
  spec: "<CRON_OR_INTERVAL>"
source: ["<ORIGIN_TABLE_STREAM_ENDPOINT_OR_INT-001>"]
transform: ["<NORMALIZE>", "<AGGREGATE>", "<APPLY_ENG-001_RULES>"]
sink:
  store: "<database|event_store|state_store|ledger|external_system|file_store>"
  resource: "<table_or_collection_or_projection>"
guarantees:
  ordering: "<none|per_key|global>"
  delivery: at_least_once
  idempotency_key: "<FIELD_OR_COMPOSITE_KEY>"
backfill:
  supported: true
  procedure: "<COMMAND_OR_STEPS_TO_REPROCESS_A_RANGE>"
  replay_safe: true
retry:
  policy: "<none|linear|exponential>"
  max_attempts: 3
  dead_letter: "<WHERE_FAILED_ITEMS_LAND>"
freshness:
  sla: "<MAX_AGE_OF_THE_VALUE_A_SCREEN_MAY_SHOW>"
  max_lag: "<TOLERATED_LAG_BEFORE_ALERT>"
  measured_by: "<TIMESTAMP_FIELD_OR_METRIC>"
scale:
  volume_profile: "<RECORDS_PER_RUN_AND_GROWTH>"
  batch_size: 500
  concurrency: 1
  breaks_at: "<WHAT_BREAKS_AT_10x_VOLUME>"
failure_runbook: "<FIRST_ACTION_WHEN_THE_RUN_FAILS_OR_IS_LATE>"
observability:
  run_log: "<WHERE_EACH_RUN_IS_LOGGED>"
  metrics: ["<records_in>", "<records_written>", "<duration>", "<lag>"]
  how_to_prove_it_ran: "<RUN_ID_OR_QUERY_THAT_SHOWS_THE_LAST_SUCCESSFUL_RUN>"
real_data:
  generation_method: job
  no_fixtures: true
  verification_path: "<REAL_QUERY_OR_COMMAND_THAT_SHOWS_THE_WRITTEN_ROWS>"
verification:
  observable_by: [job, db, api, log]
  evidence: [pipeline_run_log, db_query, api_response]
```

**Stages:**

| Stage | Input | Output | Failure mode |
|---|---|---|---|
| `<extract>` | `<SOURCE>` | `<RAW_BATCH>` | `<FAILURE>` |
| `<transform>` | `<RAW_BATCH>` | `<CANONICAL_RECORDS>` | `<FAILURE>` |
| `<load>` | `<CANONICAL_RECORDS>` | `<SINK_RESOURCE>` | `<FAILURE>` |

**Idempotency and ordering:**

- Re-running the same window produces the same result: `<HOW_DUPLICATES_ARE_COLLAPSED>`
- Ordering guarantee: `<WHAT_ORDER_IS_PRESERVED_AND_WHY_IT_MATTERS>`

**Backfill/replay procedure:**

1. `<STOP_OR_PAUSE_THE_SCHEDULED_TRIGGER>`
2. `<RUN_THE_RANGE_REPROCESS_COMMAND>`
3. `<VERIFY_COUNTS_AGAINST_THE_SOURCE>`
4. `<RESUME_AND_CONFIRM_FRESHNESS_IS_BACK_INSIDE_SLA>`

**Freshness contract:**

| Screen | Value shown | Max acceptable age | Behavior when stale |
|---|---|---|---|
| SCR-001 | `<FIELD>` | `<SLA>` | `<STALE_BADGE_OR_ERR-001>` |

**Failure runbook:**

| Symptom | Likely cause | Action | Escalate when |
|---|---|---|---|
| `<RUN_FAILED>` | `<CAUSE>` | `<ACTION>` | `<CONDITION>` |
| `<RUN_LATE_LAG_ABOVE_SLA>` | `<CAUSE>` | `<ACTION>` | `<CONDITION>` |
| `<PARTIAL_WRITE>` | `<CAUSE>` | `<REPLAY_RANGE>` | `<CONDITION>` |

## PIPE-002 — `<EVENT_DRIVEN_PIPELINE_NAME>`

```logic
id: PIPE-002
type: pipeline
status: draft
summary: "<WHAT_IT_PROJECTS_FROM_EVENTS_AND_HOW_IT_IS_REPLAYED>"
product_refs: [BR-001]
feeds: [ENG-002]
writes: [DATA-002]
related_screens: [SCR-002]
severity: must
trigger:
  kind: event
  spec: "<EVENT_NAME_OR_TOPIC_OR_ON_WRITE_RESOURCE>"
source: ["<EVENT_LOG_OR_QUEUE>"]
transform: ["<VALIDATE_EVENT>", "<FOLD_INTO_PROJECTION>"]
sink:
  store: "<database|event_store|state_store>"
  resource: "<read_model_or_projection>"
guarantees:
  ordering: per_key
  delivery: exactly_once
  idempotency_key: "<EVENT_ID>"
backfill:
  supported: true
  procedure: "<REBUILD_PROJECTION_FROM_EVENT_ZERO>"
  replay_safe: true
retry:
  policy: exponential
  max_attempts: 5
  dead_letter: "<DEAD_LETTER_RESOURCE>"
freshness:
  sla: "<SECONDS_FROM_EVENT_TO_VISIBLE_VALUE>"
  max_lag: "<CONSUMER_LAG_THRESHOLD>"
  measured_by: "<CONSUMER_OFFSET_OR_EVENT_TIMESTAMP>"
scale:
  volume_profile: "<EVENTS_PER_MINUTE_PEAK>"
  batch_size: 100
  concurrency: "<PARTITIONS>"
  breaks_at: "<WHAT_BREAKS_AT_10x_EVENT_RATE>"
failure_runbook: "<HOW_TO_DRAIN_THE_DEAD_LETTER_AND_REBUILD>"
observability:
  run_log: "<CONSUMER_LOG>"
  metrics: ["<events_consumed>", "<projection_lag>", "<dead_letter_size>"]
  how_to_prove_it_ran: "<OFFSET_OR_PROJECTION_VERSION_QUERY>"
real_data:
  generation_method: event_replay
  no_fixtures: true
  verification_path: "<REAL_QUERY_THAT_SHOWS_THE_PROJECTED_VALUE>"
verification:
  observable_by: [log, db, api, ui]
  evidence: [pipeline_run_log, db_query, api_response, screenshot]
```

**Replay contract:**

- Rebuilding the projection from scratch produces the same values as the incremental run: `<HOW_IT_IS_PROVEN>`
- Events are never mutated; corrections are new events: `<CORRECTION_EVENT_NAME>`

**Boundaries with other layers:**

| Concern | Owner | Not owned here |
|---|---|---|
| Schema of the written resource | DATA-002 | `PIPE-002` only writes it |
| Rules applied during transform | ENG-002 / DOM-001 | `PIPE-002` only executes them |
| Permission on the resulting read | PERM-001 | `PIPE-002` does not filter by role |
| External provider contract | INT-001 | `PIPE-002` only consumes it |

## Evidence

| Artifact | Path under `.orchestrator-state/evidence/<ID>/` | Proves |
|---|---|---|
| Run log | `logs/pipeline-run.txt` | The pipeline really ran: trigger, run id, records in/out, duration, exit status. |
| Backfill log | `logs/backfill.txt` | The replay/backfill procedure was executed over a real range and finished clean. |
| Output check | `db/pipeline-output-check.txt` | The canonical store holds the produced rows/events, with counts and sample values. |

```yaml
pipeline_check:
  pipeline_refs: [PIPE-001]
  engine_refs: [ENG-001, DATA-001]
  run_command: "<REAL_COMMAND_THAT_TRIGGERS_ONE_RUN>"
  output_query: "<REAL_QUERY_AGAINST_THE_CANONICAL_STORE>"
  freshness_probe: "<QUERY_OR_METRIC_THAT_RETURNS_CURRENT_LAG>"
  expect: "The run log shows a successful run, the canonical store holds its output, lag is inside the freshness SLA and no fixture data was used."
```

## Checklist

- [ ] Every pipeline declares a trigger with a concrete spec, not just a kind.
- [ ] Source, transform and sink are named; the sink resource exists in a `DATA-*`.
- [ ] Delivery, ordering and idempotency key are declared and consistent with the retry policy.
- [ ] Backfill/replay is either supported with a procedure or explicitly not supported with a reason.
- [ ] Freshness has an SLA, a max lag and a way to measure it.
- [ ] The scale profile says what breaks at 10x volume.
- [ ] There is a failure runbook with a first action per symptom.
- [ ] `how_to_prove_it_ran` is a real query/command, and its output is stored as evidence.
- [ ] `real_data.no_fixtures` holds: no fixtures, mocks, stubs or invented values in any layer.
- [ ] The matching `DATA-*` entry references this pipeline with `pipeline_ref` instead of a nested `pipeline:` block.
