# logic/integration.md — integration template

> Defines contracts with external systems: APIs, webhooks, queues, email, payments, storage, analytics, maps, AI, etc.

## Index

| ID | System | Direction | Usage | Screens | Status |
|---|---|---|---|---|---|
| INT-001 | `<SYSTEM>` | outbound | `<USAGE>` | [SCR-001] | draft |

## INT-001 — `<INTEGRATION_NAME>`

```logic
id: INT-001
type: integration
status: draft
summary: "<WHAT_IT_IS_USED_FOR>"
product_refs: [BR-001]
related_screens: [SCR-001]
depends_on: [APP-001, DATA-001, ERR-001, CORE-001]
severity: must
system: "<EXTERNAL_SYSTEM_NAME>"
direction: "<inbound|outbound|bidirectional>"
protocol: "<http|webhook|queue|sdk|file|other>"
timeout_ms: 10000
retry_policy: "<none|linear|exponential|queue>"
idempotency_required: true
verification:
  observable_by: [test, log, network, db]
  evidence: [mock_contract_test, network_log, backend_log]
```

**Input contract:**

| Field | Logical type | Required | Rule |
|---|---|---:|---|
| `<field>` | `<type>` | yes/no | `<rule>` |

**Output contract:**

| Field | Logical type | Required | Internal usage |
|---|---|---:|---|
| `<field>` | `<type>` | yes/no | `<usage>` |

**Authentication/secrets:**

- Expected secret/env: `<ENV_NAME>`
- Rotation or environment: `<RULE>`
- Sensitive data: `<PII_SECRET_TOKEN_ETC>`

**Errors and fallback:**

| Failure | Behavior | Error | Retry | Persistence |
|---|---|---|---|---|
| timeout | `<BEHAVIOR>` | ERR-001 | yes/no | `<CHANGE>` |

**Idempotency:**

`<HOW_TO_AVOID_DUPLICATES_ON_RETRIES_OR_WEBHOOKS>`

**Observability:**

- Logs: `<WHAT_TO_LOG>`
- Metrics: `<WHAT_TO_MEASURE>`
- Correlation: `<CORRELATION_ID>`

## Checklist

- [ ] The integration has an input and an output contract.
- [ ] There is a timeout and retry policy.
- [ ] Idempotency is defined if the call can be repeated.
- [ ] Secrets are not hardcoded.
- [ ] Failures are mapped to `ERR-*`.
- [ ] The integration can be verified with a mock, sandbox or network/log evidence.
