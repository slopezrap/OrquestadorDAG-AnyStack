# logic/usecases.md — use case template

> Defines atomic user or system goals. A use case may be implemented across one or more screens, but must have preconditions, a flow, alternatives and acceptance criteria.

## Index

| ID | Actor | Goal | Screens | Status |
|---|---|---|---|---|
| UC-001 | `<ACTOR>` | `<GOAL>` | [SCR-001] | draft |

## UC-001 — `<USE_CASE_NAME>`

```logic
id: UC-001
type: use_case
status: draft
summary: "<ATOMIC_GOAL>"
product_refs: [BR-001]
related_screens: [SCR-001]
depends_on: [DOM-001, APP-001, PERM-001, ST-001, ERR-001, DATA-001]
severity: must
actor: "<ACTOR_OR_ROLE>"
frequency: "<high|medium|low>"
verification:
  observable_by: [e2e, test, db, ui]
  evidence: [flow_recording, test_output, db_snapshot]
```

**Story:** As `<ACTOR>`, I want `<GOAL>`, so that `<BENEFIT>`.

**Trigger:** `<EVENT_THAT_STARTS_THE_CASE>`

**Preconditions:**

- `<PRECONDITION_1>`
- `<PRECONDITION_2>`

**Postconditions:**

- `<PERSISTED_OR_VISIBLE_RESULT>`

**Main flow:**

1. `<STEP_1>`
2. `<STEP_2>`
3. `<STEP_3>`

**Alternative flows:**

| ID | Condition | Steps | Result |
|---|---|---|---|
| UC-001-A1 | `<CONDITION>` | `<STEPS>` | `<RESULT>` |

**Exceptions:**

| Condition | Error | Result |
|---|---|---|
| `<CONDITION>` | ERR-001 | `<RESULT>` |

**Acceptance criteria:**

- When `<CONDITION>`, the system must `<OBSERVABLE_RESULT>`.
- If `<ERROR>`, the system must `<OBSERVABLE_RECOVERY>`.
- Where `<CONTEXT>`, the system must `<RULE>`.

**Required data:**

- Input: `<INPUT_DATA>`
- Persistence: DATA-001
- Read/result: DATA-002

**Permissions:**

- PERM-001: `<SUMMARY>`

## Checklist

- [ ] The use case has an actor and a benefit.
- [ ] Preconditions are verifiable.
- [ ] The main flow ends in a clear postcondition.
- [ ] Alternatives and exceptions cite errors or states.
- [ ] Acceptance criteria are observable and automatable.
