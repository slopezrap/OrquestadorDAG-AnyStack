# logic/state.md — state template

> Defines states, transitions, synchronization, concurrency and UI/business states. Must avoid ambiguities such as "pending", "active" or "closed" without a valid transition.

## Index

| ID | Machine/Entity | Initial state | Final states | Screens | Status |
|---|---|---|---|---|---|
| ST-001 | `<ENTITY>` | `<STATE>` | [`<FINAL>`] | [SCR-001] | draft |

## ST-001 — `<STATE_MACHINE_NAME>`

```logic
id: ST-001
type: state_machine
status: draft
summary: "<WHAT_STATES_IT_GOVERNS>"
product_refs: [BR-001]
related_screens: [SCR-001]
depends_on: [DOM-001, APP-001, DATA-001, ERR-001]
severity: must
entity: "<ENTITY>"
initial_state: "<initial_state>"
terminal_states: ["<final_state>"]
verification:
  observable_by: [test, db, ui]
  evidence: [state_transition_test, db_snapshot, screenshot]
```

**Allowed states:**

| State | Meaning | Visible to user | Persisted | Final |
|---|---|---:|---:|---:|
| `<state>` | `<meaning>` | yes/no | yes/no | yes/no |

**Allowed transitions:**

| From | Event | To | Actor/System | Conditions | Effects |
|---|---|---|---|---|---|
| `<state_a>` | `<event>` | `<state_b>` | `<actor>` | `<conditions>` | `<effects>` |

**Prohibited transitions:**

| From | To | Reason | Error |
|---|---|---|---|
| `<state_a>` | `<state_c>` | `<reason>` | ERR-001 |

**Minimum UI states for screens that read this entity:**

- `loading`: `<WHAT_IS_SHOWN>`
- `empty`: `<WHAT_IS_SHOWN>`
- `error`: `<WHAT_IS_SHOWN>`
- `success`: `<WHAT_IS_SHOWN>`

**Concurrency and synchronization:**

- If two actions attempt to modify the same resource: `<RULE>`
- If the client is offline or out of date: `<RULE>`

## Checklist

- [ ] Every state has a unique meaning.
- [ ] Only explicitly allowed transitions exist.
- [ ] Prohibited transitions have an associated error.
- [ ] The persisted state and the visible state do not contradict each other.
- [ ] Concurrency conditions are defined.
