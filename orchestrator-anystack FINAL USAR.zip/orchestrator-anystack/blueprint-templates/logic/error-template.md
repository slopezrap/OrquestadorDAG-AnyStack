# logic/error.md — error template

> Defines error taxonomy, visible messages, recovery, logging and severity. Every expected error must be verifiable.

## Index

| ID | Type | Visible message | Recovery | Status |
|---|---|---|---|---|
| ERR-001 | validation | `<MESSAGE>` | user_action | draft |
| ERR-002 | server | `<MESSAGE>` | retry | draft |

## ERR-001 — `<ERROR_NAME>`

```logic
id: ERR-001
type: error_case
status: draft
summary: "<ERROR_CONDITION>"
product_refs: [BR-001]
related_screens: [SCR-001]
depends_on: [APP-001, UI-001]
severity: must
error_kind: "<validation|permission|not_found|conflict|network|server|integration>"
user_recoverable: true
log_level: "warn"
verification:
  observable_by: [test, ui, log, network]
  evidence: [error_screenshot, test_output, log_excerpt]
```

**Condition:** `<WHEN_THE_ERROR_OCCURS>`

**Visible message:** `<CLEAR_MESSAGE_WITHOUT_TECHNICAL_JARGON>`

**What the user can do:**

- `<RECOVERY_ACTION>`

**Expected technical response:**

- API/logical status: `<CODE_OR_RESULT>`
- Log: `<WHAT_MUST_APPEAR>`
- Persistence: `<WHETHER_THERE_ARE_CHANGES_OR_NOT>`

**Must not happen:**

- `<DO_NOT_SHOW_STACK_TRACE>`
- `<DO_NOT_LOSE_FORM_DATA>`
- `<DO_NOT_RETRY_INFINITELY>`

## ERR-002 — `<BACKEND_UNIT_ERROR_NAME>`

> A non-UI unit (backend/data/worker/pipeline) also owns error cases. `SCREENS-template.md` cites this one from `SCR-002`, so the moulds stay referentially intact when copied into `blueprint/`.

```logic
id: ERR-002
type: error_case
status: draft
summary: "<ERROR_CONDITION_ON_THE_BACKEND_UNIT>"
product_refs: [BR-001]
related_screens: [SCR-002]
depends_on: [APP-002, DATA-002]
severity: must
error_kind: "<server|conflict|integration|not_found>"
user_recoverable: false
log_level: "error"
verification:
  observable_by: [test, log, api]
  evidence: [test_output, log_excerpt, api_response]
```

**Condition:** `<WHEN_THE_ERROR_OCCURS>`

**Structured response:** `<STATUS_CODE_OR_RESULT_SHAPE>` — never a raw stack trace across the boundary.

**Recovery:** `<RETRY_POLICY_OR_COMPENSATION>` (cite `PIPE-*.retry` when a pipeline owns it).

**Must not happen:**

- `<DO_NOT_LEAK_SECRETS_OR_PAYLOADS_TO_LOGS>`
- `<DO_NOT_LEAVE_A_PARTIAL_WRITE_IN_THE_CANONICAL_STORE>`

## Recommended taxonomy

| Type | When to use | Recovery |
|---|---|---|
| validation | Invalid or incomplete input | Fix the field |
| permission | User lacks authorization | Request access / switch account |
| not_found | Resource does not exist or is not visible | Go back / list / create |
| conflict | State changed or duplicate | Refresh / resolve conflict |
| network | No connection, timeout or temporary outage | Retry |
| server | Unexpected internal failure | Limited retry + support/log |
| integration | External provider fails | Fallback, retry or queue |

## Checklist

- [ ] Each error has a visible message.
- [ ] Each error defines a recovery path.
- [ ] Each error defines the expected logging.
- [ ] Failed operations do not leave partial data unless specified.
- [ ] Sensitive errors do not leak private information.
