# PRODUCT.md — product template

> This file is product prose. Do not describe components, tables, endpoints or frameworks unless they are a genuine business constraint.

## 0. Metadata

```yaml
product_name: "<PRODUCT_NAME>"
version: "v1"
status: "draft"
owner: "<PERSON_OR_TEAM>"
last_reviewed: "YYYY-MM-DD"
markets: ["<COUNTRY_OR_MARKET>"]
platforms: [web, android, ios]
languages: [es]
```

## 1. What it is

`<PRODUCT_NAME>` is `<SHORT_DESCRIPTION_IN_2_OR_3_SENTENCES>`.

This should make clear:

- What problem it solves.
- What task it allows the user to complete.
- What observable outcome the user gets.
- What differentiates this product from a manual or generic solution.

## 2. Why it exists

### Main problem

`<USER_PAIN_OR_NEED>`

### Cost of not solving it

`<WHAT_HAPPENS_TODAY_IF_THE_USER_LACKS_THIS_PRODUCT>`

### Expected outcome

`<BUSINESS_OR_USER_RESULT_THAT_MUST_IMPROVE>`

## 3. For whom

### Actors

| Actor | Description | Main goal | Constraints |
|---|---|---|---|
| `<ACTOR_1>` | `<WHO_THEY_ARE>` | `<WHAT_THEY_WANT_TO_ACHIEVE>` | `<LIMITS>` |
| `<ACTOR_2>` | `<WHO_THEY_ARE>` | `<WHAT_THEY_WANT_TO_ACHIEVE>` | `<LIMITS>` |

### Operational roles

| Role | Can | Cannot | Notes |
|---|---|---|---|
| `<ROLE_1>` | `<ACTIONS>` | `<FORBIDDEN_ACTIONS>` | `<NOTES>` |

## 4. v1 scope

Include only what must exist in the first acceptable version.

- `<CAPABILITY_1>`
- `<CAPABILITY_2>`
- `<CAPABILITY_3>`

## 5. v1 out-of-scope

Explicit list to prevent the agent from building too much.

- `<OUT_OF_SCOPE_1>`
- `<OUT_OF_SCOPE_2>`
- `<OUT_OF_SCOPE_3>`

## 6. Non-negotiable business rules

Every rule must have a stable ID. These rules may be cited by `SCREENS.md` and by `logic/*.md`.

### BR-001 — `<RULE_NAME>`

```logic
id: BR-001
type: business_rule
status: draft
summary: "<RULE_SUMMARY>"
rationale: "<WHY_IT_EXISTS>"
severity: must
applies_to: ["<ACTOR_OR_PROCESS>"]
related_screens: [SCR-001]
related_logic: [DOM-001, UC-001, DATA-001]
```

**Rule:** `<DESCRIBE_THE_RULE_IN_BUSINESS_LANGUAGE>`

**Valid examples:**

- `<VALID_EXAMPLE>`

**Counter-examples:**

- `<EXAMPLE_THAT_MUST_NOT_BE_ALLOWED>`

**Acceptance implication:** `<HOW_TO_OBSERVE_THAT_IT_IS_MET>`

## 7. Experience principles

- `<PRINCIPLE_1>`
- `<PRINCIPLE_2>`
- `<PRINCIPLE_3>`

Example: "The user must always know what happened, what they can do next, and whether their data has been saved."

## 8. Tone, brand and communication

### Voice

`<FORMAL_FRIENDLY_TECHNICAL_INSTITUTIONAL_ETC>`

### Forbidden microcopy

- `<WORD_OR_TONE_TO_AVOID>`

### Required microcopy

- `<WORD_OR_TONE_TO_USE>`

## 9. Legal, compliance or security constraints

- `<CONSTRAINT_1>`
- `<CONSTRAINT_2>`

## 10. Success metrics

| Metric | Definition | How observed in v1 |
|---|---|---|
| `<METRIC_1>` | `<DEFINITION>` | `<EVENT_OR_CHECK>` |

## 11. Assumptions

- `<ASSUMPTION_1>`
- `<ASSUMPTION_2>`

## 12. Open questions

| ID | Question | Impact if unresolved | Decision |
|---|---|---|---|
| Q-001 | `<QUESTION>` | `<IMPACT>` | `<PENDING_OR_DECISION>` |

## 13. Quality checklist

- [ ] The product is understandable without reading code.
- [ ] The v1 scope is buildable and verifiable.
- [ ] The out-of-scope list prevents over-building.
- [ ] `BR-*` rules are observable.
- [ ] Actors and roles are defined.
- [ ] No technical decisions are disguised as product needs.
