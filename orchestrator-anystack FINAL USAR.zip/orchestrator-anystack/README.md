# orchestrator-anystack

Orquestador para **Claude Code** que construye una aplicación **pantalla a pantalla**, en vertical (datos → API → UI), con **verificación real** y una **puerta humana**. Es **AnyStack**: la fuente de verdad de producto vive en `blueprint/` y el almacén canónico es el que tú declares (DB relacional, document DB, event store, state store/checkpointer estilo LangGraph, ledger, sistema externo, file store).

Este README es el único documento: explica el modelo y trae la **cheat sheet** para operarlo.

---

## 1. Idea en una frase

> Tú escribes el producto en `blueprint/`. El conductor (`orchestrator-flow`) construye **un único** unidad/pantalla por vez, apoyándose en **agentes-lente especializados** que leen y verifican en paralelo, y solo cierra cuando hay **evidencia real** y tú das el visto bueno con `/accept`.

Reglas de oro:
- **Escritor único:** solo `orchestrator-flow` escribe estado, código y el `result.json` consolidado. Las lentes **devuelven hallazgos**; las de verificación viva guardan sus propios artefactos (capturas/logs).
- **Nada inventado:** no se fabrica evidencia ni datos. La verdad de producto sale de `blueprint/`; el dato canónico, del almacén declarado.
- **Determinista donde importa:** el *state gate* (`validate-state.py`) y tu `/accept` son las anclas de confianza; el criterio del agente nunca las sustituye.

---

## 2. El flujo (fases → workflows → lentes → agentes)

Cada fase paralela **siempre** se lanza como un **workflow** (`.claude/workflows/*.js`, mecanismo oficial de Claude Code / ultracode) que abre en paralelo **agentes-lente** especializados; el conductor consolida y escribe. Lanzar el workflow es **obligatorio**, no una preferencia, y cada workflow hace fan-out a **TODAS** sus lentes-subagente —**todas, cada vez**— nunca a un subconjunto elegido a mano (DISCOVERY → las 6 `discovery-*`; RESEARCH/COMPILE → las 17 `research-*`; EXPLORE → `explore-scout` + las 8 `explore-*`; VERIFY → las 10 `verify-*`; VALIDATE → `validate-logs` + `validate-{web,android,ios}` por plataforma propia + `validate-engine`/`validate-pipeline` si la unidad cita `ENG-*`/`PIPE-*`). Una lente que no aplica igualmente se lanza y devuelve `n/a`. Solo si la capacidad de Workflows no está disponible en la sesión se degrada a `Agent(<lente>)` secuencial con el **mismo set completo** (`inline-fallback`, más lento; **nunca** como atajo).

```
/init-build:
  DISCOVERY ▶ discovery.js          → 6 discovery-* (checklist universal ANTES de compilar nada: producto, papel de la IA,
                                       origen de datos, event sourcing, arquitectura, stack, auth, despliegue/tenancy, UX;
                                       cada ítem acaba answered/filled/asked/deferred/n-a y se escribe en blueprint/stack/DECISIONS)
  INIT      ▶ compile-blueprint.js  → 17 research-* (modo COMPILE, leen todo el blueprint en paralelo)
            → orchestrator-flow compila spec.md + features.json → STATE GATE → stop

/next-pantalla [ID]  (una sola unidad):
  (0) RESEARCH ▶ research-fanout.js → 17 research-*  (¿blueprint completo para ESTA pantalla? si falta → CLARIFY y se escribe en blueprint)
  (1) EXPLORE  ▶ explore-fanout.js  → explore-scout + 8 explore-*  (audita el código, mapea el build, fija la ruta de verificación;
                                                       incluye motores y pipelines YA existentes, y la config/dependencias)
  (2) DEVELOP  ✗ orchestrator-flow ESCRIBE el código (sin fan-out). También es el debugger.
  (3) VERIFY   ▶ verify-fanout.js   → 10 verify-* (ESTÁTICO: tests, conformidad con docs, diseño, motor/pipeline, logs back/front/db/motor,
                                                     coherencia cross-pantalla, y deriva blueprint↔código) → emite expected_ui_values
  (4) VALIDATE ▶ validate-live.js   → validate-{web,android,ios,logs} + validate-{engine,pipeline} si cita ENG-*/PIPE-*
                                       (VIVO/humano: MCP navegador + emulador/simulador + logs; y el motor/pipeline se EJECUTA de verdad)
  (5) REVIEW   · pantalla-reviewer  (un único veredicto contractual sobre VERIFY+VALIDATE)
  (5.5) GATES  ▶ AUTOMÁTICOS, lentes en Sonnet: /verify-pipelines-data-ultracode --fix (motor/pipelines/datos)
               + /production-code-review --fix (producción). Sus checks required entran en result.json;
               si arreglan algo → pasa de debugger (re-VERIFY/re-VALIDATE).
      STATE GATE ✗ validate-state.py (determinista)  → stop en `verified`

  ↳ tras CADA fase: phase-push.sh → commit + push a origin/main (checkpoint, no-fatal; no cambia status)

/accept <ID>:  verified → accepted   (puerta humana; única transición que la hace)
               ↳ si el accept completa un journey (JOUR-*), lanza AUTOMÁTICAMENTE:
                 · /verify-app <JOUR-ID>   (costuras cross-pantalla en runtime real)
                 · /audit-motores          (arquitectura cross-producto: motores, pipelines, escala)
                 ambos reportan y recomiendan; ninguno mueve estados
```

**Bucle debugger** (DEVELOP repara y se re-corre aguas abajo, máx 3 iteraciones):
- VERIFY falla → debug → **re-VERIFY** → (al pasar) VALIDATE.
- VALIDATE falla → debug → **re-VERIFY + re-VALIDATE** (un fix de código puede invalidar lo estático).

**Estados:** `todo → ready → building → verified → accepted` ( `→ blocked` si falta una decisión; `deprecated` en `/reslice`).

**Construir por delante, aceptar en orden.** Una unidad pasa a `ready` cuando sus dependencias están **construidas** (`verified` o `accepted`) — basta con que tengan evidencia PASS real. Pero `/accept` sigue el orden de `after[]`: no puedes aceptar una unidad cuya dependencia no esté aceptada. Por eso `/build-loop` puede encadenar el producto entero dejándolo todo en `verified`, y tú lo promocionas después en orden. La puerta humana no se debilita: pasa de ser *permiso para trabajar* a *permiso para darlo por bueno*. `status.json` publica `acceptable_now` para que sepas cuáles puedes aceptar ya.

**Roles expertos:** el conductor no es un generalista: encarna **todos los roles**, cada uno a nivel **senior**, para montar la pantalla (product owner, arquitecto de software senior, DBA, ingeniero de datos, backend, frontend, mobile, DevOps, seguridad, UX, QA, SRE, tech lead). Senior significa: nombrar los trade-offs, elegir la opción probada sobre la ingeniosa, y diseñar para la aplicación completa (arquitectura, modelo de datos, motor de reglas, pipelines, clientes), no solo para la pantalla activa. Cada fase los materializa como lentes (RESEARCH/EXPLORE/VERIFY/VALIDATE/REVIEW) o como sombreros que lleva a la vez en DEVELOP (arquitecto + backend + frontend/mobile + DBA + ingeniero de datos + DevOps + seguridad + QA). Extrae lo que cada rol necesita del blueprint/diseño/código.

**Pensar primero, luego preguntar:** cuando un rol no sabe algo —en **cualquier** fase— primero lo resuelve él (relee fuentes/docs, razona desde ese rol); si tras pensarlo sigue genuinamente sin resolverse, **pregunta al humano** una pregunta precisa en vez de adivinar (mejor agrupar decisiones de producto en RESEARCH, y persistir las respuestas en `blueprint/`). Bloquear es el último recurso. Nunca inventa intención de producto ni falsea un valor.

**Checkpoint por fase:** tras cada fase (incluidas las re-corridas del debugger) el conductor ejecuta `.orchestrator/scripts/phase-push.sh "<FASE>" "<ID>"` → commit + push a `origin/main`. Es un efecto secundario (rol DevOps), **no** una transición de ciclo de vida: no cambia el `status`; el STATE GATE y tu `/accept` siguen siendo las únicas anclas. Es no-fatal: sin repo git o sin remoto `origin`, avisa y continúa (no bloquea construir). Remoto/rama configurables con `ORCH_PUSH_REMOTE`/`ORCH_PUSH_BRANCH`.

---

## 3. AnyStack y evidencia falsificable

- `data_engine.canonical_store.kind` / `source_of_truth` es el sistema de registro que declares (nunca un cliente). El validador hace cumplir las invariantes, no una tecnología.
- La evidencia (`data_engine_assertions[]`) lleva el **valor literal observado en cada capa** (`db_value`/`api_value`/`ui_value`, alias `source_value`/`transport_value`/`client_value`, + `platform_values`). El *state gate* **recalcula** `same_value` de esos literales: prueba `almacén → API/read-model → cliente`. Una pantalla bonita con datos mock no pasa.
- **El ciclo de workflows es obligatorio y está verificado por máquina, no solo por prosa.** Cada `result.json` lleva `phase_runs[]` (fase · workflow · modo · lentes que corrieron de verdad). El *state gate* (`validate-state.py`) **rechaza un PASS** que se saltó una fase de fan-out o corrió un set de lentes incompleto (RESEARCH 17 · EXPLORE scout+8 · VERIFY 10 · VALIDATE logs+plataforma propia+motor/pipeline citados · REVIEW pantalla-reviewer). Además, el hook `validate-state.sh` corre el gate completo al escribir `features.json`, así que marcar `verified` saltándose un workflow falla en el acto. Inventar `phase_runs` de una fase no ejecutada es fabricar evidencia (prohibido).

---

## 4. Estructura (todo lo que hay, y nada más)

```
CLAUDE.md                      memoria de proyecto (Claude Code la auto-carga; importa las rules)
README.md                      este documento

.claude/
  settings.json                arranca como orchestrator-flow + 2 hooks
  rules/                        constitution.md · conventions.md · stack.md   (gobernanza / memoria)
  agents/                       69 agentes (ver §5)
  skills/<cmd>/SKILL.md         init-build · next-pantalla · build-loop · accept · status · reslice
                                review-pantalla · verify-pipelines-data-ultracode · production-code-review · verify-app
                                audit-motores · arch-review · discovery · fix
  workflows/*.js                compile-blueprint · research-fanout · explore-fanout · verify-fanout · validate-live · validate-journeys
                                audit-architecture · arch-review · discovery
  hooks/                        block-rm.sh (PreToolUse) · validate-state.sh (PostToolUse)

.orchestrator/                  definición estable (no es estado vivo)
  scripts/                      validate-state.py (STATE GATE, --emit-status escribe status.json + evidence/index.json) · lint-blueprint.py (linter determinista del blueprint) · original-coverage.py (reconcilia ORIGINAL.md↔capas, alimenta CLARIFY) · validate-structure.sh (estructura + sync de lentes .js↔.py) · reset-state.sh · reset-test-data.sh (resetea el almacén de PRUEBAS delegando en stack.md; solo el conductor, antes de cada fase que ejecuta) · phase-push.sh (commit+push por fase)
  schemas/                      features.schema.json · result.schema.json (forma ilustrativa; el .py manda)
  templates/                    features.empty.json · spec.template.md · discovery-checklist.md (banco de preguntas del gate /discovery, editable) · evidence/ (esqueleto)
  examples/                     features.example.json · result.example.json (cómo es un "bueno")
                                golden-path/ — producto mínimo COMPLETO de ejemplo ("Notas rápidas"):
                                blueprint entero (14 logic + PRODUCT + SCREENS con SHELL) + estado canónico;
                                lo ejercita .orchestrator/scripts/smoke-golden-path.sh

.orchestrator-state/            estado vivo en disco
  features.json                 plan ejecutable (la pieza clave)
  spec.md · progress.md         contexto consolidado · handoff append-only
  evidence/<ID>/result.json     evidencia por unidad
  status.json · evidence/index.json   proyecciones derivadas de SOLO LECTURA para superficies externas
                                (dashboards/CI): las emite validate-state.py --emit-status, atómicas,
                                con schema_version; nunca se editan a mano ni son fuente de verdad

blueprint/                      TU entrada (fuente de verdad): PRODUCT.md · SCREENS.md · logic/*.md (14, incl. shell.md cross-pantalla,
                                engine.md ENG-* y pipeline.md PIPE-*)
blueprint-templates/            moldes para escribir el blueprint
design/                         tokens.css · screens/  (referencias visuales)
.env.example                    variables de entorno de ejemplo
```

---

## 5. Roster de agentes (69) y workflows (9)

- **Conductor (escribe):** `orchestrator-flow`.
- **DISCOVERY t=0 (7, gate `/discovery` dentro de `/init-build`, ANTES de COMPILE):** `discovery-{product,data,architecture,stack,infra,ux}` + `discovery-synthesizer` — recorren el checklist universal (`.orchestrator/templates/discovery-checklist.md`): lo que ningún blueprint suele escribir (papel de la IA, tenancy, alcance de event sourcing, postura de auth, backups, coste IA...). Regla de familia: `discovery-*` posee lo NO PREGUNTADO, `research-*` posee la AUSENCIA, `arch-*` posee el ERROR. Cada ítem acaba con disposición explícita (answered con cita · filled con default · asked en UNA ronda agrupada con opción recomendada · deferred como `DEC-*` abierto · n/a con razón); el conductor escribe las respuestas en `blueprint/**`/`stack.md`/`DECISIONS.md` y `--init-gate` exige `meta.discovery` para nacer. Nunca entra en `phase_runs[]`.
- **RESEARCH/INIT (17, uno por fichero de blueprint/ + el HTML de design/):** `research-{domain,application,core,journey,permission,state,error,integration,ui,shell,data,usecases,engine,pipeline,product,screens,design}` — dual-mode: cobertura por-pantalla (`/next-pantalla`) o COMPILE de todo el blueprint (`/init-build`). `research-shell` cubre el contrato cross-pantalla (`blueprint/logic/shell.md`, `UI-SHELL-*`); `research-engine` los motores (`ENG-*`) y `research-pipeline` lo que los alimenta (`PIPE-*`).
- **EXPLORE (9):** `explore-scout` + `explore-{data,backend,ui,existing,tests,engine,pipeline,config}` — `explore-engine`/`explore-pipeline` inventarían los motores y pipelines que YA existen en el código (para que la pantalla N no reimplemente lo que construyó la 3); `explore-config` cierra el ámbito `config` que el scout siempre descubrió y ninguna lente recibía (manifiesto de dependencias, lockfile, CI, entorno, `stack.md`).
- **VERIFY estático (10):** `verify-{tests,conformance,design,frontend,engine,pipeline,logs,quality,coherence,blueprint-drift}` — dos lentes miran más allá del código de la pantalla: `verify-coherence` la compara contra el contrato de shell y las pantallas hermanas ya `verified`/`accepted` (deriva HORIZONTAL: componentes duplicados, rutas, tokens hardcodeados), y `verify-blueprint-drift` compara el código contra CADA capa de blueprint que la unidad cita (deriva VERTICAL: conocimiento que vive solo en código y hay que devolver al blueprint). Antes esa segunda comprobación existía solo para `shell.md`.
- **VALIDATE vivo (6):** `validate-{web,android,ios,logs,engine,pipeline}` — VALIDATE dejó de ser solo-UI: si la unidad cita `ENG-*`/`PIPE-*`, el motor se EJECUTA con entrada real y el pipeline se CORRE de verdad contra el almacén canónico. Un motor ya no puede llegar a `verified` con verificación estática sola.
- **CROSS-PANTALLA vivo (1, gate opcional `/verify-app`):** `validate-journey` — recorre un journey (`JOUR-*`) completo por las pantallas ya aceptadas en el runtime real: navegación entre pantallas (costuras), mismo valor canónico en cada pantalla que lo muestre, shell coherente en movimiento. Es lo que ninguna fase por-pantalla puede ver.
- **ARCH t=0 (7, gate `/arch-review`):** `arch-{fit,data-model,identity,engines,pipelines,risk}` + `arch-synthesizer` — juzgan el DISEÑO antes de construir nada, dentro de `/init-build` (tras CLARIFY, antes de compilar `features.json`) y re-disparado por `/reslice` cuando deriva el hash de arquitectura. La regla de la familia: `research-*` posee la AUSENCIA, `arch-*` posee el ERROR. Un blocker exige `retrofit_cost` y se resuelve por tres salidas humanas: cimiento `SCR-FOUNDATION-*`, riesgo aceptado como `DEC-*`, o aplazado con trip-wire. Sus hallazgos NUNCA entran en `phase_runs[]`; el registro máquina vive en `features.json.meta.architecture_review` y `validate-state.py --init-gate` impide nacer sin él.
- **AUDIT cross-arquitectura (6, gate `/audit-motores`):** `audit-{engine-inventory,engine-contract,pipeline-topology,data-reality,scale}` + `audit-synthesizer` — miran TODO el producto a la vez, no una pantalla: ¿cada `ENG-*` implementado una sola vez y fiel a su contrato? ¿la topología `PIPE-* → almacén → ENG-* → read-model → pantallas` está sana? ¿todo dato traza a una ruta de generación real? ¿qué se rompe a 10x? Reportan y recomiendan; nunca mueven estados y NO entran en los sets requeridos de `phase_runs[]`.
- **REVIEW (1):** `pantalla-reviewer` (síntesis contractual).
- **Síntesis (6, una por fase pesada):** `compile-synthesizer` · `research-synthesizer` · `verify-synthesizer` · `audit-synthesizer` · `arch-synthesizer` · `discovery-synthesizer`
- **Utilidad (1):** `context-loader` — cargador read-only disk-first (fase Load de `validate-live`/`validate-journeys`/`audit-architecture`/`arch-review`; `model: haiku`) — reductores read-only que consolidan las lentes de `compile-blueprint`/`research-fanout`/`verify-fanout` en **un único digest** con `source_refs` al blueprint (para que el conductor reabra la fuente al desarrollar); no deciden ni escriben. Los workflows finos `explore-fanout`/`validate-live` devuelven las lentes en crudo.

**Política de modelos:** las lentes son trabajo de checklist con ámbito cerrado → `model: sonnet` explícito (59 agentes, incluidas las 7 `discovery-*`). El juicio caro de equivocarse hereda el modelo de la sesión (`model: inherit` → Fable): `orchestrator-flow` (conductor), `pantalla-reviewer` (veredicto contractual) y la familia `arch-*` (corre una vez por proyecto). `context-loader` va en `haiku`. Para cambiar una lente, edita su `model:` en `.claude/agents/<lente>.md`. Los workflows solo orquestan (no duplican la lógica).

**Cómo encaja en Claude Code:** main session = `orchestrator-flow` (vía `settings.json`); subagentes = aislados, devuelven solo su mensaje final; skills = inline (sin `context: fork`); workflows = fan-out paralelo (≤16 concurrentes); hooks = guardarraíles de sesión. **Nunca `claude -p` / headless / SDK** — esto es interactivo.

**Encadenado de skills (importante):** las 14 skills llevan `disable-model-invocation: true` a propósito — impide que el harness abra un segundo escritor por detrás del conductor. **No las hace inalcanzables.** Cuando una skill encadena a otra (`/next-pantalla` §5.5 → los dos auto-gates; `/accept` → `/verify-app` + `/audit-motores`; `/init-build` → `/discovery` + `/arch-review`; `/build-loop` → `/next-pantalla`; `/fix` → los gates), el conductor **lee el `SKILL.md` destino y ejecuta su protocolo inline en la misma sesión**, sustituyendo `$ARGUMENTS`. Nunca llama a la herramienta `Skill`. Que una skill no sea invocable por el modelo **jamás** es motivo para saltarse un gate, bloquear una unidad ni pedirte que teclees el comando.

---

## 6. CHEAT SHEET — cómo hacerlo funcionar

### Requisitos de entorno (léelo antes: el motor es real, pero descansa en estas precondiciones)

El núcleo —workflows + lentes + gate determinista— se ejecuta de verdad en Claude Code (verificado contra el binario y ejecutando los scripts). Pero **no es plug-and-play para un clon limpio** hasta que se cumple esto:

- **Claude Code ≥ v2.1.154** y **plan de pago** (Pro/Max/Team/Enterprise o API/Bedrock/Vertex). En **Free no existe la herramienta Workflow** y los 9 `.js` quedan inertes (el sistema degrada a `inline-fallback` secuencial con el mismo set de lentes: misma cobertura, más lento y más tokens).
- **En plan Pro:** activa **"Dynamic workflows"** a mano en `/config` (no viene por defecto).
- **`permissions.defaultMode: "auto"`** en tu config **personal** (`~/.claude/settings.json`) — no en la del proyecto (Claude Code la ignora ahí desde v2.1.142). Sin esto, el primer uso de cada workflow interrumpe pidiendo aprobación.
- **`python3`, `bash` y `node` en el PATH.** Claude Code no los provee. En **Windows nativo** los scripts `.sh` del gate necesitan **Git for Windows o WSL2** (PowerShell no los interpreta); `validate-state.py`/`lint-blueprint.py` son multiplataforma.
- **MCP de verificación viva:** `validate-web` usa Claude-in-Chrome (extensión, con permisos de sitio) o Chrome DevTools MCP; `validate-{android,ios,journey}` usan Dart MCP + emulador/simulador **ya arrancado**. Cada lente declara su `mcpServers` en el frontmatter (mecanismo oficial), pero las herramientas y runtimes hay que tenerlos instalados; una unidad backend/data no necesita ninguno.
- **git:** si el repo no es un repositorio git, `phase-push.sh` avisa y sigue (no-fatal) — pero pierdes el checkpoint por fase y la red bajo el debugger. `git init` + un commit inicial recomendado.

### Puesta en marcha (una vez)
1. Copia esta carpeta a tu proyecto y abre Claude Code **desde la raíz** (carga `orchestrator-flow` por `settings.json`).
   - `blueprint/DECISIONS.md` arranca **vacío** (solo su índice). No copies `DECISIONS-template.md` verbatim como decisión real: es un molde.
2. Rellena el blueprint usando los moldes de `blueprint-templates/`:
   - `blueprint/PRODUCT.md` (alcance, actores, reglas `BR-*`), `blueprint/SCREENS.md` (pantallas, orden, rutas, plataformas), `blueprint/logic/*.md` (las 14 capas: `DOM/APP/CORE/JOUR/PERM/ST/ERR/INT/UI/DATA/UC` + `shell.md` con el contrato cross-pantalla `UI-SHELL-*` + `engine.md` con los motores `ENG-*` + `pipeline.md` con los pipelines `PIPE-*`).
3. Comandos reales del stack: no hace falta `init.sh`. Deja `<COMMAND_*>` en `.claude/rules/stack.md`; `/init-build` los resuelve contigo (install/dev/test/migrate/seed/smoke/build) y el conductor los ejecuta cuando hace falta.
4. (Opcional) Mira `.orchestrator/examples/` para ver cómo queda un `features.json`/`result.json` "bueno".

### Ciclo de trabajo
```
/init-build            # blueprint → spec.md + features.json (lee TODO el blueprint en paralelo; pregunta CLARIFY si falta algo;
                       #   incluye DOS gates t=0: /discovery — el checklist universal, ¿qué quedó en el tintero? —
                       #   y /arch-review — ¿es CORRECTA la arquitectura? — ambos antes de compilar nada)
/status                # resumen de estado (solo lectura)
/next-pantalla         # construye y verifica la siguiente unidad ready (o pasa un ID); para en `verified` o `blocked`
                       #   piensa primero; si sigue sin saber algo pregunta (mejor agrupar en RESEARCH) y escribe la respuesta en blueprint/
                       #   tras CADA fase hace commit + push a origin/main (phase-push.sh, no-fatal)
/build-loop [max]      # bucle Ralph: encadena todas las unidades ready DE UNA EN UNA (cada una con su
                       #   /next-pantalla completo); para en el primer blocked o cuando no queda ready.
                       #   NUNCA acepta: produce una tanda de verified y tú las apruebas con /accept
/accept <ID>           # puerta humana: verified → accepted   (revisa la evidencia antes)
/reslice [motivo]      # reconcilia cambios de blueprint/design conservando historia y evidencia
/fix "<prompt>"        # mantenimiento: describe en texto libre un bug visto probando (o una mejora pequeña);
                       #   localiza la(s) pantalla(s) dueñas, carga contexto (blueprint citado + EXPLORE completo
                       #   sobre el código), repara y re-prueba TODO (VERIFY/VALIDATE/REVIEW con sets completos de
                       #   lentes) — de punta a punta en automático, parando solo en CLARIFY o blocked.
                       #   verified → reabre y cierra en verified (Next: /accept); accepted → repara in situ con
                       #   evidencia y source_manifest frescos; cambios de producto → blueprint + /reslice. NUNCA acepta
```

### Gates profundos — AUTOMÁTICOS (relanzables a mano)
```
/verify-pipelines-data-ultracode <ID>  # pipelines + datos + logs (motor de datos) en profundidad
/production-code-review <ID>           # producción: DRY/YAGNI/KISS, sin placeholders
```
> Ambos corren AUTOMÁTICAMENTE dentro de /next-pantalla tras el REVIEW (con --fix, lentes en Sonnet);
> aquí solo hace falta relanzarlos a mano si quieres repetirlos antes de /accept.

### Gate opcional manual
```
/review-pantalla <ID>                  # paridad UI/diseño/controles en vivo (pasada extra a demanda)
/discovery [--report-only]             # re-recorre el checklist universal a demanda (p. ej. tras ampliar
                                       # .orchestrator/templates/discovery-checklist.md); AUTO dentro de /init-build
```

### Gates cross (AUTOMÁTICOS al completar un journey con /accept; también a mano)
```
/audit-motores [ENG-ID|PIPE-ID|all]    # arquitectura de TODO el producto: cada motor implementado una vez y
                                       # fiel a su contrato, topología de pipelines, procedencia real de los
                                       # datos, acoplamiento entre módulos y perfil de escala. Estático.
/verify-app [JOUR-ID|all]              # recorre los journeys completos (todas sus pantallas accepted) en el
                                       # runtime real: navegación entre pantallas, mismo valor canónico en
                                       # todas las pantallas, shell coherente. Reporta y recomienda; NUNCA
                                       # mueve estados. El anti-Frankenstein de las costuras.
```
> Estas skills pueden escribir fixes y evidencia, pero **nunca** mueven a `accepted`. Si tocan un `verified`, su evidencia previa queda *stale* hasta re-VERIFY/re-VALIDATE.

### Scripts (los usa el conductor / tú; no las lentes)
```bash
python3 .orchestrator/scripts/validate-state.py        # STATE GATE: valida features.json + evidencia (verdict PASS real, same_value, artefactos, building<=1, checkpoint<=3, ...)
python3 .orchestrator/scripts/validate-state.py --emit-status  # + escribe status.json y evidence/index.json (contrato de lectura para dashboards/superficies externas)
python3 .orchestrator/scripts/lint-blueprint.py        # linter determinista del blueprint: IDs duplicados, referencias colgantes, ciclos, stubs (errores rompen; warnings → CLARIFY)
python3 .orchestrator/scripts/original-coverage.py     # reconcilia ORIGINAL.md contra las capas (--extract primero): qué dijo el humano que ninguna capa recoge → CLARIFY, nunca bloquea (lo corren /init-build y /reslice)
bash    .orchestrator/scripts/validate-structure.sh    # estructura del scaffold + referencias de lentes + sincronía de sets de lentes .js↔.py
bash    .orchestrator/scripts/reset-state.sh --force   # resetea SOLO .orchestrator-state/ a scaffold limpio
bash    .orchestrator/scripts/reset-test-data.sh "<FASE>"  # deja el almacén de PRUEBAS limpio antes de una fase que ejecuta la suite.
                                                       #   No sabe qué almacén es (AnyStack): delega en la clave COMMAND_RESET_TEST_DATA
                                                       #   declarada en .claude/rules/stack.md. Lo llama el CONDUCTOR, UNA vez, ANTES de
                                                       #   VERIFY/VALIDATE (y de cada re-corrida del debugger). Las lentes NO pueden llamarlo:
                                                       #   un reset a mitad de fase borra los datos que otra lente ya había probado. No fatal.
bash    .orchestrator/scripts/phase-push.sh "<FASE>" "<ID>"  # commit + push a origin/main tras cada fase (no-fatal sin git/remoto)
bash    .orchestrator/scripts/smoke-golden-path.sh     # smoke end-to-end con el golden path: prueba TODA la maquinaria determinista en positivo y negativo
```

### Qué esperar
- `/next-pantalla` **nunca** construye más de una unidad y **nunca** pasa a `accepted` solo.
- Si falta una decisión de producto a mitad de build → la unidad queda `blocked` con reproducción y siguiente acción exacta (las preguntas de producto se resuelven antes, en RESEARCH).
- La evidencia es real: acciones en runtime real, logs limpios, y el valor canónico coincide store→API→cliente.
