# Golden path — "Notas rápidas"

Un producto mínimo COMPLETO escrito como blueprint (web + SQLite: una pantalla que lista y crea notas persistidas), más el estado canónico que `/init-build` + `/next-pantalla` + `/accept` habrían producido para él. Sirve para dos cosas:

1. **Documentación viva**: así se ve un blueprint bueno (los 12 `logic/*.md` rellenos, foundations SCHEMA + SHELL, una pantalla UI con `data_engine` y contrato de valor único) y así se ve un estado bueno (`features.json` + `result.json` con `phase_runs` completos y aserciones de datos falsificables).
2. **Smoke test end-to-end**: `bash .orchestrator/scripts/smoke-golden-path.sh` copia el orquestador a un directorio temporal, monta este blueprint + estado, y comprueba TODA la maquinaria determinista — lint del blueprint, state gate, emisión de `status.json`/`evidence/index.json`, estructura + sincronía de lentes, hooks — en positivo Y en negativo (sets de lentes incompletos, evidencia prestada, deriva de valores entre capas, tope del debugger, doble building, artefactos ausentes, JSON corrupto).

> **Y `product/` también.** Los 9 ficheros bajo `product/` son stubs mínimos que existen para
> que `source_manifest` pueda citar ficheros de IMPLEMENTACIÓN con hash real —sin ellos el 100% del
> manifiesto serían rutas de blueprint y la rama que de verdad importa del guardián anti-rancio (la
> deriva de un fichero de implementación, que falla duro) no sería ejercitable—. Siguen el contrato
> del blueprint (`texto` 1..500, `NOTE_TEXT_INVALID`, `/api/v1`) para que el ejemplo sea coherente
> leído de punta a punta, pero **no son código de referencia**: son stubs de test.
>
> Un hueco deliberado: el `plan.md` de `SCR-FOUNDATION-SHELL` declara también `design/tokens.css`,
> y `product/` NO lo trae. Es a propósito — ese es el único path del fixture que colisionaría con
> un fichero real del propio repo al montarse, y los otros tres (`web/shell.{html,js,css}`) ya
> ejercitan la rama de deriva igual de bien. El fixture prefiere no pisar nada a ser exhaustivo.
>
> **Los artefactos de `state/evidence/` son FIXTURES de test etiquetados** (capturas/logs de ejemplo, no de una ejecución real): existen para probar que el gate hace cumplir sus reglas, igual que `.orchestrator/examples/result.example.json`. No son evidencia de producto y nunca deben copiarse a un proyecto real como si lo fueran.

## Ejecutar

```bash
bash .orchestrator/scripts/smoke-golden-path.sh
```

Salida esperada: todas las comprobaciones `PASS` y código de salida 0.
