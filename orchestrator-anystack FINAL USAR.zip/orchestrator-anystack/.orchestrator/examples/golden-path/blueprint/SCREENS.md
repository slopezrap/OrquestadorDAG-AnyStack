# SCREENS.md — Notas rápidas

## 0. Índice de pantallas y foundations

| Orden | ID | Tipo | Nombre | Plataforma | Ruta/deeplink | Depende de | Diseño | Estado |
|---:|---|---|---|---|---|---|---|---|
| 1 | SCR-FOUNDATION-SCHEMA | foundation | Esquema base | all | null | [] | null | ready |
| 2 | SCR-FOUNDATION-SHELL | foundation | Shell compartida | web | null | [SCR-FOUNDATION-SCHEMA] | design/screens/shell.html | ready |
| 10 | SCR-001 | ui | Mis notas | web | /notas | [SCR-FOUNDATION-SCHEMA, SCR-FOUNDATION-SHELL] | design/screens/notas.html | ready |

## 1. Foundations

### SCR-FOUNDATION-SCHEMA — Esquema base

```screen
id: SCR-FOUNDATION-SCHEMA
slug: schema
kind: foundation
platforms: [all]
route: null
order: 1
after: []
applies: [CORE-001]
design_ref: null
acceptance:
  - Cuando se ejecutan las migraciones desde cero, el sistema creará la tabla notas sin errores.
  - Cuando se consulta el esquema, el sistema expondrá la tabla notas con columnas id, texto y creada_en.
verify:
  tests:
    - "python3 -m pytest tests/test_schema.py"
  commands:
    - "python3 manage.py migrate"
  ui_states: []
  data_check:
    db_query: "SELECT name FROM sqlite_master WHERE type='table' AND name='notas'"
    expect: "La tabla notas existe con el esquema de DATA-001."
  evidence_required:
    - migration_log
    - test_output
```

### SCR-FOUNDATION-SHELL — Shell compartida y design system

```screen
id: SCR-FOUNDATION-SHELL
slug: shell
kind: foundation
platforms: [web]
route: null
order: 2
after: [SCR-FOUNDATION-SCHEMA]
applies: [UI-SHELL-001, UI-SHELL-002, UI-SHELL-003, UI-SHELL-004, UI-SHELL-005]
design_ref: "design/screens/shell.html"
acceptance:
  - Cuando se abre cualquier ruta, el sistema la renderizará dentro de la shell compartida (header con el título y navegación según UI-SHELL-001/002).
  - Cuando un componente declara color/tipografía/espaciado, el sistema consumirá tokens de design/tokens.css.
verify:
  tests:
    - "python3 -m pytest tests/test_shell.py"
  commands: []
  ui_states: [loading, success]
  data_check:
    db_query: null
    expect: "No aplica: la shell no renderiza datos de producto propios."
  evidence_required:
    - screenshot_or_recording
    - test_output
```

## 2. Pantallas UI

### SCR-001 — Mis notas

#### Qué construye

Lista de notas persistidas del usuario local, con creación de nota nueva y los cuatro estados visibles.

#### Actor principal

usuario-local

#### Entrada del usuario

- Desde: entrada de navegación "Notas" (UI-SHELL-002)
- Con datos previos: ninguno
- Estado inicial esperado: loading → empty (sin notas) o success (con notas)

#### Salida o resultado

- Persistencia esperada: nueva fila en la tabla notas
- Navegación siguiente: permanece en /notas con la lista actualizada
- Feedback visible: la nota nueva aparece en la lista; error recuperable si el texto es inválido

```screen
id: SCR-001
slug: notas
kind: ui
platforms: [web]
route:
  web: "/notas"
order: 10
after: [SCR-FOUNDATION-SCHEMA, SCR-FOUNDATION-SHELL]
applies: [BR-001, DOM-001, UC-001, APP-001, PERM-001, ST-001, ERR-001, UI-001, DATA-001, JOUR-001, UI-SHELL-002]
data_engine:
  engine_refs: [DATA-001, APP-001, UC-001, DOM-001, PERM-001]
  canonical_store:
    kind: database
    source_of_truth: database
    resources: ["notas"]
  pipeline:
    writes_to_canonical_store: true
    generation:
      required: true
      method: "api_write"
      no_frontend_fixtures: true
    write_path: ["APP-001", "repositorio", "notas"]
    read_path: ["database", "service/api", "frontend/web"]
  single_value_contract:
    - field: "texto_de_nota"
      db_source: "notas.texto"
      api_field: "$.data[0].texto"
      ui_field: "[data-testid=note-text]"
      invariant: "same value for the same user/tenant/permission context"
design_ref: "design/screens/notas.html"
acceptance:
  - "Cuando el usuario abre /notas, el sistema deberá mostrar un estado de carga mientras obtiene las notas reales."
  - "Cuando no existen notas, el sistema deberá mostrar un estado vacío con la acción de crear la primera nota."
  - "Cuando el usuario crea una nota con texto válido, el sistema deberá persistirla y mostrarla en la lista sin recargar."
  - "Si el texto es inválido (vacío o >500), el sistema deberá mostrar un error recuperable sin perder lo escrito."
  - "Cuando existen notas persistidas, el sistema deberá mostrar exactamente las notas de la tabla notas."
verify:
  test_level: e2e
  tests:
    - "python3 -m pytest tests/test_notas.py"
  commands:
    - "tail -n 50 logs/server.log"
    - "sqlite3 notas.db 'SELECT texto FROM notas ORDER BY id'"
  web:
    preferred_tools: [claude_chrome, chrome_devtools_mcp]
    required_evidence: [screenshot, console_log, network_log]
    viewports:
      - { name: desktop, width: 1440, height: 900 }
  ui_states: [loading, empty, error, success]
  data_check:
    engine_refs: [DATA-001, APP-001, UC-001]
    db_query: "SELECT texto FROM notas ORDER BY id DESC LIMIT 1"
    api_probe: "GET /api/v1/notas"
    visible_selector_or_finder: "[data-testid=note-text]"
    expect: "El texto visible coincide con la API y con la tabla notas."
  logs_check:
    frontend: "Sin errores de consola/runtime."
    backend: "Sin 5xx ni excepciones no controladas."
    database: "Sin violaciones de constraints."
  evidence_required:
    - result_json
    - screenshot_or_recording
    - test_output
    - db_check_output
```

## 3. Checklist antes de `/init-build`

- [x] Cada sección tiene un único `id` `SCR-*`.
- [x] `order` define una secuencia clara.
- [x] `after` solo referencia pantallas o foundations existentes.
- [x] `applies` solo referencia IDs existentes.
- [x] Cada pantalla con datos tiene `data_engine` y `data_check`.
- [x] Existe `SCR-FOUNDATION-SHELL` y toda pantalla UI lo lista en `after`.
