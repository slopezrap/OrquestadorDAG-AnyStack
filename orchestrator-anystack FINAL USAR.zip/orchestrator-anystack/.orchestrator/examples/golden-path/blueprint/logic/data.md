# Data Logic — motor de datos

## Reglas

### DATA-001 — Tabla notas

```logic
id: DATA-001
type: data_contract
status: ready
summary: "Tabla notas(id, texto, creada_en) en SQLite; se escribe solo vía APP-001; se lee solo vía API"
product_refs: [BR-001]
related_screens: [SCR-001]
depends_on: [DOM-001]
severity: must
canonical_store:
  source_of_truth: database
  resources: [notas]
pipeline:
  generation_method: "api_write"
  writes_to_database: true
  read_path: [database, service_api, frontend_web]
single_value_contract:
  - field: texto_de_nota
    db_source: notas.texto
    api_field: "$.data[0].texto"
    ui_field: "[data-testid=note-text]"
verification:
  observable_by: [db, api, ui]
  evidence: [db_query, api_response, screenshot]
```

**Regla:** esquema `notas(id INTEGER PRIMARY KEY AUTOINCREMENT, texto TEXT NOT NULL CHECK(length(texto) BETWEEN 1 AND 500), creada_en TEXT NOT NULL)`, creado por migración (SCR-FOUNDATION-SCHEMA). El dato se genera por escritura real de la API (`api_write`), nunca por fixtures del frontend. El valor de negocio `texto_de_nota` debe ser idéntico en tabla → API → UI.

**Verificable:** `SELECT texto FROM notas ORDER BY id DESC LIMIT 1` == `$.data[0].texto` de `GET /api/v1/notas` == texto visible en `[data-testid=note-text]`.
