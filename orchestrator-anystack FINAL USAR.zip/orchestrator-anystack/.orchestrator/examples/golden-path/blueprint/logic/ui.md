# UI Logic — comportamiento visible

## Reglas

### UI-001 — Pantalla de notas: estados y accesibilidad

```logic
id: UI-001
type: ui_rule
area: state
status: ready
summary: "Cuatro estados visibles con tokens del design system; formulario accesible por teclado"
product_refs: [BR-001]
related_screens: [SCR-001]
depends_on: [ST-001, ERR-001, DATA-001]
severity: must
platforms: [web]
verification:
  observable_by: [screenshot, e2e, accessibility, console]
  evidence: [screenshot, console_log]
```

**Regla:** la lista renderiza cada nota en un `NoteCard` (UI-SHELL-003) con el texto en `[data-testid=note-text]`. Estados: `loading` (skeleton), `empty` (mensaje + CTA "Crear tu primera nota"), `error` (mensaje de ERR-001 + retry, texto conservado), `success` (lista ordenada por más reciente). Accesibilidad: input con label, envío con Enter, foco visible, contraste vía tokens (`--color-fg` sobre `--color-bg`). Todos los valores visuales salen de `design/tokens.css`, nunca hardcodeados.

**Verificable:** captura de los cuatro estados; navegación completa con teclado; ningún literal de color/espaciado en el código de la pantalla.
