# Use Cases — casos de uso

## Reglas

### UC-001 — Crear una nota y verla

```logic
id: UC-001
type: use_case
status: ready
summary: "El usuario local escribe texto válido, lo envía y ve la nota persistida en la lista"
product_refs: [BR-001]
related_screens: [SCR-001]
depends_on: [APP-001, DOM-001, ST-001]
severity: must
verification:
  observable_by: [e2e, api, db]
  evidence: [flow_recording, api_response, db_query]
```

**Regla:** flujo principal: escribir texto (1..500) → enviar → APP-001 persiste → la lista pasa a `success` con la nota nueva primero. Alternativo: texto inválido → ERR-001 → el usuario corrige sin perder lo escrito.

**Verificable:** ejecutar el flujo completo en el runtime real con datos reales (la nota se crea de verdad por la API) y comprobar el mismo texto en las tres capas.
