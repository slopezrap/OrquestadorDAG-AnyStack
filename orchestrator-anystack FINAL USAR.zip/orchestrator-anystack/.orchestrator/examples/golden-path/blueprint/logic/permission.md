# Permission Logic — permisos

## Reglas

### PERM-001 — Acceso abierto local

```logic
id: PERM-001
type: permission
status: ready
summary: "App local de usuario único: acceso abierto sin credenciales, decidido explícitamente"
product_refs: [BR-001]
related_screens: [SCR-001]
depends_on: []
severity: must
verification:
  observable_by: [api, ui]
  evidence: [api_response, screenshot]
```

**Regla:** decisión de producto explícita (no un descuido): sin autenticación. `/notas` y `/api/v1/notas` son accesibles sin credenciales en el entorno local. Si el producto evoluciona a multiusuario, este ID se reabre vía `/reslice` antes de tocar nada.

**Verificable:** la ruta y la API responden sin cabeceras de autenticación; no existe ningún endpoint que exponga datos de otro contexto (solo hay uno).
