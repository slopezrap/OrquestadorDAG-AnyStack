# Pipeline Logic — pipelines que nutren el almacén canónico

## Reglas

### PIPE-001 — Escritura de nota por API

```logic
id: PIPE-001
type: pipeline
status: ready
summary: "La nota entra por acción real del usuario en la API y aterriza en la tabla notas; sin fixtures en ninguna capa"
product_refs: [BR-001]
feeds: []
writes: [DATA-001]
related_screens: [SCR-001]
depends_on: [APP-001, DOM-001]
severity: must
trigger:
  kind: on_write
  spec: "POST /api/v1/notas — acción real del usuario en la UI"
source: ["entrada de usuario validada por APP-001"]
transform: ["trim del texto", "sello creada_en en ISO-8601 UTC"]
sink:
  store: database
  resource: notas
guarantees:
  ordering: "id AUTOINCREMENT monotónico"
  delivery: exactly_once
  idempotency_key: "ninguna — cada POST es una nota nueva por diseño de producto (BR-001)"
backfill:
  supported: false
  procedure: "n/a — no hay histórico que reconstruir"
  replay_safe: false
retry:
  policy: "ninguno — escritura síncrona; el error se devuelve al cliente vía ERR-001"
  max_attempts: 1
  dead_letter: "n/a"
freshness:
  sla: "inmediata — la lectura posterior ve la fila"
  max_lag: "0s (misma transacción)"
  measured_by: "GET /api/v1/notas tras el POST"
scale:
  volume_profile: "bajo — escritura por acción humana"
  batch_size: 1
  concurrency: "SQLite en modo WAL, un escritor"
  breaks_at: "escrituras concurrentes sostenidas: SQLite serializa; migrar a un motor cliente/servidor antes de multi-tenant"
failure_runbook: "Si el POST falla, no hay fila parcial (transacción única). Revisar server-log.txt y devolver ERR-001 al cliente."
observability:
  run_log: "logs/server-log.txt"
  metrics: "n/a en este producto mínimo"
  how_to_prove_it_ran: "la fila existe en notas y el POST aparece en el log del servidor"
real_data:
  generation_method: api_write
  no_fixtures: true
  verification_path: "acción real en la UI -> POST /api/v1/notas -> SELECT en notas"
verification:
  observable_by: [db, api, ui, log]
  evidence: [db_query, api_response, screenshot, server_log]
```

**Regla:** el dato del producto se genera SIEMPRE por esta ruta real (`api_write`). Está prohibido sembrar la tabla con fixtures, JSON de demo o filas de ejemplo para cerrar la aceptación de `SCR-001`: el valor que se ve en pantalla tiene que haber entrado por aquí.

**Verificable:** `logs/pipeline-run.txt` muestra el POST real; `SELECT texto FROM notas ORDER BY id DESC LIMIT 1` devuelve el valor recién escrito; y ese mismo literal aparece en la API y en la UI (contrato de valor único de DATA-001).
