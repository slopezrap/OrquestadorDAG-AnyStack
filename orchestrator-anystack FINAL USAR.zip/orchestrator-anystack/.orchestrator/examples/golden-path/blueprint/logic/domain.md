# Domain Logic — entidades e invariantes

## Reglas

### DOM-001 — Entidad Nota

```logic
id: DOM-001
type: entity
status: ready
summary: "Nota {id, texto, creada_en}; el texto es obligatorio y de 1 a 500 caracteres"
product_refs: [BR-001]
related_screens: [SCR-001]
depends_on: []
severity: must
verification:
  observable_by: [unit_test, db]
  evidence: [test_output, db_query]
```

**Regla:** una Nota tiene `id` (autogenerado), `texto` (obligatorio, 1..500 caracteres tras trim) y `creada_en` (timestamp del servidor). El invariante de longitud se valida en el dominio, no solo en la UI.

**Verificable:** test unitario que rechaza texto vacío y de 501 caracteres; `SELECT` que confirma que ninguna fila viola el invariante.
