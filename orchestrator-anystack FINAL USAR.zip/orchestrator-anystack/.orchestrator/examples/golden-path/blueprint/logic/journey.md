# Journey Logic — recorridos

## Reglas

### JOUR-001 — Crear y ver una nota

```logic
id: JOUR-001
type: journey
status: ready
summary: "Abrir /notas → ver estado vacío → crear nota → verla en la lista persistida"
product_refs: [BR-001]
related_screens: [SCR-001]
depends_on: [UC-001, UI-SHELL-002]
severity: must
verification:
  observable_by: [e2e]
  evidence: [flow_recording, screenshot]
```

**Regla:** el recorrido completo del usuario local: entra por la navegación "Notas" (UI-SHELL-002), ve el estado vacío si no hay notas, crea una nota válida y la ve en la lista; tras refrescar, la nota sigue ahí (BR-001).

**Verificable:** recorrido real en navegador de principio a fin, con la persistencia comprobada tras refresco. Es el journey que `/verify-app` recorre cuando SCR-001 está aceptada.
