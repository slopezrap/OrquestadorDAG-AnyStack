# Application Logic — casos de escritura

## Reglas

### APP-001 — Crear nota

```logic
id: APP-001
type: use_case_write
status: ready
summary: "Crear nota: valida DOM-001, persiste en la tabla notas y devuelve la nota creada"
product_refs: [BR-001]
related_screens: [SCR-001]
depends_on: [DOM-001, DATA-001, ERR-001]
severity: must
verification:
  observable_by: [api, db]
  evidence: [api_response, db_query, server_log]
```

**Regla:** `POST /api/v1/notas {texto}` valida el invariante de DOM-001; si es válido persiste la fila en `notas` y responde `201 {data: {id, texto, creada_en}}`; si no, responde `422` con el error estructurado de ERR-001 y sin efectos parciales.

**Verificable:** petición real con texto válido → fila nueva en la tabla y respuesta con el mismo texto; petición con texto vacío → 422 y `COUNT(*)` sin cambios.
