# State Logic — estados y transiciones

## Reglas

### ST-001 — Estados de la pantalla de notas

```logic
id: ST-001
type: state_machine
status: ready
summary: "loading → empty | success; crear → success actualizado; fallo → error recuperable → retry"
product_refs: [BR-001]
related_screens: [SCR-001]
depends_on: [ERR-001]
severity: must
verification:
  observable_by: [e2e, screenshot]
  evidence: [screenshot, flow_recording]
```

**Regla:** transiciones legales: `loading → empty` (0 notas), `loading → success` (≥1), `success/empty → success` (tras crear), `cualquiera → error → (retry) → loading`. Ilegal: mostrar `success` sin datos reales cargados, o perder el texto escrito al pasar a `error`.

**Verificable:** recorrer las cuatro pantallas de estado en el navegador real y capturarlas; provocar el fallo (texto inválido) y comprobar la recuperación con el texto conservado.
