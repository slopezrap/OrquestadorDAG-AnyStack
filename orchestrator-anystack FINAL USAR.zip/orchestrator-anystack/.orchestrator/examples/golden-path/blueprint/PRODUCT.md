# PRODUCT.md — Notas rápidas

## 1. Qué es

Aplicación web mínima de notas personales para un único usuario local. El usuario abre `/notas`, ve sus notas persistidas y crea notas nuevas. Sin cuentas, sin colaboración, sin integraciones externas.

## 2. Actores

| Actor | Descripción | Permisos |
|---|---|---|
| usuario-local | Única persona que usa la app en su máquina | PERM-001 (acceso abierto local) |

## 3. Alcance

- En alcance: listar notas persistidas, crear nota, estados loading/empty/error/success.
- Fuera de alcance: editar/borrar notas, autenticación, multiusuario, móvil.

## 4. Reglas de negocio

### BR-001 — Toda nota persiste

```logic
id: BR-001
status: ready
summary: "Toda nota creada se persiste en el almacén canónico y sobrevive a un refresco"
related_screens: [SCR-001]
depends_on: [DATA-001, APP-001]
severity: must
verification:
  observable_by: [db, api, ui]
  evidence: [db_query, api_response, screenshot]
```

**Regla:** una nota creada existe en la tabla `notas` (almacén canónico), la devuelve la API y la muestra la UI con el mismo texto. Nada vive solo en memoria del cliente.

**Verificable:** crear una nota, refrescar la página: la nota sigue visible y su texto coincide con `SELECT texto FROM notas` y con la respuesta de la API.

## 5. Checklist

- [x] Las reglas `BR-*` son observables.
- [x] Cada actor tiene permisos declarados.
- [x] El alcance excluye explícitamente lo que no se construye.
