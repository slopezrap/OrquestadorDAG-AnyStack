# spec.md — Notas rápidas (golden path)

Vista consolidada de ejemplo. Producto: app web de notas (SQLite canónico → API Flask /api/v1 → web). Unidades: SCHEMA (accepted) → SHELL (accepted) → SCR-001 /notas (verified). Arquitectura: relational. Journey JOUR-001 cubre SCR-001.
