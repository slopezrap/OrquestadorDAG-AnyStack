# pipelines-data-ultracode — SCR-001

> Test fixture (labeled), not a real run. Shows the shape of a passing §5.5 pipelines/data gate.

## Scope
SCR-001

## Layers checked
| Layer | Observed | Result |
|---|---|---|
| canonical store | value persisted in notas | ok |
| API/read-model | same literal on the wire | ok |
| client | same literal visible | ok |

## Verdict
PASS
