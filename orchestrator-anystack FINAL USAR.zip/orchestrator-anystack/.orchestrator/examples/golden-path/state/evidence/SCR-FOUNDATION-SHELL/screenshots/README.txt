[FIXTURE golden-path - artefactos de ejemplo para probar el gate, no evidencia real]

shell-success.png es un PNG real minimo (16x16, generado con la stdlib de python3), no una captura
de una ejecucion real. Lleva la misma etiqueta dentro del propio fichero, en un chunk
tEXt/Comment:

  captura de la shell: header 'Notas rapidas' + nav 'Notas' + main

Es un PNG de verdad a proposito: un .txt renombrado a .png satisface el suelo de
evidencia web del gate por la RUTA, y este directorio no debe ensenar ese atajo.
Nunca copies estos ficheros a un proyecto real como si fueran evidencia.
