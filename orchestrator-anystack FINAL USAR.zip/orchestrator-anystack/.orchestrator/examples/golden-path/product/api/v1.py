"""FIXTURE del golden path — stub minimo. Existe para que source_manifest cite ficheros de IMPLEMENTACION reales con hash real, que es lo que este ejemplo debe ilustrar. Sigue el contrato del blueprint (DATA-001, DOM-001, ERR-001), no es codigo de produccion.

UI-SHELL-004: la API es espejo bajo /api/v1. ERR-001: sobre {error:{code,message}}.
DATA-001: $.data[0].texto es el mismo literal que notas.texto.
"""
from app.notas import crear_nota, listar_notas
from domain.nota import NotaInvalida


def post_notas(request, store):
    try:
        nota = crear_nota(store, request.json.get("texto", ""))
    except NotaInvalida as e:
        return {"error": {"code": e.code, "message": str(e)}}, 422
    return {"data": [{"id": nota.id, "texto": nota.texto, "creada_en": nota.creada_en}]}, 201


def get_notas(store):
    return {"data": [{"id": n.id, "texto": n.texto, "creada_en": n.creada_en}
                     for n in listar_notas(store)]}, 200
