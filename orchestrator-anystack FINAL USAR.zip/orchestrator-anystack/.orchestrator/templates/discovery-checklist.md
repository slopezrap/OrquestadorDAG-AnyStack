# Discovery checklist

checklist_version: 1

The universal intake for the `/discovery` gate (t=0, inside `/init-build` before COMPILE). Every item below MUST receive exactly ONE disposition in every run — nothing is silently skipped, including the `[if applies]` items (those close as `n/a` with a concrete reason when they do not apply):

- `answered` — the blueprint/ORIGINAL/DECISIONS already answers it (cite where; never re-ask).
- `propose_fill` — derivable or has a sane default; the lens proposes exact text, `orchestrator-flow` writes it.
- `ask` — a genuine product decision; one precise question with a recommended option.
- `n/a` — does not apply to this product, with a concrete reason.

`deferred` exists only as a HUMAN answer during the CLARIFY round ("decide later"); the conductor records it as an open `DEC-*`.

Each item names its write-back target after `→`. Edit this file to grow the checklist; the lenses read their own section, and `discovery-synthesizer` uses the full ID list to prove no item was dropped.

## discovery-product

- Q-PROD-01 — What problem does the product solve, for whom, and what observable result does it deliver? → `blueprint/PRODUCT.md`
- Q-PROD-02 — What differentiates it from doing the task by hand or with a generic tool? → `blueprint/PRODUCT.md`
- Q-PROD-03 — What is inside the first acceptable version (v1) and what is EXPLICITLY out? → `blueprint/PRODUCT.md`
- Q-PROD-04 — How is v1 success measured? (1-3 observable metrics) → `blueprint/PRODUCT.md`
- Q-PROD-05 — Which assumptions are being taken as true? (listed so they can be invalidated) → `blueprint/PRODUCT.md` + `blueprint/DECISIONS.md`
- Q-PROD-06 — What is the AI's role in the product: what it does, where it decides vs assists, and what it must NEVER do? → `blueprint/PRODUCT.md` (`BR-*`)
- Q-PROD-07 — Who are the actors and what does each one want to achieve? → `blueprint/PRODUCT.md`
- Q-PROD-08 — What operational roles exist and what can/can't each do? → `blueprint/logic/permission.md` (`PERM-*`)
- Q-PROD-09 — Are there sensitive actions that demand an extra permission or re-verification? → `blueprint/logic/permission.md`
- Q-PROD-10 — Are app access and identity separated so actions/data are attributable to a person? → `blueprint/logic/permission.md` + `blueprint/PRODUCT.md`
- Q-PROD-11 — What order guides the build — dependencies or value — and what human flow drives the screen order? → `blueprint/SCREENS.md` + `blueprint/logic/journey.md`
- Q-PROD-12 — [if applies] Does the app MOVE money or only record/calculate it? Billing provider, tax compliance, evidence per charge; never execute a payment without an explicit user action. → `blueprint/PRODUCT.md` (`BR-*`) + `blueprint/logic/integration.md`
- Q-PROD-13 — [if applies] Which regulation applies to the domain? Privacy (GDPR: minimization, consent, PII) and AI-use restrictions (transparency, automated decisions). → `blueprint/PRODUCT.md` + `blueprint/logic/data.md`

## discovery-data

- Q-DATA-01 — Where does the data come from? (own source, external integration, user input, generated) → `blueprint/logic/data.md` + `blueprint/logic/pipeline.md`
- Q-DATA-02 — Does the app read, write or both against that source, and which system is the source of truth? → `blueprint/logic/data.md` (`DATA-*`)
- Q-DATA-03 — Real-time, periodic batch/sync, or on-demand? → `blueprint/logic/pipeline.md` (`PIPE-*`)
- Q-DATA-04 — How is development done without the real source — seed/simulated data AND the real generation path that replaces it? → `blueprint/logic/pipeline.md` + `blueprint/logic/data.md`
- Q-DATA-05 — What data must exist before anything can be asserted with confidence? (the "ready" gate) → `blueprint/logic/data.md`
- Q-DATA-06 — What is the source of truth after EACH write? → `blueprint/logic/data.md`
- Q-DATA-07 — Event sourcing: none, full, or selective (only the critical-auditable part)? → `blueprint/logic/data.md` + `blueprint/logic/state.md` + `DEC-*`
- Q-DATA-08 — What is stored as state/snapshot and what as events? → `blueprint/logic/data.md` + `blueprint/logic/state.md`
- Q-DATA-09 — Are there read models / cache for fast read paths (CQRS-lite)? → `blueprint/logic/data.md` + `blueprint/logic/pipeline.md`
- Q-DATA-10 — Retention, PII, export and deletion of data. → `blueprint/logic/data.md`
- Q-DATA-11 — Which actions must be reconstructible/traceable (who did what, when, with which data)? → `blueprint/logic/data.md` + `blueprint/logic/state.md`
- Q-DATA-12 — [if applies] Immutable record for the sensitive part; how is it proven in an audit? → `blueprint/logic/data.md`

## discovery-architecture

- Q-ARCH-01 — Architectural style: modular monolith, hexagonal (ports/adapters), microservices? → `blueprint/logic/core.md` + `blueprint/logic/engine.md` + `DEC-*`
- Q-ARCH-02 — What is core (own rules) and what is periphery (frameworks, providers)? → `blueprint/logic/core.md` + `blueprint/logic/engine.md` (`ENG-*`)
- Q-ARCH-03 — How is the external world isolated (integrations, providers) so it can change without touching the domain? → `blueprint/logic/integration.md` (`INT-*`)
- Q-ARCH-04 — Are identity and permissions resolved server-side, never trusting the client? → `blueprint/logic/permission.md`
- Q-ARCH-05 — [if applies] Per integration: input/output contract, timeout and retry policy. → `blueprint/logic/integration.md`
- Q-ARCH-06 — [if applies] Idempotency for retries/webhooks; signature verification on webhooks. → `blueprint/logic/integration.md`
- Q-ARCH-07 — [if applies] Fallback when a provider fails; does it degrade safely? → `blueprint/logic/integration.md` + `blueprint/logic/error.md`
- Q-ARCH-08 — Which state machines exist and which transitions are allowed (and forbidden)? → `blueprint/logic/state.md` (`ST-*`)
- Q-ARCH-09 — Error taxonomy (validation, permission, not-found, conflict, network, server, integration) with visible message, recovery path and expected logging per class. → `blueprint/logic/error.md` (`ERR-*`)
- Q-ARCH-10 — How does it fail safely — no partial data left behind, no invented information? → `blueprint/logic/error.md` + `blueprint/logic/data.md`

## discovery-stack

- Q-STACK-01 — Frontend framework. → `.claude/rules/stack.md`
- Q-STACK-02 — Backend framework / runtime. → `.claude/rules/stack.md`
- Q-STACK-03 — Canonical store technology (DB, event store, state store, ledger, external system, file store). → `.claude/rules/stack.md` + `blueprint/logic/data.md`
- Q-STACK-04 — Cache and/or queue. → `.claude/rules/stack.md`
- Q-STACK-05 — Auth method (user/password, OIDC/SSO, passkeys) and account creation (open signup, invitation, provisioning). → `.claude/rules/stack.md` + `blueprint/logic/permission.md`
- Q-STACK-06 — MFA in v1 or later; re-authentication for sensitive actions. → `blueprint/logic/permission.md`
- Q-STACK-07 — Secrets management, credential hashing, secure sessions (cookies). → `.claude/rules/stack.md` + `blueprint/logic/integration.md`
- Q-STACK-08 — Rate-limiting and lockout; messages that leak nothing (anti-enumeration). → `blueprint/logic/error.md` + `blueprint/logic/permission.md`
- Q-STACK-09 — [if applies] AI gateway: provider/model for v1, ONE gateway, key in `.env`. → `.claude/rules/stack.md` + `blueprint/logic/integration.md` (`INT-*`)
- Q-STACK-10 — [if applies] AI portability: swap model/provider without rewriting. → `blueprint/logic/integration.md`
- Q-STACK-11 — [if applies] Where AI IS and IS NOT used (e.g. never on the critical/latency path). → `blueprint/PRODUCT.md` + `blueprint/logic/engine.md`
- Q-STACK-12 — [if applies] AI anti-fabrication: numbers come from queries/tools, never the model; evidence cited per answer; usage (cost/latency) logged. → `blueprint/logic/engine.md` + `blueprint/logic/pipeline.md`
- Q-STACK-13 — Version policy: "latest" or stable versions pinned in lockfiles? → `.claude/rules/stack.md`
- Q-STACK-14 — Build vs buy for solved concerns (auth, payments, search): custom or an existing library/service? → `.claude/rules/stack.md` + `DEC-*`

## discovery-infra

- Q-INFRA-01 — Where does it run per phase? (pilot: local/containers; future production target) → `.claude/rules/stack.md` (Deployment & infra)
- Q-INFRA-02 — Multi-tenant or instance per client? How is each tenant isolated? → `.claude/rules/stack.md` + `blueprint/logic/data.md` + `blueprint/logic/permission.md`
- Q-INFRA-03 — [if applies] Object/file storage. → `.claude/rules/stack.md`
- Q-INFRA-04 — [if applies] Job queue / workers. → `.claude/rules/stack.md`
- Q-INFRA-05 — Backups AND a restore test. → `.claude/rules/stack.md`
- Q-INFRA-06 — Who operates the infrastructure? Does the client touch it or is it abstracted/billed through? → `.claude/rules/stack.md` + `DEC-*`
- Q-INFRA-07 — Observability: where do logs/metrics/alerts go? → `.claude/rules/stack.md`
- Q-INFRA-08 — Environments (dev/staging/prod) and the promotion path between them. → `.claude/rules/stack.md`
- Q-INFRA-09 — [if applies] Latency target / SLO and expected load. → `.claude/rules/stack.md` + `blueprint/PRODUCT.md`
- Q-INFRA-10 — [if applies] Cost budget (infra + AI per operation). → `.claude/rules/stack.md` + `blueprint/DECISIONS.md`

## discovery-ux

- Q-UX-01 — Design tokens: palette, typography, where the visual identity comes from. → `design/tokens.css`
- Q-UX-02 — Tone and microcopy: what to say and what never to say. → `blueprint/logic/ui.md` (`UI-*`)
- Q-UX-03 — Mandatory states per screen: loading, empty, error, and [if applies] offline/stale data. → `blueprint/logic/ui.md` + `blueprint/logic/shell.md`
- Q-UX-04 — Navigation/shell: layout, navigation map, route convention. → `blueprint/logic/shell.md` (`UI-SHELL-*`)
- Q-UX-05 — Responsive (breakpoints) and accessibility (keyboard, contrast, screen readers). → `blueprint/logic/ui.md` + `blueprint/logic/shell.md`
- Q-UX-06 — The UI never invents data; it renders what the real backend returns. → covered-by-orchestrator (constitution "Data engine authority") unless the blueprint deviates
- Q-UX-07 — Language(s) and i18n scope. → `blueprint/logic/ui.md` + `blueprint/PRODUCT.md`
- Q-UX-08 — Does every screen/use case have observable acceptance criteria? → `blueprint/SCREENS.md`
- Q-UX-09 — What evidence counts as "done" (screenshots, logs, test output)? → covered-by-orchestrator (constitution "Evidence standard") unless the blueprint adds domain-specific proof
- Q-UX-10 — Test expectations: unit (rules), integration (real data), non-regression of critical rules. → covered-by-orchestrator + `.claude/rules/stack.md` (test commands)
