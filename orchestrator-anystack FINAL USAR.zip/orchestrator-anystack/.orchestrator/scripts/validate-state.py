#!/usr/bin/env python3
"""Validate .orchestrator-state without third-party dependencies.

This script is the AUTHORITATIVE enforcement layer for orchestrator state.
The JSON Schemas under .orchestrator/schemas/ are illustrative shape docs; the
checks below are what actually gate verified/accepted. If the two ever disagree,
this file wins (see the root README.md).
"""
from __future__ import annotations

import hashlib
import json
import re
import os
import sys
import tempfile
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

ROOT = Path.cwd()
ORQ = ROOT / ".orchestrator"
STATE = ROOT / ".orchestrator-state"
AGENTS = ROOT / ".claude" / "agents"
BLUEPRINT = ROOT / "blueprint"
FEATURES = STATE / "features.json"
VALID_STATUS = {"todo", "ready", "building", "verified", "accepted", "blocked", "deprecated"}
# A dependency is "built" once it holds real PASS evidence. That is enough to BUILD on top of it
# (so /build-loop can chain a whole product), but never enough to ACCEPT past it: acceptance
# still walks the after[] order, one human /accept at a time.
BUILT_STATUS = {"verified", "accepted"}
PASS_STATUSES = {"verified", "accepted"}
MOBILE_PLATFORMS = {"android", "ios", "mobile"}

# AnyStack: the canonical store is whatever the blueprint declares (relational DB,
# event store, ledger, external system of record, file store, read model, ...).
# The only hard rule is that the source of truth is NOT a client/frontend layer.
CLIENT_LAYERS = {
    "frontend", "front-end", "ui", "client", "clients", "web", "mobile", "android",
    "ios", "desktop", "cli", "tui", "browser", "localstorage", "local_storage",
    "local-storage", "fixture", "fixtures", "in-memory", "memory",
}
# Tokens that indicate a transport / read layer between the store and the client.
TRANSPORT_TOKENS = (
    "api", "service", "read", "read_model", "read-model", "rpc", "grpc", "graphql",
    "gateway", "query", "endpoint", "resolver",
)
# Observed-value key aliases per layer, so assertions are stack-neutral.
CANONICAL_VALUE_KEYS = ("db_value", "source_value", "store_value", "canonical_value", "record_value")
TRANSPORT_VALUE_KEYS = ("api_value", "service_value", "transport_value", "read_model_value", "response_value")
CLIENT_VALUE_KEYS = ("ui_value", "client_value", "visible_value", "mobile_value")

# Mandatory workflow cycle. The constitution makes launching each fan-out phase
# with its FULL lens set non-negotiable; the phase-coverage check below turns that
# from prose into a gate so a PASS cannot skip EXPLORE/VERIFY/VALIDATE or hand-pick
# a subset of lenses. inline-fallback is allowed but must carry the SAME full set.
RESEARCH_LENSES = {
    "research-domain", "research-application", "research-core", "research-journey",
    "research-permission", "research-state", "research-error", "research-integration",
    "research-ui", "research-shell", "research-data", "research-usecases",
    "research-engine", "research-pipeline",
    "research-product", "research-screens", "research-design",
}
EXPLORE_LENSES = {
    "explore-scout", "explore-data", "explore-backend", "explore-ui",
    "explore-existing", "explore-tests", "explore-engine", "explore-pipeline",
    "explore-config",
}
VERIFY_LENSES = {
    "verify-tests", "verify-conformance", "verify-design", "verify-frontend",
    "verify-engine", "verify-pipeline", "verify-logs", "verify-quality",
    "verify-coherence", "verify-blueprint-drift",
}
UI_PLATFORM_VALIDATORS = {"web": "validate-web", "android": "validate-android", "ios": "validate-ios"}
# VALIDATE stopped being UI-only: a unit that declares an engine/pipeline contract must prove it
# RAN for real, exactly as a UI unit must prove its screen was driven for real. Without this a
# rules/compute/agent engine would reach `verified` on static verification alone.
ENGINE_VALIDATORS = {"engine": "validate-engine", "pipeline": "validate-pipeline"}
# /arch-review: the t=0 architecture gate. Its lens set is deliberately NOT part of the
# required phase_runs[] sets — it audits the DESIGN before features.json exists, so wiring
# it into per-unit evidence would retroactively invalidate every verified unit.
ARCH_LENSES = {
    "arch-fit", "arch-data-model", "arch-identity", "arch-engines",
    "arch-pipelines", "arch-risk",
}
ARCH_REVIEW_STATUSES = {"clear", "accepted_with_risk", "deferred"}
# /discovery: the universal-intake gate at t=0 (before COMPILE). Like the arch lenses, its
# set is deliberately NOT part of the required phase_runs[] sets — it gates the project's
# birth (--init-gate), never a unit's evidence.
DISCOVERY_LENSES = {
    "discovery-product", "discovery-data", "discovery-architecture",
    "discovery-stack", "discovery-infra", "discovery-ux",
}
DISCOVERY_DISPOSITIONS = ("answered", "filled", "asked", "na", "deferred")
# The subset of the blueprint the arch lenses actually judge; /reslice re-triggers the
# gate when the hash over these files drifts from meta.architecture_review.architecture_hash.
ARCH_HASH_FILES = (
    "blueprint/PRODUCT.md", "blueprint/logic/data.md", "blueprint/logic/engine.md",
    "blueprint/logic/pipeline.md", "blueprint/logic/integration.md",
    "blueprint/logic/permission.md", "blueprint/logic/state.md",
    "blueprint/logic/core.md", "blueprint/logic/shell.md",
)
FANOUT_MODES = {"workflow", "inline-fallback"}


def fail(message: str) -> None:
    print(f"state invalid: {message}", file=sys.stderr)
    raise SystemExit(1)


def load_json(path: Path) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError:
        fail(f"missing {path}")
    except json.JSONDecodeError as exc:
        fail(f"invalid JSON {path}: {exc}")


def schema_name(obj: dict[str, Any]) -> str | None:
    return obj.get("schema_version") or obj.get("schema")


def _norm(value: Any) -> str | None:
    """Normalize an observed cross-layer value for equality comparison."""
    if value is None:
        return None
    return str(value).strip()


_ID_IN_BLOCK = re.compile(r"^\s*id:\s*([A-Z][A-Z0-9-]*)\s*$", re.M)
_ID_IN_HEADING = re.compile(r"^#{2,4}\s+([A-Z][A-Z0-9-]*)\b", re.M)
REF_PREFIXES = ("BR-", "SCR-", "DOM-", "APP-", "CORE-", "JOUR-", "PERM-", "ST-",
                "ERR-", "INT-", "UI-", "DATA-", "UC-", "ENG-", "PIPE-")


def _blueprint_ids() -> set[str]:
    """Every ID the blueprint actually defines. Used to reject a plan that cites rules
    nobody wrote: traceability was prose until now — `applies: ["DATA-999"]` passed both
    the gate and the linter, and an ID-only reference is exactly what agents are told
    is NOT enough intent."""
    ids: set[str] = set()
    if not BLUEPRINT.is_dir():
        return ids
    for path in sorted(BLUEPRINT.rglob("*.md")):
        text = path.read_text(encoding="utf-8", errors="replace")
        ids |= set(_ID_IN_BLOCK.findall(text))
        ids |= set(_ID_IN_HEADING.findall(text))
    return ids


def _has_client_token(value: Any) -> bool:
    """True when any WORD of `value` names a client layer.

    Segmenting matters: the old check compared the whole string against CLIENT_LAYERS,
    so `source_of_truth: "UI store"` or `"browser localStorage"` sailed through and a
    frontend became the system of record — the one invariant the constitution calls
    non-negotiable."""
    parts = {p for p in re.split(r"[^a-z0-9]+", str(value).strip().lower()) if p}
    return bool(parts & CLIENT_LAYERS)


def _is_ui_surface(screen: dict[str, Any]) -> bool:
    """A screen owns a UI surface (and must therefore declare platforms[]) when any
    independent signal says so: kind 'ui', a UI primary_verifier, or a non-null client
    route. This catches a UI screen left with empty platforms — which would otherwise
    make the gate silently treat it as backend-only and skip the whole VALIDATE phase."""
    if str(screen.get("kind", "")).strip().lower() == "ui":
        return True
    verify = screen.get("verify")
    if isinstance(verify, dict):
        if str(verify.get("primary_verifier", "")).strip().lower() in {
            "validate-web", "validate-android", "validate-ios"
        }:
            return True
    route = screen.get("route")
    if isinstance(route, dict):
        if any(route.get(plat) for plat in ("web", "android", "ios")):
            return True
    return False


def _declared_engine_kinds(screen: dict[str, Any]) -> set[str]:
    """Which live engine validators a unit owes, derived from the contracts it cites.

    The engine/pipeline layers are optional per product: a unit that cites no ENG-*/PIPE-*
    owes nothing. But a unit that DOES cite one owes live proof it ran — there is no
    not_applicable escape once a contract is cited, mirroring how data_engine's escape is
    only legal when the unit cites no DATA-* at all. Otherwise an engine could reach
    `verified` on static verification alone, which is exactly the hole this closes."""
    refs: list[str] = []
    for key in ("applies", "engine_refs", "pipeline_refs"):
        value = screen.get(key)
        if isinstance(value, list):
            refs += [str(item) for item in value]
    data_engine = screen.get("data_engine")
    if isinstance(data_engine, dict):
        for key in ("engine_refs", "pipeline_refs"):
            value = data_engine.get(key)
            if isinstance(value, list):
                refs += [str(item) for item in value]
    kinds: set[str] = set()
    for ref in refs:
        token = ref.strip().upper()
        if token.startswith("ENG-"):
            kinds.add("engine")
        elif token.startswith("PIPE-"):
            kinds.add("pipeline")
    return kinds


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    digest.update(path.read_bytes())
    return digest.hexdigest()


def _collect_artifact_paths(result: dict[str, Any]) -> set[str]:
    paths: set[str] = set()
    for artifact in result.get("artifacts", []):
        if isinstance(artifact, dict) and isinstance(artifact.get("path"), str):
            paths.add(artifact["path"])
        elif isinstance(artifact, str):
            paths.add(artifact)
    for check in result.get("checks", []):
        if isinstance(check, dict):
            for artifact in check.get("artifacts", []):
                if isinstance(artifact, str):
                    paths.add(artifact)
    return paths


def validate_source_manifest(result: dict[str, Any], path: Path) -> None:
    """Stale-PASS guard. If result.json declares a source_manifest, every listed
    file must still exist and (when a hash is given) still hash the same. This
    converts the constitution's 'evidence is stale after a fix' rule from policy
    into a mechanical check. Absent manifest stays backward compatible."""
    if result.get("verdict") != "PASS":
        return
    manifest = result.get("source_manifest")
    if manifest is None:
        return
    if not isinstance(manifest, list):
        fail(f"{path}.source_manifest must be array")
    for entry in manifest:
        if not isinstance(entry, dict):
            fail(f"{path}.source_manifest entries must be objects")
        rel = entry.get("path")
        if not isinstance(rel, str) or not rel:
            fail(f"{path}.source_manifest entry missing path")
        if "<" in rel or ">" in rel:
            fail(f"{path}.source_manifest has unresolved placeholder path: {rel}")
        fp = ROOT / rel
        if not fp.is_file():
            fail(f"{path}.source_manifest references missing or non-file source file: {rel}")
        digest = entry.get("sha256")
        if isinstance(digest, str) and digest:
            want = digest.split(":")[-1].strip().lower()
            actual = _sha256(fp).lower()
            if actual != want:
                fail(
                    f"{path}.source_manifest stale: {rel} changed since evidence "
                    f"was produced (expected {want[:12]}, got {actual[:12]}); re-verify"
                )


def validate_result(
    path: Path,
    feature_ids: set[str] | None = None,
    require_artifacts: bool = False,
    screen: dict[str, Any] | None = None,
) -> dict[str, Any]:
    result = load_json(path)
    if not isinstance(result, dict):
        fail(f"{path} root must be object")
    if schema_name(result) != "orchestrator.result.v1":
        fail(f"{path} schema_version must be orchestrator.result.v1")
    required = [
        "screen_id", "screen_title", "run_id", "attempt", "generated_at", "verdict",
        "verifier", "environment", "checks", "artifacts", "data_assertions",
        "data_engine_assertions", "logs", "failures", "summary",
    ]
    for key in required:
        if key not in result:
            fail(f"{path} missing {key}")
    sid = result["screen_id"]
    if feature_ids and sid not in feature_ids and not str(sid).startswith("SCR-TEMPLATE"):
        fail(f"{path} references unknown screen_id {sid}")
    # Evidence is bound to its owning screen by CONTENT, not just by path: a PASS
    # result.json copied/moved from another screen's evidence dir must not validate.
    if screen is not None and sid != screen.get("id"):
        fail(f"{path} screen_id {sid} does not match the screen that owns this "
             f"evidence_path ({screen.get('id')}); evidence cannot be borrowed across screens")
    if result["verdict"] not in {"PASS", "FAIL", "BLOCKED"}:
        fail(f"{path} verdict invalid")
    checks = result.get("checks", [])
    if not isinstance(checks, list):
        fail(f"{path}.checks must be array")
    failures = result.get("failures", [])
    if not isinstance(failures, list):
        fail(f"{path}.failures must be array")
    verdict_pass = result["verdict"] == "PASS"
    if verdict_pass:
        bad = [
            c.get("id", "<missing>")
            for c in checks
            if isinstance(c, dict) and c.get("required", True) and c.get("passed") is not True
        ]
        if bad:
            fail(f"{path} PASS with failing required checks: {bad}")
        if failures:
            fail(f"{path} PASS requires failures=[]")
        # Floor: a PASS may never have an empty/zero required-check set. Closes the
        # 'verified with checks:[]' hole for every screen, not just data screens.
        passed_required = [
            c for c in checks
            if isinstance(c, dict) and c.get("required", True) and c.get("passed") is True
        ]
        if not passed_required:
            fail(f"{path} PASS requires at least one passed required check")
    if require_artifacts:
        artifact_paths = _collect_artifact_paths(result)
        for rel in sorted(artifact_paths):
            if "<" in rel or ">" in rel:
                if verdict_pass:
                    fail(f"{path} PASS references unresolved placeholder artifact path: {rel}")
                continue
            if not rel:
                continue
            fp = ROOT / rel
            if not fp.is_file():
                fail(f"{path} references missing or non-file artifact: {rel} "
                     f"(a directory is not evidence)")
            if verdict_pass and fp.stat().st_size == 0:
                fail(f"{path} PASS references empty (0-byte) artifact: {rel}")
    validate_source_manifest(result, path)
    if screen is not None and verdict_pass:
        validate_evidence_floor(screen, result, path)
        validate_phase_coverage(screen, result, path)
    return result


def _phase_lenses(phase_run: dict[str, Any]) -> set[str]:
    lenses = phase_run.get("lenses", [])
    if not isinstance(lenses, list):
        return set()
    return {str(name).strip() for name in lenses if isinstance(name, str) and name.strip()}


def validate_phase_coverage(screen: dict[str, Any], result: dict[str, Any], path: Path) -> None:
    """Make the mandatory workflow cycle a hard gate, not a prose preference.

    A PASS must record, in phase_runs[], that every fan-out phase launched its
    workflow and fanned out to its FULL lens set. Skipping EXPLORE/VERIFY/VALIDATE
    — or hand-picking a subset of lenses, or verifying inline instead of via the
    fan-out — is rejected here. This closes the hole where the conductor 'did the
    work' but bypassed the independent multi-lens coverage the flow requires.
    inline-fallback is allowed (Workflows genuinely unavailable) but must still
    carry the same full lens set."""
    sid = screen.get("id", "<unknown>")
    runs = result.get("phase_runs")
    if not isinstance(runs, list) or not runs:
        fail(f"{sid} PASS requires phase_runs[] proving the full workflow cycle ran "
             f"(RESEARCH, EXPLORE, DEVELOP, VERIFY, VALIDATE when UI, REVIEW). "
             f"Skipping a fan-out workflow is not allowed.")
    # EVERY recorded entry is validated, not just the last one per phase. This used to be
    # `by_phase[name] = run`, which silently dropped all but the final entry of a repeated
    # phase — so a partial VERIFY recorded before a full one was invisible to the gate.
    # That mattered because a scoped/triage pass may never be recorded at all (see the
    # constitution's "Cost may be proportional; coverage may not" and verify-fanout.js's
    # full_set flag): if an entry is in phase_runs[], it is claiming a full lens set ran,
    # so every entry has to carry one. Accumulating also keeps the door open for reading
    # phase_runs[] as a record of how many passes happened — but note it is NOT a reliable
    # effort log and was never meant to be one: a phase that changes no files leaves no
    # checkpoint, so passes go unrecorded. Measure effort from the agent transcripts.
    by_phase: dict[str, list[dict[str, Any]]] = {}
    for run in runs:
        if not isinstance(run, dict):
            fail(f"{sid}.phase_runs entries must be objects")
        name = str(run.get("phase", "")).strip().upper()
        if not name:
            fail(f"{sid}.phase_runs entry missing phase")
        mode = str(run.get("mode", "")).strip().lower()
        if mode not in {"workflow", "inline-fallback", "inline", "agent"}:
            fail(f"{sid}.phase_runs[{name}].mode invalid: {run.get('mode')!r} "
                 f"(use workflow|inline-fallback for fan-out phases)")
        by_phase.setdefault(name, []).append(run)

    platforms = screen.get("platforms", [])
    plats = {str(p).lower() for p in platforms} if isinstance(platforms, list) else set()
    ui_plats = plats & (set(UI_PLATFORM_VALIDATORS) | MOBILE_PLATFORMS)

    engine_kinds = _declared_engine_kinds(screen)

    required_phases = ["RESEARCH", "EXPLORE", "DEVELOP", "VERIFY", "REVIEW"]
    if ui_plats or engine_kinds:
        required_phases.append("VALIDATE")
    for ph in required_phases:
        if ph not in by_phase:
            fail(f"{sid} PASS is missing phase_runs entry for {ph}; the full workflow "
                 f"cycle is mandatory and cannot be skipped")

    def require_full_fanout(phase: str, needed: set[str], label: str) -> None:
        entries = by_phase.get(phase, [])
        for idx, run in enumerate(entries):
            # Name the entry when there is more than one, so "VERIFY is incomplete" never
            # reads as "VERIFY is missing" on a unit that recorded several passes.
            where = f"{phase}" if len(entries) == 1 else f"{phase} entry #{idx + 1}/{len(entries)}"
            if str(run.get("mode", "")).strip().lower() not in FANOUT_MODES:
                fail(f"{sid}.phase_runs[{where}].mode must be 'workflow' (or 'inline-fallback' "
                     f"only when Workflows are genuinely unavailable), not "
                     f"{run.get('mode')!r}; verifying inline without the fan-out is not allowed")
            missing = sorted(needed - _phase_lenses(run))
            if missing:
                fail(f"{sid}.phase_runs[{where}] did not run its full {label} lens set; "
                     f"missing: {missing}. Launch the workflow with ALL lenses (no subset). "
                     f"A partial pass is triage and may not be recorded at all.")

    # A lens name that is not in the roster cannot have run: phase_runs[] was pure
    # string-matching, so an invented lens satisfied the "full fan-out" requirement.
    if AGENTS.is_dir():
        for phase_name in sorted(by_phase):
            for run in by_phase[phase_name]:
                for lens in sorted(_phase_lenses(run)):
                    if not (AGENTS / f"{lens}.md").is_file():
                        fail(f"{sid}.phase_runs[{phase_name}] cites lens {lens!r} that is not in the "
                             f"agent roster (.claude/agents/{lens}.md does not exist); phase_runs "
                             f"may not name agents that cannot run")

    require_full_fanout("RESEARCH", RESEARCH_LENSES, f"research-fanout ({len(RESEARCH_LENSES)})")
    require_full_fanout("EXPLORE", EXPLORE_LENSES, f"explore-fanout (scout + {len(EXPLORE_LENSES) - 1})")
    require_full_fanout("VERIFY", VERIFY_LENSES, f"verify-fanout ({len(VERIFY_LENSES)})")

    if ui_plats or engine_kinds:
        validate_entries = by_phase.get("VALIDATE", [])
        for idx, run in enumerate(validate_entries):
            where = ("VALIDATE" if len(validate_entries) == 1
                     else f"VALIDATE entry #{idx + 1}/{len(validate_entries)}")
            if str(run.get("mode", "")).strip().lower() not in FANOUT_MODES:
                fail(f"{sid}.phase_runs[{where}].mode must be 'workflow' (or 'inline-fallback'), "
                     f"not {run.get('mode')!r}; driving the live runtime inline without the "
                     f"validate-live fan-out is not allowed")
            got = _phase_lenses(run)
            needed = {"validate-logs"}
            for plat in ui_plats:
                validator = UI_PLATFORM_VALIDATORS.get(plat)
                if validator:
                    needed.add(validator)
            # A declared engine/pipeline contract must be RUN, not merely read. This mirrors the
            # UI rule: static verification never substitutes for the live runtime.
            for kind in engine_kinds:
                needed.add(ENGINE_VALIDATORS[kind])
            if "mobile" in ui_plats and not ({"validate-android", "validate-ios"} & got):
                fail(f"{sid}.phase_runs[{where}] owns a mobile surface but ran no "
                     f"validate-android/validate-ios lens")
            missing = sorted(needed - got)
            if missing:
                fail(f"{sid}.phase_runs[{where}] missing required live validators: {missing} "
                     f"(validate-logs + validate-<owned platform> + validate-engine/pipeline "
                     f"for a declared ENG-*/PIPE-* contract)")

    review_entries = by_phase.get("REVIEW", [])
    for idx, run in enumerate(review_entries):
        if "pantalla-reviewer" not in _phase_lenses(run):
            where = ("REVIEW" if len(review_entries) == 1
                     else f"REVIEW entry #{idx + 1}/{len(review_entries)}")
            fail(f"{sid}.phase_runs[{where}] must record the pantalla-reviewer sign-off")


def validate_evidence_floor(screen: dict[str, Any], result: dict[str, Any], path: Path) -> None:
    """Minimum live-proof floor for declared UI surfaces. The data path already
    has a floor (data_engine_assertions); this mirrors it for web/mobile so a UI
    screen cannot pass with no screenshot/console/device-log evidence."""
    platforms = screen.get("platforms", [])
    plats = {str(p).lower() for p in platforms} if isinstance(platforms, list) else set()
    artifact_paths = [p.lower() for p in _collect_artifact_paths(result)]

    def has(predicate) -> bool:
        return any(predicate(p) for p in artifact_paths)

    def is_screenshot(p: str) -> bool:
        return "screenshot" in p or p.endswith((".png", ".jpg", ".jpeg", ".webp"))

    def is_console(p: str) -> bool:
        return "console" in p

    def is_network(p: str) -> bool:
        return "network" in p

    def is_device_log(p: str) -> bool:
        return any(tag in p for tag in ("logcat", "idb", "flutter", "ios-log", "ios_log"))

    sid = screen.get("id", "<unknown>")
    if "web" in plats:
        if not has(is_screenshot):
            fail(f"{sid} web PASS requires at least one screenshot artifact")
        if not (has(is_console) or has(is_network)):
            fail(f"{sid} web PASS requires a console or network evidence artifact")
    if plats & MOBILE_PLATFORMS:
        if not has(is_screenshot):
            fail(f"{sid} mobile PASS requires at least one screenshot artifact")
        if not has(is_device_log):
            fail(f"{sid} mobile PASS requires a device log artifact (logcat/idb/flutter)")


def _refs_from_feature(screen: dict[str, Any]) -> set[str]:
    refs: set[str] = set()
    for key in ["applies"]:
        for item in screen.get(key, []) if isinstance(screen.get(key, []), list) else []:
            if isinstance(item, str):
                refs.add(item)
    source = screen.get("source", {})
    if isinstance(source, dict):
        for key in ["logic_refs", "product_refs"]:
            for item in source.get(key, []) if isinstance(source.get(key, []), list) else []:
                if isinstance(item, str):
                    refs.add(item)
    for ac in screen.get("acceptance", []) if isinstance(screen.get("acceptance", []), list) else []:
        if isinstance(ac, dict):
            for item in ac.get("refs", []) if isinstance(ac.get("refs", []), list) else []:
                if isinstance(item, str):
                    refs.add(item)
    return refs


def arch_hash() -> str:
    """sha256 over the architecture-bearing blueprint files, order-stable."""
    digest = hashlib.sha256()
    for rel in ARCH_HASH_FILES:
        fp = ROOT / rel
        digest.update(rel.encode("utf-8") + b"\0")
        digest.update((fp.read_bytes() if fp.is_file() else b"<absent>") + b"\0")
    return "sha256:" + digest.hexdigest()


def validate_architecture_review(meta: dict[str, Any]) -> None:
    """Validate meta.architecture_review WHEN PRESENT — never require it here.

    Non-retroactive by design: requiring the key unconditionally would brick every
    already-initialized project the moment the gate shipped (the hook runs this whole
    validator on every features.json write). Presence is demanded only by --init-gate,
    which /init-build alone invokes: a project cannot be BORN without the gate, but no
    existing state dies because of it."""
    review = meta.get("architecture_review")
    if review is None:
        return
    if not isinstance(review, dict):
        fail("meta.architecture_review must be an object")
    status = str(review.get("status", "")).strip()
    if status not in ARCH_REVIEW_STATUSES:
        fail(f"meta.architecture_review.status invalid: {review.get('status')!r} "
             f"(must be one of {sorted(ARCH_REVIEW_STATUSES)})")
    if review.get("open_blockers"):
        fail(f"meta.architecture_review.open_blockers is non-empty: resolve each blocker "
             f"(emit a foundation unit, accept the risk via a DEC-*, or defer it with a "
             f"trip-wire) before the state is valid")
    if review.get("failed_lenses"):
        fail(f"meta.architecture_review.failed_lenses is non-empty: "
             f"{review.get('failed_lenses')}; re-run /arch-review with the full lens set")
    lenses = review.get("lenses")
    got = {str(x).strip() for x in lenses} if isinstance(lenses, list) else set()
    if got != ARCH_LENSES:
        fail(f"meta.architecture_review.lenses must be the full arch set "
             f"{sorted(ARCH_LENSES)}; got {sorted(got)}")
    report_sha = str(review.get("report_sha256", "")).strip().lower().removeprefix("sha256:")
    report = STATE / "evidence" / "APP-INTEGRATION" / "reports" / "arch-review.md"
    if not report.is_file():
        fail("meta.architecture_review present but the report "
             ".orchestrator-state/evidence/APP-INTEGRATION/reports/arch-review.md does not exist")
    actual = hashlib.sha256(report.read_bytes()).hexdigest()
    if not report_sha:
        fail("meta.architecture_review.report_sha256 missing: the machine record must be "
             "sealed against the human-readable report")
    if report_sha != actual:
        fail("meta.architecture_review.report_sha256 does not match the report on disk; "
             "re-run /arch-review instead of editing either side by hand")
    for i, risk in enumerate(review.get("accepted_risks") or []):
        if not isinstance(risk, dict) or not all(
            str(risk.get(k, "")).strip() for k in ("finding_id", "rationale", "decided_by")
        ):
            fail(f"meta.architecture_review.accepted_risks[{i}] must carry finding_id, "
                 f"rationale and decided_by (a person) — an unsigned risk is not accepted")
    for i, item in enumerate(review.get("deferred") or []):
        if not isinstance(item, dict) or not str(item.get("trip_wire", "")).strip():
            fail(f"meta.architecture_review.deferred[{i}] must name a trip_wire "
                 f"(the DATA-*/ENG-*/PIPE-* whose change reopens the finding)")


def validate_discovery(meta: dict[str, Any]) -> None:
    """Validate meta.discovery WHEN PRESENT — never require it here.

    Non-retroactive for the same reason as meta.architecture_review: the hook runs this
    whole validator on every features.json write, so demanding the key unconditionally
    would brick every already-initialized project. Presence is demanded only by
    --init-gate, which /init-build alone invokes."""
    record = meta.get("discovery")
    if record is None:
        return
    if not isinstance(record, dict):
        fail("meta.discovery must be an object")
    if str(record.get("status", "")).strip() != "complete":
        fail(f"meta.discovery.status invalid: {record.get('status')!r} (must be \"complete\" — "
             f"a partial discovery is recorded nowhere, not half-recorded)")
    if record.get("failed_lenses"):
        fail(f"meta.discovery.failed_lenses is non-empty: {record.get('failed_lenses')}; "
             f"re-run /discovery with the full lens set")
    if record.get("unresolved"):
        fail(f"meta.discovery.unresolved is non-empty: {record.get('unresolved')}; every "
             f"checklist item needs a disposition — resolve them and re-run /discovery")
    lenses = record.get("lenses")
    got = {str(x).strip() for x in lenses} if isinstance(lenses, list) else set()
    if got != DISCOVERY_LENSES:
        fail(f"meta.discovery.lenses must be the full discovery set "
             f"{sorted(DISCOVERY_LENSES)}; got {sorted(got)}")
    total = record.get("items_total")
    if not isinstance(total, int) or total < 1:
        fail("meta.discovery.items_total must be a positive integer (the checklist is never empty)")
    counts = record.get("dispositions")
    if not isinstance(counts, dict) or set(counts) != set(DISCOVERY_DISPOSITIONS) or not all(
        isinstance(counts[k], int) and counts[k] >= 0 for k in DISCOVERY_DISPOSITIONS
    ):
        fail(f"meta.discovery.dispositions must carry non-negative integer counts for exactly "
             f"{list(DISCOVERY_DISPOSITIONS)}")
    if sum(counts[k] for k in DISCOVERY_DISPOSITIONS) != total:
        fail("meta.discovery.dispositions must sum to items_total — an item outside the "
             "counts is an item without a disposition")
    report = STATE / "evidence" / "APP-INTEGRATION" / "reports" / "discovery.md"
    if not report.is_file():
        fail("meta.discovery present but the report "
             ".orchestrator-state/evidence/APP-INTEGRATION/reports/discovery.md does not exist")
    report_sha = str(record.get("report_sha256", "")).strip().lower().removeprefix("sha256:")
    if not report_sha:
        fail("meta.discovery.report_sha256 missing: the machine record must be sealed "
             "against the human-readable report")
    if report_sha != hashlib.sha256(report.read_bytes()).hexdigest():
        fail("meta.discovery.report_sha256 does not match the report on disk; "
             "re-run /discovery instead of editing either side by hand")


def validate_feature_traceability(screen: dict[str, Any], blueprint_ids: set[str]) -> None:
    """Every rule ID a unit cites must exist in the blueprint.

    conventions.md promises traceability, but nothing enforced it: `applies: ["DATA-999"]`
    passed the gate AND the linter, and a phantom `DATA-` prefix even triggered the
    data_engine requirement while a phantom without a known prefix was inert. Skipped
    when the blueprint defines nothing (a bare scaffold) so /init-build can still run."""
    if not blueprint_ids:
        return
    sid = screen.get("id", "<unknown>")
    unknown = sorted(
        ref for ref in _refs_from_feature(screen)
        if ref.startswith(REF_PREFIXES) and ref not in blueprint_ids
    )
    if unknown:
        fail(f"{sid} cites rule IDs no blueprint file defines: {unknown}; a plan may not "
             f"reference intent that does not exist (fix the blueprint or the citation)")


def feature_has_data_contract(screen: dict[str, Any]) -> bool:
    refs = _refs_from_feature(screen)
    if any(ref.startswith("DATA-") for ref in refs):
        return True
    verify = screen.get("verify", {})
    if isinstance(verify, dict) and verify.get("data_checks"):
        return True
    engine = screen.get("data_engine")
    # An empty {} is NOT a data contract: a data engine must carry real shape.
    return isinstance(engine, dict) and bool(engine) and not engine.get("not_applicable_reason")


def validate_feature_data_engine(screen: dict[str, Any]) -> None:
    sid = screen.get("id", "<unknown>")
    if not feature_has_data_contract(screen):
        return
    engine = screen.get("data_engine")
    if not isinstance(engine, dict):
        fail(f"{sid} has data contract but missing data_engine")
    if engine.get("not_applicable_reason"):
        # not_applicable may not coexist with a cited DATA-* ref or declared data_checks.
        refs = _refs_from_feature(screen)
        if any(ref.startswith("DATA-") for ref in refs):
            fail(f"{sid}.data_engine.not_applicable_reason set but feature cites DATA-* refs")
        verify = screen.get("verify", {})
        if isinstance(verify, dict) and verify.get("data_checks"):
            fail(f"{sid}.data_engine.not_applicable_reason set but verify.data_checks[] is non-empty")
        return
    store = engine.get("canonical_store")
    if not isinstance(store, dict):
        fail(f"{sid}.data_engine.canonical_store must be object")
    kind = store.get("kind")
    if not isinstance(kind, str) or not kind.strip():
        fail(f"{sid}.data_engine.canonical_store.kind must be a non-empty string "
             f"(the stack's system of record: database, event_store, ledger, file_store, ...)")
    source_of_truth = store.get("source_of_truth")
    if not isinstance(source_of_truth, str) or not source_of_truth.strip():
        fail(f"{sid}.data_engine.canonical_store.source_of_truth must be a non-empty string")
    if _has_client_token(source_of_truth) or _has_client_token(kind):
        fail(f"{sid}.data_engine.canonical_store declares a client layer as system of record "
             f"(source_of_truth={source_of_truth!r}, kind={kind!r}); the source of truth must "
             f"never be a frontend/client")
    resources = store.get("resources")
    if not isinstance(resources, list) or not resources:
        fail(f"{sid}.data_engine.canonical_store.resources must be non-empty")
    pipeline = engine.get("pipeline")
    if not isinstance(pipeline, dict):
        fail(f"{sid}.data_engine.pipeline must be object")
    persists = pipeline.get("writes_to_canonical_store")
    if persists is None:
        persists = pipeline.get("writes_to_database")
    if persists is None:
        persists = pipeline.get("persists")
    if persists is not True:
        fail(f"{sid}.data_engine.pipeline must persist to the canonical store "
             f"(set writes_to_canonical_store/writes_to_database/persists = true)")
    read_path = pipeline.get("read_path")
    if not isinstance(read_path, list) or not read_path:
        fail(f"{sid}.data_engine.pipeline.read_path must be non-empty")
    steps = [str(step).lower() for step in read_path]

    def _step_matches(step: str, tokens: set[str]) -> bool:
        return any(tok in step for tok in tokens)

    # POSITIONAL, not "somewhere in the concatenation". The read path is a direction —
    # store -> transport -> client — so a reversed path used to pass, and a single step
    # could satisfy two layers at once. canonical_tokens deliberately does NOT include
    # source_of_truth itself: seeding it let the declaration bless its own read path.
    canonical_tokens = {
        kind.strip().lower(),
        "canonical", "source", "store", "database", "db", "event", "ledger", "log",
        "stream", "projection", "checkpoint", "file", "bucket", "object", "warehouse",
        "lake", "system-of-record", "system_of_record", "record",
    }
    if not _step_matches(steps[0], canonical_tokens):
        fail(f"{sid}.data_engine.pipeline.read_path must START at the canonical store "
             f"({source_of_truth}); first step is {read_path[0]!r}")
    transport_idx = next(
        (i for i, step in enumerate(steps) if _step_matches(step, TRANSPORT_TOKENS)), None
    )
    if transport_idx is None:
        fail(f"{sid}.data_engine.pipeline.read_path must include a transport/read layer "
             f"(api/service/read-model/...)")
    if transport_idx == 0:
        fail(f"{sid}.data_engine.pipeline.read_path step {read_path[0]!r} is both the canonical "
             f"store and the transport layer; they must be distinct steps")
    svc_contract = engine.get("single_value_contract")
    if not isinstance(svc_contract, list) or not svc_contract:
        fail(f"{sid}.data_engine.single_value_contract must be non-empty")
    for entry in svc_contract:
        if not isinstance(entry, dict):
            fail(f"{sid}.data_engine.single_value_contract entries must be objects")
        if not str(entry.get("field", "")).strip():
            fail(f"{sid}.data_engine.single_value_contract entry missing field")
        source_map = entry.get("db_source") or entry.get("source") or entry.get("store_source")
        client_map = entry.get("ui_field") or entry.get("client_field") or entry.get("visible_field")
        if not str(source_map or "").strip():
            fail(f"{sid}.data_engine.single_value_contract field '{entry.get('field')}' "
                 f"missing source mapping (db_source/source/store_source)")
        if not str(client_map or "").strip():
            fail(f"{sid}.data_engine.single_value_contract field '{entry.get('field')}' "
                 f"missing client mapping (ui_field/client_field/visible_field)")
    verify = screen.get("verify", {})
    data_checks = verify.get("data_checks") if isinstance(verify, dict) else None
    if not isinstance(data_checks, list) or not data_checks:
        fail(f"{sid} has data_engine but missing verify.data_checks[]")


def validate_data_engine_assertions(screen: dict[str, Any], result: dict[str, Any]) -> None:
    """Make same_value FALSIFIABLE. Each assertion must carry the observed literal
    db_value/api_value/ui_value (plus optional platform_values); the validator
    recomputes equality from those literals instead of trusting the flag."""
    sid = screen["id"]
    assertions = result.get("data_engine_assertions")
    if not isinstance(assertions, list) or not assertions:
        fail(f"{sid} PASS requires data_engine_assertions[]")
    for assertion in assertions:
        if not isinstance(assertion, dict):
            fail(f"{sid} data_engine_assertions entries must be objects")
        aid = assertion.get("id", "<missing>")
        observed: list[tuple[str, Any]] = []
        for label, keys in (
            ("canonical", CANONICAL_VALUE_KEYS),
            ("transport", TRANSPORT_VALUE_KEYS),
            ("client", CLIENT_VALUE_KEYS),
        ):
            present = [(k, assertion[k]) for k in keys if k in assertion]
            if not present:
                fail(f"{sid} data_engine_assertion {aid} missing observed {label} value (one of {list(keys)})")
            observed.extend(present)
        platform_values = assertion.get("platform_values")
        if isinstance(platform_values, dict):
            for plat, val in platform_values.items():
                observed.append((f"platform:{plat}", val))
        normalized: list[str] = []
        for key, value in observed:
            nv = _norm(value)
            if nv is None or nv == "":
                fail(f"{sid} data_engine_assertion {aid} has empty observed value for {key}")
            normalized.append(nv)
        if any(nv != normalized[0] for nv in normalized):
            shown = {k: v for k, v in observed}
            fail(f"{sid} data_engine_assertion {aid}: observed values differ across layers: {shown}")
        if assertion.get("same_value") is not True:
            fail(f"{sid} data_engine_assertion {aid} must set same_value=true when observed values match")


def validate_features(evidence_rows: list[dict[str, Any]] | None = None) -> dict[str, Any]:
    data = load_json(FEATURES)
    if not isinstance(data, dict):
        fail("features.json root must be object")
    if schema_name(data) != "orchestrator.features.v1":
        fail("features.json schema_version must be orchestrator.features.v1")
    for key in ["version", "initialized", "project", "source_files", "rules_index", "screens"]:
        if key not in data:
            fail(f"features.json missing {key}")
    if not isinstance(data["initialized"], bool):
        fail("features.initialized must be boolean")
    screens = data["screens"]
    if not isinstance(screens, list):
        fail("features.screens must be array")
    meta = data.get("meta", {}) if isinstance(data.get("meta", {}), dict) else {}
    validate_architecture_review(meta)
    validate_discovery(meta)
    lifecycle = meta.get("lifecycle")
    if data["initialized"] is False:
        if screens:
            fail("initialized=false requires screens=[]")
        if lifecycle and lifecycle != "scaffold-placeholder":
            fail("initialized=false requires meta.lifecycle scaffold-placeholder")
        return data
    if not screens:
        fail("initialized=true requires screens[]")

    # Deterministic backstop for unresolved stack commands. Once the project is initialized,
    # every verifier depends on the real install/dev/test/migrate/seed/smoke/build commands
    # in stack.md. Detecting the <COMMAND_*> placeholders was prose-to-an-LLM-lens only
    # (explore-config/explore-scout); if that lens skipped it after a compaction, nothing
    # caught it. A built project that still carries placeholders cannot verify anything.
    stack = ROOT / ".claude" / "rules" / "stack.md"
    if stack.is_file():
        leftover = sorted(set(re.findall(r"<COMMAND_[A-Z]+>", stack.read_text(encoding="utf-8"))))
        if leftover:
            fail(f".claude/rules/stack.md still holds unresolved command placeholders {leftover} "
                 f"while features.json is initialized=true; /init-build must resolve every "
                 f"<COMMAND_*> (or the verifiers have no real commands to run)")

    blueprint_ids = _blueprint_ids()
    ids: list[str] = []
    counts: Counter = Counter()
    for idx, screen in enumerate(screens):
        if not isinstance(screen, dict):
            fail(f"screens[{idx}] must be object")
        for key in [
            "id", "slug", "title", "kind", "platforms", "order", "after", "status",
            "passes", "acceptance", "verify", "evidence_path", "blocked_reason", "notes",
        ]:
            if key not in screen:
                fail(f"screens[{idx}] missing {key}")
        sid = screen["id"]
        if not isinstance(sid, str) or not sid.startswith("SCR-"):
            fail(f"screens[{idx}].id must start with SCR-")
        ids.append(sid)
        status = screen["status"]
        counts[status] += 1
        if status not in VALID_STATUS:
            fail(f"{sid} status invalid: {status}")
        if not isinstance(screen["passes"], bool):
            fail(f"{sid}.passes must be boolean")
        if screen["passes"] and status not in PASS_STATUSES:
            fail(f"{sid} passes=true requires status verified or accepted")
        if status in PASS_STATUSES and not screen["passes"]:
            fail(f"{sid} status {status} requires passes=true")
        if status == "blocked" and not str(screen.get("blocked_reason", "")).strip():
            fail(f"{sid} is blocked without blocked_reason")
        if not isinstance(screen["after"], list):
            fail(f"{sid}.after must be array")
        if not isinstance(screen["acceptance"], list):
            fail(f"{sid}.acceptance must be array")
        if not isinstance(screen["verify"], dict):
            fail(f"{sid}.verify must be object")
        expected = f".orchestrator-state/evidence/{sid}/result.json"
        if screen["evidence_path"] != expected:
            fail(f"{sid}.evidence_path must be {expected}")
        plats = (
            {str(p).lower() for p in screen["platforms"]}
            if isinstance(screen["platforms"], list) else set()
        )
        if _is_ui_surface(screen) and not (plats & (set(UI_PLATFORM_VALIDATORS) | MOBILE_PLATFORMS)):
            fail(f"{sid} is a UI surface (kind 'ui' / UI primary_verifier / client route) but "
                 f"declares no UI platform in platforms[]; add web/android/ios so VALIDATE cannot "
                 f"be silently skipped. A genuine backend-only unit must not look like a UI surface.")
        # Optional per-screen checkpoint written by /next-pantalla: {phase, iteration}.
        # Turns the "maximum 3 debugger iterations" prose into a gate, and lets a
        # crashed/compacted session resume the active unit from disk.
        checkpoint = screen.get("checkpoint")
        if checkpoint is not None:
            if not isinstance(checkpoint, dict):
                fail(f"{sid}.checkpoint must be object {{phase, iteration}}")
            iteration = checkpoint.get("iteration", 0)
            if not isinstance(iteration, int) or iteration < 0:
                fail(f"{sid}.checkpoint.iteration must be a non-negative integer")
            if iteration > 3:
                fail(f"{sid}.checkpoint.iteration is {iteration}: the debugger loop cap is 3; "
                     f"mark the unit blocked with reason/reproduction instead of iterating forever")
        validate_feature_data_engine(screen)
        validate_feature_traceability(screen, blueprint_ids)

    # Central sequential-build invariant: at most one unit may be building.
    if counts.get("building", 0) > 1:
        building_ids = sorted(s["id"] for s in screens if s.get("status") == "building")
        fail(f"more than one unit is building {building_ids}; exactly one may build at a time")

    dupes = sorted([sid for sid, n in Counter(ids).items() if n > 1])
    if dupes:
        fail(f"duplicate screen ids: {dupes}")
    known = set(ids)
    by_id = {screen["id"]: screen for screen in screens}
    for screen in screens:
        sid = screen["id"]
        for dep in screen.get("after", []):
            if dep not in known:
                fail(f"{sid}.after references unknown dependency {dep}")
        # Two different bars, deliberately. BUILDING on a dependency only needs that dependency
        # to exist and hold real PASS evidence (`verified`); PROMOTING past it needs the human.
        # Collapsing both into "accepted" is what made /build-loop advance a single DAG level per
        # run: the loop never accepts, so nothing downstream ever became ready. The human gate is
        # untouched — it moved from "permission to work" to "permission to call it done".
        if screen["status"] in {"ready", "building"}:
            for dep in screen.get("after", []):
                if by_id[dep]["status"] not in BUILT_STATUS:
                    fail(f"{sid} is {screen['status']} but dependency {dep} is "
                         f"{by_id[dep]['status']}; a dependency must be verified or accepted "
                         f"before its dependents can be built")
        if screen["status"] == "accepted":
            for dep in screen.get("after", []):
                if by_id[dep]["status"] != "accepted":
                    fail(f"{sid} is accepted but dependency {dep} is {by_id[dep]['status']}; "
                         f"acceptance follows the after[] order — accept {dep} first")

    summary = data.get("summary")
    if isinstance(summary, dict):
        if summary.get("total") != len(screens):
            fail("summary.total mismatch")
        for status in VALID_STATUS:
            if summary.get(status, 0) != counts.get(status, 0):
                fail(f"summary.{status} mismatch")

    visiting: set[str] = set()
    visited: set[str] = set()

    def dfs(node: str, stack: list[str]) -> None:
        if node in visited:
            return
        if node in visiting:
            fail("dependency cycle: " + " -> ".join(stack + [node]))
        visiting.add(node)
        stack.append(node)
        for dep in by_id[node].get("after", []):
            dfs(dep, stack)
        stack.pop()
        visiting.remove(node)
        visited.add(node)

    for sid in ids:
        dfs(sid, [])

    for screen in screens:
        if screen["status"] in PASS_STATUSES:
            result_path = ROOT / screen["evidence_path"]
            result = validate_result(result_path, known, require_artifacts=True, screen=screen)
            if result.get("verdict") != "PASS":
                fail(f"{screen['id']} is {screen['status']} but evidence verdict is not PASS")
            if feature_has_data_contract(screen):
                validate_data_engine_assertions(screen, result)
            if evidence_rows is not None:
                runs = result.get("phase_runs") or []
                evidence_rows.append({
                    "screen_id": screen["id"],
                    "status": screen["status"],
                    "verdict": result.get("verdict"),
                    "attempt": result.get("attempt"),
                    "generated_at": result.get("generated_at"),
                    "summary": result.get("summary"),
                    "result_path": screen["evidence_path"],
                    "phases": [
                        {"phase": r.get("phase"), "mode": r.get("mode"), "lenses": r.get("lenses", [])}
                        for r in runs if isinstance(r, dict)
                    ],
                    "artifacts": sorted(_collect_artifact_paths(result)),
                })
    return data


def _atomic_write_json(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=str(path.parent), prefix=path.name + ".", suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            json.dump(payload, handle, ensure_ascii=False, indent=2)
            handle.write("\n")
        os.replace(tmp, path)
    except BaseException:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise


def emit_status(data: dict[str, Any], evidence_rows: list[dict[str, Any]]) -> None:
    """Derived, machine-readable read contract for external surfaces (dashboards,
    CI, monitor screens). Written ONLY on --emit-status after a successful gate run,
    always atomically (write temp + rename), so concurrent readers never see a torn
    file. These files are projections: features.json stays the canonical plan and
    the single-writer rule is untouched — the conductor invokes this script."""
    screens = data.get("screens") if isinstance(data.get("screens"), list) else []
    screens = [s for s in screens if isinstance(s, dict)]
    counts = Counter(str(s.get("status")) for s in screens)
    building = [s["id"] for s in screens if s.get("status") == "building"]
    verified = [s["id"] for s in screens if s.get("status") == "verified"]
    # Since a unit may be BUILT on a merely-verified dependency but only ACCEPTED after that
    # dependency is accepted, "verified" no longer means "acceptable now". Split the list so the
    # human (and /accept) sees the legal order instead of guessing it.
    status_by_id = {s.get("id"): s.get("status") for s in screens}
    after_by_id = {s.get("id"): (s.get("after") or []) for s in screens}
    acceptable_now = [
        sid for sid in verified
        if all(status_by_id.get(dep) == "accepted" for dep in after_by_id.get(sid, []))
    ]
    blocked_by_accept = [
        {
            "id": sid,
            "waiting_on": sorted(
                dep for dep in after_by_id.get(sid, [])
                if status_by_id.get(dep) != "accepted"
            ),
        }
        for sid in verified if sid not in acceptable_now
    ]
    ready = sorted(
        (s for s in screens if s.get("status") == "ready"),
        key=lambda s: (s.get("order") is None, s.get("order")),
    )
    generated_at = datetime.now(timezone.utc).isoformat(timespec="seconds")
    project = data.get("project") if isinstance(data.get("project"), dict) else {}
    _atomic_write_json(STATE / "status.json", {
        "schema_version": "orchestrator.status.v1",
        "generated_at": generated_at,
        "initialized": data.get("initialized", False),
        "project": project.get("name"),
        "total": len(screens),
        "counts": {status: counts.get(status, 0) for status in sorted(VALID_STATUS)},
        "building": building[0] if building else None,
        "verified_awaiting_accept": verified,
        "acceptable_now": acceptable_now,
        "verified_blocked_by_accept_order": blocked_by_accept,
        "next_ready": ready[0]["id"] if ready else None,
        "blocked": [
            {"id": s.get("id"), "reason": s.get("blocked_reason")}
            for s in screens if s.get("status") == "blocked"
        ],
        "screens": [
            {
                "id": s.get("id"), "slug": s.get("slug"), "title": s.get("title"),
                "kind": s.get("kind"), "platforms": s.get("platforms"),
                "order": s.get("order"), "after": s.get("after"),
                "status": s.get("status"), "passes": s.get("passes"),
                "checkpoint": s.get("checkpoint"),
                "evidence_path": s.get("evidence_path"),
            }
            for s in screens
        ],
    })
    _atomic_write_json(STATE / "evidence" / "index.json", {
        "schema_version": "orchestrator.evidence-index.v1",
        "generated_at": generated_at,
        "screens": evidence_rows,
    })
    print(f"status emitted: {STATE / 'status.json'} + {STATE / 'evidence' / 'index.json'}")


def validate_templates() -> None:
    candidates = [
        ORQ / "schemas" / "features.schema.json",
        ORQ / "schemas" / "result.schema.json",
        ORQ / "templates" / "features.empty.json",
        ORQ / "templates" / "evidence" / "result.json",
        ORQ / "examples" / "features.example.json",
        ORQ / "examples" / "result.example.json",
    ]
    for path in candidates:
        if not path.exists():
            fail(f"missing {path}")
        load_json(path)


def main() -> None:
    args = sys.argv[1:]
    if "--arch-hash" in args:
        # Deterministic hash for /arch-review and /reslice; no state required.
        print(arch_hash())
        return
    emit = "--emit-status" in args
    init_gate = "--init-gate" in args
    if not ORQ.exists():
        fail("missing .orchestrator")
    if not STATE.exists():
        fail("missing .orchestrator-state")
    for file in ["spec.md", "features.json", "progress.md"]:
        if not (STATE / file).exists():
            fail(f"missing .orchestrator-state/{file}")
    if not (STATE / "evidence").exists():
        fail("missing .orchestrator-state/evidence")
    validate_templates()
    evidence_rows: list[dict[str, Any]] = []
    data = validate_features(evidence_rows if emit else None)
    if init_gate:
        # /init-build only: a project cannot be born without its birth gates.
        meta = data.get("meta", {}) if isinstance(data.get("meta", {}), dict) else {}
        missing = []
        if meta.get("architecture_review") is None:
            missing.append("meta.architecture_review is missing — /init-build must run "
                           "/arch-review (all 6 arch-* lenses) before compiling features.json")
        if meta.get("discovery") is None:
            missing.append("meta.discovery is missing — /init-build must run "
                           "/discovery (all 6 discovery-* lenses) before compiling features.json")
        if missing:
            fail("--init-gate: " + "; ".join(missing))
    if emit:
        emit_status(data, evidence_rows)
    print("orchestrator state OK")


if __name__ == "__main__":
    main()
