#!/usr/bin/env bash
set -uo pipefail
# self-root to repo root so the delegated command never runs cwd-relative.
# BASH_SOURCE is checked, not assumed: run under a shell that does not define it (zsh executing
# this file directly), the root would silently resolve to nothing and every later failure would
# be reported as "stack.md not found" — a wrong diagnosis that looks exactly like a real one.
if [ -z "${BASH_SOURCE[0]:-}" ]; then
  echo "reset-test-data: must be run with bash (BASH_SOURCE unavailable). Use: bash .orchestrator/scripts/reset-test-data.sh <PHASE>" >&2
  exit 2
fi
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
cd "$ROOT" || { echo "reset-test-data: cannot enter repo root '$ROOT'." >&2; exit 2; }

# Leave the test-data store clean and reproducible before a phase that executes the suite.
#
# WHO CALLS IT, AND WHEN: the CONDUCTOR (orchestrator-flow), ONCE, immediately before a phase
# that will run commands — VERIFY, VALIDATE, and any debugger re-run of either. Lenses are
# FORBIDDEN from calling it. That prohibition is the whole point: the executing lenses are
# serialized precisely so they stop overwriting each other's data, and a lens that reset the
# store mid-phase would wipe the rows a previous lens had already proven — re-creating, from
# inside the fix, the exact contamination the fix removes. One reset, one owner, before the
# phase; never during it.
#
# A FLOOR, NOT A SUBSTITUTE. Read this before treating one reset as "the store is clean".
# The executing lenses run SERIALIZED, so a single reset before the stage leaves a pristine store
# for the FIRST lens only; the second inherits whatever the first wrote, the third inherits both.
# Do NOT try to fix that by resetting between lenses: that would erase rows an earlier lens has
# already cited as evidence, turning its saved artifact into a claim about data that no longer
# exists — the exact failure this whole mechanism exists to prevent, re-created from inside it.
# The rule that already governs this still governs it (stack.md, "Runtime evidence policy":
# isolated test data, disposable local state or safe cleanup when a verification mutates
# persistence): every lens that WRITES scopes itself to identifiers it generated, and concludes
# nothing from a global count — "3 rows exist" is not a finding when a neighbour also writes.
# This script only guarantees a KNOWN STARTING POINT. It does not make a lens's reads unambiguous,
# and it is never a licence to stop scoping.
#
# ANYSTACK: this script cannot know what the store is — relational DB, event log, state store,
# ledger, external system, file store. It knows only the DELEGATION CONTRACT below. It never
# names a language, package manager, database, provider or framework.
#
# DELEGATION CONTRACT — the key this script reads:
#
#   COMMAND_RESET_TEST_DATA   in   .claude/rules/stack.md
#
#   Declared inside the "## Canonical commands" fenced block, following that file's existing
#   convention: a comment line naming the key, then the command on the next line.
#
#       # reset the verifiable test-data store (COMMAND_RESET_TEST_DATA)
#       <the project's real command>
#
#   A scaffold that has not run /init-build yet still carries the <COMMAND_RESET_TEST_DATA>
#   placeholder. That is a THIRD state, reported distinctly from "not declared": the contract
#   exists and is simply not resolved yet. Collapsing the two would hide a real setup gap.
#
#   The delegated command MUST be idempotent — running it twice in a row leaves the same state.
#   This script is idempotent exactly insofar as that command is; it adds no state of its own.
#
# NON-FATAL BY DESIGN (same discipline as phase-push.sh): a missing stack.md, an undeclared key,
# an unresolved placeholder or a failing delegated command all log the reason and exit 0, so
# preparing data never blocks a build. Only a bad invocation exits non-zero. The caller decides
# what to do with a reset that did not happen; this script's job is to say so, loudly and
# precisely, never to guess and never to halt the flow.
#
# NOT ACCEPTANCE EVIDENCE: stack.md already rules that orchestrator reset/clean commands are not
# acceptance evidence for an active screen. This is phase PREPARATION. Its output belongs in the
# phase log, never in a data_engine assertion.

STACK_FILE=".claude/rules/stack.md"
KEY="COMMAND_RESET_TEST_DATA"
phase="${1:-PHASE}"

case "${1:-}" in
  -h|--help)
    cat <<'EOF'
usage: bash .orchestrator/scripts/reset-test-data.sh [PHASE_LABEL]

Runs the command declared as COMMAND_RESET_TEST_DATA in .claude/rules/stack.md to reset the
project's test-data store. Called by the conductor ONCE before VERIFY/VALIDATE (and before any
debugger re-run of them). Lenses must never call it.

Always exits 0 unless invoked wrongly: an undeclared key, an unresolved placeholder or a failing
delegated command are reported on stderr and treated as "no reset performed".
EOF
    exit 0
    ;;
esac

# 1. The stack file must exist; without it there is no contract to read.
if [ ! -f "$STACK_FILE" ]; then
  echo "reset-test-data[$phase]: $STACK_FILE not found; no reset contract to read, skipped." >&2
  exit 0
fi

# 2. Resolve the key: find the comment line that names it, then take the first following line
#    that is neither blank, nor a comment, nor the closing fence. Mirrors how every other
#    <COMMAND_*> is declared in that file, so there is one convention to learn, not two.
#    Three malformed-declaration cases are detected and reported rather than guessed through,
#    because each of them would otherwise resolve to SOMEONE ELSE'S command and report success:
#      MALFORMED  — the marker line carries trailing content (the command written on the same
#                   line instead of the next), so skipping the line would silently fall through
#                   to the next key's command;
#      AMBIGUOUS  — more than one marker line for this key (a half-finished merge or write-back),
#                   where first-match-wins could pick a stale placeholder over a resolved command;
#      the fence/EOF case, where the block ends before any command appears.
#    "Runs the wrong command and says it worked" is the one outcome a reset must never produce.
#    THE MARKER IS THE LITERAL "(KEY)", not a mention of the key. This distinction is the whole
#    safety property: matching any comment that merely CONTAINS the key name would turn an
#    ordinary explanatory note — "read by reset-test-data.sh, which uses COMMAND_RESET_TEST_DATA"
#    — into a marker, and adopt whatever line follows it as the command. In a file that is a
#    living document (write-backs, DEC-* notes), prose that names a key is normal; prose that
#    writes "(KEY)" is a declaration. Only the second one counts.
# The parser lives in lib/stack-command.sh so preflight-check.sh reads stack.md exactly the
# same way; see that file for why the "(KEY)" marker is the declaration.
# shellcheck source=lib/stack-command.sh
. "$ROOT/.orchestrator/scripts/lib/stack-command.sh"
parse="$(stack_command "$KEY" "$STACK_FILE")"

case "$parse" in
  "MALFORMED "*)
    echo "reset-test-data[$phase]: the $KEY marker line in $STACK_FILE carries trailing content ('${parse#MALFORMED }'). The command must be on the line AFTER the comment, like every other <COMMAND_*>. Refusing to guess; no reset performed." >&2
    exit 0
    ;;
  "AMBIGUOUS "*)
    echo "reset-test-data[$phase]: $KEY is declared ${parse#AMBIGUOUS } times in $STACK_FILE. Leave exactly one declaration; refusing to guess which is current. No reset performed." >&2
    exit 0
    ;;
esac
command_line="${parse#OK }"
[ "$parse" = "$command_line" ] && command_line=""

if [ -z "$command_line" ]; then
  echo "reset-test-data[$phase]: $KEY is not declared in $STACK_FILE; no reset performed." >&2
  echo "reset-test-data[$phase]: declare it under '## Canonical commands' as a '# ... ($KEY)' comment followed by the command." >&2
  exit 0
fi

# 3. Distinguish "declared but unresolved" from "not declared" — an unresolved placeholder means
#    /init-build has not finished wiring this project, which is a different problem to report.
case "$command_line" in
  "<"*">")
    echo "reset-test-data[$phase]: $KEY is declared but still the placeholder '$command_line'; /init-build must resolve it with a real command. No reset performed." >&2
    exit 0
    ;;
esac

# 4. Delegate. Report the exact command so the phase log shows what ran, and never hide a failure
#    behind a zero exit: say it failed, then let the caller decide.
echo "reset-test-data[$phase]: running $KEY -> $command_line"
if bash -c "$command_line"; then
  echo "reset-test-data[$phase]: test-data store reset."
  exit 0
fi

echo "reset-test-data[$phase]: '$command_line' failed; the store may be in a partial state. Verify before trusting this phase's data." >&2
exit 0
