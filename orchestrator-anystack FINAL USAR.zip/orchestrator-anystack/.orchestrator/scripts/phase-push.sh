#!/usr/bin/env bash
set -uo pipefail
# self-root to repo root so the commit/push is never cwd-relative
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
cd "$ROOT"

# Phase checkpoint: commit the work done in one /next-pantalla phase and push it
# to origin/main. Called by orchestrator-flow after every phase (RESEARCH,
# EXPLORE, DEVELOP, VERIFY, VALIDATE, REVIEW). This is a DevOps-role side effect,
# not a lifecycle transition: it never touches features.json status and the
# STATE GATE / human /accept remain the only trust anchors.
#
# It is non-fatal by design: when there is no git work tree or no 'origin'
# remote (the scaffold may run before the product repo is wired), it logs and
# exits 0 so building a screen is never blocked. Remote/branch are overridable
# via ORCH_PUSH_REMOTE / ORCH_PUSH_BRANCH.

phase="${1:-}"
unit="${2:-state}"
remote="${ORCH_PUSH_REMOTE:-origin}"
branch="${ORCH_PUSH_BRANCH:-main}"

if [ -z "$phase" ]; then
  echo "usage: bash .orchestrator/scripts/phase-push.sh <PHASE> [UNIT_ID]" >&2
  exit 2
fi

# 1. Require a git work tree, else skip (scaffold may run pre-init).
if ! git rev-parse --is-inside-work-tree >/dev/null 2>&1; then
  echo "phase-push[$phase]: not a git repository; push skipped." >&2
  exit 0
fi

# 2. Commit a checkpoint when there is something to record. Failure (e.g. a
#    product pre-commit hook) is non-fatal: keep going so the flow is not blocked.
git add -A || true
if git diff --cached --quiet; then
  echo "phase-push[$phase]: no changes to commit."
else
  if git commit -m "orchestrator($unit): $phase phase checkpoint" \
      -m "Automated checkpoint after the $phase phase of /next-pantalla."; then
    echo "phase-push[$phase]: committed checkpoint for $unit."
  else
    echo "phase-push[$phase]: commit failed (kept working tree); push skipped." >&2
    exit 0
  fi
fi

# 3. Push HEAD to <remote>/<branch> when the remote exists, else skip non-fatally.
if ! git remote get-url "$remote" >/dev/null 2>&1; then
  echo "phase-push[$phase]: remote '$remote' not configured; commit kept local, push skipped." >&2
  exit 0
fi

if git push "$remote" "HEAD:$branch"; then
  echo "phase-push[$phase]: pushed to $remote/$branch."
else
  echo "phase-push[$phase]: push to $remote/$branch failed; commit kept local, resolve and re-push." >&2
  exit 0
fi
