#!/usr/bin/env python3
"""Refuse to launch a VERIFY fan-out on a repair pass whose diff adversary never ran.

    python3 .orchestrator/scripts/adversary-check.py "<PHASE>" [ID]              # the GATE
    python3 .orchestrator/scripts/adversary-check.py "<PHASE>" [ID] --record -   # record a run

WHY THIS EXISTS, AND WHY IT IS A SCRIPT AND NOT ANOTHER PARAGRAPH.

`next-pantalla` §6 has required the diff adversary on every repair pass since DEC-ORCH-008, and
`constitution.md` states it as a rule. MEASURED on a real run: it ran in 1 of 5 repair passes, and
nothing noticed. At least two findings the literal adversary question would have produced in ~3
minutes surfaced later in the 12-subagent VERIFY fan-out (~28 min), each costing a full repair
round on top.

The cause is not forgetfulness, and the difference from the checks that DID run every time is the
whole design of this file:

  * the checks that get run are triggered by an EVENT the conductor receives — a finding arrives,
    and the finding is itself the reminder that it must be processed;
  * this one is triggered by a STATE the conductor is IN — "you have just produced a diff".
    Nobody says so. Nothing arrives.

Events get noticed; states get forgotten — and they get forgotten hardest near the close, which is
exactly when diffs are most rushed and this read is worth most. There is a second force pushing the
same way: near the close the conductor optimises for FINISHING, and launching four more subagents
FEELS like adding a step when it wants to remove them. It is the reverse — it is the cheap step that
removes the expensive ones — but the bias does not operate with that arithmetic in front of it. Any
fix that depends on the conductor doing that sum correctly, at that moment, fails again.

So: no more prose. This is a step that returns non-zero and stops the flow, modelled on
`preflight-check.sh` — same place in the procedure (right before `verify-fanout` launches), same
exit contract, same message shape, and the message carries the exact commands that unblock it.

WHAT IT IS NOT, and these boundaries are load-bearing (see the charter in `next-pantalla` §6):

  * It is NOT evidence. It never enters `phase_runs[]`, `checks[]` or `advisory_findings[]`, and it
    adds no requirement to any file under the evidence contract. `validate-state.py` never learns
    this file exists — deliberately: giving the adversary a `*_LENSES` constant there would make it
    a mandatory phase with a full-set requirement, which is precisely the round generator its
    charter forbids. The marker it reads is a SIDE marker, in the same `logs/` directory that
    already holds the other two non-evidence working files of a repair pass
    (`changed-files.txt`, `repair-diff.patch`).
  * It does NOT judge the adversary's answer. `nothing_found` lifts the gate. Four findings lift
    the gate. An adversary that died twice lifts the gate (loudly) — its charter says proceed to
    VERIFY. The only question asked here is whether the four questions were ASKED.
  * It spends no iteration and blocks no unit. Non-zero means "do not launch the fan-out yet",
    exactly as a red pre-flight does.

WHAT IT CANNOT DO, said out loud rather than implied: it cannot prove the workflow ran, only that a
run was recorded against THIS diff. A conductor determined to fabricate the marker can. That is not
the failure being closed — the measured failure was an OMISSION, a state nobody was reminded of, and
an omission is exactly what a mandatory step catches. Turning a forgettable state into a deliberate
lie is the entire win here.

EXIT CONTRACT — the same three states as preflight-check.sh, and the same reading:
  0  the gate does not apply, or the run is recorded: the fan-out may launch
  1  a repair pass with a behaviour diff and no valid record: DO NOT launch the fan-out
  2  the check could not run at all (bad invocation, unreadable state, the classifier moved).
     Still non-zero, still "do not launch" — but it is the CHECK that is broken, not the pass.
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import sys
import tempfile
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parent.parent.parent
STATE = ROOT / ".orchestrator-state"
FEATURES = STATE / "features.json"
VERIFY_FANOUT = ROOT / ".claude" / "workflows" / "verify-fanout.js"
ADVERSARY_WORKFLOW = ROOT / ".claude" / "workflows" / "diff-adversary.js"
MARKER_SCHEMA = "orchestrator.adversary-run.v1"

PHASE = "PHASE"


def say(msg: str) -> None:
    print(f"adversary[{PHASE}]: {msg}", file=sys.stderr)


def out(msg: str) -> None:
    print(f"adversary[{PHASE}]: {msg}")


def cannot_run(msg: str) -> None:
    say(msg)
    raise SystemExit(2)


# ---------------------------------------------------------------------------------------------
# THE DOC/CODE CLASSIFIER IS NOT DEFINED HERE. It is EXTRACTED from verify-fanout.js.
#
# The same question — "did this pass touch any implementation or test code?" — already has exactly
# one answer in this repository: `isDocPath`/`docsOnly` in .claude/workflows/verify-fanout.js, which
# derives the docs-only VERIFY scope (DEC-ORCH-006). Writing a second copy here is the drift this
# repo has already been bitten by: two classifiers, one of them edited, and the pass that VERIFY
# treats as docs-only is not the pass this gate excuses. A Workflow script has no filesystem access,
# so verify-fanout.js cannot read a shared module — which leaves extraction as the only way for the
# two to be the SAME rule rather than two rules that agree today.
#
# When the extraction fails, this exits 2 and refuses to classify. That direction is deliberate and
# it is preflight-check.sh's own ("refusing to report a clean pre-flight it never performed"): a
# classifier that silently falls back to a guess would excuse passes it has no right to excuse, and
# the failure would be invisible — which is the shape of every defect this file exists to close.
#
# What is NOT copied: verify-fanout.js's 150-file CHANGED_CAP. That cap is a prompt-size cost
# heuristic (past it, a file list stops focusing ten lenses and just bloats them), not part of the
# doc/code predicate. 200 changed markdown files still contain no behaviour diff.
# ---------------------------------------------------------------------------------------------
def load_doc_classifier():
    """Return isDocPath(path) -> bool, built from verify-fanout.js's own literals."""
    if not VERIFY_FANOUT.is_file():
        cannot_run(f"{VERIFY_FANOUT.relative_to(ROOT)} is missing, so the docs-only rule cannot be "
                   f"read from the one place that defines it. Refusing to classify this pass.")
    src = VERIFY_FANOUT.read_text(encoding="utf-8")

    m = re.search(r"const\s+DOC_EXTENSION\s*=\s*/(.+?)/i", src)
    if not m:
        cannot_run("cannot find DOC_EXTENSION in verify-fanout.js. The docs-only classifier moved "
                   "or changed shape; this gate reads it from there on purpose and will not guess "
                   "a second copy. Re-point the extraction in adversary-check.py.")
    try:
        doc_ext = re.compile(m.group(1), re.IGNORECASE)
    except re.error as exc:
        cannot_run(f"DOC_EXTENSION in verify-fanout.js is not a regex Python can read ({exc}).")

    body = re.search(r"const\s+isDocPath\s*=\s*(.+?)\nconst\s", src, re.DOTALL)
    if not body:
        cannot_run("cannot find isDocPath in verify-fanout.js. Same reason as above: the predicate "
                   "lives there and is read from there, never re-implemented here.")
    excluded = tuple(re.findall(r"!\s*f\.startsWith\('([^']+)'\)", body.group(1)))
    included = tuple(re.findall(r"(?<![!\w])f\.startsWith\('([^']+)'\)", body.group(1)))
    if not excluded or not included:
        cannot_run(f"isDocPath in verify-fanout.js no longer reads as prefix tests "
                   f"(excluded={list(excluded)}, included={list(included)}). Refusing to classify "
                   f"a pass with a rule this gate cannot prove it read correctly.")

    def is_doc_path(f: str) -> bool:
        if f.startswith(excluded):
            return False
        return bool(doc_ext.search(f)) or f.startswith(included)

    return is_doc_path


def load_adversaries() -> list[str]:
    """The four questions, read from the workflow that asks them — never a second list.

    Same technique validate-structure.sh already uses on this file, and for the same reason: the
    roster is one literal array, and anything that needs to know it reads it from there.
    """
    if not ADVERSARY_WORKFLOW.is_file():
        cannot_run(f"{ADVERSARY_WORKFLOW.relative_to(ROOT)} is missing: there is no workflow to "
                   f"run and no roster of questions to check a run against.")
    src = ADVERSARY_WORKFLOW.read_text(encoding="utf-8")
    src = re.sub(r"//[^\n]*", "", src)
    m = re.search(r"^const ADVERSARIES\s*=\s*\[(.*?)\]", src, re.DOTALL | re.MULTILINE)
    if not m:
        cannot_run("cannot find the ADVERSARIES array in diff-adversary.js.")
    names = re.findall(r"'(diff-adversary-[a-z-]+)'", m.group(1))
    if not names:
        cannot_run("the ADVERSARIES array in diff-adversary.js names no question.")
    return names


# The corpus below is the extraction's own proof, run by validate-structure.sh with --self-check.
# It is not a unit test of the classifier — verify-fanout.js owns that rule and may change it. It
# asserts that this file still READS that rule correctly, which is the only thing that can silently
# break here: a rename in the .js turns extraction into a guess, and a guess in a classifier that
# decides when a gate does not apply is a gate that stops applying. Loud at structure-gate time
# beats silent at repair time, exactly as the lens-set sync gates already work.
#
# The last two rows are the ones with teeth. `.claude/**.md` is NOT documentation: an agent file or
# a SKILL.md is the definition of behaviour of a lens or a command, so editing one is the opposite
# of "no code moved". And one code file makes the whole pass a full pass.
SELF_CHECK_CORPUS = [
    ("blueprint/logic/data.md", True),
    ("README.md", True),
    (".orchestrator-state/evidence/SCR-001/result.json", True),
    ("docs/notes.txt", True),
    (".claude/agents/verify-tests.md", False),
    (".claude/skills/next-pantalla/SKILL.md", False),
    ("web/notas.js", False),
    ("app/notas.py", False),
    ("migrations/0001_notas.sql", False),
]


def self_check(adversaries: list[str]) -> None:
    is_doc = load_doc_classifier()
    wrong = [f"{p} -> {is_doc(p)} (expected {want})"
             for p, want in SELF_CHECK_CORPUS if is_doc(p) is not want]
    if wrong:
        cannot_run("the docs-only classifier extracted from verify-fanout.js no longer agrees with "
                   "what this gate assumes it means: " + "; ".join(wrong) + ". Either the rule in "
                   "verify-fanout.js changed deliberately (update SELF_CHECK_CORPUS here) or the "
                   "extraction is now reading the wrong thing.")
    out(f"self-check OK: {len(adversaries)} questions ({', '.join(adversaries)}); docs-only "
        f"classifier extracted from verify-fanout.js agrees on {len(SELF_CHECK_CORPUS)} paths.")
    raise SystemExit(0)


def load_unit(explicit_id: str | None) -> dict[str, Any]:
    """Resolve the unit exactly as verify-fanout.js's loader does: an explicit id, else the single
    `building` screen (validate-state.py guarantees at most one)."""
    if not FEATURES.is_file():
        cannot_run(f"{FEATURES.relative_to(ROOT)} not found; cannot tell which unit is being "
                   f"repaired. Run this from a project with orchestrator state.")
    try:
        data = json.loads(FEATURES.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, UnicodeDecodeError) as exc:
        cannot_run(f"{FEATURES.relative_to(ROOT)} is not readable JSON ({exc}).")
    screens = data.get("screens") if isinstance(data, dict) else None
    if not isinstance(screens, list) or not screens:
        cannot_run("features.json carries no screens[]; there is no repair pass to gate.")
    if explicit_id:
        hits = [s for s in screens if isinstance(s, dict) and s.get("id") == explicit_id]
        if len(hits) != 1:
            cannot_run(f"{len(hits)} screens match id {explicit_id!r}; expected exactly one.")
        return hits[0]
    building = [s for s in screens if isinstance(s, dict) and s.get("status") == "building"]
    if len(building) != 1:
        cannot_run(f"{len(building)} screens are in status 'building' "
                   f"({[s.get('id') for s in building]}); leave exactly one, or pass the id "
                   f"explicitly: python3 .orchestrator/scripts/adversary-check.py \"{PHASE}\" <ID>")
    return building[0]


def unit_iteration(unit: dict[str, Any]) -> int:
    cp = unit.get("checkpoint")
    if isinstance(cp, dict):
        try:
            return int(cp.get("iteration", 0) or 0)
        except (TypeError, ValueError):
            return 0
    return 0


def read_changed_files(path: Path) -> tuple[int, list[str]]:
    """The `# iteration:` header and the literal path list, parsed exactly as the VERIFY loader
    is told to parse them (next-pantalla §5): -1 when the header is missing or unparseable."""
    header = -1
    paths: list[str] = []
    for line in path.read_text(encoding="utf-8").splitlines():
        raw = line.strip()
        if not raw:
            continue
        if raw.startswith("#"):
            m = re.match(r"#\s*iteration:\s*(-?\d+)", raw)
            if m and header == -1:
                header = int(m.group(1))
            continue
        paths.append(raw.replace("\\", "/").removeprefix("./"))
    return header, paths


def sha256_of(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def unblock_text(sid: str, iteration: int, diff_path: Path, marker_path: Path) -> str:
    # Step 3 goes through a FILE, and that is not a style choice. The obvious form —
    # `printf '%s' '<the JSON>' | ... --record -` — wraps LLM-written prose in single quotes, and
    # the four adversaries write English: one apostrophe in a `detail` field ("doesn't", "it's", a
    # possessive) closes the quote early and the unblock command dies of a shell syntax error. That
    # is the worst possible place for friction: it is the one command that lifts the gate, offered
    # at the moment the conductor is closest to the close. The conductor has a Write tool; asking it
    # to shell-quote arbitrary text instead is the mistake.
    return (
        f"  Unblock by running the step, in this order:\n"
        f"    1) {{ echo \"# iteration: {iteration}\"; git add -A && git diff --cached; }} \\\n"
        f"         > {diff_path.relative_to(ROOT)}\n"
        f"    2) launch .claude/workflows/diff-adversary.js with args {{\"screen_id\": \"{sid}\"}}\n"
        f"    3) Write what it returned, verbatim, to "
        f"{marker_path.parent.relative_to(ROOT)}/adversary-return.json (use the Write tool — the\n"
        f"       return is LLM prose and one apostrophe in it breaks a shell-quoted pipe), then:\n"
        f"         python3 .orchestrator/scripts/adversary-check.py \"{PHASE}\" {sid} \\\n"
        f"           --record {marker_path.parent.relative_to(ROOT)}/adversary-return.json\n"
        f"    4) fold any finding into THIS repair pass (never a new round), then re-run:\n"
        f"         python3 .orchestrator/scripts/adversary-check.py \"{PHASE}\" {sid}\n"
        f"  Marker it looks for: {marker_path.relative_to(ROOT)}"
    )


def do_record(unit: dict[str, Any], iteration: int, source: str,
              adversaries: list[str], diff_path: Path, marker_path: Path) -> None:
    """Write the side marker from the workflow's OWN return value.

    The conductor pipes what `diff-adversary.js` returned rather than hand-writing a JSON, and this
    computes the iteration and the diff hash itself. That is not convenience: a marker the conductor
    has to assemble by hand is friction on the hot path, and friction on the hot path is how the
    step gets routed around — which is the failure this whole file exists to close.
    """
    sid = unit.get("id")
    if not diff_path.is_file():
        cannot_run(f"{diff_path.relative_to(ROOT)} does not exist, so there is nothing to bind this "
                   f"run to. Write the repair diff FIRST, then launch the workflow, then record it.")
    if diff_path.stat().st_size == 0:
        cannot_run(f"{diff_path.relative_to(ROOT)} is empty (0 bytes): the four agents were handed "
                   f"no diff to read. Re-write it and re-launch the workflow.")
    try:
        payload = sys.stdin.read() if source == "-" else Path(source).read_text(encoding="utf-8")
    except OSError as exc:
        cannot_run(f"cannot read the workflow return from {source!r} ({exc}).")
    try:
        ret = json.loads(payload)
    except json.JSONDecodeError as exc:
        cannot_run(f"the workflow return is not JSON ({exc}). Pipe what diff-adversary.js returned, "
                   f"verbatim.")
    if not isinstance(ret, dict):
        cannot_run("the workflow return must be a JSON object.")

    ret_sid = ret.get("screen_id")
    if ret_sid is None:
        # diff-adversary.js returns screen_id:null together with not_run_reason when it was launched
        # without args.screen_id. It read no diff and asked nothing — recording it would certify a
        # run that did not happen. Refused HERE, at record time, rather than by blocking at gate
        # time: the charter says this step never blocks a unit, and a malformed LAUNCH is a
        # different thing from an adversary that failed to answer.
        cannot_run(f"this return says the workflow never read a diff "
                   f"(not_run_reason: {ret.get('not_run_reason')!r}). Re-launch "
                   f"diff-adversary.js with args {{\"screen_id\": \"{sid}\"}} and record that.")
    if ret_sid != sid:
        cannot_run(f"the workflow return is for {ret_sid!r} but this repair pass is on {sid!r}. "
                   f"A marker borrowed from a sibling unit certifies nothing about this diff.")

    answered = ret.get("answered") if isinstance(ret.get("answered"), list) else []
    failed = ret.get("failed_adversaries") if isinstance(ret.get("failed_adversaries"), list) else []
    named = {a.get("adversary") for a in answered if isinstance(a, dict)} | {f for f in failed}
    missing = [a for a in adversaries if a not in named]
    if missing:
        cannot_run(f"the workflow return accounts for neither an answer nor a failure from "
                   f"{missing}. Every one of the {len(adversaries)} questions must appear in "
                   f"answered[] or in failed_adversaries[]; a return missing one is not a run.")

    findings = ret.get("findings") if isinstance(ret.get("findings"), list) else []
    marker = {
        "schema_version": MARKER_SCHEMA,
        "unit": sid,
        "iteration": iteration,
        # `diff` stays because a human opening this file needs to know WHICH patch the hash below
        # refers to. `workflow` and `clean` were dropped: nothing reads them, the first is implied
        # by the file's own name and the second is recomputable from the two fields under it — a
        # marker carrying fields no reader consumes is the same defect as prose with no control.
        "diff": str(diff_path.relative_to(ROOT)),
        "diff_sha256": sha256_of(diff_path),
        "answered": [{"adversary": a.get("adversary"), "verdict": a.get("verdict")}
                     for a in answered if isinstance(a, dict)],
        "failed_adversaries": list(failed),
        "retried_adversaries": list(ret.get("retried_adversaries") or []),
        "findings": len(findings),
    }
    marker_path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=str(marker_path.parent), prefix=".adversary-", suffix=".tmp")
    with os.fdopen(fd, "w", encoding="utf-8") as fh:
        json.dump(marker, fh, ensure_ascii=False, indent=2)
        fh.write("\n")
    os.replace(tmp, marker_path)

    verdicts = ", ".join(f"{a['adversary'].removeprefix('diff-adversary-')}={a['verdict']}"
                         for a in marker["answered"] if a.get("adversary"))
    out(f"recorded {sid} iteration {iteration} -> {marker_path.relative_to(ROOT)} "
        f"({len(marker['answered'])}/{len(adversaries)} answered: {verdicts or 'none'}; "
        f"{marker['findings']} finding(s)). Not evidence: nothing reads this but the gate.")
    if failed:
        say(f"{failed} returned nothing twice. That is NOT 'found nothing' — those questions went "
            f"unasked. The gate still lifts (this step never blocks a unit), but do not read the "
            f"pass as adversary-clean.")
    raise SystemExit(0)


def main() -> None:
    global PHASE
    argv = sys.argv[1:]
    record_from: str | None = None
    if "--record" in argv:
        i = argv.index("--record")
        if i + 1 >= len(argv):
            cannot_run("--record needs a source: '-' for stdin, or a path to the workflow return.")
        record_from = argv[i + 1]
        argv = argv[:i] + argv[i + 2:]
    positional = [a for a in argv if not a.startswith("--")]
    if positional:
        PHASE = positional[0]
    explicit_id = positional[1] if len(positional) > 1 else None

    adversaries = load_adversaries()
    if "--self-check" in sys.argv:
        self_check(adversaries)
    unit = load_unit(explicit_id)
    sid = unit.get("id")
    if not isinstance(sid, str) or not sid:
        cannot_run("the resolved unit has no id.")
    status = unit.get("status")
    iteration = unit_iteration(unit)

    logs = STATE / "evidence" / sid / "logs"
    diff_path = logs / "repair-diff.patch"
    marker_path = logs / f"adversary-{iteration}.json"

    if record_from is not None:
        do_record(unit, iteration, record_from, adversaries, diff_path, marker_path)

    # ------------------------------------------------------------------------------------------
    # WHEN THIS DOES NOT APPLY, and it matters as much as when it does. A control that cries wolf
    # is a control someone eventually deletes, and that is worse than never having had it.
    #
    # Both exemptions are DERIVED from state the procedure already keeps — no new field, nothing
    # for the conductor to declare, and therefore nothing it can declare wrongly to escape.
    # ------------------------------------------------------------------------------------------

    # (1) The unit's first build pass. next-pantalla §1 opens a unit at iteration 0 and §6
    # increments on each repair, so `iteration >= 1` IS the procedure's own definition of "this is
    # a repair pass" — the same one verify-fanout.js uses to decide a scope is worth honouring.
    # The exception is a /fix repairing an `accepted` unit IN PLACE: its status never changes and
    # it carries no checkpoint, yet every pass of it repairs code that is already proven, which is
    # the very thing an adversary reads. There is no first-build pass to excuse there.
    if iteration < 1 and status != "accepted":
        out(f"{sid} is at iteration {iteration} (status {status!r}): first build pass, not a "
            f"repair. The adversary reads a repair diff and there is none. Not applicable.")
        raise SystemExit(0)

    # (2) A docs-only pass. All four questions are about the shape of code, and this diff has none.
    # The classification is verify-fanout.js's, extracted rather than re-implemented (see above),
    # so a pass this gate excuses is exactly a pass VERIFY scopes to its four doc<->code lenses.
    changed_fp = logs / "changed-files.txt"
    if changed_fp.is_file():
        header, paths = read_changed_files(changed_fp)
        if header != iteration:
            # Same staleness guard verify-fanout.js applies to the same file, and for the sharper
            # reason here: a list from a previous pass would excuse a pass it never described.
            say(f"ignoring {changed_fp.relative_to(ROOT)} — it declares iteration {header} but this "
                f"pass is iteration {iteration}. A stale list cannot prove this pass is docs-only.")
        elif paths and all(load_doc_classifier()(p) for p in paths):
            out(f"{sid} iteration {iteration} is a DOCS-ONLY pass ({len(paths)} file(s), none of "
                f"them implementation or test code). The four questions are about the shape of "
                f"code and this diff contains none. Not applicable.")
            raise SystemExit(0)

    # ------------------------------------------------------------------------------------------
    # It applies. From here every exit is 1 until a valid record is found.
    # ------------------------------------------------------------------------------------------
    hint = (f"  This is a REPAIR pass on {sid} (iteration {iteration}) and its diff has not been "
            f"read adversarially.\n"
            f"  Four read-only agents on a bounded diff cost ~3 minutes; the fan-out behind this "
            f"launch is 12 subagents, and a finding it raises costs a whole repair round on top. "
            f"This is the cheap step that removes the expensive ones, not an extra one.\n")

    if diff_path.exists() and not diff_path.is_file():
        cannot_run(f"{diff_path.relative_to(ROOT)} exists but is not a file (a directory?). Write "
                   f"the repair diff there; reporting it as 'never written' would send the reader "
                   f"to look for a missing step instead of a wrong path.")
    if not diff_path.is_file():
        say(f"{diff_path.relative_to(ROOT)} does not exist: the repair diff was never written, so "
            f"the four questions were never asked.\n" + hint
            + unblock_text(sid, iteration, diff_path, marker_path))
        raise SystemExit(1)
    if not marker_path.is_file():
        say(f"no diff-adversary run is recorded for this pass.\n" + hint
            + unblock_text(sid, iteration, diff_path, marker_path))
        raise SystemExit(1)

    try:
        marker = json.loads(marker_path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, UnicodeDecodeError) as exc:
        say(f"{marker_path.relative_to(ROOT)} is not readable JSON ({exc}); it certifies nothing.\n"
            + unblock_text(sid, iteration, diff_path, marker_path))
        raise SystemExit(1)
    if not isinstance(marker, dict):
        say(f"{marker_path.relative_to(ROOT)} must be a JSON object.\n"
            + unblock_text(sid, iteration, diff_path, marker_path))
        raise SystemExit(1)

    if marker.get("unit") != sid:
        say(f"{marker_path.relative_to(ROOT)} records unit {marker.get('unit')!r}, not {sid!r}. A "
            f"marker borrowed from another unit certifies nothing about this diff.\n"
            + unblock_text(sid, iteration, diff_path, marker_path))
        raise SystemExit(1)
    if marker.get("iteration") != iteration:
        say(f"{marker_path.relative_to(ROOT)} records iteration {marker.get('iteration')!r}, but "
            f"this pass is iteration {iteration}.\n"
            + unblock_text(sid, iteration, diff_path, marker_path))
        raise SystemExit(1)

    # The binding that makes the marker about THIS diff rather than about this iteration number.
    # It is what closes the one case the filename cannot: a /fix repairing an `accepted` unit in
    # place runs several passes that all resolve to iteration 0, so a marker from the first pass
    # would silently lift the gate for the second. The contract it assumes is the one §6 already
    # states — the patch is written ONCE per pass, before the workflow, and is not rewritten after
    # a finding is folded (the fold's proof is the verify-fanout right behind it, never a second
    # adversary run).
    actual = sha256_of(diff_path)
    if marker.get("diff_sha256") != actual:
        say(f"{marker_path.relative_to(ROOT)} was recorded against a different diff "
            f"(recorded {str(marker.get('diff_sha256'))[:12]}..., on disk {actual[:12]}...).\n"
            f"  Either this is a NEW repair pass whose adversary has not run — run it — or the "
            f"patch was rewritten after the workflow read it, which §6 forbids: it is written once "
            f"per pass, before the four questions, and the fold is proven by VERIFY, not by a "
            f"second adversary run.\n"
            + unblock_text(sid, iteration, diff_path, marker_path))
        raise SystemExit(1)

    answered = marker.get("answered") if isinstance(marker.get("answered"), list) else []
    failed = marker.get("failed_adversaries") if isinstance(marker.get("failed_adversaries"), list) else []
    named = {a.get("adversary") for a in answered if isinstance(a, dict)} | {f for f in failed}
    missing = [a for a in adversaries if a not in named]
    if missing:
        say(f"{marker_path.relative_to(ROOT)} accounts for neither an answer nor a failure from "
            f"{missing}: those questions were never asked.\n"
            + unblock_text(sid, iteration, diff_path, marker_path))
        raise SystemExit(1)

    # It ran. Nothing below judges WHAT it found — `nothing_found` is a complete answer and lifts
    # the gate exactly as a finding does. The bar is on the finding, never on the count, and a gate
    # that expected a rate would be a quota by another name.
    verdicts = ", ".join(f"{a['adversary'].removeprefix('diff-adversary-')}={a.get('verdict')}"
                         for a in answered if isinstance(a, dict) and a.get("adversary"))
    if failed:
        say(f"{failed} returned nothing twice on this pass. That is a question that went unasked, "
            f"not a clean answer. The gate lifts — this step never blocks a unit — but do not read "
            f"the pass as adversary-clean.")
    out(f"{sid} iteration {iteration}: diff-adversary run recorded for this diff "
        f"({len(answered)}/{len(adversaries)} answered: {verdicts or 'none'}; "
        f"{marker.get('findings', 0)} finding(s)). Fan-out may launch.")
    raise SystemExit(0)


if __name__ == "__main__":
    main()
