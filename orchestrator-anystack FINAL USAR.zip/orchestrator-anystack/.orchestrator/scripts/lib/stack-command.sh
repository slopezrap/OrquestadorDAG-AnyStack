#!/usr/bin/env bash
# Shared resolver for the <COMMAND_*> declarations in .claude/rules/stack.md.
#
# Sourced by reset-test-data.sh and preflight-check.sh. It lives here because both need the SAME
# reading of the same file, and a second copy of this parser would drift the first time either
# script learned something the other did not — the hand-kept-duplicate defect this repo refuses
# elsewhere (see the lens-set sync gate in validate-structure.sh).
#
# The marker is the declaration. A comment line ending in "(KEY)" declares that the NEXT
# non-comment line is that command. This matters because stack.md is a living document: prose
# that merely NAMES a key ("read by reset-test-data.sh, which uses COMMAND_RESET_TEST_DATA") is
# normal, and adopting the line after it would run the wrong command and report success — the
# single worst outcome available to a script whose whole job is to be trusted. Only "(KEY)" counts.
#
# stack_command <KEY> <stack-file>  ->  prints exactly one of:
#     OK <command>        a single declaration resolved to a command line
#     MALFORMED <rest>    the marker line carries trailing content (the command must be on the NEXT line)
#     AMBIGUOUS <n>       the key is declared n>1 times; refusing to guess which is current
#     <empty>             not declared at all
# The caller decides what each case means: a missing reset command is fine, a missing build
# command is fine, a DECLARED one that fails is not — and that judgement is deliberately not made
# here.
stack_command() {
  awk -v key="$1" '
    BEGIN { marker = "(" key ")" }
    /^[[:space:]]*#/ && index($0, marker) {
      markers++
      rest = substr($0, index($0, marker) + length(marker))
      sub(/^[[:space:]]+/, "", rest)
      sub(/[[:space:]]+$/, "", rest)
      if (rest != "" && rest !~ /^#/) { bad = "MALFORMED " rest }
      found = 1
      next
    }
    found && !value {
      line = $0
      sub(/^[[:space:]]+/, "", line)
      sub(/[[:space:]]+$/, "", line)
      if (line == "" || line ~ /^#/) next
      if (line ~ /^```/) { found = 0; next }
      value = line
      found = 0
      next
    }
    END {
      if (markers > 1) { print "AMBIGUOUS " markers; exit }
      if (bad != "")   { print bad; exit }
      if (value != "") { print "OK " value }
    }
  ' "$2"
}
