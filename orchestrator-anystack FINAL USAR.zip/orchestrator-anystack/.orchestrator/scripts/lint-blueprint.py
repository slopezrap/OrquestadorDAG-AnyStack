#!/usr/bin/env python3
"""Deterministic blueprint linter — no LLM, stdlib only.

Runs BEFORE the research fan-out spends tokens (/init-build step 1,
/next-pantalla after CLARIFY writes, /reslice step 1) so the pipeline starts
from a referentially intact spec instead of discovering broken IDs mid-build.

ERRORS (exit 1) — structurally broken blueprint:
  - duplicate IDs (same ID defined in more than one ``` block)
  - dangling references (after/applies/depends_on/related_screens/product_refs/
    data_refs/engine_refs pointing to an ID no file defines)
  - dependency cycles in SCREENS after[]

WARNINGS (exit 0, printed) — incomplete but not broken; /init-build turns these
into CLARIFY questions instead of guessing:
  - leftover stubs ("Pendiente de definir", "TBD", unresolved <PLACEHOLDER> tokens)
  - screen blocks without acceptance criteria
  - non-ID tokens inside a reference list
  - references that resolve only to a heading (no ``` block defines them)

An ID counts as DEFINED only when a ```logic/```screen block declares it via
`id:`. A heading alone is a title, not a definition — otherwise an empty
section would satisfy referential integrity and duplicate detection (which
only sees blocks) would disagree with it.
"""
from __future__ import annotations

import re
import sys
from pathlib import Path

ROOT = Path.cwd()
BLUEPRINT = ROOT / "blueprint"

ID_PATTERN = re.compile(r"^(?:BR|SCR|DOM|APP|CORE|JOUR|PERM|ST|ERR|INT|UI|DATA|UC|ENG|PIPE|DEC)-[A-Z0-9][A-Z0-9-]*$")
HEADING_ID = re.compile(r"^#{2,4}\s+((?:BR|SCR|DOM|APP|CORE|JOUR|PERM|ST|ERR|INT|UI|DATA|UC|ENG|PIPE|DEC)-[A-Z0-9][A-Z0-9-]*)\b")
FENCED_BLOCK = re.compile(r"```(screen|logic)\n(.*?)```", re.DOTALL)
REF_KEYS = ("after", "applies", "depends_on", "related_screens", "product_refs", "data_refs", "engine_refs",
            "pipeline_refs", "feeds", "writes", "consumed_by", "related_engines",
            "supersedes", "written_to", "affects_screens", "reopens")
STUB_MARKERS = ("Pendiente de definir", "Pendiente.", "PENDIENTE", "por definir", "TBD", "TODO", "To be defined")
# <UPPER_SNAKE> scaffold tokens. The {2,} floor (4+ chars inside <>) avoids
# false positives on HTML (<b>, <br>) and generics (<T>).
PLACEHOLDER = re.compile(r"<[A-Z][A-Z0-9_]{2,}>")
PLACEHOLDER_SAMPLE = 5

errors: list[str] = []
warnings: list[str] = []


def parse_list(raw: str) -> list[str]:
    raw = raw.strip()
    if not (raw.startswith("[") and raw.endswith("]")):
        return []
    inner = raw[1:-1].strip()
    if not inner:
        return []
    return [tok.strip().strip("\"'") for tok in inner.split(",") if tok.strip()]


def blueprint_files() -> list[Path]:
    files = [BLUEPRINT / "PRODUCT.md", BLUEPRINT / "SCREENS.md", BLUEPRINT / "DECISIONS.md"]
    files += sorted((BLUEPRINT / "logic").glob("*.md"))
    return [f for f in files if f.exists()]


def main() -> None:
    if not BLUEPRINT.exists():
        print("lint-blueprint: missing blueprint/ directory", file=sys.stderr)
        raise SystemExit(1)

    defined: dict[str, list[str]] = {}   # id -> [locations of ``` block definitions]
    known_ids: set[str] = set()          # block ids only — the real definitions
    heading_ids: set[str] = set()        # ids seen as a title (checked only after known_ids)
    refs: list[tuple[str, str, str]] = []  # (source_location, key, token)
    after_edges: dict[str, list[str]] = {}

    for path in blueprint_files():
        rel = str(path.relative_to(ROOT))
        text = path.read_text(encoding="utf-8")

        placeholder_hits: dict[str, int] = {}
        for lineno, line in enumerate(text.splitlines(), 1):
            heading = HEADING_ID.match(line)
            if heading:
                heading_ids.add(heading.group(1))
            for marker in STUB_MARKERS:
                if marker in line:
                    warnings.append(f"{rel}:{lineno}: stub marker '{marker}' — still undefined")
                    break
            for token in PLACEHOLDER.findall(line):
                placeholder_hits[token] = placeholder_hits.get(token, 0) + 1

        # One warning per file, not per line: a fresh copy of the templates has
        # hundreds of these and /init-build needs the signal, not the noise.
        if placeholder_hits:
            distinct = sorted(placeholder_hits)
            sample = ", ".join(distinct[:PLACEHOLDER_SAMPLE])
            extra = len(distinct) - PLACEHOLDER_SAMPLE
            if extra > 0:
                sample += f", +{extra} more"
            warnings.append(
                f"{rel}: {sum(placeholder_hits.values())} unresolved placeholder token(s) "
                f"({len(distinct)} distinct: {sample}) — fill them in or turn them into CLARIFY questions"
            )

        for kind, body in FENCED_BLOCK.findall(text):
            block_id = None
            id_match = re.search(r"^id:\s*([^\s#]+)\s*$", body, re.MULTILINE)
            if id_match:
                block_id = id_match.group(1).strip().strip("\"'")
                if ID_PATTERN.match(block_id):
                    defined.setdefault(block_id, []).append(rel)
                    known_ids.add(block_id)
                elif "<" in block_id:
                    warnings.append(f"{rel}: block id '{block_id}' is an unresolved placeholder")
                else:
                    warnings.append(f"{rel}: block id '{block_id}' does not match any known ID prefix")
            else:
                warnings.append(f"{rel}: {kind} block without id:")

            if kind == "screen" and "acceptance:" not in body:
                warnings.append(f"{rel}: screen block {block_id or '<no-id>'} has no acceptance criteria")

            for key in REF_KEYS:
                for ref_match in re.finditer(rf"^\s*{key}:\s*(\[.*?\])\s*$", body, re.MULTILINE):
                    tokens = parse_list(ref_match.group(1))
                    for tok in tokens:
                        refs.append((f"{rel} ({block_id or kind})", key, tok))
                    if key == "after" and block_id and ID_PATTERN.match(block_id):
                        after_edges.setdefault(block_id, []).extend(
                            t for t in tokens if ID_PATTERN.match(t)
                        )

    for bid, locations in sorted(defined.items()):
        if len(locations) > 1:
            errors.append(f"duplicate ID {bid} defined in: {', '.join(locations)}")

    for source, key, tok in refs:
        if tok == "ALL":
            continue  # documented sentinel (shell rules: every ui screen)
        if "<" in tok or ">" in tok:
            warnings.append(f"{source}: {key} contains unresolved placeholder '{tok}'")
            continue
        if not ID_PATTERN.match(tok):
            warnings.append(f"{source}: {key} contains non-ID token '{tok}'")
            continue
        if tok not in known_ids:
            if tok in heading_ids:
                warnings.append(
                    f"{source}: {key} references {tok}, which only exists as a heading — "
                    "no ```logic/```screen block defines it"
                )
                continue
            errors.append(f"{source}: {key} references undefined ID {tok}")

    visiting: set[str] = set()
    visited: set[str] = set()

    def dfs(node: str, stack: list[str]) -> None:
        if node in visited:
            return
        if node in visiting:
            errors.append("after[] dependency cycle: " + " -> ".join(stack + [node]))
            return
        visiting.add(node)
        stack.append(node)
        for dep in after_edges.get(node, []):
            dfs(dep, stack)
        stack.pop()
        visiting.discard(node)
        visited.add(node)

    for node in sorted(after_edges):
        dfs(node, [])

    for warning in warnings:
        print(f"warning: {warning}")
    if errors:
        for error in errors:
            print(f"error: {error}", file=sys.stderr)
        print(f"blueprint lint FAILED: {len(errors)} error(s), {len(warnings)} warning(s)", file=sys.stderr)
        raise SystemExit(1)
    print(f"blueprint lint OK ({len(warnings)} warning(s))")


if __name__ == "__main__":
    main()
