#!/usr/bin/env bash
# End-to-end smoke test of the orchestrator's deterministic machinery, using the
# golden-path example (.orchestrator/examples/golden-path). Copies the scaffold to
# a temp dir, mounts the golden blueprint + canonical state, and checks:
#   POSITIVE: blueprint lint, state gate, --emit-status projections, structure +
#             lens-set sync, hook on a valid state.
#   NEGATIVE: the gate MUST reject — incomplete lens set, borrowed evidence,
#             cross-layer value drift, debugger cap exceeded, two units building,
#             missing artifact; and the hook MUST reject corrupted features.json.
# Exit 0 only if every expectation holds.
set -uo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
GP="$ROOT/.orchestrator/examples/golden-path"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT

WORK="$TMP/orch"
mkdir -p "$WORK"
cp -R "$ROOT/." "$WORK/"
rm -rf "$WORK/blueprint" "$WORK/.orchestrator-state"
cp -R "$GP/blueprint" "$WORK/blueprint"
cp -R "$GP/state" "$WORK/.orchestrator-state"
# An initialized project has its stack commands resolved; the golden path carries a resolved
# stack.md fixture so the gate's <COMMAND_*> backstop sees a real (finished) project, not the
# repo scaffold's placeholders.
cp "$GP/stack.md" "$WORK/.claude/rules/stack.md"
cd "$WORK"
# El hook resuelve el proyecto por CLAUDE_PROJECT_DIR: fijarlo al arbol temporal o,
# si viene heredado del entorno, el smoke validaria el repo real en vez de este.
export CLAUDE_PROJECT_DIR="$WORK"

pass=0; fail=0
ok()   { echo "PASS  $1"; pass=$((pass+1)); }
bad()  { echo "FAIL  $1"; fail=$((fail+1)); }
expect_ok()   { local d="$1"; shift; if "$@" >/dev/null 2>&1; then ok "$d"; else bad "$d"; fi; }
expect_fail() { local d="$1"; shift; if "$@" >/dev/null 2>&1; then bad "$d (debería haber fallado)"; else ok "$d"; fi; }
# Negativo con motivo: exigir que el gate falle POR el invariante que el caso dice
# probar, no por un daño colateral de la mutación (un expect_fail a secas se queda
# en verde aunque el invariante esté desactivado).
expect_fail_msg() {
  local d="$1" pat="$2"; shift 2
  local out rc
  out="$("$@" 2>&1)"; rc=$?
  if [ "$rc" -eq 0 ]; then bad "$d (debería haber fallado)"
  elif printf '%s' "$out" | grep -q "$pat"; then ok "$d"
  else bad "$d (falló por otro motivo: $out)"; fi
}
# Positivo con motivo: exigir que un script no-fatal salga 0 Y haya hecho lo que dice hacer.
# Un expect_ok a secas se queda en verde con un script que sale 0 sin actuar — que es
# exactamente el fallo que reset-test-data.sh podría tener y nadie notaría.
expect_ok_msg() {
  local d="$1" pat="$2"; shift 2
  local out rc
  out="$("$@" 2>&1)"; rc=$?
  if [ "$rc" -ne 0 ]; then bad "$d (salió $rc, debería salir 0)"
  elif printf '%s' "$out" | grep -qF "$pat"; then ok "$d"
  else bad "$d (salió 0 pero no hizo lo que dice: $out)"; fi
}

FEAT=".orchestrator-state/features.json"
RES=".orchestrator-state/evidence/SCR-001/result.json"

echo "== golden path: positivos =="
expect_ok "lint-blueprint: blueprint golden sin errores" python3 .orchestrator/scripts/lint-blueprint.py
expect_ok "state gate: estado canónico valida" python3 .orchestrator/scripts/validate-state.py
expect_ok "emit-status: escribe proyecciones" python3 .orchestrator/scripts/validate-state.py --emit-status
expect_ok "status.json: 2 accepted + 1 verified, SCR-001 esperando accept" python3 -c "
import json
d = json.load(open('.orchestrator-state/status.json'))
assert d['schema_version'] == 'orchestrator.status.v1'
assert d['counts']['accepted'] == 2 and d['counts']['verified'] == 1
assert d['verified_awaiting_accept'] == ['SCR-001'] and d['building'] is None
"
expect_ok "evidence/index.json: 3 unidades con sus fases" python3 -c "
import json
d = json.load(open('.orchestrator-state/evidence/index.json'))
assert len(d['screens']) == 3
scr = next(s for s in d['screens'] if s['screen_id'] == 'SCR-001')
assert {p['phase'] for p in scr['phases']} == {'RESEARCH','EXPLORE','DEVELOP','VERIFY','VALIDATE','REVIEW'}
"
expect_ok "estructura + sincronía de lentes .js↔.py" bash .orchestrator/scripts/validate-structure.sh
expect_ok "hook: comando Bash sobre estado válido pasa" bash -c 'echo "{\"tool_input\":{\"command\":\"cat .orchestrator-state/features.json\"}}" | bash .claude/hooks/validate-state.sh'

echo "== golden path: negativos (el gate debe rechazar) =="
cp "$RES" "$TMP/res.bak"; cp "$FEAT" "$TMP/feat.bak"

python3 - <<'PY'
import json
p = '.orchestrator-state/evidence/SCR-001/result.json'
d = json.load(open(p))
for run in d['phase_runs']:
    if run['phase'] == 'VERIFY':
        run['lenses'] = [l for l in run['lenses'] if l != 'verify-coherence']
json.dump(d, open(p, 'w'), ensure_ascii=False, indent=2)
PY
expect_fail "rechaza VERIFY con set de lentes incompleto (sin verify-coherence)" python3 .orchestrator/scripts/validate-state.py
cp "$TMP/res.bak" "$RES"

python3 - <<'PY'
import json
p = '.orchestrator-state/evidence/SCR-001/result.json'
d = json.load(open(p)); d['screen_id'] = 'SCR-FOUNDATION-SHELL'
json.dump(d, open(p, 'w'), ensure_ascii=False, indent=2)
PY
expect_fail "rechaza evidencia prestada (screen_id de otra pantalla)" python3 .orchestrator/scripts/validate-state.py
cp "$TMP/res.bak" "$RES"

python3 - <<'PY'
import json
p = '.orchestrator-state/evidence/SCR-001/result.json'
d = json.load(open(p)); d['data_engine_assertions'][0]['ui_value'] = 'Comprar té'
json.dump(d, open(p, 'w'), ensure_ascii=False, indent=2)
PY
expect_fail "recomputa same_value: deriva db/ui ('café' vs 'té')" python3 .orchestrator/scripts/validate-state.py
cp "$TMP/res.bak" "$RES"

python3 - <<'PY'
import json
p = '.orchestrator-state/features.json'
d = json.load(open(p))
next(s for s in d['screens'] if s['id'] == 'SCR-001')['checkpoint'] = {'phase': 'VERIFY', 'iteration': 4}
json.dump(d, open(p, 'w'), ensure_ascii=False, indent=2)
PY
expect_fail "rechaza debugger loop pasado del tope (iteration 4 > 3)" python3 .orchestrator/scripts/validate-state.py
cp "$TMP/feat.bak" "$FEAT"

python3 - <<'PY'
import json
p = '.orchestrator-state/features.json'
d = json.load(open(p))
for sid in ('SCR-FOUNDATION-SCHEMA', 'SCR-FOUNDATION-SHELL'):
    s = next(x for x in d['screens'] if x['id'] == sid)
    s['status'] = 'building'; s['passes'] = False
# El resto del estado queda coherente para que el UNICO fallo posible sea el
# invariante `building <= 1`: las dos unidades quedan independientes (si SHELL
# siguiera dependiendo de SCHEMA fallaria por la dependencia) y el summary se
# recalcula. Verificado: neutralizando el invariante, el gate vuelve a pasar.
next(x for x in d['screens'] if x['id'] == 'SCR-FOUNDATION-SHELL')['after'] = []
if isinstance(d.get('summary'), dict):
    counts = {}
    for s in d['screens']:
        counts[s['status']] = counts.get(s['status'], 0) + 1
    for k in d['summary']:
        if k != 'total':
            d['summary'][k] = counts.get(k, 0)
json.dump(d, open(p, 'w'), ensure_ascii=False, indent=2)
PY
expect_fail_msg "rechaza dos unidades en building a la vez" "more than one unit is building" \
  python3 .orchestrator/scripts/validate-state.py
cp "$TMP/feat.bak" "$FEAT"

mv .orchestrator-state/evidence/SCR-001/screenshots/success.png "$TMP/shot.bak"
expect_fail "rechaza PASS con artefacto ausente (screenshot borrado)" python3 .orchestrator/scripts/validate-state.py
mv "$TMP/shot.bak" .orchestrator-state/evidence/SCR-001/screenshots/success.png

# VALIDATE dejó de ser solo-UI: una unidad que cita PIPE-* (o ENG-*) debe PROBAR que el
# pipeline/motor corrió de verdad. Verificarlo estáticamente ya no basta para llegar a verified.
python3 - <<'PY'
import json
p = '.orchestrator-state/evidence/SCR-001/result.json'
d = json.load(open(p))
for run in d['phase_runs']:
    if run['phase'] == 'VALIDATE':
        run['lenses'] = [l for l in run['lenses'] if l != 'validate-pipeline']
json.dump(d, open(p, 'w'), ensure_ascii=False, indent=2)
PY
expect_fail "rechaza unidad que cita PIPE-001 sin validate-pipeline en vivo" python3 .orchestrator/scripts/validate-state.py
cp "$TMP/res.bak" "$RES"

echo 'esto ya no es json' > "$FEAT"
if echo "{\"tool_input\":{\"file_path\":\"$WORK/$FEAT\"}}" | bash .claude/hooks/validate-state.sh >/dev/null 2>&1; then
  bad "hook rechaza features.json corrupto (debería haber fallado)"
else
  ok "hook rechaza features.json corrupto"
fi
cp "$TMP/feat.bak" "$FEAT"

# Ralph: build-loop encadena sin aceptar. Construir sobre una dependencia `verified` es LEGAL
# (permiso para trabajar); aceptar saltandose el orden de after[] NO lo es (permiso para dar por
# bueno). Sin el primero, /build-loop solo avanzaba un nivel del DAG por ejecucion.
python3 - <<'PY'
import json
p = '.orchestrator-state/features.json'
d = json.load(open(p))
for s in d['screens']:
    if s['status'] == 'accepted':
        s['status'] = 'verified'
counts = {}
for s in d['screens']:
    counts[s['status']] = counts.get(s['status'], 0) + 1
for k in d['summary']:
    if k != 'total':
        d['summary'][k] = counts.get(k, 0)
json.dump(d, open(p, 'w'), ensure_ascii=False, indent=2)
PY
expect_ok "permite construir sobre dependencias solo verified (cadena entera sin accepts)" python3 .orchestrator/scripts/validate-state.py
expect_ok "status.json separa lo aceptable-ya de lo que espera orden" python3 -c "
import json, subprocess
subprocess.run(['python3', '.orchestrator/scripts/validate-state.py', '--emit-status'], check=True, capture_output=True)
d = json.load(open('.orchestrator-state/status.json'))
assert d['acceptable_now'] == ['SCR-FOUNDATION-SCHEMA'], d['acceptable_now']
waiting = {r['id'] for r in d['verified_blocked_by_accept_order']}
assert waiting == {'SCR-FOUNDATION-SHELL', 'SCR-001'}, waiting
"
cp "$TMP/feat.bak" "$FEAT"

python3 - <<'PY'
import json
p = '.orchestrator-state/features.json'
d = json.load(open(p))
# SCR-001 aceptado mientras su dependencia SHELL sigue solo verified: la puerta humana
# debe seguir el orden del DAG aunque construir por delante este permitido.
next(s for s in d['screens'] if s['id'] == 'SCR-FOUNDATION-SHELL')['status'] = 'verified'
next(s for s in d['screens'] if s['id'] == 'SCR-001')['status'] = 'accepted'
json.dump(d, open(p, 'w'), ensure_ascii=False, indent=2)
PY
expect_fail "rechaza aceptar saltandose el orden de after[] (dependencia solo verified)" python3 .orchestrator/scripts/validate-state.py
cp "$TMP/feat.bak" "$FEAT"

# Un DIRECTORIO no es evidencia: `exists()` lo daba por bueno y el guard `is_file()` del
# control de 0 bytes lo dejaba pasar limpiamente. Renombrar un .txt a .png ya no basta.
mv .orchestrator-state/evidence/SCR-001/screenshots/success.png "$TMP/shot2.bak"
mkdir .orchestrator-state/evidence/SCR-001/screenshots/success.png
expect_fail_msg "rechaza un DIRECTORIO haciendose pasar por artefacto" "non-file artifact" \
  python3 .orchestrator/scripts/validate-state.py
rmdir .orchestrator-state/evidence/SCR-001/screenshots/success.png
mv "$TMP/shot2.bak" .orchestrator-state/evidence/SCR-001/screenshots/success.png

# La fuente de verdad nunca es un cliente. Antes se comparaba la CADENA ENTERA contra el set
# de capas cliente, asi que anadir una palabra ("UI store") burlaba el invariante que la
# constitucion declara no negociable.
python3 - <<'PY'
import json
p = '.orchestrator-state/features.json'
d = json.load(open(p))
s = next(x for x in d['screens'] if x['id'] == 'SCR-001')
s['data_engine']['canonical_store']['source_of_truth'] = 'UI store'
json.dump(d, open(p, 'w'), ensure_ascii=False, indent=2)
PY
expect_fail_msg "rechaza un cliente como fuente de verdad ('UI store')" "client layer as system of record" \
  python3 .orchestrator/scripts/validate-state.py
cp "$TMP/feat.bak" "$FEAT"

# Trazabilidad: un ID que no define ningun fichero del blueprint pasaba gate Y linter.
python3 - <<'PY'
import json
p = '.orchestrator-state/features.json'
d = json.load(open(p))
next(x for x in d['screens'] if x['id'] == 'SCR-001')['applies'].append('DATA-999')
json.dump(d, open(p, 'w'), ensure_ascii=False, indent=2)
PY
expect_fail_msg "rechaza un ID que ningun fichero del blueprint define (DATA-999)" "no blueprint file defines" \
  python3 .orchestrator/scripts/validate-state.py
cp "$TMP/feat.bak" "$FEAT"

# El fan-out obligatorio era comparacion de cadenas: una lente inventada satisfacia el set.
python3 - <<'PY'
import json
p = '.orchestrator-state/evidence/SCR-001/result.json'
d = json.load(open(p))
for run in d['phase_runs']:
    if run['phase'] == 'VERIFY':
        run['lenses'].append('verify-lente-totalmente-inventada')
json.dump(d, open(p, 'w'), ensure_ascii=False, indent=2)
PY
expect_fail_msg "rechaza una lente que no existe en el roster de agentes" "not in the agent roster" \
  python3 .orchestrator/scripts/validate-state.py
cp "$TMP/res.bak" "$RES"

# El read_path es una DIRECCION (almacen -> transporte -> cliente): invertido pasaba, porque
# se buscaban subcadenas sobre la concatenacion de todos los pasos en vez de por posicion.
python3 - <<'PY'
import json
p = '.orchestrator-state/features.json'
d = json.load(open(p))
rp = next(x for x in d['screens'] if x['id'] == 'SCR-001')['data_engine']['pipeline']['read_path']
rp.reverse()
json.dump(d, open(p, 'w'), ensure_ascii=False, indent=2)
PY
expect_fail_msg "rechaza un read_path invertido (cliente -> almacen)" "must START at the canonical store" \
  python3 .orchestrator/scripts/validate-state.py
cp "$TMP/feat.bak" "$FEAT"

# Gate de arquitectura /arch-review: NO retroactivo (un estado sin meta.architecture_review
# sigue siendo valido — el golden path no la trae y todos los positivos de arriba pasan),
# pero --init-gate SI la exige (un proyecto no puede NACER sin el gate), y si la clave
# existe, su forma se valida con dureza: blockers abiertos o set de lentes parcial rompen.
expect_fail_msg "--init-gate exige meta.architecture_review para nacer" "must run /arch-review" \
  python3 .orchestrator/scripts/validate-state.py --init-gate
expect_fail_msg "--init-gate exige meta.discovery para nacer" "must run /discovery" \
  python3 .orchestrator/scripts/validate-state.py --init-gate

python3 - <<'PY'
import json
p = '.orchestrator-state/features.json'
d = json.load(open(p))
d.setdefault('meta', {})['architecture_review'] = {
    'status': 'clear',
    'lenses': ['arch-fit', 'arch-data-model', 'arch-identity', 'arch-engines',
               'arch-pipelines', 'arch-risk'],
    'failed_lenses': [],
    'open_blockers': [{'finding_id': 'ARCH-001', 'detail': 'tenancy sin decidir'}],
    'report_sha256': 'deadbeef',
}
json.dump(d, open(p, 'w'), ensure_ascii=False, indent=2)
PY
expect_fail_msg "rechaza architecture_review con blockers abiertos" "open_blockers is non-empty" \
  python3 .orchestrator/scripts/validate-state.py
cp "$TMP/feat.bak" "$FEAT"

python3 - <<'PY'
import json
p = '.orchestrator-state/features.json'
d = json.load(open(p))
d.setdefault('meta', {})['architecture_review'] = {
    'status': 'clear',
    'lenses': ['arch-fit'],  # set parcial: mismo pecado que un fan-out a medias
    'failed_lenses': [], 'open_blockers': [], 'report_sha256': 'deadbeef',
}
json.dump(d, open(p, 'w'), ensure_ascii=False, indent=2)
PY
expect_fail_msg "rechaza architecture_review con set de lentes parcial" "full arch set" \
  python3 .orchestrator/scripts/validate-state.py
cp "$TMP/feat.bak" "$FEAT"

# Gate de descubrimiento /discovery: misma disciplina que architecture_review — NO retroactivo
# (un estado sin meta.discovery sigue siendo valido), pero si la clave existe su forma se valida
# con dureza: items sin disposicion o set de lentes parcial rompen.
python3 - <<'PY'
import json
p = '.orchestrator-state/features.json'
d = json.load(open(p))
d.setdefault('meta', {})['discovery'] = {
    'status': 'complete',
    'lenses': ['discovery-product', 'discovery-data', 'discovery-architecture',
               'discovery-stack', 'discovery-infra', 'discovery-ux'],
    'failed_lenses': [], 'unresolved': ['Q-UX-07'],  # un item sin disposicion
    'checklist_version': 1, 'items_total': 62,
    'dispositions': {'answered': 30, 'filled': 20, 'asked': 8, 'na': 4, 'deferred': 0},
    'report_sha256': 'deadbeef',
}
json.dump(d, open(p, 'w'), ensure_ascii=False, indent=2)
PY
expect_fail_msg "rechaza discovery con items sin disposicion" "unresolved is non-empty" \
  python3 .orchestrator/scripts/validate-state.py
cp "$TMP/feat.bak" "$FEAT"

python3 - <<'PY'
import json
p = '.orchestrator-state/features.json'
d = json.load(open(p))
d.setdefault('meta', {})['discovery'] = {
    'status': 'complete',
    'lenses': ['discovery-product'],  # set parcial: mismo pecado que un fan-out a medias
    'failed_lenses': [], 'unresolved': [],
    'checklist_version': 1, 'items_total': 62,
    'dispositions': {'answered': 30, 'filled': 20, 'asked': 8, 'na': 4, 'deferred': 0},
    'report_sha256': 'deadbeef',
}
json.dump(d, open(p, 'w'), ensure_ascii=False, indent=2)
PY
expect_fail_msg "rechaza discovery con set de lentes parcial" "full discovery set" \
  python3 .orchestrator/scripts/validate-state.py
cp "$TMP/feat.bak" "$FEAT"

# Backstop determinista: un proyecto inicializado que conserve <COMMAND_*> sin resolver en
# stack.md no puede validar — sin comandos reales los verificadores no tienen nada que correr.
cp .claude/rules/stack.md "$TMP/stack.bak"
printf '\n# leftover\n<COMMAND_TEST>\n' >> .claude/rules/stack.md
expect_fail_msg "rechaza proyecto inicializado con <COMMAND_*> sin resolver" "unresolved command placeholders" \
  python3 .orchestrator/scripts/validate-state.py
cp "$TMP/stack.bak" .claude/rules/stack.md

# reset-test-data.sh: contrato de delegación a stack.md. Prueba los TRES estados, porque el
# fallo silencioso que importa aquí es un script que sale 0 sin hacer nada y parece correcto.
# Positivo real: sobre el stack.md resuelto del golden path DEBE resolver la clave y delegar.
echo "== reset-test-data: contrato de delegación =="
expect_ok_msg "resuelve COMMAND_RESET_TEST_DATA y delega el comando declarado" \
  "running COMMAND_RESET_TEST_DATA -> npm run migrate && npm run seed" \
  bash .orchestrator/scripts/reset-test-data.sh VERIFY
# No fatal: el comando delegado falla aquí (el golden path no trae node_modules) y aun así sale 0
# — preparar datos nunca puede bloquear una fase; el conductor decide qué hacer con el aviso.
expect_ok_msg "no es fatal cuando el comando delegado falla" \
  "may be in a partial state" \
  bash .orchestrator/scripts/reset-test-data.sh VERIFY
# Estado "no declarada" distinguible de estado "declarada sin resolver": colapsarlos ocultaría
# un hueco real de configuración detrás del mismo mensaje.
grep -v "COMMAND_RESET_TEST_DATA" "$TMP/stack.bak" > .claude/rules/stack.md
expect_ok_msg "reporta clave no declarada sin romper" \
  "is not declared in .claude/rules/stack.md" \
  bash .orchestrator/scripts/reset-test-data.sh VERIFY
printf '\n# reset (COMMAND_RESET_TEST_DATA)\n<COMMAND_RESET_TEST_DATA>\n' >> .claude/rules/stack.md
expect_ok_msg "distingue placeholder sin resolver de clave ausente" \
  "declared but still the placeholder" \
  bash .orchestrator/scripts/reset-test-data.sh VERIFY
cp "$TMP/stack.bak" .claude/rules/stack.md

expect_ok "estado restaurado: el gate vuelve a pasar" python3 .orchestrator/scripts/validate-state.py

echo
echo "golden-path smoke: $pass PASS, $fail FAIL"
[ "$fail" -eq 0 ]
