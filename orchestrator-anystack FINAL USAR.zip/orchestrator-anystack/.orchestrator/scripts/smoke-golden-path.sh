#!/usr/bin/env bash
# End-to-end smoke test of the orchestrator's deterministic machinery, using the
# golden-path example (.orchestrator/examples/golden-path). Copies the scaffold to
# a temp dir, mounts the golden blueprint + canonical state, and checks:
#   POSITIVE: blueprint lint, state gate, --emit-status projections, structure +
#             lens-set sync, hook on a valid state.
#   NEGATIVE: the gate MUST reject — incomplete lens set, borrowed evidence,
#             cross-layer value drift, debugger cap exceeded, two units building,
#             missing artifact; and the hook MUST reject corrupted features.json.
# Exit 0 only if every expectation holds.
set -uo pipefail
# Without the check, ROOT is empty and the fixture is assembled from the wrong tree, so the suite
# reports on something that is not this repo.
if [ -z "${BASH_SOURCE[0]:-}" ]; then
  echo "smoke-golden-path: must be run with bash (BASH_SOURCE unavailable). Use: bash .orchestrator/scripts/smoke-golden-path.sh" >&2
  exit 2
fi
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
GP="$ROOT/.orchestrator/examples/golden-path"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT

WORK="$TMP/orch"
mkdir -p "$WORK"
# Copia SOLO la definicion del orquestador, no el arbol entero del repo anfitrion.
#
# Esto era `cp -R "$ROOT/." "$WORK/"`, y en el repo del orquestador —donde no hay producto— no
# se notaba. En un proyecto REAL, que es exactamente donde este smoke tiene que poder correr,
# arrastraba al temporal el `node_modules`/`.git`/`venv` del proyecto: medido en un repo de los
# de verdad, 483 MB por invocacion. El smoke no se rompia, se colgaba — que es peor, porque un
# script que tarda para siempre no da un fallo que alguien pueda leer, da la impresion de que la
# maquina esta pensando.
#
# La lista es corta porque el fixture monta lo demas por su cuenta (blueprint, estado y producto
# vienen del golden path, justo debajo). `design/` entra porque el fixture FUSIONA su producto
# sobre lo que el repo ya trae ahi; `blueprint-templates/` porque lint-blueprint.py compara cada
# valor contra su default de plantilla. Copiar lo que se usa tambien es mas honesto sobre lo que
# se esta probando: si manana el smoke necesita otra cosa del repo, hay que anadirla aqui a
# proposito en vez de recibirla por arrastre.
for entry in .claude .orchestrator blueprint-templates design CLAUDE.md; do
  [ -e "$ROOT/$entry" ] && cp -R "$ROOT/$entry" "$WORK/"
done
cp -R "$GP/blueprint" "$WORK/blueprint"
# El fixture trae ademas un arbol de producto minimo bajo product/: sin el, source_manifest solo
# podria citar ficheros de blueprint y el ejemplo canonico incumpliria lo que el propio §7 exige
# ("path + sha256 of the unit's implementation files"). Con el, la rama que de verdad importa de
# validate_source_manifest — la deriva de un fichero de IMPLEMENTACION, que falla duro — pasa a
# ser ejercitable por mutacion. Se monta con cp -R product/. para FUSIONAR con lo que el repo
# auto-alojado ya trae en su raiz (design/screens/), nunca para reemplazarlo.
cp -R "$GP/product/." "$WORK/"
cp -R "$GP/state" "$WORK/.orchestrator-state"
# An initialized project has its stack commands resolved; the golden path carries a resolved
# stack.md fixture so the gate's <COMMAND_*> backstop sees a real (finished) project, not the
# repo scaffold's placeholders.
cp "$GP/stack.md" "$WORK/.claude/rules/stack.md"
cd "$WORK"
# El hook resuelve el proyecto por CLAUDE_PROJECT_DIR: fijarlo al arbol temporal o,
# si viene heredado del entorno, el smoke validaria el repo real en vez de este.
export CLAUDE_PROJECT_DIR="$WORK"

pass=0; fail=0
ok()   { echo "PASS  $1"; pass=$((pass+1)); }
bad()  { echo "FAIL  $1"; fail=$((fail+1)); }
expect_ok()   { local d="$1"; shift; if "$@" >/dev/null 2>&1; then ok "$d"; else bad "$d"; fi; }
expect_fail() { local d="$1"; shift; if "$@" >/dev/null 2>&1; then bad "$d (debería haber fallado)"; else ok "$d"; fi; }
# Negativo con motivo: exigir que el gate falle POR el invariante que el caso dice
# probar, no por un daño colateral de la mutación (un expect_fail a secas se queda
# en verde aunque el invariante esté desactivado).
expect_fail_msg() {
  local d="$1" pat="$2"; shift 2
  local out rc
  out="$("$@" 2>&1)"; rc=$?
  if [ "$rc" -eq 0 ]; then bad "$d (debería haber fallado)"
  elif printf '%s' "$out" | grep -q -- "$pat"; then ok "$d"
  else bad "$d (falló por otro motivo: $out)"; fi
}
# Todos pasan `--` antes del patron: sin el, un patron que empiece por `-` (por ejemplo el
# comando `--record ...` que sugiere un mensaje de error) lo lee grep como una OPCION y el caso
# falla "por otro motivo" — un falso rojo que manda a buscar el defecto donde no esta.
# Los negativos usan expect_fail_msg, no expect_fail: sin patron, un caso pasa igual si el gate
# CASCA (un traceback sin capturar tambien sale non-zero) que si el invariante se aplica. Se
# comprobo por mutacion: desactivando el check de artefacto existente, el gate revienta con
# FileNotFoundError y el caso seguia en verde. El patron es lo que distingue "lo rechazo por
# esto" de "algo se rompio por ahi".
# Positivo con motivo: exigir que un script no-fatal salga 0 Y haya hecho lo que dice hacer.
# Un expect_ok a secas se queda en verde con un script que sale 0 sin actuar — que es
# exactamente el fallo que reset-test-data.sh podría tener y nadie notaría.
expect_ok_msg() {
  local d="$1" pat="$2"; shift 2
  local out rc
  out="$("$@" 2>&1)"; rc=$?
  if [ "$rc" -ne 0 ]; then bad "$d (salió $rc, debería salir 0)"
  elif printf '%s' "$out" | grep -qF -- "$pat"; then ok "$d"
  else bad "$d (salió 0 pero no hizo lo que dice: $out)"; fi
}
# Igual que el anterior pero insensible a mayusculas: para contratos que varias
# implementaciones cumplen con redacciones distintas.
expect_ok_imsg() {
  local d="$1" pat="$2"; shift 2
  local out rc
  out="$("$@" 2>&1)"; rc=$?
  if [ "$rc" -ne 0 ]; then bad "$d (salió $rc, debería salir 0)"
  elif printf '%s' "$out" | grep -qiF -- "$pat"; then ok "$d"
  else bad "$d (salió 0 pero no hizo lo que dice: $out)"; fi
}

FEAT=".orchestrator-state/features.json"
RES=".orchestrator-state/evidence/SCR-001/result.json"

echo "== golden path: positivos =="
expect_ok "lint-blueprint: blueprint golden sin errores" python3 .orchestrator/scripts/lint-blueprint.py
# El indice de blueprint/DECISIONS.md dejo de ser bookkeeping el dia que las ~23 lentes
# discovery-*/research-* pasaron a leer SOLO esa tabla y a parar en el primer '## DEC-'.
# Una decision con seccion pero sin fila es invisible para todas ellas, y el fallo es silencioso
# e invertido: la lente no da error, PREGUNTA al humano algo que el humano ya decidio — lo que la
# constitucion llama la forma mas rapida de que deje de fiarse de las preguntas. La fila huerfana
# es el defecto espejo, mas barato: una lente cita una decision que no existe. Ambos son ERROR
# porque toda la lectura por indice descansa en esta sincronia, y la decide un script en vez de
# pedirsela a quien escribe la decision.
# El golden path no trae blueprint/DECISIONS.md (un proyecto puede no haber tomado ninguna
# decision todavia), asi que cada caso se monta el suyo minimo y lo borra al salir.
make_dec_index() {  # cabecera + tabla de indice vacia, la forma que crea /init-build
  printf '# DECISIONS.md\n\n## Índice\n\n| ID | Fecha | Decisión | Supersede | Escrita en |\n|---|---|---|---|---|\n' \
    > blueprint/DECISIONS.md
}
export -f make_dec_index
expect_fail_msg "lint-blueprint: rechaza un DEC-* con seccion pero sin fila en el Índice" \
  "no row in the" bash -c '
make_dec_index
printf "\n## DEC-001 — decision de prueba\n\n\140\140\140logic\nid: DEC-001\ntype: decision\n\140\140\140\n" >> blueprint/DECISIONS.md
python3 .orchestrator/scripts/lint-blueprint.py'
rm -f blueprint/DECISIONS.md
expect_fail_msg "lint-blueprint: rechaza una fila del Índice sin su seccion ## DEC-" \
  "citing nothing" bash -c '
make_dec_index
printf "| DEC-042 | 2026-01-01 | fila sin seccion | — | DATA-001 |\n" >> blueprint/DECISIONS.md
python3 .orchestrator/scripts/lint-blueprint.py'
rm -f blueprint/DECISIONS.md
expect_ok "lint-blueprint: acepta un DEC-* con su seccion Y su fila" bash -c '
make_dec_index
printf "| DEC-001 | 2026-01-01 | decision de prueba | — | DATA-001 |\n" >> blueprint/DECISIONS.md
printf "\n## DEC-001 — decision de prueba\n\n\140\140\140logic\nid: DEC-001\ntype: decision\n\140\140\140\n" >> blueprint/DECISIONS.md
python3 .orchestrator/scripts/lint-blueprint.py'
rm -f blueprint/DECISIONS.md
# DECISIONS.md era la UNICA capa fuera de la integridad referencial: toda ella opera sobre ids
# declarados en bloques ```logic/```screen, y una decision se escribe rutinariamente como
# cabecera + fila de indice, sin bloque. Medido en un proyecto real: 15 de 16 familias 100%
# cubiertas, DEC-* con 1 bloque (el ejemplo de la plantilla) y 62 entradas solo-cabecera; dos
# '## DEC-062' y el linter salia 0. Lo cazaron TRES lentes de VERIFY, al precio de una vuelta
# completa de depurador — la inversion exacta de "lo que un script puede decidir no debe costar
# un fan-out". El caso de arriba (cabecera + bloque + fila) es tambien la trampa que hay que no
# repetir: registrar cabeceras a ciegas lo convierte en un falso "duplicate ID DEC-001".
expect_fail_msg "lint-blueprint: caza dos secciones ## DEC-* duplicadas sin bloque" \
  "duplicate ID DEC-062" bash -c '
make_dec_index
for i in 1 2; do
  printf "| DEC-062 | 2026-01-01 | duplicada | — | DATA-001 |\n" >> blueprint/DECISIONS.md
  printf "\n## DEC-062 — duplicada\n\n**Decision:** algo\n" >> blueprint/DECISIONS.md
done
python3 .orchestrator/scripts/lint-blueprint.py'
rm -f blueprint/DECISIONS.md
# El defecto ESPEJO, encontrado por sonda contra el binario real: row_ids tambien era un set(),
# asi que dos filas identicas colapsaban y salia 0. Las lentes leen la tabla como su vista
# entera del ledger, de modo que una fila repetida les ensena dos decisiones donde hay una.
expect_fail_msg "lint-blueprint: caza una fila del Índice repetida" \
  "index table lists DEC-070" bash -c '
make_dec_index
printf "| DEC-070 | 2026-01-01 | p | — | DATA-001 |\n" >> blueprint/DECISIONS.md
printf "| DEC-070 | 2026-01-01 | p | — | DATA-001 |\n" >> blueprint/DECISIONS.md
printf "\n## DEC-070 — una sola seccion\n" >> blueprint/DECISIONS.md
python3 .orchestrator/scripts/lint-blueprint.py'
rm -f blueprint/DECISIONS.md
# La tercera trampa medida: guardar el registro con `if id not in defined` parece el arreglo del
# falso positivo de arriba y desactiva la deteccion entera (defined se acumula, asi que la
# SEGUNDA cabecera nunca se registra). Este caso mixto — 2 cabeceras, 1 bloque — es el que se
# pone rojo si alguien "simplifica" la aritmetica a esa guarda.
expect_fail_msg "lint-blueprint: caza 2 cabeceras DEC-* con 1 solo bloque (caso mixto)" \
  "duplicate ID DEC-080" bash -c '
make_dec_index
printf "| DEC-080 | 2026-01-01 | p | — | DATA-001 |\n" >> blueprint/DECISIONS.md
printf "\n## DEC-080 — primera\n\n\140\140\140logic\nid: DEC-080\ntype: decision\n\140\140\140\n" >> blueprint/DECISIONS.md
printf "\n## DEC-080 — segunda, duplicada\n\n**Decision:** otra cosa\n" >> blueprint/DECISIONS.md
python3 .orchestrator/scripts/lint-blueprint.py'
rm -f blueprint/DECISIONS.md
# `written_to` es una afirmacion sobre el DISCO — donde aterrizo la decision — y no tenia
# comprobador. Fallo 4 veces en 2 ciclos del mismo proyecto real pese a que autonomy.md ya lo
# advertia EN PROSA; cuatro fallos de la misma advertencia escrita son informacion sobre la
# REGLA, no sobre quien la escribe. Dos direcciones: lo declarado existe (ERROR si no), y lo
# escrito esta declarado (WARNING, porque un fichero puede citar una decision sin ser destino).
expect_fail_msg "lint-blueprint: rechaza un written_to que apunta a un fichero inexistente" \
  "which does not exist" bash -c '
make_dec_index
printf "| DEC-090 | 2026-01-01 | p | — | x |\n" >> blueprint/DECISIONS.md
printf "\n## DEC-090 — prueba\n\n\140\140\140logic\nid: DEC-090\ntype: decision\nwritten_to: [blueprint/logic/no-existe.md]\n\140\140\140\n" >> blueprint/DECISIONS.md
python3 .orchestrator/scripts/lint-blueprint.py'
rm -f blueprint/DECISIONS.md
expect_ok_msg "lint-blueprint: avisa (sin romper) de un written_to que no dejo rastro" \
  "never mentions DEC-091" bash -c '
make_dec_index
printf "| DEC-091 | 2026-01-01 | p | — | x |\n" >> blueprint/DECISIONS.md
printf "\n## DEC-091 — prueba\n\n\140\140\140logic\nid: DEC-091\ntype: decision\nwritten_to: [.claude/rules/stack.md]\n\140\140\140\n" >> blueprint/DECISIONS.md
python3 .orchestrator/scripts/lint-blueprint.py'
rm -f blueprint/DECISIONS.md
# La direccion INVERSA: una capa cita la decision y el written_to de esa decision no la nombra.
# Es la mitad que nadie nota, y la que hace que un ledger deje de ser un registro.
expect_ok_msg "lint-blueprint: avisa de una capa que cita una decision no declarada en su written_to" \
  "does not name this file" bash -c '
make_dec_index
printf "| DEC-092 | 2026-01-01 | p | — | x |\n" >> blueprint/DECISIONS.md
printf "\n## DEC-092 — prueba\n\n\140\140\140logic\nid: DEC-092\ntype: decision\nwritten_to: [.claude/rules/stack.md]\n\140\140\140\n" >> blueprint/DECISIONS.md
printf "\n<!-- aplicado por DEC-092 -->\n" >> blueprint/logic/error.md
python3 .orchestrator/scripts/lint-blueprint.py'
rm -f blueprint/DECISIONS.md
# Restaurar desde la FUENTE pristina, no con git: $WORK nunca es un repositorio git (este script
# no hace git init en ningun momento), asi que `git checkout --` falla SIEMPRE y en silencio por
# el 2>/dev/null, y el sed de reserva solo borraba la linea del marcador, dejando la linea en
# blanco que el mismo printf habia insertado antes. Un fixture que no vuelve a su estado exacto
# contamina los casos siguientes — ya paso una vez en esta suite. El patron correcto es el que
# usa el caso de product/app/notas.py mas abajo: copiar de nuevo desde $GP.
cp "$GP/blueprint/logic/error.md" blueprint/logic/error.md
# --decidedness existia en 6 sitios que lo invocaban y en ninguno que lo implementara:
# el script no tenia argparse, asi que el flag se ignoraba en silencio y undecided_fields[]
# salia SIEMPRE vacio. Eso rompia la regla en las dos direcciones a la vez — /arch-review
# daba por decidido un blueprint entero sin decidir, y las lentes arch-* levantaban como
# blocker campos que solo eran el default de la plantilla. Un vacio indistinguible de
# "nada sin decidir" es justo la clase de defecto que la constitucion llama peligroso.
expect_ok "lint-blueprint: --decidedness --json emite JSON con undecided_fields[]" python3 -c "
import json, subprocess
out = subprocess.run(['python3', '.orchestrator/scripts/lint-blueprint.py', '--decidedness', '--json'],
                     capture_output=True, text=True, check=True).stdout
d = json.loads(out)
assert d['schema_version'] == 'orchestrator.blueprint-lint.v1', d['schema_version']
assert isinstance(d['undecided_fields'], list), type(d['undecided_fields'])
assert d['counts']['undecided_fields'] == len(d['undecided_fields']), d['counts']
for row in d['undecided_fields']:
    assert set(row) == {'file', 'block', 'key', 'value', 'reason', 'block_match_ratio'}, row
    assert row['reason'] in ('placeholder', 'template_default'), row
    # El ratio es la defensa contra el sobre-reporte: un template_default solo cuenta si el
    # BLOQUE entero sigue sin tocar. Un placeholder lo salta — es ausencia sin ambiguedad.
    assert row['reason'] == 'placeholder' or row['block_match_ratio'] >= 0.6, row
"
# El flag no debe alterar el comportamiento por defecto: 12 sitios lo invocan sin flags.
expect_ok_msg "lint-blueprint: sin flags se comporta como siempre" "blueprint lint OK" \
  python3 .orchestrator/scripts/lint-blueprint.py
# Y debe DISCRIMINAR: un blueprint sin tocar tiene mas silencio que uno relleno. Sin esto
# el flag podria devolver [] siempre y los dos asserts de arriba seguirian en verde.
expect_ok "lint-blueprint: distingue plantilla sin rellenar de blueprint decidido" python3 -c "
import json, subprocess, shutil, os
def undecided():
    out = subprocess.run(['python3', '.orchestrator/scripts/lint-blueprint.py', '--decidedness', '--json'],
                         capture_output=True, text=True).stdout
    return len(json.loads(out)['undecided_fields'])
filled = undecided()
tpl = next((t for t in sorted(os.listdir('blueprint-templates/logic'))
            if os.path.exists('blueprint/logic/' + t.replace('-template', ''))), None)
assert tpl, 'ninguna plantilla de logic/ tiene su capa correspondiente en el blueprint'
shutil.copy('blueprint-templates/logic/' + tpl, 'blueprint/logic/' + tpl.replace('-template', ''))
raw = undecided()
assert raw > filled, f'plantilla cruda ({raw}) deberia tener MAS campos sin decidir que el blueprint relleno ({filled})'
"
cp -R "$GP/blueprint/." blueprint/
# Integridad referencial BIDIRECCIONAL. El linter ya cazaba una cita a un ID que nadie define;
# el sentido contrario —una capa que declara related_screens: [SCR-X] mientras el applies[] de
# SCR-X no la cita de vuelta— quedaba invisible, y es el caro: TODA lente se acota a applies[],
# asi que una capa no citada no tiene dueno y la unidad cierra en verde sin haberse juzgado
# nunca contra ella. Cuando se escribio este check, el propio golden path traia dos (CORE-001 y
# PIPE-001 reclamaban SCR-001 sin que SCR-001 las citara); estan arregladas y esto lo sostiene.
expect_ok "lint-blueprint: el golden path no deja ninguna capa sin citar" python3 -c "
import json, subprocess
d = json.loads(subprocess.run(['python3', '.orchestrator/scripts/lint-blueprint.py', '--json'],
                              capture_output=True, text=True).stdout)
assert d['uncited_claims'] == [], d['uncited_claims']
assert d['counts']['uncited_claims'] == 0, d['counts']
"
# Y debe cazarlo cuando existe, como AVISO y no como error: SCREENS.md se escribe el ultimo
# (USO.md §3), asi que romper aqui dispararia en todo proyecto a medio escribir — y un check
# que rechaza estados validos acaba esquivado.
expect_ok "lint-blueprint: avisa (sin romper) de una capa que reclama una pantalla que no la cita" bash -c '
python3 - <<PY
import json, subprocess
from pathlib import Path
p = Path("blueprint/SCREENS.md")
p.write_text(p.read_text().replace("applies: [BR-001, CORE-001,", "applies: [BR-001,"))
r = subprocess.run(["python3", ".orchestrator/scripts/lint-blueprint.py", "--json"],
                   capture_output=True, text=True)
d = json.loads(r.stdout)
assert [x for x in d["uncited_claims"]
        if x["block"] == "CORE-001" and x["screen"] == "SCR-001"], d["uncited_claims"]
assert d["counts"]["errors"] == 0, "debe ser aviso, no error"
assert r.returncode == 0, r.returncode
assert all(x["reason"] == "not_cited_back" for x in d["uncited_claims"]), d["uncited_claims"]
PY
'
cp -R "$GP/blueprint/." blueprint/
# Dos huecos del propio check, ambos silenciosos hasta que se probaron:
#  (a) un ID reclamado que SI esta definido pero NO como bloque ```screen``` no lo cazaba nadie —
#      el bucle de referencias colgantes solo habla cuando el token no esta en NINGUN bloque, y
#      este no tiene applies[] contra el que comparar. La reclamacion sigue rota: una capa no
#      puede estar "relacionada con" algo que no es una unidad.
#  (b) `related_screens: [SCR-001, SCR-001]` es UNA reclamacion escrita dos veces; cada fila de
#      uncited_claims[] acaba siendo una pregunta CLARIFY, y preguntar N veces lo mismo es como
#      una ronda de preguntas deja de leerse.
expect_ok "lint-blueprint: caza una reclamacion a un ID que existe pero no es una pantalla, y no duplica" bash -c '
python3 - <<PY
import json, subprocess
from pathlib import Path
p = Path("blueprint/logic/data.md")
p.write_text(p.read_text() + """
### DATA-900 — reclamante de prueba

\\x60\\x60\\x60logic
id: DATA-900
related_screens: [DATA-001, SCR-001, SCR-001]
\\x60\\x60\\x60
""")
r = subprocess.run(["python3", ".orchestrator/scripts/lint-blueprint.py", "--json"],
                   capture_output=True, text=True)
d = json.loads(r.stdout)
rows = [x for x in d["uncited_claims"] if x["block"] == "DATA-900"]
kinds = sorted(x["reason"] for x in rows)
assert kinds == ["not_cited_back", "target_is_not_a_screen"], rows
assert r.returncode == 0, r.returncode
PY
'
cp -R "$GP/blueprint/." blueprint/
expect_ok "state gate: estado canónico valida" python3 .orchestrator/scripts/validate-state.py
# Los gates cruzados dejaron de producir informes huerfanos: emiten SCR-FIX-* que el bucle
# recoge. `remediates` es una lista de referencias como after/applies, asi que el linter debe
# resolverla — una unidad de reparacion no puede citar una pantalla que nadie define.
expect_ok "lint-blueprint: acepta un SCR-FIX-* con remediates[] resoluble" bash -c '
cat >> blueprint/SCREENS.md <<EOF

### SCR-FIX-SMOKE-001 — reparacion emitida por un gate

\`\`\`screen
id: SCR-FIX-SMOKE-001
kind: fix
platforms: [web]
order: 99
after: [SCR-001]
applies: [JOUR-001]
remediates: [SCR-001]
status: draft
acceptance:
  - "el contador de la cabecera muestra el valor canonico al volver de detalle"
\`\`\`
EOF
python3 .orchestrator/scripts/lint-blueprint.py'
expect_fail_msg "lint-blueprint: rechaza un SCR-FIX-* que remedia una pantalla inexistente" "references undefined ID SCR-999" bash -c '
python3 - <<PY
from pathlib import Path
p = Path("blueprint/SCREENS.md")
p.write_text(p.read_text().replace("remediates: [SCR-001]", "remediates: [SCR-999]"))
PY
python3 .orchestrator/scripts/lint-blueprint.py'
cp -R "$GP/blueprint/." blueprint/
expect_ok "emit-status: escribe proyecciones" python3 .orchestrator/scripts/validate-state.py --emit-status
expect_ok "status.json: 2 accepted + 1 verified, SCR-001 esperando accept" python3 -c "
import json
d = json.load(open('.orchestrator-state/status.json'))
assert d['schema_version'] == 'orchestrator.status.v1'
assert d['counts']['accepted'] == 2 and d['counts']['verified'] == 1
assert d['verified_awaiting_accept'] == ['SCR-001'] and d['building'] is None
"
expect_ok "evidence/index.json: 3 unidades con sus fases" python3 -c "
import json
d = json.load(open('.orchestrator-state/evidence/index.json'))
assert len(d['screens']) == 3
scr = next(s for s in d['screens'] if s['screen_id'] == 'SCR-001')
assert {p['phase'] for p in scr['phases']} == {'RESEARCH','EXPLORE','DEVELOP','VERIFY','VALIDATE','REVIEW'}
"
expect_ok "estructura + sincronía de lentes .js↔.py" bash .orchestrator/scripts/validate-structure.sh
# `args` llega como CADENA JSON en este build, no como objeto: medido, typeof args === "string".
# Eso hacia que args.screen_id (y changed_files, scope_to, fail_fast) fueran undefined en los 9
# workflows. No rompio nada porque cada uno cae a su default disk-first y resuelve la unidad
# correcta de disco -- pero TODO argumento opcional dejo de funcionar en silencio, incluida la
# optimizacion de alcance de reparaciones entera. Un fallo que apunta al lado seguro es el que
# mas tarda en verse, asi que se prueba el normalizador, no solo que el flag exista.
expect_ok "workflows: args normalizado (objeto, cadena JSON, cadena no-JSON, ausente)" node -e "
const norm = (args) => { const log = () => {};
  if (args === undefined || args === null) return {};
  if (typeof args === 'object') return args;
  if (typeof args === 'string') { const raw = args.trim(); if (!raw) return {};
    try { const p = JSON.parse(raw); return (p && typeof p === 'object') ? p : {}; } catch (e) { return {}; } }
  return {}; };
const eq = (a, b, m) => { if (a !== b) { console.error(m, a, '!==', b); process.exit(1); } };
eq(norm({screen_id:'SCR-001'}).screen_id, 'SCR-001', 'objeto');
eq(norm(JSON.stringify({screen_id:'SCR-001'})).screen_id, 'SCR-001', 'cadena JSON');
eq(norm('SCR-001').screen_id, undefined, 'cadena no-JSON');
eq(norm(undefined).screen_id, undefined, 'ausente');
eq(norm('').screen_id, undefined, 'cadena vacia');
eq(norm('[1,2]').length, 2, 'array JSON');
"
# Y que NINGUN workflow lea `args` crudo: el normalizador solo sirve si todos pasan por el.
expect_ok "workflows: ninguno accede a args crudo fuera del normalizador" python3 -c "
import re, pathlib, sys
bad = []
for f in sorted(pathlib.Path('.claude/workflows').glob('*.js')):
    src = f.read_text(encoding='utf-8')
    assert 'const ARGS = (() =>' in src, f'{f.name}: sin normalizador'
    for i, l in enumerate(src.splitlines(), 1):
        if l.strip().startswith('//') or 'args.trim()' in l: continue
        for m in re.finditer(r'(?<![A-Za-z_.])args\.[a-z_]+', l):
            pre = l[:m.start()]
            if pre.count(chr(96)) % 2 or pre.count(chr(39)) % 2 or pre.count(chr(34)) % 2: continue
            bad.append(f'{f.name}:{i}')
assert not bad, bad
"
# El alcance de reparacion (changed_files + las dos directivas de triage) viaja por `args`, y
# `args` se ha medido que NO llega al script a veces: sin error, el global sale undefined y no
# hay forma de distinguir "no me pasaron nada" de "me pasaron algo y se perdio". Por eso tambien
# se escribe a disco. Esto prueba el CONTRATO del fichero que verify-fanout pide leer al loader:
# cabecera con la iteracion (guarda de frescura) + directivas opcionales + rutas literales.
expect_ok "changed-files.txt: contrato de cabecera parseable y con guarda de frescura" python3 -c "
import re
sample = '''# iteration: 2
# command: git diff --name-only HEAD~1..HEAD
# triage: fail_fast
# triage: scope_to=verify-tests,verify-design
src/app/notes.py
src/ui/list.tsx
'''
lines = sample.splitlines()
it = int(re.match(r'# iteration:\s*(-?\d+)', lines[0]).group(1))
ff = any(l.strip() == '# triage: fail_fast' for l in lines)
sc = next((m.group(1).split(',') for l in lines for m in [re.match(r'# triage:\s*scope_to=(.+)', l.strip())] if m), [])
paths = [l for l in lines if l.strip() and not l.startswith('#')]
assert it == 2, it
assert ff is True
assert sc == ['verify-tests', 'verify-design'], sc
assert paths == ['src/app/notes.py', 'src/ui/list.tsx'], paths
# Guarda de frescura: un alcance de la iteracion 2 NO puede aplicarse a la 3. Un alcance viejo
# es peor que ninguno — la propia skill lo dice: 'diez lentes se lo van a creer'.
for now in (0, 1, 3):
    assert not (it == now and now > 0), f'iteracion {now} no deberia honrar un fichero de la {it}'
assert (it == 2 and 2 > 0), 'la iteracion que coincide SI debe honrarse'
# Y sin cabecera de iteracion no se honra nada: ausencia = baseline, nunca 'aplicalo igual'.
assert re.match(r'# iteration:', 'src/app/notes.py') is None
"
# Ambas directivas fuerzan full_set:false, que el conductor no puede registrar en phase_runs[]
# y que el gate rechaza como VERIFY incompleto. Esa es la razon por la que leerlas de disco es
# aceptable: una directiva olvidada cuesta una pasada, no un PASS falso.
# Copia PROPIA: $TMP/res.bak todavia no existe en este punto del smoke (se crea mas abajo),
# asi que restaurar desde ahi dejaria el estado mutado para todas las pruebas siguientes.
cp "$RES" "$TMP/res-triage.bak"
expect_fail_msg "el gate rechaza un VERIFY truncado por triage (set incompleto)" "verify-fanout" bash -c '
python3 - <<PY
import json
p = ".orchestrator-state/evidence/SCR-001/result.json"
d = json.load(open(p))
for run in d["phase_runs"]:
    if run["phase"] == "VERIFY":
        run["lenses"] = [l for l in run["lenses"] if l not in ("verify-design", "verify-tests")]
json.dump(d, open(p, "w"), indent=2)
PY
python3 .orchestrator/scripts/validate-state.py'
cp "$TMP/res-triage.bak" "$RES"
# V2: full_set:false es legal en una entrada VERIFY que NO es la de cierre (triage real, con
# carried_forward[]). Pero este fixture solo registra UNA entrada VERIFY, así que es a la vez
# primera y última -- sigue siendo la de cierre. Marcarla full_set:false (con carried_forward de
# los dos lenses que se omitieron) debe seguir siendo ILEGAL, ahora por el motivo nuevo: la de
# cierre exige full_set:true explícito, no basta con listar lo que se "arrastró".
cp "$RES" "$TMP/res-triage2.bak"
expect_fail_msg "rechaza full_set:false en la entrada VERIFY de cierre (aunque traiga carried_forward)" "closing VERIFY entry" bash -c '
python3 - <<PY
import json
p = ".orchestrator-state/evidence/SCR-001/result.json"
d = json.load(open(p))
for run in d["phase_runs"]:
    if run["phase"] == "VERIFY":
        run["lenses"] = [l for l in run["lenses"] if l not in ("verify-design", "verify-tests")]
        run["full_set"] = False
        run["carried_forward"] = [{"lens": "verify-design", "from_iteration": 0}, {"lens": "verify-tests", "from_iteration": 0}]
json.dump(d, open(p, "w"), indent=2)
PY
python3 .orchestrator/scripts/validate-state.py'
cp "$TMP/res-triage2.bak" "$RES"
# Positivo: la secuencia REAL de una reparación -- baseline completa (iteration 0), luego una
# pasada de triage (full_set:false + carried_forward citándola), luego la de cierre completa.
# El orden importa y es parte del contrato: un triage no puede preceder a toda pasada completa,
# porque entonces no habría nada de donde arrastrar. Sin este test, el código nuevo solo estaría
# probado por el lado del rechazo.
cp "$RES" "$TMP/res-triage3.bak"
expect_ok "acepta baseline completa -> triage (full_set:false, citando iteration 0) -> cierre completa" bash -c '
python3 - <<PY
import copy, json
p = ".orchestrator-state/evidence/SCR-001/result.json"
d = json.load(open(p))
closing = next(r for r in d["phase_runs"] if r["phase"] == "VERIFY")
baseline = copy.deepcopy(closing)
baseline["iteration"] = 0
triage = copy.deepcopy(closing)
triage["iteration"] = 1
triage["lenses"] = [l for l in triage["lenses"] if l not in ("verify-design", "verify-tests")]
triage["full_set"] = False
triage["carried_forward"] = [{"lens": "verify-design", "from_iteration": 0}, {"lens": "verify-tests", "from_iteration": 0}]
closing["full_set"] = True
closing["iteration"] = 1
idx = d["phase_runs"].index(closing)
d["phase_runs"][idx:idx] = [baseline, triage]
json.dump(d, open(p, "w"), indent=2)
PY
python3 .orchestrator/scripts/validate-state.py'
cp "$TMP/res-triage3.bak" "$RES"
# --- Grandfathering de sets de lentes -----------------------------------------------------
# Crecer un set de lentes solia romper el gate del PROYECTO ENTERO: la comprobacion de cobertura
# media toda entrada historica contra la constante ACTUAL, asi que la primera unidad ya verified
# con el set viejo fallaba duro, y como el hook corre el gate en cada escritura de features.json,
# ni siquiera quedaba forma legal de reabrirla. Ahora cada set es una tupla ordenada (actual al
# final) y una entrada que cubre un set SUPERSEDED avisa en vez de fallar. Estos tres casos fijan
# las tres mitades del contrato: el positivo, el negativo que NO debe relajarse, y el agujero que
# el grandfathering abrio en carried_forward y que hubo que cerrar aparte.
VS=".orchestrator/scripts/validate-state.py"
cp "$VS" "$TMP/vs-gf.bak"
grow_verify_set() {  # anade verify-newlens al set actual CONSERVANDO el viejo en el historial
  printf -- '---\nname: verify-newlens\nmodel: sonnet\ntools: Read, Grep, Glob\n---\nstub\n' \
    > .claude/agents/verify-newlens.md
  python3 - <<'PY'
from pathlib import Path
p = Path(".orchestrator/scripts/validate-state.py")
t = p.read_text(encoding="utf-8")
assert "VERIFY_LENS_SETS = (VERIFY_LENSES,)" in t, "el ancla de VERIFY_LENS_SETS cambio de forma"
p.write_text(t.replace(
    "VERIFY_LENS_SETS = (VERIFY_LENSES,)",
    'VERIFY_LENSES_V1 = set(VERIFY_LENSES)\n'
    'VERIFY_LENSES = VERIFY_LENSES | {"verify-newlens"}\n'
    'VERIFY_LENS_SETS = (VERIFY_LENSES_V1, VERIFY_LENSES)'), encoding="utf-8")
PY
}
restore_verify_set() { cp "$TMP/vs-gf.bak" "$VS"; rm -f .claude/agents/verify-newlens.md; }
# Los casos corren via `bash -c`, que no hereda funciones del shell padre: sin este export
# grow_verify_set falla con "command not found" DENTRO del subshell y los tres tests pasan por el
# motivo equivocado (el set nunca crece, asi que validan el comportamiento de siempre). Solo
# grow_verify_set se exporta: restore_verify_set corre en el shell padre y usa $TMP/$VS de ahi.
export -f grow_verify_set

cp "$RES" "$TMP/res-gf1.bak"
expect_ok "grandfathering: evidencia completa bajo el set ANTERIOR avisa y no rompe el gate" bash -c '
grow_verify_set
python3 .orchestrator/scripts/validate-state.py'
restore_verify_set; cp "$TMP/res-gf1.bak" "$RES"

cp "$RES" "$TMP/res-gf2.bak"
expect_fail_msg "grandfathering NO tapa un set genuinamente parcial (no cubre ningun set historico)" \
  "did not run its full" bash -c '
grow_verify_set
python3 - <<PY
import json
p = ".orchestrator-state/evidence/SCR-001/result.json"
d = json.load(open(p))
run = next(r for r in d["phase_runs"] if r["phase"] == "VERIFY")
run["lenses"] = [l for l in run["lenses"] if l != "verify-quality"]
json.dump(d, open(p, "w"), indent=2)
PY
python3 .orchestrator/scripts/validate-state.py'
restore_verify_set; cp "$TMP/res-gf2.bak" "$RES"

# El agujero que abrio el grandfathering: mientras "completa" significaba "cubre el unico set
# actual", citar una iteracion bastaba, porque una entrada completa habia corrido TODA lente del
# set. Con historial eso deja de implicarse, y un triage podria arrastrar una lente ANADIDA
# DESPUES de la pasada que cita -- una lente que esa pasada nunca ejecuto. La cita se comprueba
# ahora contra las lentes realmente corridas, no contra el numero de iteracion.
cp "$RES" "$TMP/res-gf3.bak"
expect_fail_msg "rechaza carried_forward de una lente que la pasada citada nunca corrio" \
  "never ran" bash -c '
grow_verify_set
python3 - <<PY
import copy, json
p = ".orchestrator-state/evidence/SCR-001/result.json"
d = json.load(open(p))
closing = next(r for r in d["phase_runs"] if r["phase"] == "VERIFY")
ten = list(closing["lenses"])
baseline = copy.deepcopy(closing); baseline["iteration"] = 0; baseline["lenses"] = ten
triage = copy.deepcopy(closing); triage["iteration"] = 1; triage["full_set"] = False
triage["lenses"] = []
triage["carried_forward"] = [{"lens": l, "from_iteration": 0} for l in ten + ["verify-newlens"]]
closing["iteration"] = 2; closing["lenses"] = ten + ["verify-newlens"]
idx = d["phase_runs"].index(closing)
d["phase_runs"][idx:idx] = [baseline, triage]
json.dump(d, open(p, "w"), indent=2)
PY
python3 .orchestrator/scripts/validate-state.py'
restore_verify_set; cp "$TMP/res-gf3.bak" "$RES"
# fail_fast: la prosa (next-pantalla §6, constitution.md, result.schema.json) promete DOS reglas
# --- una pasada fail-fast no puede ser la de cierre, y su verdict debe ser "fail". Estuvieron sin
# respaldo mecanico hasta que una revision de regresion lo probo; estos dos casos existen para que
# no vuelva a pasar desapercibido.
cp "$RES" "$TMP/res-ff.bak"
expect_fail_msg "rechaza fail_fast:true en la entrada VERIFY de cierre" "CLOSING VERIFY entry" bash -c '
python3 - <<PY
import json
p = ".orchestrator-state/evidence/SCR-001/result.json"
d = json.load(open(p))
next(r for r in d["phase_runs"] if r["phase"] == "VERIFY")["fail_fast"] = True
json.dump(d, open(p, "w"), indent=2)
PY
python3 .orchestrator/scripts/validate-state.py'
cp "$TMP/res-ff.bak" "$RES"
expect_fail_msg "rechaza fail_fast:true cuyo verdict no es fail" "verdict is" bash -c '
python3 - <<PY
import copy, json
p = ".orchestrator-state/evidence/SCR-001/result.json"
d = json.load(open(p))
closing = next(r for r in d["phase_runs"] if r["phase"] == "VERIFY")
ff = copy.deepcopy(closing); ff["fail_fast"] = True; ff["verdict"] = "pass"
d["phase_runs"].insert(d["phase_runs"].index(closing), ff)
json.dump(d, open(p, "w"), indent=2)
PY
python3 .orchestrator/scripts/validate-state.py'
cp "$TMP/res-ff.bak" "$RES"
# `verdict` se leia en UN solo sitio —la rama fail_fast, que exige que SEA 'fail'— y en ningun otro.
# Asi que una entrada de cierre con las 10 lentes intactas y verdict:'fail' pasaba el gate, y lo
# mismo en VALIDATE y en REVIEW: la unidad podia sostener un PASS cuya ultima fase decia que fallo.
# El de REVIEW usa MAYUSCULA a proposito: pantalla-reviewer declara PASS|FAIL asi, y un cheque por
# igualdad exacta habria cubierto dos fases y saltado en silencio justo la del veredicto contractual.
VD_SET='import json,sys;p=".orchestrator-state/evidence/SCR-001/result.json";d=json.load(open(p));r=[x for x in d["phase_runs"] if x.get("phase","").upper()==sys.argv[1]];r[-1]["verdict"]=sys.argv[2];json.dump(d,open(p,"w"),indent=2)'
cp "$RES" "$TMP/res-vd.bak"
expect_fail_msg "rechaza verdict:fail en la entrada VERIFY de cierre" "cannot itself report fail" \
  bash -c 'python3 -c "$0" VERIFY fail && python3 .orchestrator/scripts/validate-state.py' "$VD_SET"
cp "$TMP/res-vd.bak" "$RES"
expect_fail_msg "rechaza verdict:fail en la entrada VALIDATE de cierre" "cannot itself report fail" \
  bash -c 'python3 -c "$0" VALIDATE fail && python3 .orchestrator/scripts/validate-state.py' "$VD_SET"
cp "$TMP/res-vd.bak" "$RES"
expect_fail_msg "rechaza verdict:FAIL (mayuscula) en la entrada REVIEW de cierre" "cannot itself report fail" \
  bash -c 'python3 -c "$0" REVIEW FAIL && python3 .orchestrator/scripts/validate-state.py' "$VD_SET"
cp "$TMP/res-vd.bak" "$RES"
# La frontera: una pasada NO-cerradora que fallo es la forma NORMAL del bucle de reparacion
# ("esta ronda encontro algo, se reparo"), y el cheque no puede tocarla.
expect_ok "acepta verdict:fail en una entrada NO-cerradora seguida de un cierre limpio" bash -c '
python3 - <<PY
import copy, json
p = ".orchestrator-state/evidence/SCR-001/result.json"
d = json.load(open(p))
i = [k for k, r in enumerate(d["phase_runs"]) if r.get("phase") == "VERIFY"][-1]
base = copy.deepcopy(d["phase_runs"][i]); base["iteration"] = 0; base["verdict"] = "fail"
d["phase_runs"].insert(i, base)
json.dump(d, open(p, "w"), indent=2)
PY
python3 .orchestrator/scripts/validate-state.py'
cp "$TMP/res-vd.bak" "$RES"
# DEVELOP es obligatoria en TODA unidad pero no tiene fan-out, asi que no pasaba por
# require_full_fanout y quedaba fuera del cheque. Una revision lo reprodujo: un PASS podia cerrar
# con phase_runs[DEVELOP].verdict:'fail' sin que el gate dijera nada. Ahora el cheque recorre la
# entrada de cierre de TODA fase presente, no tres sitios elegidos a mano.
expect_fail_msg "rechaza verdict:fail en la entrada DEVELOP de cierre" "cannot itself report fail" \
  bash -c 'python3 -c "$0" DEVELOP fail && python3 .orchestrator/scripts/validate-state.py' "$VD_SET"
cp "$TMP/res-vd.bak" "$RES"
# cap_override y layers_not_applicable: dos exenciones portadas desde maser-onda junto con el
# codigo que las implementa. Se traen SUS pruebas, no solo la funcion: una exencion sin el caso
# negativo que la acota es indistinguible de haber quitado el control.
cp "$FEAT" "$TMP/feat-cap.bak"
expect_fail_msg "rechaza cap_override vacio (sin decided_by/reason)" "cap_override" bash -c '
python3 - <<PY
import json
p = ".orchestrator-state/features.json"
d = json.load(open(p))
next(s for s in d["screens"] if s["id"] == "SCR-001")["checkpoint"] = {
    "phase": "VERIFY", "iteration": 4, "cap_override": {"decided_by": "", "reason": ""}}
json.dump(d, open(p, "w"), ensure_ascii=False, indent=2)
PY
python3 .orchestrator/scripts/validate-state.py'
cp "$TMP/feat-cap.bak" "$FEAT"
expect_ok "acepta cap_override con decided_by y reason reales" bash -c '
python3 - <<PY
import json
p = ".orchestrator-state/features.json"
d = json.load(open(p))
next(s for s in d["screens"] if s["id"] == "SCR-001")["checkpoint"] = {
    "phase": "VERIFY", "iteration": 4,
    "cap_override": {"decided_by": "El dueno", "reason": "cada pasada hallo un defecto distinto"}}
json.dump(d, open(p, "w"), ensure_ascii=False, indent=2)
PY
python3 .orchestrator/scripts/validate-state.py'
cp "$TMP/feat-cap.bak" "$FEAT"
cp "$RES" "$TMP/res-lna.bak"
expect_fail_msg "rechaza exencion de capa que la feature NO declara n/a" "does not mark that layer" bash -c '
python3 - <<PY
import json
p = ".orchestrator-state/evidence/SCR-001/result.json"
d = json.load(open(p))
a = d["data_engine_assertions"][0]
a.pop("ui_value", None)
a["layers_not_applicable"] = {"client": "inventada: la feature SI declara ui_field real"}
json.dump(d, open(p, "w"), ensure_ascii=False, indent=2)
PY
python3 .orchestrator/scripts/validate-state.py'
cp "$TMP/res-lna.bak" "$RES"
expect_ok "hook: comando Bash sobre estado válido pasa" bash -c 'echo "{\"tool_input\":{\"command\":\"cat .orchestrator-state/features.json\"}}" | bash .claude/hooks/validate-state.sh'

# PreCompact: la compactacion borra el chat, y el ancla de reanudacion vive en disco. El hook
# no decide ni muta ciclo de vida (constitution: "Do not use hooks to mutate lifecycle") —
# refresca las proyecciones e imprime el ancla. Debe ser SIEMPRE no-fatal: un hook que pueda
# fallar aqui convierte "el contexto se hizo largo" en "la tirada murio".
echo
echo "== block-rm: el guardarrail de borrado =="
# De los 3 hooks, este era el UNICO sin un solo caso — ni positivo ni negativo. Por eso llevaba
# desde siempre un escape por travesia: is_temp() comparaba el token LITERAL contra las raices
# temporales, asi que "rm -rf /tmp/../etc" empezaba por "/tmp/" y se PERMITIA. Verificado en vivo
# antes del arreglo, incluido "rm -rf /tmp/../Users/<tu>/Desktop" — el padre del propio repo.
# La exencion dice "esto cae en scratch", que es una afirmacion sobre donde RESUELVE la ruta, no
# sobre como se escribe; por eso ahora se normaliza antes de comparar.
rm_denies() {  # $1 = comando; exito si el hook lo DENIEGA
  printf '{"tool_input":{"command":%s}}\n' "$(python3 -c 'import json,sys;print(json.dumps(sys.argv[1]))' "$1")" \
    | bash .claude/hooks/block-rm.sh 2>/dev/null | grep -q '"permissionDecision": "deny"'
}
rm_allows() { ! rm_denies "$1"; }
export -f rm_denies rm_allows
expect_ok "block-rm: deniega un borrado recursivo fuera de scratch" bash -c 'rm_denies "rm -rf /etc"'
expect_ok "block-rm: deniega el escape por .. desde una raiz temporal" bash -c '
rm_denies "rm -rf /tmp/../etc" && rm_denies "find /tmp/../etc -delete" && rm_denies "rm -rf /tmp//../etc"'
expect_ok "block-rm: deniega el escape por .. tras una variable \$TMP*" bash -c '
rm_denies "rm -rf \$TMPDIR/../../etc" && rm_denies "rm -rf \${TMPDIR}/../.."'
expect_ok "block-rm: sigue permitiendo limpieza legitima de scratch" bash -c '
rm_allows "rm -rf /tmp/scratch" && rm_allows "rm -rf \$TMPDIR/build" && rm_allows "rm -rf /tmp/a/b/../c"'
expect_ok "block-rm: sigue deniegando lo de siempre (., \$HOME, git clean, sudo)" bash -c '
rm_denies "rm -rf ." && rm_denies "rm -rf \$HOME" && rm_denies "git clean -fdx" && rm_denies "sudo rm -rf /"'

expect_ok_msg "precompact: imprime el ancla de reanudacion desde disco" "resume anchor" \
  bash .claude/hooks/precompact-checkpoint.sh
# Los 4 casos de arriba comprueban el TEXTO del ancla, nunca la CLAVE JSON que lo porta — asi que
# revertir el defecto original (volver a hookSpecificOutput.additionalContext, que PreCompact no
# soporta: el ancla dejaria de llegar a ninguna parte) los deja a los 4 en verde. Un test que no
# cae cuando el bug vuelve no protege nada. Este fija la FORMA: clave systemMessage de primer
# nivel, y ninguna mencion de additionalContext en la salida.
expect_ok "precompact: emite systemMessage, NO el additionalContext que PreCompact no soporta" bash -c '
out="$(bash .claude/hooks/precompact-checkpoint.sh 2>/dev/null)"
python3 - "$out" <<PY
import json, sys
raw = sys.argv[1]
d = json.loads(raw)
assert list(d.keys()) == ["systemMessage"], f"clave de primer nivel inesperada: {list(d.keys())}"
assert "additionalContext" not in raw, "additionalContext reaparecio: PreCompact no lo soporta"
assert "hookSpecificOutput" not in raw, "hookSpecificOutput reaparecio en un evento que no lo usa"
assert "resume anchor" in d["systemMessage"], "el ancla no viaja dentro de systemMessage"
PY'
expect_ok_msg "precompact: nombra la unidad activa y su checkpoint" "resume at phase VERIFY, iteration 2" \
  bash -c '
python3 - <<PY
import json
p=".orchestrator-state/features.json"; d=json.load(open(p))
s=next(x for x in d["screens"] if x["id"]=="SCR-001")
s["status"]="building"; s["passes"]=False; s["checkpoint"]={"phase":"VERIFY","iteration":2}
c={}
for x in d["screens"]: c[x["status"]]=c.get(x["status"],0)+1
for k in d["summary"]:
    if k!="total": d["summary"][k]=c.get(k,0)
json.dump(d,open(p,"w"),indent=2)
PY
bash .claude/hooks/precompact-checkpoint.sh'
expect_ok_msg "precompact: nombra el batch en vuelo, no el recuento recordado" "BATCH IN FLIGHT" \
  bash -c '
echo "{\"schema_version\":\"orchestrator.batch.v1\",\"mode\":\"build-loop\",\"started_at\":\"2026-01-01T00:00:00Z\",\"status\":\"running\",\"max_requested\":5,\"units_built\":[\"SCR-FOUNDATION-SCHEMA\"]}" > .orchestrator-state/batch.json
bash .claude/hooks/precompact-checkpoint.sh'
# Un batch.json corrupto no puede tumbar la compactacion: degrada a aviso y sigue.
expect_ok_msg "precompact: batch.json corrupto avisa pero no rompe" "does not parse" \
  bash -c 'echo "esto no es json" > .orchestrator-state/batch.json; bash .claude/hooks/precompact-checkpoint.sh'
rm -f .orchestrator-state/batch.json
cp "$TMP/feat.bak" "$FEAT" 2>/dev/null || cp "$GP/state/features.json" "$FEAT"

echo "== golden path: negativos (el gate debe rechazar) =="
cp "$RES" "$TMP/res.bak"; cp "$FEAT" "$TMP/feat.bak"

python3 - <<'PY'
import json
p = '.orchestrator-state/evidence/SCR-001/result.json'
d = json.load(open(p))
for run in d['phase_runs']:
    if run['phase'] == 'VERIFY':
        run['lenses'] = [l for l in run['lenses'] if l != 'verify-coherence']
json.dump(d, open(p, 'w'), ensure_ascii=False, indent=2)
PY
expect_fail_msg "rechaza VERIFY con set de lentes incompleto (sin verify-coherence)" "did not run its full" python3 .orchestrator/scripts/validate-state.py
cp "$TMP/res.bak" "$RES"

# COBERTURA CRITERIO -> CHECK. conventions.md siempre exigio que result.json "connect checks to
# acceptance criteria", y `acceptance_ids` no aparecia NI UNA VEZ en validate-state.py: una unidad
# podia cerrar con los checks etiquetados por tema aproximado ("tests", "datos", "logs"), ninguno
# rastreable al criterio que debia responder. La evidencia parecia completa y probaba otra cosa.
python3 - <<'PY'
import json
p = '.orchestrator-state/evidence/SCR-001/result.json'
d = json.load(open(p))
for c in d['checks']:
    ids = c.get('acceptance_ids') or []
    if 'AC-SCR-001-004' in ids:
        c['acceptance_ids'] = [x for x in ids if x != 'AC-SCR-001-004']
json.dump(d, open(p, 'w'), ensure_ascii=False, indent=2)
PY
expect_fail_msg "rechaza un criterio de aceptacion que ningun check cita por su id" \
  "acceptance criteria with no check citing them" \
  python3 .orchestrator/scripts/validate-state.py
cp "$TMP/res.bak" "$RES"
python3 - <<'PY'
import json
p = '.orchestrator-state/evidence/SCR-001/result.json'
d = json.load(open(p))
d['checks'][0].setdefault('acceptance_ids', []).append('AC-SCR-001-999')
json.dump(d, open(p, 'w'), ensure_ascii=False, indent=2)
PY
expect_fail_msg "rechaza un check que cita un criterio que la unidad no declara" \
  "acceptance ids the unit does not declare" \
  python3 .orchestrator/scripts/validate-state.py
cp "$TMP/res.bak" "$RES"
# Valvula de escape: un criterio que esta unidad no puede probar (consistencia cross-pantalla que
# solo /verify-app ejercita) se NOMBRA y se justifica, no se falsea con un check trivial. Misma
# forma que data_engine.not_applicable_reason. Sin razon no excusa nada.
python3 - <<'PY'
import json
p = '.orchestrator-state/evidence/SCR-001/result.json'
d = json.load(open(p))
for c in d['checks']:
    ids = c.get('acceptance_ids') or []
    if 'AC-SCR-001-004' in ids:
        c['acceptance_ids'] = [x for x in ids if x != 'AC-SCR-001-004']
d['acceptance_deferred'] = [{'id': 'AC-SCR-001-004', 'reason': ''}]
json.dump(d, open(p, 'w'), ensure_ascii=False, indent=2)
PY
expect_fail_msg "un diferimiento SIN razon no excusa el criterio" \
  "acceptance criteria with no check citing them" \
  python3 .orchestrator/scripts/validate-state.py
python3 - <<'PY'
import json
p = '.orchestrator-state/evidence/SCR-001/result.json'
d = json.load(open(p))
d['acceptance_deferred'] = [{'id': 'AC-SCR-001-004',
                             'reason': 'consistencia cross-pantalla: solo /verify-app la prueba',
                             'proved_by': '/verify-app JOUR-001'}]
json.dump(d, open(p, 'w'), ensure_ascii=False, indent=2)
PY
expect_ok "un diferimiento CON razon excusa el criterio" python3 .orchestrator/scripts/validate-state.py
cp "$TMP/res.bak" "$RES"

# advisory_findings[]: la SEGUNDA salida de un hallazgo, y la razon de que el bucle no terminara.
# Existia en el schema y /accept --auto lo leia, pero NADIE lo escribia: los "non-blocking cleanups"
# de los gates §5.5 vivian solo en la prosa de su informe, que nada aguas abajo consumia, asi que
# repararlos era la unica forma de que no se olvidaran — y cada reparacion abria otra vuelta.
python3 - <<'PY'
import json
p = '.orchestrator-state/evidence/SCR-001/result.json'
d = json.load(open(p))
d['advisory_findings'] = [{
    'id': 'ADV-SCR-001-001', 'severity': 'low', 'source': 'production-code-review',
    'detail': 'el helper de formato podria vivir en la shell; a una pantalla no compensa',
    'refs': ['UI-SHELL-003'], 'status': 'open',
}]
json.dump(d, open(p, 'w'), ensure_ascii=False, indent=2)
PY
expect_ok "un hallazgo no bloqueante se registra y NO impide cerrar" \
  python3 .orchestrator/scripts/validate-state.py
# La frontera es lo que sostiene el peso: no puede ser a la vez lo que bloquea y lo que se perdona.
# El escenario se monta con verdict:FAIL a proposito: sobre un PASS, la regla "failures[] vacio"
# lo rechazaria antes y esta guarda no llegaria a correr, asi que el caso solo prueba lo que dice
# probar mientras la unidad esta EN VUELO — que es justo cuando alguien marca como deuda algo que
# todavia esta fallando.
# (Este caso invocaba `--preflight SCR-001`. Ese flag no existe: main() solo parsea --arch-hash,
#  --emit-status e --init-gate, y los desconocidos se ignoran en silencio — el mismo defecto que
#  --decidedness tuvo y que este fichero documenta mas arriba. El caso pasaba por el gate normal,
#  no por un modo "en vuelo" inexistente; quitar el flag no cambia lo que prueba, solo deja de
#  afirmar un mecanismo que no hay.)
python3 - <<'PY'
import json
p = '.orchestrator-state/evidence/SCR-001/result.json'
d = json.load(open(p))
d['verdict'] = 'FAIL'
d['advisory_findings'][0]['status'] = 'accepted_as_debt'
d['failures'] = ['ADV-SCR-001-001']
json.dump(d, open(p, 'w'), ensure_ascii=False, indent=2)
PY
expect_fail_msg "rechaza un hallazgo aceptado como deuda que ademas esta en failures[]" \
  "either blocking or waived, never both" \
  python3 .orchestrator/scripts/validate-state.py
cp "$TMP/res.bak" "$RES"
# Y su severidad tiene que ser legible: /accept --auto la compara contra el techo de autonomy.md,
# asi que una severidad invalida desactivaria esa barra en silencio.
python3 - <<'PY'
import json
p = '.orchestrator-state/evidence/SCR-001/result.json'
d = json.load(open(p))
d['advisory_findings'] = [{'id': 'ADV-1', 'severity': 'meh', 'detail': 'x'}]
json.dump(d, open(p, 'w'), ensure_ascii=False, indent=2)
PY
expect_fail_msg "rechaza una severidad advisory que --auto no puede comparar" \
  "severity must be one of" \
  python3 .orchestrator/scripts/validate-state.py
cp "$TMP/res.bak" "$RES"
# Un blocker NUNCA es deuda: si se pudiera perdonar escribiendole un status al lado, "los hallazgos
# no bloqueantes se registran en vez de repararse" se convertiria en "cualquier hallazgo se registra
# en vez de repararse", que no es una segunda salida sino una salida del estandar de evidencia.
python3 - <<'PY'
import json
p = '.orchestrator-state/evidence/SCR-001/result.json'
d = json.load(open(p))
d['advisory_findings'] = [{'id': 'ADV-1', 'severity': 'blocker', 'detail': 'rompe el contrato de datos',
                           'status': 'accepted_as_debt'}]
json.dump(d, open(p, 'w'), ensure_ascii=False, indent=2)
PY
expect_fail_msg "rechaza perdonar como deuda un hallazgo de severidad blocker" \
  "a blocker is never" \
  python3 .orchestrator/scripts/validate-state.py
cp "$TMP/res.bak" "$RES"

# EL MISMO AGUJERO, UN NIVEL MAS ABAJO — el tercero de esta familia, tras el source_manifest
# ausente y el vacio. El bucle de existencia abre cada ruta que el result CITA; no tiene nada que
# decir de un result que no cita ninguna. Asi que un PASS con artifacts:[] corria el guarda sobre
# CERO rutas y salia pareciendo comprobado. Encontrado en produccion: una cita fantasma sobrevivio
# muchas iteraciones justo porque la coleccion en la que debia estar iba vacia.
python3 - <<'PY'
import json
p = '.orchestrator-state/evidence/SCR-001/result.json'
d = json.load(open(p))
d['artifacts'] = []
for c in d['checks']:
    c['artifacts'] = []
json.dump(d, open(p, 'w'), ensure_ascii=False, indent=2)
PY
expect_fail_msg "rechaza un PASS que no cita NINGUN artefacto" "cites NO artifacts at all" \
  python3 .orchestrator/scripts/validate-state.py
cp "$TMP/res.bak" "$RES"

# EXPLORE debe dejar su plan en disco (phase_runs[EXPLORE].plan -> evidence/<ID>/plan.md).
# La seccion que lo produce se llama "Explore AND PLAN": el plan es el entregable de EXPLORE,
# no una fase aparte. Vivia solo en el contexto del conductor, y de ahi salian tres cosas: una
# compactacion a mitad de DEVELOP lo re-derivaba, nadie podia preguntar "¿se construyo lo que
# se planeo?", y un criterio sin respuesta a "¿como se prueba?" no se veia hasta gastar el
# abanico de VERIFY. Se comprueba igual que cualquier artefacto: existe y no pesa 0 bytes.
python3 - <<'PY'
import json
p = '.orchestrator-state/evidence/SCR-001/result.json'
d = json.load(open(p))
for run in d['phase_runs']:
    if run['phase'] == 'EXPLORE':
        run.pop('plan', None)
json.dump(d, open(p, 'w'), ensure_ascii=False, indent=2)
PY
expect_fail_msg "rechaza un EXPLORE sin plan[] en una unidad aun en vuelo" "has no .plan." \
  python3 .orchestrator/scripts/validate-state.py
cp "$TMP/res.bak" "$RES"

python3 - <<'PY'
import json
p = '.orchestrator-state/evidence/SCR-001/result.json'
d = json.load(open(p))
for run in d['phase_runs']:
    if run['phase'] == 'EXPLORE':
        run['plan'] = '.orchestrator-state/evidence/SCR-001/plan-que-no-existe.md'
json.dump(d, open(p, 'w'), ensure_ascii=False, indent=2)
PY
expect_fail_msg "rechaza un plan citado que no es un fichero real" "which is not a file" \
  python3 .orchestrator/scripts/validate-state.py
cp "$TMP/res.bak" "$RES"

# CONTENCION del plan. Sin ella el check solo prueba que EXISTE algun fichero no vacio en alguna
# parte: `ROOT / "/etc/hosts"` descarta ROOT entero (pathlib tira el operando izquierdo ante uno
# absoluto) y suficientes `../` se salen del arbol, asi que cualquier fichero legible de la maquina
# satisfacia "EXPLORE escribio su plan". Y ademas cierra el hueco de evidencia prestada que
# validate_result ya cierra para result.json: citar el plan.md de OTRA unidad tambien pasaba.
for bad in "/etc/hosts" "../../../../../../../../etc/hosts" ".orchestrator-state/evidence/SCR-FOUNDATION-SCHEMA/plan.md"; do
  python3 - "$bad" <<'PY'
import json, sys
p = '.orchestrator-state/evidence/SCR-001/result.json'
d = json.load(open(p))
for run in d['phase_runs']:
    if run['phase'] == 'EXPLORE':
        run['plan'] = sys.argv[1]
json.dump(d, open(p, 'w'), ensure_ascii=False, indent=2)
PY
  expect_fail_msg "rechaza un plan fuera del directorio de evidencia de la unidad ($bad)" \
    "must be a repo-relative path inside this" \
    python3 .orchestrator/scripts/validate-state.py
  cp "$TMP/res.bak" "$RES"
done

# `"plan": null` TIENE la clave, asi que dict.get(k, "") no aplica el default y str(None)=="None"
# se colaba hasta el chequeo de fichero, dando "points at None" — que se lee como un problema de
# ruta en vez de como un plan ausente. Mismo fallo, mensaje que manda al sitio equivocado.
python3 - <<'PY'
import json
p = '.orchestrator-state/evidence/SCR-001/result.json'
d = json.load(open(p))
for run in d['phase_runs']:
    if run['phase'] == 'EXPLORE':
        run['plan'] = None
json.dump(d, open(p, 'w'), ensure_ascii=False, indent=2)
PY
expect_fail_msg "un plan a null se reporta como plan AUSENTE, no como ruta rota" "has no .plan." \
  python3 .orchestrator/scripts/validate-state.py
cp "$TMP/res.bak" "$RES"

# Retroactividad, igual que source_manifest: una unidad que un humano ya ACEPTO no se invalida
# por un requisito que no existia cuando la firmo — reabrir `accepted` esta prohibido en otro
# sitio de este mismo gate, asi que fallar aqui no dejaria ninguna jugada legal. Avisa y sigue.
cp "$GP/state/evidence/SCR-FOUNDATION-SCHEMA/result.json" "$TMP/res-schema.bak"
python3 - <<'PY'
import json
p = '.orchestrator-state/evidence/SCR-FOUNDATION-SCHEMA/result.json'
d = json.load(open(p))
for run in d['phase_runs']:
    if run['phase'] == 'EXPLORE':
        run.pop('plan', None)
json.dump(d, open(p, 'w'), ensure_ascii=False, indent=2)
PY
expect_ok "una unidad ya accepted sin plan solo AVISA (no invalida evidencia firmada)" bash -c '
out=$(python3 .orchestrator/scripts/validate-state.py 2>&1); rc=$?
[ "$rc" -eq 0 ] && printf "%s" "$out" | grep -q "SCR-FOUNDATION-SCHEMA.phase_runs\[EXPLORE\] has no"'
cp "$TMP/res-schema.bak" ".orchestrator-state/evidence/SCR-FOUNDATION-SCHEMA/result.json"

python3 - <<'PY'
import json
p = '.orchestrator-state/evidence/SCR-001/result.json'
d = json.load(open(p)); d['screen_id'] = 'SCR-FOUNDATION-SHELL'
json.dump(d, open(p, 'w'), ensure_ascii=False, indent=2)
PY
expect_fail_msg "rechaza evidencia prestada (screen_id de otra pantalla)" "evidence cannot be borrowed across screens" python3 .orchestrator/scripts/validate-state.py
cp "$TMP/res.bak" "$RES"

python3 - <<'PY'
import json
p = '.orchestrator-state/evidence/SCR-001/result.json'
d = json.load(open(p)); d['data_engine_assertions'][0]['ui_value'] = 'Comprar té'
json.dump(d, open(p, 'w'), ensure_ascii=False, indent=2)
PY
expect_fail_msg "recomputa same_value: deriva db/ui ('café' vs 'té')" "observed values differ across layers" python3 .orchestrator/scripts/validate-state.py
cp "$TMP/res.bak" "$RES"

python3 - <<'PY'
import json
p = '.orchestrator-state/features.json'
d = json.load(open(p))
next(s for s in d['screens'] if s['id'] == 'SCR-001')['checkpoint'] = {'phase': 'VERIFY', 'iteration': 4}
json.dump(d, open(p, 'w'), ensure_ascii=False, indent=2)
PY
expect_fail_msg "rechaza debugger loop pasado del tope (iteration 4 > 3)" "the debugger loop cap is 3" python3 .orchestrator/scripts/validate-state.py
cp "$TMP/feat.bak" "$FEAT"

# EL TERMINADOR DE LA RACHA DOCS-ONLY. Una pasada docs-only no gasta checkpoint.iteration ni
# total_repair_passes — esa exencion es lo que la abarata, y era tambien lo unico que la dejaba
# SIN COTA: una lente pide escribir en el blueprint, la escritura es docs-only, la pasada
# docs-only relanza esas mismas 4 lentes, y una puede pedir la siguiente escritura. Cada vuelta
# crea su propia entrada siguiente, que es exactamente la clase de bucle sin punto fijo que la
# constitucion ya nombra. La cota es la RACHA, derivada del derived_scope que el conductor ya
# tiene que registrar — no un campo nuevo que se pueda olvidar.
cp "$RES" "$TMP/res-docsonly.bak"
python3 - <<'PY'
import json
p = '.orchestrator-state/evidence/SCR-001/result.json'
d = json.load(open(p))
runs = d['phase_runs']
verify = [r for r in runs if str(r.get('phase', '')).upper() == 'VERIFY']
base = dict(verify[-1])
full = [l for l in base.get('lenses', [])]
# 3 docs-only seguidas: una mas de las 2 que permite el tope
extra = []
for i in range(3):
    e = dict(base)
    e['derived_scope'] = 'docs_only'
    e['full_set'] = False
    e['iteration'] = 1
    e['lenses'] = ['verify-conformance', 'verify-design', 'verify-coherence', 'verify-blueprint-drift']
    e['carried_forward'] = [{'lens': l, 'from_iteration': 0}
                            for l in full if l not in e['lenses']]
    extra.append(e)
idx = runs.index(verify[-1])
d['phase_runs'] = runs[:idx + 1] + extra + [dict(base)] + runs[idx + 1:]   # cierra completa, y conserva VALIDATE/REVIEW
json.dump(d, open(p, 'w'), ensure_ascii=False, indent=2)
PY
expect_fail_msg "rechaza una racha de 3 pasadas docs-only seguidas (tope 2)" \
  "consecutive docs-only passes" python3 .orchestrator/scripts/validate-state.py
cp "$TMP/res-docsonly.bak" "$RES"
# Y el positivo: 2 seguidas es legal — el tope acota, no prohibe la optimizacion.
python3 - <<'PY'
import json
p = '.orchestrator-state/evidence/SCR-001/result.json'
d = json.load(open(p))
runs = d['phase_runs']
verify = [r for r in runs if str(r.get('phase', '')).upper() == 'VERIFY']
base = dict(verify[-1])
full = [l for l in base.get('lenses', [])]
extra = []
for i in range(2):
    e = dict(base)
    e['derived_scope'] = 'docs_only'
    e['full_set'] = False
    e['iteration'] = 1
    e['lenses'] = ['verify-conformance', 'verify-design', 'verify-coherence', 'verify-blueprint-drift']
    e['carried_forward'] = [{'lens': l, 'from_iteration': 0}
                            for l in full if l not in e['lenses']]
    extra.append(e)
idx = runs.index(verify[-1])
d['phase_runs'] = runs[:idx + 1] + extra + [dict(base)] + runs[idx + 1:]
json.dump(d, open(p, 'w'), ensure_ascii=False, indent=2)
PY
expect_ok "acepta 2 pasadas docs-only seguidas (el tope acota, no prohibe)" \
  python3 .orchestrator/scripts/validate-state.py
cp "$TMP/res-docsonly.bak" "$RES"

python3 - <<'PY'
import json
p = '.orchestrator-state/features.json'
d = json.load(open(p))
for sid in ('SCR-FOUNDATION-SCHEMA', 'SCR-FOUNDATION-SHELL'):
    s = next(x for x in d['screens'] if x['id'] == sid)
    s['status'] = 'building'; s['passes'] = False
# El resto del estado queda coherente para que el UNICO fallo posible sea el
# invariante `building <= 1`: las dos unidades quedan independientes (si SHELL
# siguiera dependiendo de SCHEMA fallaria por la dependencia) y el summary se
# recalcula. Verificado: neutralizando el invariante, el gate vuelve a pasar.
next(x for x in d['screens'] if x['id'] == 'SCR-FOUNDATION-SHELL')['after'] = []
if isinstance(d.get('summary'), dict):
    counts = {}
    for s in d['screens']:
        counts[s['status']] = counts.get(s['status'], 0) + 1
    for k in d['summary']:
        if k != 'total':
            d['summary'][k] = counts.get(k, 0)
json.dump(d, open(p, 'w'), ensure_ascii=False, indent=2)
PY
expect_fail_msg "rechaza dos unidades en building a la vez" "more than one unit is building" \
  python3 .orchestrator/scripts/validate-state.py
cp "$TMP/feat.bak" "$FEAT"

mv .orchestrator-state/evidence/SCR-001/screenshots/success.png "$TMP/shot.bak"
expect_fail_msg "rechaza PASS con artefacto ausente (screenshot borrado)" "references missing or non-file artifact" python3 .orchestrator/scripts/validate-state.py
# El screenshot vuelve ANTES de los dos casos siguientes: si no, el gate falla por el
# artefacto que falta y ambos se quedarian en verde sin probar su propio invariante.
mv "$TMP/shot.bak" .orchestrator-state/evidence/SCR-001/screenshots/success.png
cp "$RES" "$TMP/res-optional.bak"
# LA FIRMA: un guarda escrito como "si el campo esta, compruebalo" se apaga omitiendo el campo,
# y un guarda apagado produce exactamente la misma salida que uno satisfecho. Ya paso una vez
# aqui (platforms[] vacio hacia que el gate se saltara VALIDATE entera, validate-state.py:178).
# Estos dos casos cierran los que quedaban.
python3 - <<'PYX'
import json
p = ".orchestrator-state/evidence/SCR-001/result.json"
d = json.load(open(p)); d.pop("source_manifest", None)
json.dump(d, open(p, "w"), indent=2)
PYX
expect_fail_msg "rechaza un PASS sin source_manifest (el guarda anti-rancio no puede correr)" \
  "indistinguishable from a manifest that passes" python3 .orchestrator/scripts/validate-state.py
cp "$TMP/res-optional.bak" "$RES"
# La otra mitad de esa misma regla, y la que no estaba probada: una unidad ya ACEPTADA con el
# manifiesto AUSENTE solo avisa. Las dos hermanas mas leves —manifiesto vacio y entrada sin
# sha256— ya lo hacian; esta fallaba duro pasara lo que pasara, que es al reves de como deberia
# ordenarse. En un proyecto anterior a la regla eso solo dejaba dos salidas, y las dos malas:
# el gate en rojo para siempre, o RELLENAR el manifiesto con los hashes de hoy sobre una prueba
# que nunca los comparo. Fabricar evidencia para contentar al guarda contra la evidencia rancia
# seria el peor final posible, asi que aqui se avisa. Sigue fallando duro fuera de `accepted`,
# que es lo que comprueba el caso de justo encima con SCR-001 (`verified`).
cp "$GP/state/evidence/SCR-FOUNDATION-SCHEMA/result.json" "$TMP/res-nomanifest.bak"
python3 - <<'PY'
import json
p = '.orchestrator-state/evidence/SCR-FOUNDATION-SCHEMA/result.json'
d = json.load(open(p)); d.pop('source_manifest', None)
json.dump(d, open(p, 'w'), ensure_ascii=False, indent=2)
PY
expect_ok "una unidad ya accepted SIN source_manifest solo AVISA (no se fabrica un manifiesto)" bash -c '
out=$(python3 .orchestrator/scripts/validate-state.py 2>&1); rc=$?
[ "$rc" -eq 0 ] && printf "%s" "$out" | grep -q "is a PASS with no source_manifest"'
cp "$TMP/res-nomanifest.bak" ".orchestrator-state/evidence/SCR-FOUNDATION-SCHEMA/result.json"
# La razon de ser del manifiesto: si un fichero de IMPLEMENTACION cambio despues de la evidencia,
# el PASS certifica codigo que ya no existe. Hasta que el fixture trajo product/, esta rama —la mas
# importante de validate_source_manifest— no era ejercitable, porque el 100% del manifiesto eran
# rutas de blueprint y esas solo AVISAN. Los dos casos prueban justo esa asimetria.
expect_fail_msg "rechaza evidencia rancia: un fichero de IMPLEMENTACION cambio tras el PASS" \
  "source_manifest stale" bash -c '
echo "// editado despues de la evidencia" >> app/notas.py
python3 .orchestrator/scripts/validate-state.py'
cp "$TMP/res-optional.bak" "$RES"
git checkout -- app/notas.py 2>/dev/null || cp "$GP/product/app/notas.py" app/notas.py
expect_ok_msg "un fichero de BLUEPRINT cambiado solo avisa (un write-back no invalida una prueba)" \
  "source_manifest" bash -c '
echo "" >> blueprint/logic/data.md
python3 .orchestrator/scripts/validate-state.py'
cp -R "$GP/blueprint/." blueprint/
python3 - <<'PYX'
import json
p = ".orchestrator-state/evidence/SCR-001/result.json"
d = json.load(open(p)); d.pop("expected_ui_values", None)
json.dump(d, open(p, "w"), indent=2)
PYX
expect_fail_msg "rechaza un PASS con valor de cliente y sin expected_ui_values[]" \
  "derives-from assertion was vacuous" python3 .orchestrator/scripts/validate-state.py
cp "$TMP/res-optional.bak" "$RES"

# VALIDATE dejó de ser solo-UI: una unidad que cita PIPE-* (o ENG-*) debe PROBAR que el
# pipeline/motor corrió de verdad. Verificarlo estáticamente ya no basta para llegar a verified.
python3 - <<'PY'
import json
p = '.orchestrator-state/evidence/SCR-001/result.json'
d = json.load(open(p))
for run in d['phase_runs']:
    if run['phase'] == 'VALIDATE':
        run['lenses'] = [l for l in run['lenses'] if l != 'validate-pipeline']
json.dump(d, open(p, 'w'), ensure_ascii=False, indent=2)
PY
expect_fail_msg "rechaza unidad que cita PIPE-001 sin validate-pipeline en vivo" "missing required live validators" python3 .orchestrator/scripts/validate-state.py
cp "$TMP/res.bak" "$RES"

echo 'esto ya no es json' > "$FEAT"
if echo "{\"tool_input\":{\"file_path\":\"$WORK/$FEAT\"}}" | bash .claude/hooks/validate-state.sh >/dev/null 2>&1; then
  bad "hook rechaza features.json corrupto (debería haber fallado)"
else
  ok "hook rechaza features.json corrupto"
fi
cp "$TMP/feat.bak" "$FEAT"

# Ralph: build-loop encadena sin aceptar. Construir sobre una dependencia `verified` es LEGAL
# (permiso para trabajar); aceptar saltandose el orden de after[] NO lo es (permiso para dar por
# bueno). Sin el primero, /build-loop solo avanzaba un nivel del DAG por ejecucion.
python3 - <<'PY'
import json
p = '.orchestrator-state/features.json'
d = json.load(open(p))
for s in d['screens']:
    if s['status'] == 'accepted':
        s['status'] = 'verified'
counts = {}
for s in d['screens']:
    counts[s['status']] = counts.get(s['status'], 0) + 1
for k in d['summary']:
    if k != 'total':
        d['summary'][k] = counts.get(k, 0)
json.dump(d, open(p, 'w'), ensure_ascii=False, indent=2)
PY
expect_ok "permite construir sobre dependencias solo verified (cadena entera sin accepts)" python3 .orchestrator/scripts/validate-state.py
expect_ok "status.json separa lo aceptable-ya de lo que espera orden" python3 -c "
import json, subprocess
subprocess.run(['python3', '.orchestrator/scripts/validate-state.py', '--emit-status'], check=True, capture_output=True)
d = json.load(open('.orchestrator-state/status.json'))
assert d['acceptable_now'] == ['SCR-FOUNDATION-SCHEMA'], d['acceptable_now']
waiting = {r['id'] for r in d['verified_blocked_by_accept_order']}
assert waiting == {'SCR-FOUNDATION-SHELL', 'SCR-001'}, waiting
"
cp "$TMP/feat.bak" "$FEAT"

python3 - <<'PY'
import json
p = '.orchestrator-state/features.json'
d = json.load(open(p))
# SCR-001 aceptado mientras su dependencia SHELL sigue solo verified: la puerta humana
# debe seguir el orden del DAG aunque construir por delante este permitido.
next(s for s in d['screens'] if s['id'] == 'SCR-FOUNDATION-SHELL')['status'] = 'verified'
next(s for s in d['screens'] if s['id'] == 'SCR-001')['status'] = 'accepted'
json.dump(d, open(p, 'w'), ensure_ascii=False, indent=2)
PY
expect_fail_msg "rechaza aceptar saltandose el orden de after[] (dependencia solo verified)" "acceptance follows the aft" python3 .orchestrator/scripts/validate-state.py
cp "$TMP/feat.bak" "$FEAT"

# /accept --auto solo es honesto contra una politica RESUELTA. Espejo exacto del backstop de
# <COMMAND_*> en stack.md: una politica con placeholders no ha autorizado nada, y leer
# <AUTO_ACCEPT_SEVERITY_CEILING> como permiso produciria unidades "aceptadas por politica"
# donde no habia politica. Solo se comprueba cuando alguien reclama aceptacion automatica.
# Variable PROPIA: $RES es global y apunta a SCR-001. Reasignarla haria que los
# `cp "$TMP/res.bak" "$RES"` posteriores escribieran la evidencia de una pantalla en la
# ruta de otra — justo el "evidencia prestada" que el gate rechaza tres casos mas arriba.
RES_SCHEMA=".orchestrator-state/evidence/SCR-FOUNDATION-SCHEMA/result.json"
cp "$RES_SCHEMA" "$TMP/res-schema.bak"
cp .claude/rules/autonomy.md "$TMP/autonomy.bak"
# Los dos casos de abajo necesitan una politica CON un placeholder sin resolver. En el scaffold
# eso se cumple por accidente, y por eso el caso pasaba: leia la autonomy.md del repo ANFITRION.
# En un proyecto real la politica esta rellenada, no queda ni un placeholder, el gate no tiene
# nada que rechazar y el caso fallaba — un test que dependia del entorno en vez de montarse su
# propio supuesto. Se lo montamos aqui: asi prueba el GATE, y prueba lo mismo en todas partes.
printf '\n<UNRESOLVED_SMOKE_PLACEHOLDER>\n' >> .claude/rules/autonomy.md
mark_auto() { python3 - "$1" <<'PY'
import json, sys
p = ".orchestrator-state/evidence/SCR-FOUNDATION-SCHEMA/result.json"
d = json.load(open(p))
d.setdefault("human_gate", {}).update(
    {"accepted": True, "accepted_by": "auto",
     "policy_rule": None if sys.argv[1] == "sin-regla" else "AUTO-003"})
# Una aceptacion automatica completa declara advisory_findings, aunque sea vacio: --auto
# comprueba los hallazgos contra el techo de severidad, y un array AUSENTE no es "no hay
# hallazgos", es "nadie los escribio". El caso sin el se prueba aparte, mas abajo.
if sys.argv[1] != "sin-hallazgos":
    d["advisory_findings"] = []
else:
    d.pop("advisory_findings", None)
json.dump(d, open(p, "w"), indent=2)
PY
}
expect_ok "politica con placeholders no molesta si nadie acepto por politica" python3 .orchestrator/scripts/validate-state.py
mark_auto con-regla
expect_fail_msg "rechaza auto-aceptacion contra una politica sin resolver" "an unfilled policy authorizes nothing" \
  python3 .orchestrator/scripts/validate-state.py
python3 - <<'PY'
import re
from pathlib import Path
p = Path('.claude/rules/autonomy.md')
p.write_text(re.sub(r'<[A-Z][A-Z0-9_]{2,}>', 'resuelto', p.read_text(encoding='utf-8')), encoding='utf-8')
PY
expect_ok "acepta auto-aceptacion contra una politica resuelta" python3 .orchestrator/scripts/validate-state.py
mark_auto sin-regla
expect_fail_msg "rechaza auto-aceptacion que no nombra la regla que la autorizo" "no policy_rule" \
  python3 .orchestrator/scripts/validate-state.py
# La ausencia del array no puede leerse como "no hay hallazgos". Mismo defecto que el
# manifiesto ausente y que --decidedness devolviendo []: un guarda apagado y un guarda
# satisfecho no pueden producir la misma salida.
mark_auto sin-hallazgos
expect_fail_msg "rechaza auto-aceptacion sin advisory_findings[] declarado" "an absent array is not the same as an empty one" \
  python3 .orchestrator/scripts/validate-state.py
cp "$TMP/res-schema.bak" "$RES_SCHEMA"
cp "$TMP/autonomy.bak" .claude/rules/autonomy.md

# El otro sentido de la regla de `ready`: una unidad que DEBERIA estar ready y nadie promovio.
# El gate ya rechazaba la promocion indebida (ready con deps sin construir); esto cubre el
# fallo simetrico y silencioso — todo con deps construidas, nada ready, nada building: el
# bucle recomputa, no encuentra nada y reporta "no queda ready", que se lee como "terminado".
# Es warn() y no fail() a proposito: la promocion es perezosa por diseño y un todo promovible
# es legal mientras el conductor tenga trabajo en la mano. Solo es sospechoso cuando no hay
# nada ready NI building, que es justo el instante en que el bucle decide que ha acabado.
python3 - <<'PY'
import json
p = '.orchestrator-state/features.json'
d = json.load(open(p))
# Todo aceptado salvo una unidad huerfana en todo cuyas dependencias ya estan construidas.
for s in d['screens']:
    s['status'] = 'accepted'
# Derivada de una unidad real del fixture para heredar TODOS los campos obligatorios
# (verify, data_engine, ...): una unidad escrita a mano falla el gate por su forma, no
# por el invariante que este caso quiere probar.
import copy
huerfana = copy.deepcopy(next(s for s in d['screens'] if s['id'] == 'SCR-001'))
huerfana.update({
    "id": "SCR-TODO-HUERFANA", "slug": "huerfana",
    "title": "Unidad promovible no promovida",
    "order": 99, "status": "todo", "after": ["SCR-001"], "passes": False,
    "evidence_path": ".orchestrator-state/evidence/SCR-TODO-HUERFANA/result.json",
})
huerfana.pop('checkpoint', None)
d['screens'].append(huerfana)
counts = {}
for s in d['screens']:
    counts[s['status']] = counts.get(s['status'], 0) + 1
d['summary']['total'] = len(d['screens'])
for k in d['summary']:
    if k != 'total':
        d['summary'][k] = counts.get(k, 0)
json.dump(d, open(p, 'w'), ensure_ascii=False, indent=2)
PY
expect_ok_msg "avisa (sin romper) de un todo promovible cuando nada esta ready ni building" \
  "they should have been promoted to ready" \
  python3 .orchestrator/scripts/validate-state.py
expect_ok "status.json expone promotable_todo para que el bucle no lea 'nada ready' como 'terminado'" python3 -c "
import json, subprocess
subprocess.run(['python3', '.orchestrator/scripts/validate-state.py', '--emit-status'], check=True, capture_output=True)
d = json.load(open('.orchestrator-state/status.json'))
assert d['promotable_todo'] == ['SCR-TODO-HUERFANA'], d['promotable_todo']
assert d['next_ready'] is None, d['next_ready']
"
cp "$TMP/feat.bak" "$FEAT"

# Un DIRECTORIO no es evidencia: `exists()` lo daba por bueno y el guard `is_file()` del
# control de 0 bytes lo dejaba pasar limpiamente. Renombrar un .txt a .png ya no basta.
mv .orchestrator-state/evidence/SCR-001/screenshots/success.png "$TMP/shot2.bak"
mkdir .orchestrator-state/evidence/SCR-001/screenshots/success.png
expect_fail_msg "rechaza un DIRECTORIO haciendose pasar por artefacto" "non-file artifact" \
  python3 .orchestrator/scripts/validate-state.py
rmdir .orchestrator-state/evidence/SCR-001/screenshots/success.png
mv "$TMP/shot2.bak" .orchestrator-state/evidence/SCR-001/screenshots/success.png

# La fuente de verdad nunca es un cliente. Antes se comparaba la CADENA ENTERA contra el set
# de capas cliente, asi que anadir una palabra ("UI store") burlaba el invariante que la
# constitucion declara no negociable.
python3 - <<'PY'
import json
p = '.orchestrator-state/features.json'
d = json.load(open(p))
s = next(x for x in d['screens'] if x['id'] == 'SCR-001')
s['data_engine']['canonical_store']['source_of_truth'] = 'UI store'
json.dump(d, open(p, 'w'), ensure_ascii=False, indent=2)
PY
expect_fail_msg "rechaza un cliente como fuente de verdad ('UI store')" "client layer as system of record" \
  python3 .orchestrator/scripts/validate-state.py
cp "$TMP/feat.bak" "$FEAT"

# Trazabilidad: un ID que no define ningun fichero del blueprint pasaba gate Y linter.
python3 - <<'PY'
import json
p = '.orchestrator-state/features.json'
d = json.load(open(p))
next(x for x in d['screens'] if x['id'] == 'SCR-001')['applies'].append('DATA-999')
json.dump(d, open(p, 'w'), ensure_ascii=False, indent=2)
PY
expect_fail_msg "rechaza un ID que ningun fichero del blueprint define (DATA-999)" "no blueprint file defines" \
  python3 .orchestrator/scripts/validate-state.py
cp "$TMP/feat.bak" "$FEAT"

# El fan-out obligatorio era comparacion de cadenas: una lente inventada satisfacia el set.
python3 - <<'PY'
import json
p = '.orchestrator-state/evidence/SCR-001/result.json'
d = json.load(open(p))
for run in d['phase_runs']:
    if run['phase'] == 'VERIFY':
        run['lenses'].append('verify-lente-totalmente-inventada')
json.dump(d, open(p, 'w'), ensure_ascii=False, indent=2)
PY
expect_fail_msg "rechaza una lente que no existe en el roster de agentes" "not in the agent roster" \
  python3 .orchestrator/scripts/validate-state.py
cp "$TMP/res.bak" "$RES"

# El read_path es una DIRECCION (almacen -> transporte -> cliente): invertido pasaba, porque
# se buscaban subcadenas sobre la concatenacion de todos los pasos en vez de por posicion.
python3 - <<'PY'
import json
p = '.orchestrator-state/features.json'
d = json.load(open(p))
rp = next(x for x in d['screens'] if x['id'] == 'SCR-001')['data_engine']['pipeline']['read_path']
rp.reverse()
json.dump(d, open(p, 'w'), ensure_ascii=False, indent=2)
PY
expect_fail_msg "rechaza un read_path invertido (cliente -> almacen)" "must START at the canonical store" \
  python3 .orchestrator/scripts/validate-state.py
cp "$TMP/feat.bak" "$FEAT"

# Gate de arquitectura /arch-review: NO retroactivo (un estado sin meta.architecture_review
# sigue siendo valido — el golden path no la trae y todos los positivos de arriba pasan),
# pero --init-gate SI la exige (un proyecto no puede NACER sin el gate), y si la clave
# existe, su forma se valida con dureza: blockers abiertos o set de lentes parcial rompen.
expect_fail_msg "--init-gate exige meta.architecture_review para nacer" "must run /arch-review" \
  python3 .orchestrator/scripts/validate-state.py --init-gate
expect_fail_msg "--init-gate exige meta.discovery para nacer" "must run /discovery" \
  python3 .orchestrator/scripts/validate-state.py --init-gate

# Orden de obra: la comprobacion de cimiento-sin-consumidor es ADVISORY en toda corrida normal
# (un orden raro puede ser una decision humana con razones que el gate no ve) pero BLOQUEANTE en
# --init-gate, que es el unico momento en que reordenar cuesta una edicion. Medido: el mismo
# defecto dejado pasar costo 4x (307 lanzamientos contra 78). El golden path esta bien ordenado,
# asi que primero se comprueba que NO dispara — un check que salta siempre no es un check.
expect_ok "orden de obra: el golden path no dispara el aviso de cimiento sin consumidor" bash -c '
out=$(python3 .orchestrator/scripts/validate-state.py 2>&1)
! printf "%s" "$out" | grep -q "foundation unit(s) have no"'
cp "$FEAT" "$TMP/feat-order.bak"
python3 - <<'PY'
import json
p = '.orchestrator-state/features.json'
d = json.load(open(p))
d['screens'].append({
    'id': 'SCR-FOUNDATION-HUERFANO', 'slug': 'huerfano',
    'title': 'cimiento que nada ejercita', 'kind': 'foundation', 'platforms': [],
    'order': 1, 'after': [], 'status': 'todo', 'passes': False,
    'acceptance': ['existe el andamiaje'], 'verify': {},
    'evidence_path': '.orchestrator-state/evidence/SCR-FOUNDATION-HUERFANO/result.json',
    'blocked_reason': None, 'notes': '',
})
d['summary']['total'] += 1
d['summary']['todo'] = d['summary'].get('todo', 0) + 1
json.dump(d, open(p, 'w'), ensure_ascii=False, indent=2)
PY
expect_ok "orden de obra: el gate normal AVISA de un cimiento huerfano y no rompe" bash -c '
out=$(python3 .orchestrator/scripts/validate-state.py 2>&1); rc=$?
[ "$rc" -eq 0 ] && printf "%s" "$out" | grep -q "foundation unit(s) have no"'
# El patron NO puede empezar por '--': expect_fail_msg usa `grep -q "$pat"` y grep lo tomaria
# por una opcion suya. Se ancla igualmente al prefijo que solo emite la rama de --init-gate.
expect_fail_msg "orden de obra: --init-gate lo convierte en fallo duro" \
  "init-gate: 1 foundation unit(s) have no" \
  python3 .orchestrator/scripts/validate-state.py --init-gate
cp "$TMP/feat-order.bak" "$FEAT"

# MEMORIA PERMANENTE: la doble carga. Claude Code carga cada `.claude/rules/**/*.md` sin
# frontmatter `paths:` al arrancar, con la misma prioridad que CLAUDE.md — asi que un `@import`
# de ese mismo fichero en CLAUDE.md mete las mismas lineas en contexto por SEGUNDA vez, en cada
# sesion y en cada subagente. El contador de este aviso sumaba cada fichero UNA vez, de modo que
# un proyecto pagando cientos de lineas duplicadas se leia comodamente por debajo del techo: el
# instrumento callaba justo en el caso para el que se construyo. Ademas el aviso vivia DESPUES
# del return temprano de initialized=false, asi que en un scaffold —donde se editan las reglas—
# no corria nunca.
cp CLAUDE.md "$TMP/claudemd.bak"
# El caso MONTA la doble carga; no la da por supuesta. Estas comprobaciones se escribieron cuando
# el repo TRAIA los tres `@import`, asi que usaban su propio CLAUDE.md como fixture — y el dia que
# se borraron los imports (el arreglo que el aviso pedia) los dos casos se pusieron rojos por hacer
# justo lo correcto. Un caso que solo pasa mientras el repo esta mal se invierte en cuanto lo
# arreglas, que es la peor forma de fallo que puede tener una suite.
expect_ok_msg "memoria: avisa de una regla importada con @ que .claude/rules/ ya auto-carga" \
  "loaded TWICE" bash -c '
printf "\n@.claude/rules/constitution.md\n" >> CLAUDE.md
python3 .orchestrator/scripts/validate-state.py 2>&1'
cp "$TMP/claudemd.bak" CLAUDE.md
expect_ok "memoria: sin los @import no hay aviso (el estado que ESTE repo envia)" bash -c '
out=$(python3 .orchestrator/scripts/validate-state.py 2>&1) || exit 1
! printf "%s" "$out" | grep -q "loaded TWICE"'
cp "$TMP/claudemd.bak" CLAUDE.md
# Y corre ANTES del return temprano de initialized=false: un scaffold es exactamente donde se
# editan las reglas, y donde este aviso estaba muerto. Se muta el fixture a scaffold conservando
# el resto de campos obligatorios (sin bash -c: $TMP/$FEAT son variables del shell padre y no
# llegan a un subshell, que fue como este mismo caso corrompio el fixture al escribirse).
cp "$FEAT" "$TMP/feat-mem.bak"
python3 - <<'PY'
import json
p = '.orchestrator-state/features.json'
d = json.load(open(p))
d['initialized'] = False
d['screens'] = []
d.setdefault('meta', {})['lifecycle'] = 'scaffold-placeholder'
json.dump(d, open(p, 'w'), ensure_ascii=False, indent=2)
PY
expect_ok_msg "memoria: el aviso corre tambien en un scaffold sin inicializar" \
  "loaded TWICE" bash -c '
printf "\n@.claude/rules/constitution.md\n" >> CLAUDE.md
python3 .orchestrator/scripts/validate-state.py 2>&1'
cp "$TMP/claudemd.bak" CLAUDE.md
cp "$TMP/feat-mem.bak" "$FEAT"

python3 - <<'PY'
import json
p = '.orchestrator-state/features.json'
d = json.load(open(p))
d.setdefault('meta', {})['architecture_review'] = {
    'status': 'clear',
    'lenses': ['arch-fit', 'arch-data-model', 'arch-identity', 'arch-engines',
               'arch-pipelines', 'arch-risk'],
    'failed_lenses': [],
    'open_blockers': [{'finding_id': 'ARCH-001', 'detail': 'tenancy sin decidir'}],
    'report_sha256': 'deadbeef',
}
json.dump(d, open(p, 'w'), ensure_ascii=False, indent=2)
PY
expect_fail_msg "rechaza architecture_review con blockers abiertos" "open_blockers is non-empty" \
  python3 .orchestrator/scripts/validate-state.py
cp "$TMP/feat.bak" "$FEAT"

python3 - <<'PY'
import json
p = '.orchestrator-state/features.json'
d = json.load(open(p))
d.setdefault('meta', {})['architecture_review'] = {
    'status': 'clear',
    'lenses': ['arch-fit'],  # set parcial: mismo pecado que un fan-out a medias
    'failed_lenses': [], 'open_blockers': [], 'report_sha256': 'deadbeef',
}
json.dump(d, open(p, 'w'), ensure_ascii=False, indent=2)
PY
expect_fail_msg "rechaza architecture_review con set de lentes parcial" "full arch set" \
  python3 .orchestrator/scripts/validate-state.py
cp "$TMP/feat.bak" "$FEAT"

# Gate de descubrimiento /discovery: misma disciplina que architecture_review — NO retroactivo
# (un estado sin meta.discovery sigue siendo valido), pero si la clave existe su forma se valida
# con dureza: items sin disposicion o set de lentes parcial rompen.
python3 - <<'PY'
import json
p = '.orchestrator-state/features.json'
d = json.load(open(p))
d.setdefault('meta', {})['discovery'] = {
    'status': 'complete',
    'lenses': ['discovery-product', 'discovery-data', 'discovery-architecture',
               'discovery-stack', 'discovery-infra', 'discovery-ux'],
    'failed_lenses': [], 'unresolved': ['Q-UX-07'],  # un item sin disposicion
    'checklist_version': 1, 'items_total': 62,
    'dispositions': {'answered': 30, 'filled': 20, 'asked': 8, 'na': 4, 'deferred': 0},
    'report_sha256': 'deadbeef',
}
json.dump(d, open(p, 'w'), ensure_ascii=False, indent=2)
PY
expect_fail_msg "rechaza discovery con items sin disposicion" "unresolved is non-empty" \
  python3 .orchestrator/scripts/validate-state.py
cp "$TMP/feat.bak" "$FEAT"

python3 - <<'PY'
import json
p = '.orchestrator-state/features.json'
d = json.load(open(p))
d.setdefault('meta', {})['discovery'] = {
    'status': 'complete',
    'lenses': ['discovery-product'],  # set parcial: mismo pecado que un fan-out a medias
    'failed_lenses': [], 'unresolved': [],
    'checklist_version': 1, 'items_total': 62,
    'dispositions': {'answered': 30, 'filled': 20, 'asked': 8, 'na': 4, 'deferred': 0},
    'report_sha256': 'deadbeef',
}
json.dump(d, open(p, 'w'), ensure_ascii=False, indent=2)
PY
expect_fail_msg "rechaza discovery con set de lentes parcial" "full discovery set" \
  python3 .orchestrator/scripts/validate-state.py
cp "$TMP/feat.bak" "$FEAT"

# Backstop determinista: un proyecto inicializado que conserve <COMMAND_*> sin resolver en
# stack.md no puede validar — sin comandos reales los verificadores no tienen nada que correr.
cp .claude/rules/stack.md "$TMP/stack.bak"
printf '\n# leftover\n<COMMAND_TEST>\n' >> .claude/rules/stack.md
expect_fail_msg "rechaza proyecto inicializado con <COMMAND_*> sin resolver" "unresolved command placeholders" \
  python3 .orchestrator/scripts/validate-state.py
cp "$TMP/stack.bak" .claude/rules/stack.md

# reset-test-data.sh: contrato de delegación a stack.md. Prueba los TRES estados, porque el
# fallo silencioso que importa aquí es un script que sale 0 sin hacer nada y parece correcto.
# Positivo real: sobre el stack.md resuelto del golden path DEBE resolver la clave y delegar.
echo "== reset-test-data: contrato de delegación =="
expect_ok_imsg "resuelve COMMAND_RESET_TEST_DATA y delega el comando declarado" \
  "python3 manage.py migrate" \
  bash .orchestrator/scripts/reset-test-data.sh VERIFY
# No fatal: el comando delegado falla aquí (el golden path no trae manage.py) y aun así sale 0
# — preparar datos nunca puede bloquear una fase; el conductor decide qué hacer con el aviso.
expect_ok_imsg "no es fatal cuando el comando delegado falla" \
  "fail" \
  bash .orchestrator/scripts/reset-test-data.sh VERIFY
# Estado "no declarada" distinguible de estado "declarada sin resolver": colapsarlos ocultaría
# un hueco real de configuración detrás del mismo mensaje.
grep -v "COMMAND_RESET_TEST_DATA" "$TMP/stack.bak" > .claude/rules/stack.md
expect_ok_imsg "reporta clave no declarada sin romper" \
  "not declared" \
  bash .orchestrator/scripts/reset-test-data.sh VERIFY
printf '\n# reset (COMMAND_RESET_TEST_DATA)\n<COMMAND_RESET_TEST_DATA>\n' >> .claude/rules/stack.md
expect_ok_imsg "distingue placeholder sin resolver de clave ausente" \
  "placeholder" \
  bash .orchestrator/scripts/reset-test-data.sh VERIFY
cp "$TMP/stack.bak" .claude/rules/stack.md

echo
echo "== preflight-check: contrato de salida =="
# Su contrato es DELIBERADAMENTE distinto al de reset-test-data.sh, y esa diferencia es su razon
# de existir: aquel es no-fatal siempre (un reset no debe bloquear una fase), mientras que aqui el
# fallo ES la senal que evita gastar el fan-out. Un exit 0 ante un comando declarado que falla
# devolveria el defecto entero, asi que ese caso es el que mas importa de los cuatro.
PF_SET='import sys;from pathlib import Path;p=Path(".claude/rules/stack.md");t=p.read_text(encoding="utf-8");p.write_text(t.replace(sys.argv[1],sys.argv[2]),encoding="utf-8")'
cp .claude/rules/stack.md "$TMP/stack-pf.bak"
expect_ok "preflight: comandos declarados que pasan -> exit 0" bash -c '
python3 -c "$0" "python3 -m ruff check ." "true" &&
python3 -c "$0" "python3 manage.py build" "true" &&
bash .orchestrator/scripts/preflight-check.sh SMOKE' "$PF_SET"
cp "$TMP/stack-pf.bak" .claude/rules/stack.md
expect_fail_msg "preflight: un comando declarado que FALLA -> exit != 0" "FAILED" bash -c '
python3 -c "$0" "python3 -m ruff check ." "false" &&
bash .orchestrator/scripts/preflight-check.sh SMOKE' "$PF_SET"
cp "$TMP/stack-pf.bak" .claude/rules/stack.md
expect_ok "preflight: un placeholder sin resolver se salta y no rompe" bash -c '
python3 -c "$0" "python3 -m ruff check ." "<COMMAND_LINT>" &&
python3 -c "$0" "python3 manage.py build" "<COMMAND_BUILD>" &&
bash .orchestrator/scripts/preflight-check.sh SMOKE' "$PF_SET"
cp "$TMP/stack-pf.bak" .claude/rules/stack.md
expect_ok "preflight: una clave no declarada se salta y no rompe" \
  bash .orchestrator/scripts/preflight-check.sh SMOKE COMMAND_QUE_NO_EXISTE
# El modo de fallo mas peligroso que puede tener este script: invocado por un shell que no define
# BASH_SOURCE (zsh ejecutando el fichero, o su contenido por pipe), ROOT quedaba vacio, el source
# fallaba y terminaba en "nothing to check" con exit 0 — EXITO SILENCIOSO reportado por el unico
# script cuyo trabajo entero es avisar cuando algo falla. Ningun caso lo cubria. Exit 2 lo separa
# de los otros dos: ni "no aplica" (0) ni "un comando fallo" (1), sino "no se pudo comprobar".
expect_fail_msg "preflight: invocado sin bash falla alto, no en silencio" "must be run with bash" \
  bash -c 'cat .orchestrator/scripts/preflight-check.sh | bash -s SMOKE'
expect_fail_msg "preflight: sin la libreria compartida se niega a reportar limpio" "refusing to report" \
  bash -c 'cp .orchestrator/scripts/lib/stack-command.sh "$TMPDIR/sc.bak" 2>/dev/null || cp .orchestrator/scripts/lib/stack-command.sh /tmp/sc.bak
rm -f .orchestrator/scripts/lib/stack-command.sh
bash .orchestrator/scripts/preflight-check.sh SMOKE; rc=$?
cp "$TMPDIR/sc.bak" .orchestrator/scripts/lib/stack-command.sh 2>/dev/null || cp /tmp/sc.bak .orchestrator/scripts/lib/stack-command.sh
exit $rc'
# Fail-fast: si BUILD falla, TEST no llega a lanzarse. Sin esto el pre-flight reportaria dos veces
# el mismo defecto (un proyecto que no compila no puede dar un resultado de suite con sentido).
expect_fail_msg "preflight: fail-fast — tras un fallo no lanza el siguiente comando" "FAILED" bash -c '
python3 -c "$0" "python3 -m ruff check ." "false" &&
python3 -c "$0" "python3 -m pytest" "echo LENTE_QUE_NO_DEBE_CORRER" &&
out=$(bash .orchestrator/scripts/preflight-check.sh SMOKE COMMAND_LINT COMMAND_TEST 2>&1); rc=$?
echo "$out"
echo "$out" | grep -q LENTE_QUE_NO_DEBE_CORRER && exit 0
exit $rc' "$PF_SET"
cp "$TMP/stack-pf.bak" .claude/rules/stack.md

# EL ADVERSARIO DEL DIFF. Sus 4 agentes NO son un lens set de validate-state.py a proposito: darles
# una constante *_LENSES alli los convertiria en fase obligatoria con set completo, que es justo el
# generador de vueltas que su carta prohibe. Las dos garantias que si tienen son estas, y por eso
# se prueban: los 4 existen, y los 4 son de solo lectura (leen un diff, no ejecutan nada — uno con
# Bash entraria en silencio en la clase serializada que este workflow nunca serializa).
# La copia de seguridad se hace en el shell PADRE y con rutas relativas al cwd del fixture: $GP y
# $ROOT son variables del padre y NO llegan a un `bash -c`, cosa que en esta suite ya ha causado dos
# fixtures sin restaurar. Aqui no se usa ninguna.
cp .claude/agents/diff-adversary-edge.md "$TMP/adv-edge.bak"
cp .claude/agents/diff-adversary-unreachable.md "$TMP/adv-unreachable.bak"
sed -i.tmp "s/^tools: Read, Grep, Glob/tools: Read, Grep, Glob, Bash/" .claude/agents/diff-adversary-edge.md
rm -f .claude/agents/diff-adversary-edge.md.tmp
expect_fail_msg "diff-adversary: caza una pregunta con herramientas de ejecucion" \
  "must be read-only" bash .orchestrator/scripts/validate-structure.sh
cp "$TMP/adv-edge.bak" .claude/agents/diff-adversary-edge.md
mv .claude/agents/diff-adversary-unreachable.md "$TMP/adv-moved.md"
expect_fail_msg "diff-adversary: caza una pregunta sin fichero de agente" \
  "no agent file" bash .orchestrator/scripts/validate-structure.sh
cp "$TMP/adv-unreachable.bak" .claude/agents/diff-adversary-unreachable.md
expect_ok "diff-adversary: NO esta en validate-state.py (no es una fase obligatoria)" bash -c '
! grep -q "diff-adversary\|ADVERSARY_LENSES" .orchestrator/scripts/validate-state.py'

echo "== el rango git de una pasada de reparacion: sobre lo PREPARADO, no sobre commits =="
# Encontrado trazando el flujo: `phase-push.sh` commitea al FINAL de una fase, asi que mientras una
# pasada de reparacion esta en curso su trabajo no esta commiteado y `HEAD~1..HEAD` describe el
# checkpoint de la fase ANTERIOR — a las diez lentes se les entregaria la lista de la corrida que
# acaba de fallar, y a los cuatro adversarios el diff equivocado. Ademas el fold ocurre DESPUES del
# adversario, asi que ni siquiera un commit a mitad de pasada lo incluiria.
# Todo el resto de la suite escribe estos ficheros a mano con printf, asi que NINGUN caso ejercitaba
# el comando contra un git real. Este si: monta un repo de verdad y compara los dos rangos.
expect_ok_msg "git: el rango preparado ve la reparacion Y el fold; el de commits no ve ninguno" \
  "RANGO-OK" bash -c '
G=$(mktemp -d) || exit 1
cd "$G" || exit 1
git init -q . >/dev/null 2>&1 || exit 1
git config user.email smoke@local; git config user.name smoke
echo base > producto.py; git add -A; git commit -qm baseline
echo evidencia > nota.txt; git add -A; git commit -qm "checkpoint de la fase anterior"
# la reparacion (modifica) y el fold (fichero NUEVO, sin trackear), ambos sin commitear
echo reparado >> producto.py
echo nuevo > fold_helper.py
VIEJO=$(git diff --name-only HEAD~1..HEAD | sort | tr "\n" " ")
NUEVO=$(git add -A && git diff --cached --name-only | sort | tr "\n" " ")
cd /; rm -rf "$G"
echo "viejo=[$VIEJO] nuevo=[$NUEVO]"
case "$VIEJO" in *producto.py*) exit 1;; esac        # el rango de commits NO puede ver la reparacion
case "$VIEJO" in *fold_helper.py*) exit 1;; esac     # ni el fold
case "$NUEVO" in *producto.py*) ;; *) exit 1;; esac  # el preparado ve la reparacion
case "$NUEVO" in *fold_helper.py*) ;; *) exit 1;; esac # y el fichero nuevo del fold
echo RANGO-OK'
# Y el comando que la skill documenta es exactamente ese: si alguien lo devuelve a un rango de
# commits, este caso y el de arriba dejan de contar la misma historia.
expect_ok_msg "git: la skill documenta el rango preparado, no un rango de commits" \
  "git add -A && git diff --cached --name-only" \
  grep -m1 "git add -A && git diff --cached --name-only" .claude/skills/next-pantalla/SKILL.md
expect_ok "git: no queda ningun HEAD~1..HEAD como comando en la skill" bash -c '
! grep -q "git diff.*HEAD~1\.\.HEAD" .claude/skills/next-pantalla/SKILL.md'

echo "== adversary-check: el gate que impide gastar el abanico sin haber leido el diff =="
# La regla ("en toda pasada de REPARACION corre el adversario") llevaba escrita desde DEC-ORCH-008
# en next-pantalla §6 y en constitution.md, y MEDIDA corrio en 1 de cada 5 pasadas. La causa no es
# olvido: las comprobaciones que si corren las dispara un EVENTO que llega (un hallazgo), y esta la
# dispara un ESTADO en el que uno esta ("acabas de producir un diff"), que nadie anuncia. De ahi que
# el arreglo sea un paso que sale non-zero, no otro parrafo. Y de ahi que estos casos importen en
# LAS DOS direcciones: un guard que nadie ha visto fallar no es un guard, y uno que grita en falso
# es uno que alguien acaba borrando.
ADV_LOGS=".orchestrator-state/evidence/SCR-001/logs"
ADV_SET_ITER='import json,sys
p=".orchestrator-state/features.json"; d=json.load(open(p))
for s in d["screens"]:
    if s["id"]=="SCR-001":
        s["status"]="building"; s["passes"]=False
        s["checkpoint"]={"phase":"DEVELOP","iteration":int(sys.argv[1])}
json.dump(d,open(p,"w"),indent=2)'
ADV_RET='{"screen_id":"SCR-001","clean":true,"findings":[],"retried_adversaries":[],
"answered":[{"adversary":"diff-adversary-regression","verdict":"nothing_found"},
{"adversary":"diff-adversary-incomplete","verdict":"nothing_found"},
{"adversary":"diff-adversary-unreachable","verdict":"nothing_found"},
{"adversary":"diff-adversary-edge","verdict":"nothing_found"}],"failed_adversaries":[]}'
cp "$FEAT" "$TMP/feat-adv.bak"
mkdir -p "$ADV_LOGS"
python3 -c "$ADV_SET_ITER" 2
printf '# iteration: 2\n--- a/web/notas.js\n+++ b/web/notas.js\n+if (!user.can_edit) return;\n' > "$ADV_LOGS/repair-diff.patch"

# MUTACION 1 — sin marcador, el gate PARA. Este es el caso que se estaba dando 4 de cada 5 veces.
expect_fail_msg "adversary: una pasada de reparacion SIN adversario no deja lanzar el abanico" \
  "no diff-adversary run is recorded" \
  python3 .orchestrator/scripts/adversary-check.py VERIFY
# ...y el mensaje trae el comando exacto que desbloquea, como el pre-flight. Un gate que dice "no"
# sin decir "haz esto" se rodea antes que se obedece.
expect_fail_msg "adversary: el mensaje incluye el comando exacto para desbloquear" \
  "--record .orchestrator-state/evidence/SCR-001/logs/adversary-return.json" \
  python3 .orchestrator/scripts/adversary-check.py VERIFY

# MUTACION 2 — con marcador, el gate LEVANTA. Y "no se encontro nada" es respuesta suficiente: el
# liston va en el hallazgo, nunca en el recuento (DEC-ORCH-009), asi que un gate que esperase
# hallazgos seria una cuota con otro nombre.
expect_ok_msg "adversary: registrar la corrida del workflow escribe el marcador lateral" \
  "recorded SCR-001 iteration 2" bash -c '
printf "%s" "$0" | python3 .orchestrator/scripts/adversary-check.py VERIFY --record -' "$ADV_RET"
expect_ok_msg "adversary: con marcador (y nothing_found x4) el abanico puede lanzarse" \
  "Fan-out may launch" python3 .orchestrator/scripts/adversary-check.py VERIFY
# El comando documentado registra por FICHERO, no por tuberia con comillas simples: los cuatro
# adversarios escriben en ingles y un solo apostrofe en un `detail` cierra la comilla antes de
# tiempo y mata justo el comando que levanta el gate. Se prueba con un retorno que lleva apostrofes.
rm -f "$ADV_LOGS/adversary-2.json"
python3 - <<'PY2'
import json
p=".orchestrator-state/evidence/SCR-001/logs/adversary-return.json"
json.dump({"screen_id":"SCR-001","clean":False,"findings":[
    {"file":"web/notas.js","detail":"the guard doesn't run anymore; it's unreachable"}],
    "answered":[{"adversary":a,"verdict":"found" if a.endswith("unreachable") else "nothing_found"}
                for a in ["diff-adversary-regression","diff-adversary-incomplete",
                          "diff-adversary-unreachable","diff-adversary-edge"]],
    "failed_adversaries":[],"retried_adversaries":[]},
    open(p,"w"), ensure_ascii=False, indent=2)
PY2
expect_ok_msg "adversary: --record por fichero traga un retorno con apostrofes" \
  "recorded SCR-001 iteration 2" bash -c '
python3 .orchestrator/scripts/adversary-check.py VERIFY SCR-001 \
  --record .orchestrator-state/evidence/SCR-001/logs/adversary-return.json'
expect_ok_msg "adversary: y un hallazgo real levanta el gate igual que nothing_found" \
  "Fan-out may launch" python3 .orchestrator/scripts/adversary-check.py VERIFY
rm -f "$ADV_LOGS/adversary-return.json"

# El marcador va atado al DIFF, no solo a la iteracion: es lo unico que cierra el caso de /fix
# reparando una unidad accepted, donde todas las pasadas resuelven a la misma iteracion y un
# marcador de la pasada anterior levantaria el gate de la siguiente.
printf '# iteration: 2\n--- a/web/notas.js\n+++ b/web/notas.js\n+otra reparacion distinta\n' > "$ADV_LOGS/repair-diff.patch"
expect_fail_msg "adversary: un marcador de otro diff no vale (nueva pasada, mismo numero)" \
  "recorded against a different diff" \
  python3 .orchestrator/scripts/adversary-check.py VERIFY
rm -f "$ADV_LOGS/adversary-2.json"

# NO DISPARA (1) — pasada solo-documental. Las cuatro preguntas son sobre la forma del codigo y este
# diff no tiene. La clasificacion NO se reimplementa aqui: se EXTRAE de isDocPath en verify-fanout.js,
# que es la unica manera de que sean la misma regla y no dos que hoy coinciden.
printf '# iteration: 2\nblueprint/logic/shell.md\n.orchestrator-state/evidence/SCR-001/result.json\n' > "$ADV_LOGS/changed-files.txt"
expect_ok_msg "adversary: NO dispara en una pasada solo-documental" "DOCS-ONLY" \
  python3 .orchestrator/scripts/adversary-check.py VERIFY
# ...y un solo fichero de codigo hace que la pasada entera sea una pasada completa, igual que en
# verify-fanout.js. Un `.claude/**.md` cuenta como codigo: un fichero de agente es la definicion de
# comportamiento de una lente, no documentacion sobre el producto.
printf '# iteration: 2\nblueprint/logic/shell.md\nweb/notas.js\n' > "$ADV_LOGS/changed-files.txt"
expect_fail_msg "adversary: un fichero de codigo entre docs SI dispara" \
  "no diff-adversary run is recorded" python3 .orchestrator/scripts/adversary-check.py VERIFY
printf '# iteration: 2\n.claude/agents/verify-tests.md\n' > "$ADV_LOGS/changed-files.txt"
expect_fail_msg "adversary: .claude/**.md no es documentacion, dispara" \
  "no diff-adversary run is recorded" python3 .orchestrator/scripts/adversary-check.py VERIFY
# Una lista de otra iteracion no puede probar que ESTA pasada sea documental: misma guarda de
# frescura que aplica verify-fanout.js al mismo fichero, y aqui por una razon mas afilada.
printf '# iteration: 1\nblueprint/logic/shell.md\n' > "$ADV_LOGS/changed-files.txt"
expect_fail_msg "adversary: una lista obsoleta no exime (se ignora y el gate aplica)" \
  "stale list cannot prove" python3 .orchestrator/scripts/adversary-check.py VERIFY
rm -f "$ADV_LOGS/changed-files.txt"

# NO DISPARA (2) — primera pasada de construccion: no hay reparacion previa que leer. La condicion
# es la que ya usa el propio procedimiento (§1 abre la unidad en iteration 0, §6 incrementa en cada
# reparacion), no un campo nuevo que alguien pueda declarar mal para escaparse.
python3 -c "$ADV_SET_ITER" 0
expect_ok_msg "adversary: NO dispara en la primera pasada de construccion" "first build pass" \
  python3 .orchestrator/scripts/adversary-check.py VERIFY
# Una unidad accepted reparada in place por /fix SI aplica aunque no lleve checkpoint: ahi no hay
# primera construccion que eximir, toda pasada repara codigo ya probado.
expect_fail_msg "adversary: una unidad accepted reparada por /fix tambien aplica" \
  "REPAIR pass" python3 .orchestrator/scripts/adversary-check.py FIX SCR-FOUNDATION-SHELL

# El registro NO es evidencia: no entra en el contrato de evidencia y el STATE GATE ni lo mira.
python3 -c "$ADV_SET_ITER" 2
printf '%s' "$ADV_RET" | python3 .orchestrator/scripts/adversary-check.py VERIFY --record - >/dev/null 2>&1
cp "$TMP/feat-adv.bak" "$FEAT"
expect_ok "adversary: el marcador no anade ningun requisito al gate de estado" \
  python3 .orchestrator/scripts/validate-state.py
expect_ok "adversary: NO esta en validate-state.py (no es fase ni evidencia)" bash -c '
! grep -q "adversary" .orchestrator/scripts/validate-state.py'
rm -f "$ADV_LOGS/repair-diff.patch" "$ADV_LOGS/adversary-2.json" "$ADV_LOGS/adversary-0.json"

# El clasificador docs-only se EXTRAE de verify-fanout.js. Lo unico que puede romperse en silencio
# ahi es la extraccion, asi que su self-check corre en validate-structure.sh: si la regla cambia de
# nombre o de forma, el gate se niega a clasificar (exit 2) en vez de adivinar.
cp .claude/workflows/verify-fanout.js "$TMP/vf-adv.bak"
python3 - <<'PY'
from pathlib import Path
p = Path('.claude/workflows/verify-fanout.js')
p.write_text(p.read_text(encoding='utf-8').replace('const DOC_EXTENSION', 'const DOC_EXT_RENAMED'),
             encoding='utf-8')
PY
expect_fail_msg "adversary: si el clasificador docs-only se mueve, la estructura falla alto" \
  "cannot find DOC_EXTENSION" bash .orchestrator/scripts/validate-structure.sh
cp "$TMP/vf-adv.bak" .claude/workflows/verify-fanout.js
expect_ok "adversary: restaurado el clasificador, la estructura vuelve a pasar" \
  bash .orchestrator/scripts/validate-structure.sh

# El class scan tiene la misma naturaleza que el adversario y por tanto la misma prohibicion: cambia
# lo que una reparacion BARRE, nunca lo que la evidencia PRUEBA. Meterlo en el gate lo convertiria en
# fase obligatoria y en un generador de vueltas. Y es de solo lectura: propone, no repara.
expect_ok "repair-class-scan: NO esta en validate-state.py (no es una fase obligatoria)" bash -c '
! grep -q "repair-class-scan\|CLASS_SCAN" .orchestrator/scripts/validate-state.py'
expect_ok_msg "repair-class-scan: es de solo lectura" "tools: Read, Grep, Glob" \
  grep -m1 "^tools:" .claude/agents/repair-class-scan.md

# El limite "no tocar fuera de la unidad" era PROSA: `changed_files` no aparecia ni una vez en el
# gate y ninguna lente pregunta por lo tocado DE MAS (verificado por grep). Toda la maquinaria es
# asimetrica: comprueba que lo PROMETIDO se entrego, nunca que no se entrego de mas. Importa mas
# desde el class scan, que existe para ensanchar una reparacion y entrega un out_of_scope[] de
# defectos reales que el conductor tiene prohibido tocar solo por escrito.
mkdir -p .orchestrator-state/evidence/SCR-001/logs
printf 'web/notas.js\napp/notas.py\n' > .orchestrator-state/evidence/SCR-001/logs/changed-files.txt
expect_ok "scope: NO avisa cuando todo lo tocado esta declarado en plan.md" bash -c '
! python3 .orchestrator/scripts/validate-state.py 2>&1 | grep -q "never declares"'
# La propagacion es OBLIGATORIA en una reparacion (paso 2), no es salirse de ambito. Avisar de
# ella dispararia en TODA reparacion correcta, que es como un aviso deja de leerse.
printf 'blueprint/logic/shell.md\n.orchestrator-state/evidence/SCR-001/result.json\n' > .orchestrator-state/evidence/SCR-001/logs/changed-files.txt
expect_ok "scope: NO avisa de la propagacion al blueprint ni de la evidencia propia" bash -c '
! python3 .orchestrator/scripts/validate-state.py 2>&1 | grep -q "never declares"'
printf 'web/notas.js\nsrc/otra-unidad/facturas.py\n' > .orchestrator-state/evidence/SCR-001/logs/changed-files.txt
expect_ok_msg "scope: avisa de un fichero de codigo que el plan nunca declara" "never declares" \
  python3 .orchestrator/scripts/validate-state.py
# Y avisa SIN bloquear: la autoridad es la columna "ficheros a tocar", escrita en prosa antes de
# existir el codigo. Un fichero legitimo que no anticipo (una util compartida, una migracion) no
# puede tumbar una unidad correcta -- un gate que lo hace se aprende a rodear.
expect_ok "scope: avisar NO hace fallar al gate" python3 .orchestrator/scripts/validate-state.py
rm -f .orchestrator-state/evidence/SCR-001/logs/changed-files.txt

echo "== applies[]: cobertura de las reglas que la unidad cita =="
# Medido: una unidad declaraba JOUR-005 en applies[], no lo tocaba, y paso OCHO abanicos (diez
# lentes cada uno) y dos puertas antes de que lo viera la REVIEW. Todas las lentes se ACOTAN a
# applies[], asi que una regla citada que nadie implementa no falla ninguna lente: no la mira nadie
# desde la direccion que ensenaria la ausencia. Es el espejo de acceptance_ids, una columna mas alla.
cp "$RES" "$TMP/res-applies.bak"
python3 - <<'PY'
import json
p=".orchestrator-state/evidence/SCR-001/result.json"; d=json.load(open(p))
for c in d["checks"]:
    if c.get("id")=="CHK-SCR-001-LIVE-WEB": c.pop("applies_ids",None)
json.dump(d,open(p,"w"),ensure_ascii=False,indent=2)
PY
expect_fail_msg "applies: caza una regla citada que ningun check nombra" \
  "no check names" python3 .orchestrator/scripts/validate-state.py
# La valvula de escape es la misma que acceptance_deferred: NOMBRAR la regla y decir por que esta
# unidad no la prueba. Sin valvula, la regla fabricaria un check falso -- el defecto que combate.
python3 - <<'PY'
import json
p=".orchestrator-state/evidence/SCR-001/result.json"; d=json.load(open(p))
d["applies_deferred"]=[{"id":x,"reason":"prueba extremo a extremo que cierra /verify-app"}
                       for x in ["UI-001","UI-SHELL-002","PERM-001","JOUR-001"]]
json.dump(d,open(p,"w"),ensure_ascii=False,indent=2)
PY
expect_ok "applies: applies_deferred[] con motivo excusa la regla" \
  python3 .orchestrator/scripts/validate-state.py
cp "$TMP/res-applies.bak" "$RES"
expect_ok "applies: el golden path cita todas sus reglas y pasa" \
  python3 .orchestrator/scripts/validate-state.py
# Un criterio de aceptacion YA lleva sus reglas en `refs`. Si el gate no leyera ese campo, exigiria
# una segunda grafia de algo que todo proyecto compilado registra — trámite sobre trabajo correcto.
# El fixture cubre el 100% via checks[].applies_ids, asi que sin este caso quitar "refs" de
# APPLIES_REF_KEYS no pondria nada en rojo. Aqui la regla es alcanzable SOLO desde acceptance.refs.
python3 - <<'PY2'
import json
f=".orchestrator-state/features.json"; d=json.load(open(f))
for s in d["screens"]:
    if s["id"]=="SCR-001":
        s["applies"]=list(s["applies"])+["UI-SHELL-001"]
        s["acceptance"][0].setdefault("refs",[]).append("UI-SHELL-001")
json.dump(d,open(f,"w"),ensure_ascii=False,indent=2)
PY2
expect_ok "applies: una regla alcanzable solo desde acceptance[].refs YA esta cubierta" \
  python3 .orchestrator/scripts/validate-state.py
python3 - <<'PY2'
import json
f=".orchestrator-state/features.json"; d=json.load(open(f))
for s in d["screens"]:
    if s["id"]=="SCR-001":
        s["acceptance"][0]["refs"]=[r for r in s["acceptance"][0]["refs"] if r!="UI-SHELL-001"]
json.dump(d,open(f,"w"),ensure_ascii=False,indent=2)
PY2
expect_fail_msg "applies: y sin esa via, la misma regla queda descubierta" \
  "no check names" python3 .orchestrator/scripts/validate-state.py
cp "$TMP/feat.bak" "$FEAT"
# Y al reves: un check que prueba una regla que la unidad no declara es o creep o un applies[]
# incompleto. Ambos valen una edicion ahora.
python3 - <<'PY'
import json
p=".orchestrator-state/evidence/SCR-001/result.json"; d=json.load(open(p))
d["checks"][0].setdefault("applies_ids",[]).append("DOM-999")
json.dump(d,open(p,"w"),ensure_ascii=False,indent=2)
PY
expect_fail_msg "applies: caza un check que nombra una regla fuera de applies[]" \
  "does not cite in applies" python3 .orchestrator/scripts/validate-state.py
cp "$TMP/res-applies.bak" "$RES"
# Retroactividad, igual que plan.md y source_manifest: una unidad ya ACEPTADA avisa, no rompe --
# reabrir accepted esta prohibido, asi que fallar no dejaria jugada legal.
cp .orchestrator-state/evidence/SCR-FOUNDATION-SHELL/result.json "$TMP/res-shell.bak"
python3 - <<'PY'
import json
p=".orchestrator-state/evidence/SCR-FOUNDATION-SHELL/result.json"; d=json.load(open(p))
for c in d["checks"]: c.pop("applies_ids",None)
json.dump(d,open(p,"w"),ensure_ascii=False,indent=2)
PY
expect_ok_msg "applies: en una unidad ya accepted avisa, no falla" "already accepted" \
  python3 .orchestrator/scripts/validate-state.py
cp "$TMP/res-shell.bak" .orchestrator-state/evidence/SCR-FOUNDATION-SHELL/result.json

echo "== advisory de lente: el hallazgo de una lente que PASO tiene salida, con dueno =="
# Las dos puertas §5.5 podian mandar un hallazgo no bloqueante a advisory_findings[]; las diez
# lentes no. Asi que un verify-* que devuelve pass con tres minor no tenia ruta -- ni failures[]
# (la lente paso) ni advisory (estaban vetadas) -- y por defecto se trataban como trabajo: una
# reparacion, un re-VERIFY y superficie nueva para la vuelta siguiente. Lo que decide la salida es
# el VEREDICTO DE LA LENTE, nunca la severidad ni el criterio del conductor.
python3 - <<'PY'
import json
p=".orchestrator-state/evidence/SCR-001/result.json"; d=json.load(open(p))
d["advisory_findings"]=[{"id":"ADV-SCR-001-001","severity":"low","source":"verify-quality",
                         "detail":"comentario redundante en el adaptador","refs":[],"status":"open"}]
json.dump(d,open(p,"w"),ensure_ascii=False,indent=2)
PY
expect_fail_msg "advisory: un hallazgo de lente sin dueno no es deuda registrada" \
  "carries no" python3 .orchestrator/scripts/validate-state.py
python3 - <<'PY'
import json
p=".orchestrator-state/evidence/SCR-001/result.json"; d=json.load(open(p))
d["advisory_findings"][0]["owner"]="human-review"
json.dump(d,open(p,"w"),ensure_ascii=False,indent=2)
PY
expect_fail_msg "advisory: sin trip-wire tampoco: es la parte que lo hace reabrible" \
  "trip_wire" python3 .orchestrator/scripts/validate-state.py
python3 - <<'PY'
import json
p=".orchestrator-state/evidence/SCR-001/result.json"; d=json.load(open(p))
d["advisory_findings"][0]["trip_wire"]="si se vuelve a tocar el adaptador, se limpia en esa pasada"
json.dump(d,open(p,"w"),ensure_ascii=False,indent=2)
PY
expect_ok "advisory: con dueno y trip-wire queda registrado y el gate pasa" \
  python3 .orchestrator/scripts/validate-state.py
# Y NO se le pide nada nuevo a las dos puertas: su formato de siempre sigue valiendo.
python3 - <<'PY'
import json
p=".orchestrator-state/evidence/SCR-001/result.json"; d=json.load(open(p))
d["advisory_findings"]=[{"id":"ADV-SCR-001-002","severity":"low","source":"production-code-review",
                         "detail":"duplicacion menor","refs":[],"status":"open"}]
json.dump(d,open(p,"w"),ensure_ascii=False,indent=2)
PY
expect_ok "advisory: una entrada de puerta 5.5 no gana requisitos nuevos" \
  python3 .orchestrator/scripts/validate-state.py
# El caso que la revision adversarial encontro: /verify-pipelines-data-ultracode es una PUERTA, no
# una lente, y su nombre empieza por "verify-". Un test de prefijo la habria hecho fallar contra su
# propio contrato documentado — y contra lo que dice el ledger de este mismo cambio. Se comprueba
# contra el ROSTER de lentes, no contra el prefijo.
python3 - <<'PY2'
import json
p=".orchestrator-state/evidence/SCR-001/result.json"; d=json.load(open(p))
d["advisory_findings"]=[{"id":"ADV-SCR-001-003","severity":"low",
                         "source":"verify-pipelines-data-ultracode",
                         "detail":"cobertura de logs mejorable","refs":[],"status":"open"}]
json.dump(d,open(p,"w"),ensure_ascii=False,indent=2)
PY2
expect_ok "advisory: una puerta cuyo nombre empieza por verify- NO es una lente" \
  python3 .orchestrator/scripts/validate-state.py
# Y el vocabulario: las diez lentes declaran blocker|major|minor|nit en su propio contrato de
# retorno, mientras el campo nacio con blocker|high|medium|low|nit. Rechazar "major" habria hecho
# inservible la ruta para los agentes que la estrenan.
python3 - <<'PY2'
import json
p=".orchestrator-state/evidence/SCR-001/result.json"; d=json.load(open(p))
d["advisory_findings"]=[{"id":"ADV-SCR-001-004","severity":"major","source":"verify-coherence",
                         "detail":"componente duplicado","refs":[],"status":"open",
                         "owner":"human-review","trip_wire":"si otra pantalla lo copia, se extrae"}]
json.dump(d,open(p,"w"),ensure_ascii=False,indent=2)
PY2
expect_ok "advisory: acepta el vocabulario de severidad que las lentes SI emiten (major)" \
  python3 .orchestrator/scripts/validate-state.py
python3 - <<'PY2'
import json
p=".orchestrator-state/evidence/SCR-001/result.json"; d=json.load(open(p))
d["advisory_findings"][0]["severity"]="catastrofica"
json.dump(d,open(p,"w"),ensure_ascii=False,indent=2)
PY2
expect_fail_msg "advisory: y sigue rechazando una severidad inventada" \
  "severity must be one of" python3 .orchestrator/scripts/validate-state.py
cp "$TMP/res-applies.bak" "$RES"
# Un grep de la cadena pasaria aunque el campo saliera de required[] y se quedara solo en
# properties[] o en el prompt: eso es un caso que no puede ponerse rojo revirtiendo la feature.
# Se comprueba la PERTENENCIA al array required del DIGEST.
expect_ok "advisory: advisory_candidates es REQUIRED en el schema del digest, no solo mencionado" \
  python3 -c '
import re,sys
t=open(".claude/workflows/verify-fanout.js").read()
m=re.search(r"const DIGEST = \{(.*?)\n\}", t, re.S)
req=re.search(r"required:\s*\[(.*?)\]", m.group(1), re.S)
sys.exit(0 if "advisory_candidates" in req.group(1) else 1)'
expect_ok_msg "advisory: el prompt del sintetizador ordena emitirlo (aun vacio)" \
  "advisory_candidates[]: ALWAYS emit it" \
  grep -m1 "advisory_candidates\[\]: ALWAYS emit it" .claude/workflows/verify-fanout.js
expect_ok_msg "advisory: el sintetizador lleva el contrato de esa separacion" \
  "advisory_candidates" grep -m1 "advisory_candidates" .claude/agents/verify-synthesizer.md

echo "== VERIFY de cierre solo-documental: permitida, y solo cuando se puede PROBAR =="
# La VERIFY de cierre corre las 10 nativas. Correcto en general -- su premisa es "el codigo puede
# haberse movido desde la ultima pasada completa". Pero esa premisa es DECIDIBLE:
# derived_scope:"docs_only" no lo declara el conductor, lo DERIVA verify-fanout.js de la lista de
# ficheros cambiados. Si toda la cadena desde la ultima completa es docs-only, las 6 lentes
# heredadas siguen juzgando exactamente el mismo codigo. Una sola entrada no-docs-only la rompe.
cat > "$TMP/mk-close.py" <<'PY'
import json, sys
mode = sys.argv[1]
p = ".orchestrator-state/evidence/SCR-001/result.json"
d = json.load(open(p))
full = dict([r for r in d["phase_runs"] if r["phase"] == "VERIFY"][0]); full["iteration"] = 0
CARRY6 = ["verify-frontend","verify-tests","verify-engine","verify-pipeline","verify-logs","verify-quality"]
DOC4 = ["verify-conformance","verify-design","verify-coherence","verify-blueprint-drift"]
close = {"phase":"VERIFY","workflow":"verify-fanout","mode":"workflow","full_set":False,
         "derived_scope":"docs_only","iteration":0,"lenses":DOC4,
         "carried_forward":[{"lens":l,"from_iteration":0} for l in CARRY6]}
triage = {"phase":"VERIFY","workflow":"verify-fanout","mode":"workflow","full_set":False,
          "iteration":0,"lenses":["verify-tests"],
          "carried_forward":[{"lens":l,"from_iteration":0} for l in DOC4 + [x for x in CARRY6 if x != "verify-tests"]]}
if mode == "ok":            seq = [full, close]
elif mode == "stale_citation":
    # completa@0, completa@1 (una reparacion REAL: si no fuera docs-only, el codigo se movio),
    # y el cierre docs-only citando la 0. Cada entrada por separado es valida; la cita no.
    repair = dict(full); repair["iteration"] = 1
    seq = [full, repair, close]
elif mode == "from_triage": seq = [full, triage, close]
elif mode == "closing_triage":
    bad = dict(close); bad.pop("derived_scope"); seq = [full, bad]
elif mode == "first_docs_only": seq = [close]
else: raise SystemExit("unknown mode")
out = []
for r in d["phase_runs"]:
    if r["phase"] == "VERIFY":
        out.extend(seq)          # replace the single VERIFY entry, in place, keeping every other
    else:                        # phase exactly where it was: dropping DEVELOP would make these
        out.append(r)            # cases fail on a missing phase instead of on what they test
d["phase_runs"] = out
json.dump(d, open(p,"w"), ensure_ascii=False, indent=2)
PY
python3 "$TMP/mk-close.py" ok
expect_ok "cierre docs-only: legal detras de una VERIFY completa citada" \
  python3 .orchestrator/scripts/validate-state.py
cp "$TMP/res-applies.bak" "$RES"
# No puede heredar de TRIAGE: eso dejaria decaer la cobertura una pasada cada vez con todas las
# entradas pareciendo individualmente justificadas.
python3 "$TMP/mk-close.py" from_triage
expect_fail_msg "cierre docs-only: no puede heredar de una pasada de triage" \
  "is not a COMPLETE pass" python3 .orchestrator/scripts/validate-state.py
cp "$TMP/res-applies.bak" "$RES"
# Y no puede citar una pasada completa RANCIA. Encontrado por revision adversarial: el paseo hacia
# atras probaba que la cadena docs-only llega a una pasada completa, pero la validacion de citas
# aceptaba CUALQUIER pasada completa anterior. Con completa@0, completa@1 (una reparacion real, o
# sea codigo movido) y cierre docs-only citando la 0, todas las comprobaciones individuales pasaban
# y la unidad cerraba con seis veredictos anteriores a la reparacion — justo la decadencia que la
# excepcion dice impedir.
python3 "$TMP/mk-close.py" stale_citation
expect_fail_msg "cierre docs-only: no puede citar una pasada completa mas antigua que su ancla" \
  "leads back to the complete pass at iteration" python3 .orchestrator/scripts/validate-state.py
cp "$TMP/res-applies.bak" "$RES"
# Una entrada de cierre recortada que NO sea docs-only sigue prohibida: la regla vieja, intacta.
python3 "$TMP/mk-close.py" closing_triage
expect_fail_msg "cierre docs-only: un triage normal sigue sin poder cerrar" \
  "closing VERIFY entry with full_set:false" python3 .orchestrator/scripts/validate-state.py
cp "$TMP/res-applies.bak" "$RES"
# Y la PRIMERA VERIFY de una unidad no puede serlo: no hay prueba anterior que heredar.
python3 "$TMP/mk-close.py" first_docs_only
expect_fail_msg "cierre docs-only: la primera VERIFY nunca puede serlo" \
  "no VERIFY entry precedes" python3 .orchestrator/scripts/validate-state.py
cp "$TMP/res-applies.bak" "$RES"
expect_ok "cierre docs-only: estado restaurado" python3 .orchestrator/scripts/validate-state.py

echo "== derived-figures: la cifra en prosa atada al comando que la deriva =="
# Cuatro celdas acopladas corregidas en cuatro pasadas, tres mintiendo cada vez. Una cifra escrita
# en prosa es una afirmacion sobre otra cosa, y una afirmacion que nadie puede re-ejecutar no es
# evidencia. validate-structure.sh ya lo exigia para los SETS de lentes (.js contra .py); cada
# restatement en prosa era una tercera copia sin nada detras.
expect_ok_msg "derived: todas las cifras marcadas cuadran con su fuente" "match their source" \
  python3 .orchestrator/scripts/derived-figures.py
cp .claude/rules/constitution.md "$TMP/const-df.bak"
python3 - <<'PY'
from pathlib import Path
p = Path(".claude/rules/constitution.md")
p.write_text(p.read_text(encoding="utf-8").replace(
  "VERIFY -> `verify-fanout` -> all **10** `verify-*` lenses",
  "VERIFY -> `verify-fanout` -> all **9** `verify-*` lenses").replace(
  "VERIFY → `verify-fanout` → all **10** `verify-*` lenses",
  "VERIFY → `verify-fanout` → all **9** `verify-*` lenses"), encoding="utf-8")
PY
expect_fail_msg "derived: caza una cifra que dejo de cuadrar con su fuente" \
  "figure and its source disagree" python3 .orchestrator/scripts/derived-figures.py
expect_fail_msg "derived: y la estructura falla por ello, no solo el linter suelto" \
  "figure and its source disagree" bash .orchestrator/scripts/validate-structure.sh
cp "$TMP/const-df.bak" .claude/rules/constitution.md
expect_ok "derived: restaurada la cifra, vuelve a pasar" \
  python3 .orchestrator/scripts/derived-figures.py
# Sin marcador no hay comprobacion: el linter no adivina que cifras de la prosa son derivables, y
# esa es la razon de que no grite en falso sobre todo numero que aparezca en un documento.
# LA ATADURA POSICIONAL, que es la razon de ser del multi-marcador. Sin ella un par INTERCAMBIADO
# pasa —los dos valores estan en la linea, da igual a que figura pertenezca cada uno— o sea la celda
# acoplada reproducida por la herramienta que existe para cazarla. Verificado por mutacion: con la
# comparacion contra la linea entera, este caso se queda verde.
expect_fail_msg "derived: caza un par de figuras INTERCAMBIADAS en la misma linea" "disagree" bash -c '
mkdir -p blueprint/dfa blueprint/dfb
: > blueprint/dfa/1.md; : > blueprint/dfa/2.md; : > blueprint/dfa/3.md
: > blueprint/dfb/1.md; : > blueprint/dfb/2.md
printf "Hay 2 en A <!-- derived: glob:blueprint/dfa/*.md --> y 3 en B <!-- derived: glob:blueprint/dfb/*.md -->\n" > blueprint/df-swap.md
python3 .orchestrator/scripts/derived-figures.py 2>&1; rc=$?
rm -rf blueprint/dfa blueprint/dfb blueprint/df-swap.md
exit $rc'
# Y el mismo fixture con cada figura en su sitio pasa: la atadura no grita sobre lo correcto.
expect_ok "derived: el mismo par bien puesto pasa" bash -c '
mkdir -p blueprint/dfa blueprint/dfb
: > blueprint/dfa/1.md; : > blueprint/dfa/2.md; : > blueprint/dfa/3.md
: > blueprint/dfb/1.md; : > blueprint/dfb/2.md
printf "Hay 3 en A <!-- derived: glob:blueprint/dfa/*.md --> y 2 en B <!-- derived: glob:blueprint/dfb/*.md -->\n" > blueprint/df-swap.md
python3 .orchestrator/scripts/derived-figures.py >/dev/null 2>&1; rc=$?
rm -rf blueprint/dfa blueprint/dfb blueprint/df-swap.md
exit $rc'
# El marcador SOLO en su linea toma la anterior como claim: disposicion documentada, y su modo de
# fallo era un falso PASS silencioso (el claim real detras del marcador no se leia nunca).
expect_ok "derived: marcador solo en su linea usa la linea anterior como claim" bash -c '
printf "Hay 10 lentes de verify.\n<!-- derived: jsarray:.claude/workflows/verify-fanout.js:LENSES -->\n" > blueprint/df-prev.md
python3 .orchestrator/scripts/derived-figures.py >/dev/null 2>&1; rc=$?
rm -f blueprint/df-prev.md
exit $rc'
expect_fail_msg "derived: un claim colocado DETRAS del marcador se rechaza, no se ignora" \
  "sits AFTER this marker" bash -c '
printf "Step 5 del setup, sin relacion con ningun recuento.\n<!-- derived: sh:echo 5 --> el recuento real de ESTA afirmacion es 9\n" > blueprint/df-after.md
python3 .orchestrator/scripts/derived-figures.py 2>&1; rc=$?
rm -f blueprint/df-after.md
exit $rc'
expect_ok "derived: una cifra SIN marcador no se comprueba (no grita en falso)" bash -c '
printf "Hay 999 lentes de verify.\n" > blueprint/df-unmarked.md
python3 .orchestrator/scripts/derived-figures.py >/dev/null; rc=$?
rm -f blueprint/df-unmarked.md
exit $rc'

# Las tres formas de derivacion se prueban, no solo la que usan los 8 marcadores del repo: una
# rama que se envia sin ejercitar es codigo muerto que parece cobertura. glob: y sh: existen para
# el PROYECTO que consume este orquestador (donde jsarray: no significa nada), no para el scaffold.
expect_ok "derived: la forma glob: cuenta ficheros de verdad" bash -c '
mkdir -p blueprint/dfglob && : > blueprint/dfglob/a.md && : > blueprint/dfglob/b.md
printf "Hay 2 ficheros. <!-- derived: glob:blueprint/dfglob/*.md -->\n" > blueprint/df-glob.md
python3 .orchestrator/scripts/derived-figures.py >/dev/null 2>&1; rc=$?
rm -rf blueprint/dfglob blueprint/df-glob.md
exit $rc'
expect_fail_msg "derived: la forma glob: caza el recuento que miente" "disagree" bash -c '
mkdir -p blueprint/dfglob && : > blueprint/dfglob/a.md && : > blueprint/dfglob/b.md
printf "Hay 7 ficheros. <!-- derived: glob:blueprint/dfglob/*.md -->\n" > blueprint/df-glob.md
python3 .orchestrator/scripts/derived-figures.py 2>&1; rc=$?
rm -rf blueprint/dfglob blueprint/df-glob.md
exit $rc'
expect_ok "derived: la forma sh: ejecuta el comando declarado" bash -c '
printf "El resultado es 4. <!-- derived: sh:echo 4 -->\n" > blueprint/df-sh.md
python3 .orchestrator/scripts/derived-figures.py >/dev/null 2>&1; rc=$?
rm -f blueprint/df-sh.md
exit $rc'

echo "== class scan: la misma pregunta sobre un hecho escrito, no solo sobre codigo =="
expect_ok_msg "class scan: acepta un hecho documental como sujeto" "written_fact" \
  grep -m1 "written_fact" .claude/agents/repair-class-scan.md
expect_ok_msg "class scan: pregunta donde mas es FALSO ese hecho" "now FALSE" \
  grep -m1 "now FALSE" .claude/agents/repair-class-scan.md
expect_ok_msg "class scan: manda la cifra derivable al marcador, no a un quinto arreglo a mano" \
  "derivable_by" grep -m1 "derivable_by" .claude/agents/repair-class-scan.md
expect_ok "class scan: sigue sin estar en validate-state.py (no es fase obligatoria)" bash -c '
! grep -q "repair-class-scan\|CLASS_SCAN" .orchestrator/scripts/validate-state.py'


expect_ok "estado restaurado: el gate vuelve a pasar" python3 .orchestrator/scripts/validate-state.py

echo
echo "golden-path smoke: $pass PASS, $fail FAIL"
[ "$fail" -eq 0 ]
