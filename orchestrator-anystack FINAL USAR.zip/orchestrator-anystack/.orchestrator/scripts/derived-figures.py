#!/usr/bin/env python3
"""Re-derive every figure that declares how it is derived, and fail on the ones that lie.

    python3 .orchestrator/scripts/derived-figures.py            # check every marked figure
    python3 .orchestrator/scripts/derived-figures.py --list     # show what is marked, no verdict

WHY THIS EXISTS.

MEASURED: a set of four coupled cells was corrected in four separate passes, leaving three of them
lying each time. Three different enumerations of one set — a rule saying "the five", a module
docstring listing three of seven outputs, a guard claiming "ALL" — were three rounds of the same
shape. Nobody was careless. Each pass fixed the statement it was shown, and NOTHING asked which
other statements that same edit had just falsified.

The generalisation is the one this repository keeps re-learning one instance at a time: a number
written in prose is a claim about something else, and a claim nobody can re-run is not evidence.
`validate-structure.sh` already enforces exactly this for the lens SETS — it extracts the arrays
from the workflow .js files and fails when they disagree with validate-state.py. Every prose
restatement of those same sets was a third copy with nothing behind it.

So: a figure may declare the derivation that produces it, next to itself, and this re-runs it.

    ... all **10** `verify-*` lenses ...   <!-- derived: jsarray:.claude/workflows/verify-fanout.js:LENSES -->

The marker sits on the same line as the claim, or alone on the line immediately after it. The value
this script computes must appear in the claim text as a standalone token; if it does not, the figure
and its source have drifted, and the script says which is which.

WHAT IT IS NOT. It is not a gate on a unit and it is not evidence: it never enters `phase_runs[]`,
`checks[]` or `result.json`, and no unit's status depends on it. It is a linter of the repository's
own prose, in the same family as `lint-blueprint.py`, and it runs from `validate-structure.sh`.

HONEST LIMIT, stated because a checker whose blind spot is undocumented gets trusted past it: this
verifies that the correct value APPEARS in the claim line, not that the sentence around it means
what it says. A line that happens to contain the right number for another reason passes. It closes
the failure that was measured — a figure that says four when the source says five — and nothing
more. Prose that enumerates a set longhand ("the five outputs are A, B, C") is only partly covered:
mark it with the count and the count is checked; whether the list beneath it is the right list is a
`repair-class-scan` question with `subject_kind: written_fact`, not a scriptable one.

DERIVATIONS. Three forms, and the first two exist so the common case needs no shell quoting:

    jsarray:<file>:<CONST>   count of quoted names in `const <CONST> = [ ... ]` in that file
    glob:<pattern>           count of files matching a repo-relative glob
    sh:<command>             literal shell one-liner; its stdout, stripped, is the value

`sh:` runs a command out of a repository file. That is the same posture the orchestrator already
takes with `stack.md`'s declared commands (`preflight-check.sh`, `reset-test-data.sh`), and the
same caveat applies: it is only ever as safe as the repository is trusted. It is offered last on
purpose — prefer the two declarative forms, which cannot do anything but count.

EXIT CONTRACT:
  0  every marked figure matches what its derivation computes (or nothing is marked)
  1  at least one marked figure disagrees with its source
  2  the check could not run at all (a derivation is malformed, or its target is missing)
"""
from __future__ import annotations

import re
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent.parent

# Where prose lives. Deliberately NOT the whole tree: node_modules, build output and a project's
# own product code are not this linter's business, and walking them makes a fast check slow.
SEARCH_ROOTS = ("CLAUDE.md", "README.md", "USO.md", "PROMPT.md",
                ".claude", ".orchestrator", "blueprint", "blueprint-templates")
SEARCH_SUFFIXES = {".md", ".js", ".py", ".sh", ".css", ".json"}
SKIP_PARTS = {"__pycache__", "node_modules", ".git", ".orchestrator-state"}
# This linter's own docstring DESCRIBES the marker rather than claiming anything with it: reading it
# would check an example against reality, which is a checker grading its own documentation.
# smoke-golden-path.sh is a FORWARD GUARD, not a current need — today it embeds no marker (verified:
# zero matches), but its whole job is to mutate fixtures, and the day it writes one inline this
# linter would start grading a deliberately-broken fixture. Listed now because the failure would be
# confusing later and the line costs nothing.
SKIP_NAMES = {"derived-figures.py", "smoke-golden-path.sh"}

# The marker, in whichever comment syntax the host file uses. One shape, three wrappers.
MARKER = re.compile(r"(?:<!--|#|//)\s*derived:\s*(.+?)\s*(?:-->|$)")

errors: list[str] = []
notes: list[str] = []


def die(msg: str) -> None:
    print(f"derived-figures: {msg}", file=sys.stderr)
    raise SystemExit(2)


def count_js_array(spec: str) -> str:
    try:
        _, rel, const = spec.split(":", 2)
    except ValueError:
        die(f"malformed derivation {spec!r}; expected jsarray:<file>:<CONST>")
    fp = ROOT / rel
    if not fp.is_file():
        die(f"derivation {spec!r} targets {rel}, which does not exist")
    text = re.sub(r"//[^\n]*", "", fp.read_text(encoding="utf-8"))
    m = re.search(rf"^const {re.escape(const)}\s*=\s*\[(.*?)\]", text, re.DOTALL | re.MULTILINE)
    if not m:
        die(f"derivation {spec!r}: no `const {const} = [...]` in {rel}")
    return str(len(set(re.findall(r"'([^']+)'", m.group(1)))))


def count_glob(spec: str) -> str:
    pattern = spec.split(":", 1)[1]
    return str(len([p for p in ROOT.glob(pattern) if p.is_file()]))


def run_shell(spec: str) -> str:
    command = spec.split(":", 1)[1]
    try:
        out = subprocess.run(["bash", "-c", command], cwd=str(ROOT), capture_output=True,
                             text=True, timeout=60)
    except subprocess.TimeoutExpired:
        die(f"derivation {spec!r} timed out after 60s")
    if out.returncode != 0:
        die(f"derivation {spec!r} exited {out.returncode}: {out.stderr.strip()[:200]}")
    return out.stdout.strip()


def derive(spec: str) -> str:
    if spec.startswith("jsarray:"):
        return count_js_array(spec)
    if spec.startswith("glob:"):
        return count_glob(spec)
    if spec.startswith("sh:"):
        return run_shell(spec)
    die(f"unknown derivation form {spec!r}; expected jsarray:, glob: or sh:")
    return ""


def candidate_files():
    for entry in SEARCH_ROOTS:
        base = ROOT / entry
        if base.is_file():
            yield base
            continue
        if not base.is_dir():
            continue
        for fp in base.rglob("*"):
            if not fp.is_file() or fp.suffix not in SEARCH_SUFFIXES:
                continue
            if any(part in SKIP_PARTS for part in fp.parts) or fp.name in SKIP_NAMES:
                continue
            yield fp


def main() -> None:
    listing = "--list" in sys.argv
    checked = 0
    for fp in candidate_files():
        try:
            lines = fp.read_text(encoding="utf-8").splitlines()
        except UnicodeDecodeError:
            continue
        rel = fp.relative_to(ROOT)
        for idx, line in enumerate(lines):
            # SEVERAL markers per line are supported, and that is the whole point rather than a
            # convenience: the measured failure was FOUR COUPLED CELLS, and coupled cells live
            # next to each other. A tool that could only check one figure per line would be unable
            # to express the very case it exists for.
            specs = [s.strip() for s in MARKER.findall(line)
                     if s.strip().startswith(("jsarray:", "glob:", "sh:"))]
            if not specs:
                continue
            # POSITIONAL BINDING — each spec is checked against the text that PRECEDES its own
            # marker, back to the previous marker, not against the whole line.
            #
            # Matching every value anywhere in the merged line is not a weaker version of the same
            # check, it is a different and much worse one: on `... 17 research-* ... 8 explore-*`
            # with two markers, both values are present no matter which claim each belongs to, so
            # swapping them passes. That is exactly the coupled-cell failure this file exists to
            # catch, reproduced by the tool meant to catch it. Segments fix it and cost nothing.
            claim_line = idx + 1
            no_previous_line = False
            segments = []
            cursor = 0
            for m in MARKER.finditer(line):
                if m.group(1).strip().startswith(("jsarray:", "glob:", "sh:")):
                    segments.append(line[cursor:m.start()])
                cursor = m.end()
            tail = line[cursor:].strip().lstrip("#/-> ").strip()
            no_leading_claim = not any(s.strip().lstrip("#/ ").strip() for s in segments)
            # THE PREVIOUS-LINE FALLBACK, and the condition that keeps it from lying.
            #
            # A marker ALONE on its line claims nothing itself, so the claim is the previous
            # non-empty line. But "nothing before the marker" is NOT the same test as "the marker
            # is alone": a line shaped `<marker> ...real claim text...` also has nothing before it,
            # and the first version of this fallback silently validated the PREVIOUS line instead —
            # a false PASS, produced by the branch written to prevent false passes. Reproduced: a
            # preceding line reading "Step 5 of the setup" satisfied a `sh:echo 5` derivation while
            # the real, co-located claim on the marker's own line said 9 and was never read.
            #
            # So the fallback needs BOTH halves empty. Trailing text means the author put the claim
            # after its marker, which positional binding cannot bind — and that is refused below
            # with a message that says where to move it, never absorbed into a weaker check.
            if no_leading_claim and not tail:
                back = idx - 1
                while back >= 0 and not lines[back].strip():
                    back -= 1
                if back >= 0:
                    segments = [lines[back].strip()] * len(specs)
                    claim_line = back + 1
                else:
                    segments = [""] * len(specs)
                    no_previous_line = True
            trailing_claim = no_leading_claim and bool(tail)
            for spec, segment in zip(specs, segments):
                claim = segment.strip().lstrip("#/ ").strip()
                checked += 1
                if not claim:
                    # Three ways to have no claim, and each gets its own sentence — a diagnosis that
                    # names the wrong cause sends the reader to the wrong line, which on a linter is
                    # most of the cost of being wrong.
                    if trailing_claim:
                        where_to = ("the claim text sits AFTER this marker. Positional binding "
                                    "reads what precedes a marker, so move the marker to the end "
                                    "of its claim; leaving it in front would silently bind it to "
                                    "the previous line instead")
                    elif no_previous_line:
                        where_to = ("this marker stands alone on the first line of the file, so "
                                    "there is no previous line to claim anything. Put the figure "
                                    "before it, on the same line")
                    else:
                        where_to = ("another marker sits immediately in front of it. Put each "
                                    "marker directly AFTER the figure it derives, so each binds to "
                                    "its own claim; markers stacked at the end of a line cannot be "
                                    "told apart, and a pair whose values are swapped would pass")
                    errors.append(f"{rel}:{idx + 1}: the derivation {spec} has no claim text bound "
                                  f"to it — {where_to}.")
                    continue
                value = derive(spec)
                if listing:
                    notes.append(f"{rel}:{claim_line}: {spec} -> {value!r}")
                    continue
                if not value:
                    errors.append(f"{rel}:{claim_line}: derivation {spec} produced no value; a "
                                  f"figure whose source computes nothing is not a derived figure")
                    continue
                # Token boundaries: the value must stand alone, but a figure at the END OF A SENTENCE is
                # still standing alone. A plain "not followed by [\\w.]" rejected "es 4." — the period is
                # punctuation there, not a decimal point. Block the decimal case specifically (a digit
                # before, or a digit after an optional dot) and let ordinary punctuation through.
                if not re.search(rf"(?<![\w.]){re.escape(value)}(?!\.?\d)(?!\w)", claim):
                    errors.append(
                        f"{rel}:{claim_line}: the figure and its source disagree. Its derivation "
                        f"({spec}) computes {value!r}, which does not appear in the claim:\n"
                        f"      {claim[:160]}\n"
                        f"    Fix the prose, or fix the source — but not one of them alone: this "
                        f"is the coupled-cell failure, where each pass corrects the statement it "
                        f"was shown and leaves the others lying.")

    if listing:
        for note in notes:
            print(note)
        print(f"derived-figures: {checked} marked figure(s).")
        raise SystemExit(0)
    if errors:
        print("derived-figures: figures that disagree with their own source:", file=sys.stderr)
        for err in errors:
            print(f"  {err}", file=sys.stderr)
        raise SystemExit(1)
    print(f"derived-figures: {checked} marked figure(s) match their source.")
    raise SystemExit(0)


if __name__ == "__main__":
    main()
