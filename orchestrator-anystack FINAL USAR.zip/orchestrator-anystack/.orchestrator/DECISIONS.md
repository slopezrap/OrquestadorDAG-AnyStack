# DECISIONS.md — decisiones sobre la MAQUINARIA del orquestador

> No confundir con `blueprint/DECISIONS.md`, que es el ledger de **producto** del proyecto que
> construyes con esto: nace vacío, lo llena tu proyecto, y `decided_by` es quien decide sobre
> tu producto. Este registra decisiones sobre el orquestador **mismo** — sus gates, sus
> contratos de evidencia, sus fases — y por eso vive en `.orchestrator/`, que es "definición
> estable, no estado vivo".
>
> Aquí solo entra lo **contractual**: un cambio que hace que un estado antes válido deje de
> serlo, o al revés. El resto del *porqué* de esta maquinaria vive donde siempre ha vivido, en
> los comentarios largos del código que lo implementa — un check no contractual se explica
> junto a su propio `if`, no en un fichero que nadie abre.
>
> Mismas reglas que el ledger de producto: **append-only**, una decisión por entrada, y el
> `trip_wire` es la parte que sostiene el peso — es lo que permite reabrir una decisión a quien
> no estuvo cuando se tomó.

## Índice

| ID | Fecha | Decisión | Supersede | Escrita en |
|---|---|---|---|---|
| DEC-ORCH-001 | 2026-08-15 | EXPLORE debe persistir su plan; el gate lo exige | — | `validate-state.py`, `next-pantalla/SKILL.md`, `constitution.md`, `conventions.md`, `result.schema.json` |
| DEC-ORCH-002 | 2026-08-15 | El orden de obra pasa de aviso a fallo duro en `--init-gate` | — | `validate-state.py`, `init-build/SKILL.md` |
| DEC-ORCH-003 | 2026-08-15 | Un set de lentes requerido es un historial ordenado; la evidencia completa bajo un set anterior avisa en vez de romper | — | `validate-state.py`, `smoke-golden-path.sh` |
| DEC-ORCH-004 | 2026-08-15 | Pre-flight determinista antes de cada abanico de VERIFY; `validate-structure.sh` exige dos scripts nuevos | — | `preflight-check.sh`, `lib/stack-command.sh`, `validate-structure.sh`, `next-pantalla/SKILL.md`, `constitution.md` |

---

## DEC-ORCH-001 — EXPLORE persiste su plan y el gate lo exige

```logic
id: DEC-ORCH-001
type: decision
status: applied
date: 2026-08-15
decided_by: "Sergio"
trigger: "auditoría del flujo contra el SDD canónico: la fase /plan era el único paso del ciclo specify→plan→tasks→implement sin equivalente aquí, y el plan que sí se escribía vivía solo en el contexto del conductor"
rejected_alternative: "PLAN como 7ª fase propia en phase_runs[]. Descartada tras el recon: obligaba a tocar 9 sitios de prosa que enumeran las fases, required_phases, dos schemas y el enum de checkpoint.phase, y volvía FALSA la frase de la constitución 'DEVELOP is the only phase with no workflow by design'. Además era ceremonia: la sección que produce el plan ya se llama 'Explore AND PLAN', así que el plan es el ENTREGABLE de EXPLORE, no una fase aparte"
trip_wire: "si alguna vez PLAN necesita fan-out propio (lentes que planifiquen en paralelo), deja de ser un artefacto de EXPLORE y vuelve a ser una fase — y entonces sí hay que pagar los 9 sitios de prosa. Mientras el conductor sea el único que lo escribe, esta forma es la correcta"
supersedes: []
written_to: [validate-state.py:validate_phase_coverage, next-pantalla/SKILL.md, constitution.md, conventions.md, result.schema.json, verify-conformance.md, pantalla-reviewer.md]
affects_screens: [TODAS las unidades no accepted]
reopens: []
```

**Decisión:** la entrada EXPLORE de `result.json.phase_runs[]` lleva `plan:
".orchestrator-state/evidence/<ID>/plan.md"`, y ese fichero tiene que existir y no pesar 0
bytes para que la unidad pueda cerrar en PASS. El plan contiene el **mapa de aceptación** (una
fila por criterio: IDs que lo rigen, ficheros a tocar, **cómo se probará**, artefacto
esperado), el orden vertical, el **consumidor declarado** de la unidad, y una sección
`## Delivery` que DEVELOP cierra declarando entregado / entregado-con-desviación / no
entregado.

**Por qué:** el plan existía —`next-pantalla` §2 siempre dijo "escribe el plan vertical"— pero
solo en el contexto del conductor. De ahí salían tres cosas, y la tercera es la que paga el
cambio. (1) Una compactación a mitad de DEVELOP lo re-derivaba, justo en el momento en que
peor se re-deriva, porque lo que se acaba de borrar es la memoria de lo que ya habías
decidido. (2) Nada podía preguntar *¿se construyó lo que se planeó?* — `pantalla-reviewer`
juzga código contra `acceptance[]` y `verify-conformance` contra el blueprint; ninguna de las
dos es esa pregunta. (3) Un criterio sin respuesta en la columna *cómo se probará* no se veía
hasta VERIFY, doce lanzamientos después, y costaba una iteración de debugger completa. Ahora
salta en EXPLORE por cero.

**Lo que reemplaza:** nada nuevo en intención — reemplaza un plan implícito por uno
falsable. Coste en lanzamientos de subagente: **cero**. Lo escribe el conductor inline, que
es también lo que impide que se convierta en auto-revisión: la sección `## Delivery` es una
DECLARACIÓN, y los dientes los ponen dos agentes independientes — `verify-conformance` la
audita desde el código (`plan_delivery[]`) y `pantalla-reviewer` nombra cada desviación
(`plan_deviations[]`, con `declared:false` como gap).

**Consecuencia:** **es un cambio contractual y rompe evidencia existente.** Cualquier unidad
en `verified` de un proyecto vivo falla el gate hasta que tenga su `plan.md`. Las `accepted`
solo avisan — deliberado: reabrir una unidad `accepted` está prohibido en la propia
constitución, así que fallar ahí no dejaría ninguna jugada legal; es el mismo carve-out de
retroactividad que ya usa `validate_source_manifest`. Los tres fixtures del golden-path se
actualizaron con su `plan.md` real, y el smoke ganó 3 casos (sin plan → falla; plan que no es
fichero → falla; `accepted` sin plan → solo avisa).

---

## DEC-ORCH-002 — El orden de obra bloquea al nacer, no solo avisa

```logic
id: DEC-ORCH-002
type: decision
status: applied
date: 2026-08-15
decided_by: "Sergio"
trigger: "el comentario de validate-state.py que empieza 'Global reachability alone was measured too weak' registra que la comprobación despejó 29 de 33 cimientos en el proyecto real, incluido el que iteró 14 veces; era el único defecto del fichero con coste medido y su única consecuencia era un warn (se cita por el TEXTO del comentario, no por número de línea: una cita fichero:línea envejece con el primer edit de arriba, y una cita rancia en un ledger de decisiones es el defecto que este fichero existe para evitar)"
rejected_alternative: "dejarlo en warn en todas las corridas (el estado anterior), y su opuesto: hacerlo fail SIEMPRE. Lo primero ya se probó y no funcionó — el proyecto que costó 4x fue avisado y siguió. Lo segundo es peor: una vez el proyecto está en marcha, un orden raro puede ser una decisión humana con razones que el gate no ve, y un gate que rechaza estados válidos acaba esquivado"
trip_wire: "FOUNDATION_CONSUMER_MAX_DISTANCE = 8 está calibrado con dos muestras (un fixture sano que llega a 2, un proyecto roto en el rango 3..33). Si un proyecto legítimo empieza a fallar --init-gate con cimientos que sí tienen consumidor razonable, la constante está mal, no la regla — recalíbrala antes de relajar el gate"
supersedes: []
written_to: [validate-state.py:validate_features, init-build/SKILL.md]
affects_screens: [ninguna existente — solo proyectos que nacen]
reopens: []
```

**Decisión:** la comprobación de cimiento-sin-consumidor sigue siendo `warn()` en toda corrida
normal del gate y pasa a `fail()` bajo `--init-gate`, que solo invoca `/init-build`.

**Por qué:** es el mismo argumento que pone `/arch-review` en t=0 — *el único momento en que
la arquitectura cambia gratis*. Al nacer no hay ninguna decisión humana que defender: nada
está construido, no hay evidencia, y reordenar `order`/`after[]` cuesta una edición. Una vez
el proyecto corre, la asimetría se invierte y el `warn` es lo correcto. Y es el único defecto
de este fichero con un precio medido: 307 lanzamientos contra 78 en la misma maquinaria, 4×,
porque un cimiento sin nada que lo ejecute no falla en su primera pasada — falla en la ronda
4, cuando algo por fin lo usa, y cada ronda es una reparación completa.

**Lo que reemplaza:** un `warn` que un `/build-loop --autonomous` no lee. La salida de escape
sigue existiendo y ahora queda escrita: si el orden es deliberado, se registra como un `DEC-*`
`accepted_with_risk` nombrando los cimientos y el porqué — una decisión en el registro en vez
de un aviso que nadie vio.

**Consecuencia:** `init-build/SKILL.md` documenta el orden de obra como disparador de CLARIFY
en el paso 3 y las **tres** cosas que `--init-gate` exige de más en el paso 6. Implementado
con un parámetro `init_gate` en `validate_features()`, no con una global: el script no tiene
ninguna variable global mutable y no es el sitio para estrenar la primera. Tres casos nuevos
de smoke (golden-path no dispara · gate normal avisa y sale 0 · `--init-gate` falla duro).

---

## DEC-ORCH-003 — Un set de lentes requerido es un historial, no un set

```logic
id: DEC-ORCH-003
type: decision
status: applied
date: 2026-08-15
decided_by: "Sergio"
trigger: "revisión adversaria del propio orquestador: require_full_fanout era la ÚNICA función de cobertura del fichero sin la rama warn-si-accepted que el resto aplica sistemáticamente, y compara toda entrada histórica contra la constante ACTUAL. Consecuencia medida sobre el golden-path: crecer VERIFY de 10 a 11 lentes hace fail() duro en la primera unidad ya verified, el hook corre el gate en cada escritura de features.json, y la reabertura que lo arreglaría es ella misma una escritura que el gate bloquea — el proyecto ENTERO queda sin jugada legal, no solo la unidad"
rejected_alternative: "grabar un campo nuevo por entrada (lens_set_size / lens_set_version) y comparar cada entrada contra lo que ELLA declaró. Descartada: toda entrada ya escrita carece del campo, así que su ausencia habría que interpretarla de todos modos — se paga un campo nuevo, un cambio de schema y una cosa más que el conductor debe acordarse de escribir, para acabar necesitando igual la misma regla de grandfathering. La otra descartada: fallar duro y reabrir a mano cada unidad afectada, que es exactamente la jugada que la constitución prohíbe sobre accepted"
trip_wire: "el mecanismo NO distingue una entrada genuinamente vieja de una nueva que registró un set viejo — nada en la entrada dice cuándo cambió el set. El respaldo es que validate-structure.sh fuerza a cada fan-out .js a coincidir con el set ACTUAL, así que una corrida nueva lanza físicamente todas las lentes de hoy. Si alguna vez ese respaldo se afloja (un workflow que elija su set en runtime, o un .js que deje de compararse), este grandfathering pasa de red de seguridad a agujero y hay que sustituirlo por la alternativa descartada arriba. Segundo trip-wire: si covered_set() llegara a aceptar un set que nunca fue completo bajo ninguna versión histórica, la regla está rota, no relajada"
supersedes: []
written_to: [validate-state.py:require_full_fanout, validate-state.py:RESEARCH_LENS_SETS, validate-state.py:EXPLORE_LENS_SETS, validate-state.py:VERIFY_LENS_SETS, smoke-golden-path.sh]
affects_screens: [ninguna existente — solo amplía lo que el gate acepta]
reopens: []
```

**Decisión:** `RESEARCH_LENSES` / `EXPLORE_LENSES` / `VERIFY_LENSES` dejan de ser el argumento de
`require_full_fanout` y pasan a serlo `*_LENS_SETS`, una tupla ordenada con el set vigente al
final. Tres resultados: cubre el set actual → pasa igual que siempre; cubre uno **superseded** →
`warn()` que nombra el remedio; no cubre **ninguno** → `fail()` con el mensaje de siempre. Crecer
un set es añadir una entrada a la tupla y no tocar las anteriores.

**Por qué:** un `phase_runs[]` registra lo que corrió **cuando la unidad corrió**, y medirlo
contra la constante de hoy convierte cada crecimiento del set en una invalidación retroactiva de
todo lo ya construido. El resultado no era un gate estricto sino un gate que **no se puede
evolucionar**: el orquestador no podía añadir una lente a ninguna de sus tres fases de fan-out
sin abandonar cualquier proyecto con historial. Y era una asimetría accidental, no una postura:
`validate_source_manifest`, el guard de artefactos y el de `plan.md` ya tenían su carve-out; esta
función se quedó sin él.

**Lo que reemplaza:** un fallo duro por un aviso **solo** en el caso en que la evidencia fue
completa bajo las reglas de su momento. Un set genuinamente parcial —que no cubre ningún set que
esta fase haya requerido nunca— sigue siendo `fail()` con el mismo mensaje: esto no relaja el
estándar, distingue *incompleto* de *anterior*.

**Consecuencia — y el defecto que el propio cambio introdujo.** Mientras "completa" significó
"cubre el único set actual", una entrada completa había corrido **toda** lente del set, así que
`carried_forward[]` podía citar solo la **iteración**. El grandfathering rompe esa implicación: una
entrada puede ser completa para un set superseded, y una cita por iteración dejaba entonces que un
triage arrastrase una lente **añadida después** de la pasada que cita — una lente que esa pasada
provablemente nunca ejecutó, sin `warn` ni `fail`. Lo encontraron dos revisores independientes con
control A/B sobre la misma evidencia fabricada. La cita se comprueba ahora contra las **lentes
realmente corridas** por la entrada citada, no contra su número de iteración. El smoke ganó tres
casos (superseded avisa y no rompe · parcial sigue fallando · carrear una lente que la pasada
citada nunca corrió falla), los tres verificados por mutación: revertir el arreglo los pone en
rojo.

---

## DEC-ORCH-004 — Un pre-flight determinista precede a cada abanico de VERIFY

```logic
id: DEC-ORCH-004
type: decision
status: applied
date: 2026-08-15
decided_by: "Sergio"
trigger: "verify-fanout.js espera sus 4 lentes documentales al completo antes de arrancar la mitad serializada, y la lente que prueba el build (verify-frontend) es la PRIMERA de esa mitad. En una pasada donde el codigo no compila se pagan 5 lanzamientos de subagente para saber lo que <COMMAND_BUILD> dice en segundos — y como un VERIFY fallido es una pasada de reparacion, una errata puede gastar un tercio de las 3 iteraciones de la unidad. El conductor nunca corria los comandos del stack por su cuenta: solo setup/smoke al rehidratar, una vez por unidad"
rejected_alternative: "solapar las 4 documentales con la cadena serie dentro de verify-fanout.js (ahorra reloj sin script nuevo). Descartada: hoy las documentales leen un arbol EN REPOSO, y solaparlas las expone a leer fuentes mientras un lint --fix o unos snapshots las reescriben — reintroduce la clase de fallo que pertenece-al-vecino que la serializacion existe para eliminar. La otra descartada: meter COMMAND_TEST en el set por defecto; verify-tests ya corre la suite entera de forma incondicional en cada pasada, asi que pagaria el comando mas lento dos veces en el camino feliz"
trip_wire: "el pre-flight NO es evidencia y jamas entra en phase_runs[]: si algun dia una entrada de phase_runs cita el pre-flight, o si verify-frontend/verify-tests dejan de correr porque 'el pre-flight ya lo comprobo', la regla esta rota y hay que revertir. Segundo trip-wire: el tope de 2 intentos vive solo en el contexto del conductor (una compactacion lo reinicia); si aparece un caso real de bucle de pre-flight que no llega a blocked, ese contador necesita un campo en disco"
supersedes: []
written_to: [preflight-check.sh, lib/stack-command.sh, validate-structure.sh, smoke-golden-path.sh, next-pantalla/SKILL.md, fix/SKILL.md, orchestrator-flow.md, constitution.md, stack.md, CLAUDE.md, README.md]
affects_screens: [ninguna existente — no cambia ninguna evidencia ya escrita]
reopens: []
```

**Decision:** antes de CADA lanzamiento de `verify-fanout` —incluidas todas las re-corridas del debugger— el conductor ejecuta `preflight-check.sh`, que corre `COMMAND_LINT` y `COMMAND_BUILD` de `stack.md`. Non-zero: reparar y re-correr **sin lanzar el abanico y sin incrementar `checkpoint.iteration`**, parando tras el segundo fallo consecutivo. Ademas, cuando una pasada de VERIFY devuelve varios fallos, se reparan en orden de causalidad (build → tests → engine → pipeline → logs → quality → las 4 documentales).

**Por que es CONTRACTUAL y entra en este ledger.** No por el pre-flight en si —que es prosa de conductor— sino porque `validate-structure.sh` ahora exige `preflight-check.sh` y `lib/stack-command.sh` en su `required[]`: un checkout que antes pasaba la validacion de estructura, sin esos dos ficheros, ya no pasa. Eso es exactamente "un cambio que hace que un estado antes valido deje de serlo".

**Lo que reemplaza:** el parser de `stack.md` estaba embebido en `reset-test-data.sh`; se extrajo a `lib/stack-command.sh` para que ambos scripts lean el fichero igual, en vez de duplicar un awk que habria divergido en cuanto uno de los dos aprendiera algo. Y `stack.md` gano los marcadores `(COMMAND_LINT)`/`(COMMAND_BUILD)`/`(COMMAND_TEST)`: sin ellos el parser —que trata el marcador como la declaracion, no el texto del comentario— no encontraba nada.

**Consecuencia, incluido lo que la revision adversaria encontro roto.** El script nacio sin el guard de `BASH_SOURCE` que su hermano si tiene, y por tanto, invocado por un shell que no lo define, degradaba a `exit 0 / nothing to check`: **exito silencioso en el unico script cuyo trabajo entero es avisar de un fallo**. Cerrado con `exit 2` propio (ni "no aplica" ni "un comando fallo", sino "no se pudo comprobar") y dos casos de smoke que ningun test cubria. El smoke paso de 92 a 99 casos.
