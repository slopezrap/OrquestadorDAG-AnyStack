# DECISIONS.md — decisiones sobre la MAQUINARIA del orquestador

> No confundir con `blueprint/DECISIONS.md`, que es el ledger de **producto** del proyecto que
> construyes con esto: nace vacío, lo llena tu proyecto, y `decided_by` es quien decide sobre
> tu producto. Este registra decisiones sobre el orquestador **mismo** — sus gates, sus
> contratos de evidencia, sus fases — y por eso vive en `.orchestrator/`, que es "definición
> estable, no estado vivo".
>
> Aquí solo entra lo **contractual**: un cambio que hace que un estado antes válido deje de
> serlo, o al revés. El resto del *porqué* de esta maquinaria vive donde siempre ha vivido, en
> los comentarios largos del código que lo implementa — un check no contractual se explica
> junto a su propio `if`, no en un fichero que nadie abre.
>
> Mismas reglas que el ledger de producto: **append-only**, una decisión por entrada, y el
> `trip_wire` es la parte que sostiene el peso — es lo que permite reabrir una decisión a quien
> no estuvo cuando se tomó.

## Índice

| ID | Fecha | Decisión | Supersede | Escrita en |
|---|---|---|---|---|
| DEC-ORCH-001 | 2026-08-15 | EXPLORE debe persistir su plan; el gate lo exige | — | `validate-state.py`, `next-pantalla/SKILL.md`, `constitution.md`, `conventions.md`, `result.schema.json` |
| DEC-ORCH-002 | 2026-08-15 | El orden de obra pasa de aviso a fallo duro en `--init-gate` | — | `validate-state.py`, `init-build/SKILL.md` |
| DEC-ORCH-003 | 2026-08-15 | Un set de lentes requerido es un historial ordenado; la evidencia completa bajo un set anterior avisa en vez de romper | — | `validate-state.py`, `smoke-golden-path.sh` |
| DEC-ORCH-004 | 2026-08-15 | Pre-flight determinista antes de cada abanico de VERIFY; `validate-structure.sh` exige dos scripts nuevos | — | `preflight-check.sh`, `lib/stack-command.sh`, `validate-structure.sh`, `next-pantalla/SKILL.md`, `constitution.md` |
| DEC-ORCH-005 | 2026-08-16 | `DEC-*` entra en el registro compartido del linter; `written_to` pasa a comprobarse contra disco | — | `lint-blueprint.py`, `smoke-golden-path.sh` |
| DEC-ORCH-006 | 2026-08-16 | Una pasada de VERIFY docs-only deriva su propio ámbito a las 4 lentes doc↔código | — | `verify-fanout.js`, `next-pantalla/SKILL.md`, `constitution.md` |
| DEC-ORCH-007 | 2026-08-16 | La racha de pasadas docs-only tiene tope 2; es el terminador que a DEC-ORCH-006 le faltaba | — | `validate-state.py`, `next-pantalla/SKILL.md`, `constitution.md`, `smoke-golden-path.sh` |
| DEC-ORCH-008 | 2026-08-16 | El adversario del diff: 4 preguntas de solo lectura entre la reparación y la prueba | — | `diff-adversary.js`, 4 agentes nuevos, `next-pantalla/SKILL.md`, `constitution.md`, `validate-structure.sh` |
| DEC-ORCH-009 | 2026-08-16 | El listón del adversario va en el hallazgo, no en el recuento: fuera toda expectativa de frecuencia | DEC-ORCH-008 (cláusula 5) | `diff-adversary.js`, los 4 agentes, `next-pantalla/SKILL.md`, `constitution.md` |
| DEC-ORCH-010 | 2026-08-16 | Un hallazgo es una INSTANCIA de una clase hasta que se barre: la reparación cierra la clase, no el punto | — | `repair-class-scan.md`, `next-pantalla/SKILL.md`, `constitution.md`, `conventions.md` |
| DEC-ORCH-011 | 2026-08-16 | El límite de la unidad gana diente: el gate avisa de todo fichero tocado que su propio `plan.md` no declara | — | `validate-state.py`, `next-pantalla/SKILL.md`, `smoke-golden-path.sh` |

---

## DEC-ORCH-001 — EXPLORE persiste su plan y el gate lo exige

```logic
id: DEC-ORCH-001
type: decision
status: applied
date: 2026-08-15
decided_by: "Sergio"
trigger: "auditoría del flujo contra el SDD canónico: la fase /plan era el único paso del ciclo specify→plan→tasks→implement sin equivalente aquí, y el plan que sí se escribía vivía solo en el contexto del conductor"
rejected_alternative: "PLAN como 7ª fase propia en phase_runs[]. Descartada tras el recon: obligaba a tocar 9 sitios de prosa que enumeran las fases, required_phases, dos schemas y el enum de checkpoint.phase, y volvía FALSA la frase de la constitución 'DEVELOP is the only phase with no workflow by design'. Además era ceremonia: la sección que produce el plan ya se llama 'Explore AND PLAN', así que el plan es el ENTREGABLE de EXPLORE, no una fase aparte"
trip_wire: "si alguna vez PLAN necesita fan-out propio (lentes que planifiquen en paralelo), deja de ser un artefacto de EXPLORE y vuelve a ser una fase — y entonces sí hay que pagar los 9 sitios de prosa. Mientras el conductor sea el único que lo escribe, esta forma es la correcta"
supersedes: []
written_to: [validate-state.py:validate_phase_coverage, next-pantalla/SKILL.md, constitution.md, conventions.md, result.schema.json, verify-conformance.md, pantalla-reviewer.md]
affects_screens: [TODAS las unidades no accepted]
reopens: []
```

**Decisión:** la entrada EXPLORE de `result.json.phase_runs[]` lleva `plan:
".orchestrator-state/evidence/<ID>/plan.md"`, y ese fichero tiene que existir y no pesar 0
bytes para que la unidad pueda cerrar en PASS. El plan contiene el **mapa de aceptación** (una
fila por criterio: IDs que lo rigen, ficheros a tocar, **cómo se probará**, artefacto
esperado), el orden vertical, el **consumidor declarado** de la unidad, y una sección
`## Delivery` que DEVELOP cierra declarando entregado / entregado-con-desviación / no
entregado.

**Por qué:** el plan existía —`next-pantalla` §2 siempre dijo "escribe el plan vertical"— pero
solo en el contexto del conductor. De ahí salían tres cosas, y la tercera es la que paga el
cambio. (1) Una compactación a mitad de DEVELOP lo re-derivaba, justo en el momento en que
peor se re-deriva, porque lo que se acaba de borrar es la memoria de lo que ya habías
decidido. (2) Nada podía preguntar *¿se construyó lo que se planeó?* — `pantalla-reviewer`
juzga código contra `acceptance[]` y `verify-conformance` contra el blueprint; ninguna de las
dos es esa pregunta. (3) Un criterio sin respuesta en la columna *cómo se probará* no se veía
hasta VERIFY, doce lanzamientos después, y costaba una iteración de debugger completa. Ahora
salta en EXPLORE por cero.

**Lo que reemplaza:** nada nuevo en intención — reemplaza un plan implícito por uno
falsable. Coste en lanzamientos de subagente: **cero**. Lo escribe el conductor inline, que
es también lo que impide que se convierta en auto-revisión: la sección `## Delivery` es una
DECLARACIÓN, y los dientes los ponen dos agentes independientes — `verify-conformance` la
audita desde el código (`plan_delivery[]`) y `pantalla-reviewer` nombra cada desviación
(`plan_deviations[]`, con `declared:false` como gap).

**Consecuencia:** **es un cambio contractual y rompe evidencia existente.** Cualquier unidad
en `verified` de un proyecto vivo falla el gate hasta que tenga su `plan.md`. Las `accepted`
solo avisan — deliberado: reabrir una unidad `accepted` está prohibido en la propia
constitución, así que fallar ahí no dejaría ninguna jugada legal; es el mismo carve-out de
retroactividad que ya usa `validate_source_manifest`. Los tres fixtures del golden-path se
actualizaron con su `plan.md` real, y el smoke ganó 3 casos (sin plan → falla; plan que no es
fichero → falla; `accepted` sin plan → solo avisa).

---

## DEC-ORCH-002 — El orden de obra bloquea al nacer, no solo avisa

```logic
id: DEC-ORCH-002
type: decision
status: applied
date: 2026-08-15
decided_by: "Sergio"
trigger: "el comentario de validate-state.py que empieza 'Global reachability alone was measured too weak' registra que la comprobación despejó 29 de 33 cimientos en el proyecto real, incluido el que iteró 14 veces; era el único defecto del fichero con coste medido y su única consecuencia era un warn (se cita por el TEXTO del comentario, no por número de línea: una cita fichero:línea envejece con el primer edit de arriba, y una cita rancia en un ledger de decisiones es el defecto que este fichero existe para evitar)"
rejected_alternative: "dejarlo en warn en todas las corridas (el estado anterior), y su opuesto: hacerlo fail SIEMPRE. Lo primero ya se probó y no funcionó — el proyecto que costó 4x fue avisado y siguió. Lo segundo es peor: una vez el proyecto está en marcha, un orden raro puede ser una decisión humana con razones que el gate no ve, y un gate que rechaza estados válidos acaba esquivado"
trip_wire: "FOUNDATION_CONSUMER_MAX_DISTANCE = 8 está calibrado con dos muestras (un fixture sano que llega a 2, un proyecto roto en el rango 3..33). Si un proyecto legítimo empieza a fallar --init-gate con cimientos que sí tienen consumidor razonable, la constante está mal, no la regla — recalíbrala antes de relajar el gate"
supersedes: []
written_to: [validate-state.py:validate_features, init-build/SKILL.md]
affects_screens: [ninguna existente — solo proyectos que nacen]
reopens: []
```

**Decisión:** la comprobación de cimiento-sin-consumidor sigue siendo `warn()` en toda corrida
normal del gate y pasa a `fail()` bajo `--init-gate`, que solo invoca `/init-build`.

**Por qué:** es el mismo argumento que pone `/arch-review` en t=0 — *el único momento en que
la arquitectura cambia gratis*. Al nacer no hay ninguna decisión humana que defender: nada
está construido, no hay evidencia, y reordenar `order`/`after[]` cuesta una edición. Una vez
el proyecto corre, la asimetría se invierte y el `warn` es lo correcto. Y es el único defecto
de este fichero con un precio medido: 307 lanzamientos contra 78 en la misma maquinaria, 4×,
porque un cimiento sin nada que lo ejecute no falla en su primera pasada — falla en la ronda
4, cuando algo por fin lo usa, y cada ronda es una reparación completa.

**Lo que reemplaza:** un `warn` que un `/build-loop --autonomous` no lee. La salida de escape
sigue existiendo y ahora queda escrita: si el orden es deliberado, se registra como un `DEC-*`
`accepted_with_risk` nombrando los cimientos y el porqué — una decisión en el registro en vez
de un aviso que nadie vio.

**Consecuencia:** `init-build/SKILL.md` documenta el orden de obra como disparador de CLARIFY
en el paso 3 y las **tres** cosas que `--init-gate` exige de más en el paso 6. Implementado
con un parámetro `init_gate` en `validate_features()`, no con una global: el script no tiene
ninguna variable global mutable y no es el sitio para estrenar la primera. Tres casos nuevos
de smoke (golden-path no dispara · gate normal avisa y sale 0 · `--init-gate` falla duro).

---

## DEC-ORCH-003 — Un set de lentes requerido es un historial, no un set

```logic
id: DEC-ORCH-003
type: decision
status: applied
date: 2026-08-15
decided_by: "Sergio"
trigger: "revisión adversaria del propio orquestador: require_full_fanout era la ÚNICA función de cobertura del fichero sin la rama warn-si-accepted que el resto aplica sistemáticamente, y compara toda entrada histórica contra la constante ACTUAL. Consecuencia medida sobre el golden-path: crecer VERIFY de 10 a 11 lentes hace fail() duro en la primera unidad ya verified, el hook corre el gate en cada escritura de features.json, y la reabertura que lo arreglaría es ella misma una escritura que el gate bloquea — el proyecto ENTERO queda sin jugada legal, no solo la unidad"
rejected_alternative: "grabar un campo nuevo por entrada (lens_set_size / lens_set_version) y comparar cada entrada contra lo que ELLA declaró. Descartada: toda entrada ya escrita carece del campo, así que su ausencia habría que interpretarla de todos modos — se paga un campo nuevo, un cambio de schema y una cosa más que el conductor debe acordarse de escribir, para acabar necesitando igual la misma regla de grandfathering. La otra descartada: fallar duro y reabrir a mano cada unidad afectada, que es exactamente la jugada que la constitución prohíbe sobre accepted"
trip_wire: "el mecanismo NO distingue una entrada genuinamente vieja de una nueva que registró un set viejo — nada en la entrada dice cuándo cambió el set. El respaldo es que validate-structure.sh fuerza a cada fan-out .js a coincidir con el set ACTUAL, así que una corrida nueva lanza físicamente todas las lentes de hoy. Si alguna vez ese respaldo se afloja (un workflow que elija su set en runtime, o un .js que deje de compararse), este grandfathering pasa de red de seguridad a agujero y hay que sustituirlo por la alternativa descartada arriba. Segundo trip-wire: si covered_set() llegara a aceptar un set que nunca fue completo bajo ninguna versión histórica, la regla está rota, no relajada"
supersedes: []
written_to: [validate-state.py:require_full_fanout, validate-state.py:RESEARCH_LENS_SETS, validate-state.py:EXPLORE_LENS_SETS, validate-state.py:VERIFY_LENS_SETS, smoke-golden-path.sh]
affects_screens: [ninguna existente — solo amplía lo que el gate acepta]
reopens: []
```

**Decisión:** `RESEARCH_LENSES` / `EXPLORE_LENSES` / `VERIFY_LENSES` dejan de ser el argumento de
`require_full_fanout` y pasan a serlo `*_LENS_SETS`, una tupla ordenada con el set vigente al
final. Tres resultados: cubre el set actual → pasa igual que siempre; cubre uno **superseded** →
`warn()` que nombra el remedio; no cubre **ninguno** → `fail()` con el mensaje de siempre. Crecer
un set es añadir una entrada a la tupla y no tocar las anteriores.

**Por qué:** un `phase_runs[]` registra lo que corrió **cuando la unidad corrió**, y medirlo
contra la constante de hoy convierte cada crecimiento del set en una invalidación retroactiva de
todo lo ya construido. El resultado no era un gate estricto sino un gate que **no se puede
evolucionar**: el orquestador no podía añadir una lente a ninguna de sus tres fases de fan-out
sin abandonar cualquier proyecto con historial. Y era una asimetría accidental, no una postura:
`validate_source_manifest`, el guard de artefactos y el de `plan.md` ya tenían su carve-out; esta
función se quedó sin él.

**Lo que reemplaza:** un fallo duro por un aviso **solo** en el caso en que la evidencia fue
completa bajo las reglas de su momento. Un set genuinamente parcial —que no cubre ningún set que
esta fase haya requerido nunca— sigue siendo `fail()` con el mismo mensaje: esto no relaja el
estándar, distingue *incompleto* de *anterior*.

**Consecuencia — y el defecto que el propio cambio introdujo.** Mientras "completa" significó
"cubre el único set actual", una entrada completa había corrido **toda** lente del set, así que
`carried_forward[]` podía citar solo la **iteración**. El grandfathering rompe esa implicación: una
entrada puede ser completa para un set superseded, y una cita por iteración dejaba entonces que un
triage arrastrase una lente **añadida después** de la pasada que cita — una lente que esa pasada
provablemente nunca ejecutó, sin `warn` ni `fail`. Lo encontraron dos revisores independientes con
control A/B sobre la misma evidencia fabricada. La cita se comprueba ahora contra las **lentes
realmente corridas** por la entrada citada, no contra su número de iteración. El smoke ganó tres
casos (superseded avisa y no rompe · parcial sigue fallando · carrear una lente que la pasada
citada nunca corrió falla), los tres verificados por mutación: revertir el arreglo los pone en
rojo.

---

## DEC-ORCH-004 — Un pre-flight determinista precede a cada abanico de VERIFY

```logic
id: DEC-ORCH-004
type: decision
status: applied
date: 2026-08-15
decided_by: "Sergio"
trigger: "verify-fanout.js espera sus 4 lentes documentales al completo antes de arrancar la mitad serializada, y la lente que prueba el build (verify-frontend) es la PRIMERA de esa mitad. En una pasada donde el codigo no compila se pagan 5 lanzamientos de subagente para saber lo que <COMMAND_BUILD> dice en segundos — y como un VERIFY fallido es una pasada de reparacion, una errata puede gastar un tercio de las 3 iteraciones de la unidad. El conductor nunca corria los comandos del stack por su cuenta: solo setup/smoke al rehidratar, una vez por unidad"
rejected_alternative: "solapar las 4 documentales con la cadena serie dentro de verify-fanout.js (ahorra reloj sin script nuevo). Descartada: hoy las documentales leen un arbol EN REPOSO, y solaparlas las expone a leer fuentes mientras un lint --fix o unos snapshots las reescriben — reintroduce la clase de fallo que pertenece-al-vecino que la serializacion existe para eliminar. La otra descartada: meter COMMAND_TEST en el set por defecto; verify-tests ya corre la suite entera de forma incondicional en cada pasada, asi que pagaria el comando mas lento dos veces en el camino feliz"
trip_wire: "el pre-flight NO es evidencia y jamas entra en phase_runs[]: si algun dia una entrada de phase_runs cita el pre-flight, o si verify-frontend/verify-tests dejan de correr porque 'el pre-flight ya lo comprobo', la regla esta rota y hay que revertir. Segundo trip-wire: el tope de 2 intentos vive solo en el contexto del conductor (una compactacion lo reinicia); si aparece un caso real de bucle de pre-flight que no llega a blocked, ese contador necesita un campo en disco"
supersedes: []
written_to: [preflight-check.sh, lib/stack-command.sh, validate-structure.sh, smoke-golden-path.sh, next-pantalla/SKILL.md, fix/SKILL.md, orchestrator-flow.md, constitution.md, stack.md, CLAUDE.md, README.md]
affects_screens: [ninguna existente — no cambia ninguna evidencia ya escrita]
reopens: []
```

**Decision:** antes de CADA lanzamiento de `verify-fanout` —incluidas todas las re-corridas del debugger— el conductor ejecuta `preflight-check.sh`, que corre `COMMAND_LINT` y `COMMAND_BUILD` de `stack.md`. Non-zero: reparar y re-correr **sin lanzar el abanico y sin incrementar `checkpoint.iteration`**, parando tras el segundo fallo consecutivo. Ademas, cuando una pasada de VERIFY devuelve varios fallos, se reparan en orden de causalidad (build → tests → engine → pipeline → logs → quality → las 4 documentales).

**Por que es CONTRACTUAL y entra en este ledger.** No por el pre-flight en si —que es prosa de conductor— sino porque `validate-structure.sh` ahora exige `preflight-check.sh` y `lib/stack-command.sh` en su `required[]`: un checkout que antes pasaba la validacion de estructura, sin esos dos ficheros, ya no pasa. Eso es exactamente "un cambio que hace que un estado antes valido deje de serlo".

**Lo que reemplaza:** el parser de `stack.md` estaba embebido en `reset-test-data.sh`; se extrajo a `lib/stack-command.sh` para que ambos scripts lean el fichero igual, en vez de duplicar un awk que habria divergido en cuanto uno de los dos aprendiera algo. Y `stack.md` gano los marcadores `(COMMAND_LINT)`/`(COMMAND_BUILD)`/`(COMMAND_TEST)`: sin ellos el parser —que trata el marcador como la declaracion, no el texto del comentario— no encontraba nada.

**Consecuencia, incluido lo que la revision adversaria encontro roto.** El script nacio sin el guard de `BASH_SOURCE` que su hermano si tiene, y por tanto, invocado por un shell que no lo define, degradaba a `exit 0 / nothing to check`: **exito silencioso en el unico script cuyo trabajo entero es avisar de un fallo**. Cerrado con `exit 2` propio (ni "no aplica" ni "un comando fallo", sino "no se pudo comprobar") y dos casos de smoke que ningun test cubria. El smoke paso de 92 a 99 casos.

---

## DEC-ORCH-005 — `DEC-*` entra en la maquinaria de integridad, y `written_to` deja de ser una promesa

```logic
id: DEC-ORCH-005
type: decision
status: applied
date: 2026-08-16
decided_by: "Sergio"
trigger: "medido en el proyecto real maser-invariant-chronicle: dos '## DEC-062' distintos con sus dos filas de índice y lint-blueprint.py salía 0. Lo cazaron TRES lentes de VERIFY — la inversión exacta de 'lo que un script puede decidir no debe costar nunca un fan-out' — al precio de una vuelta completa de depurador. En el mismo proyecto, `written_to` estuvo mal 4 veces en 2 ciclos (un fichero declarado que nunca se escribió, otro escrito que nunca se declaró) pese a que autonomy.md ya lo advertía en prosa"
rejected_alternative: "arreglar la FRASE en vez del código — constitution.md promete 'lint-blueprint.py catches dangling refs, duplicate IDs, cycles and stubs' y para DEC-* eso era falso, así que degradar la promesa era una salida legal. Descartada: la cobertura es barata (una línea de aritmética) y la promesa es lo que sostiene los tiers baratos de edición del blueprint; rebajarla habría empujado ediciones editoriales hacia /reslice. La otra descartada: enseñar a cada regla a leer DECISIONS.md — arregla el duplicado de hoy y ninguna regla futura"
trip_wire: "la aritmética `occurrences[len(defined.get(dec_id, [])):]` es lo único que separa este arreglo de sus tres trampas medidas (el `|=` con 314 errores espurios, el falso 'duplicate ID DEC-001' sobre la forma canónica, y la guarda `if id not in defined` que desactiva la detección entera). Si alguien la 'simplifica', los tres casos de smoke añadidos aquí se ponen rojos: son la red, no la decoración. Segundo trip-wire, y el que de verdad importa: si `family_coverage` deja de emitirse bajo --json, o si el aviso de familia-fuera-del-registro se silencia, vuelve el defecto de CLASE — un linter que cubre 15 de 16 familias sin decirlo"
supersedes: []
written_to: [.orchestrator/scripts/lint-blueprint.py, .orchestrator/scripts/smoke-golden-path.sh]
affects_screens: [ninguna existente — solo proyectos con blueprint/DECISIONS.md poblado]
reopens: []
```

**Decisión:** tres cambios en `lint-blueprint.py`, uno por capa del defecto.

1. **Las cabeceras `## DEC-*` entran en el registro compartido** (`defined`), en el número que EXCEDE a los bloques que ya definen ese id. Con eso, la regla de duplicados que siempre existió pasa a cubrir el ledger sin tocar la regla, y cubre también cualquier regla que se añada después. Se añade el defecto espejo que encontró la sonda: las filas del índice se recogían con `set()`, así que una fila repetida también salía 0.
2. **Invariante meta:** el linter calcula ahora su propia tabla de cobertura por familia (`family_coverage` bajo `--json`) y AVISA cuando una familia entera vive fuera del registro. Esto es lo que impide la recurrencia; el punto 1 arregla `DEC-*`, este arregla la clase.
3. **`written_to` se comprueba contra el disco**, en las dos direcciones: lo declarado existe (ERROR si una ruta no resuelve) y lo escrito está declarado (WARNING si una capa cita una decisión que su `written_to` no nombra).

**Por qué:** toda la integridad referencial de este fichero opera sobre ids declarados en bloques cercados, y `DEC-*` es la única familia cuyas entradas se escriben rutinariamente como cabecera + fila. Medido: 15 de 16 familias 100% cubiertas (315 ids), `DEC-*` con 1 bloque —el ejemplo de la plantilla— y 62 entradas invisibles. La cobertura no era del 94%: era del 94% **en silencio**, que es lo que la hizo durar. Y el sub-defecto que salió al leerlo: el bloque de `DECISIONS.md` REASIGNABA `heading_ids`, la variable de alcance global llena con las cabeceras de todo el blueprint, así que la rama "esto solo existe como cabecera" del comprobador de referencias colgantes trabajaba con 63 ids en vez de 376 y estaba muerta para todas las demás familias — una referencia a un `DOM-*` solo-cabecera daba error duro en vez del aviso previsto. Confirmado por mutación A/B sobre el mismo fixture.

**Lo que reemplaza:** una promesa de `constitution.md` que para `DEC-*` era falsa, y una advertencia en prosa de `autonomy.md` que falló cuatro veces seguidas. Cuatro fallos de la misma advertencia escrita no son información sobre quien la escribe, son información sobre la regla — el mismo razonamiento que este orquestador ya aplicó al frontmatter `tools:`.

**Consecuencia:** **es contractual y rompe estados antes válidos.** Un `blueprint/DECISIONS.md` con ids duplicados, filas repetidas o un `written_to` que apunta a un fichero inexistente pasaba el lint y ahora sale 1. El coste en lanzamientos de subagente es **cero**. La salida sobre un blueprint sano es byte a byte idéntica al baseline (verificado con `diff`). El smoke pasó de 113 a 119 casos, los seis verificados por mutación: desactivando el arreglo, los seis se ponen rojos.

---

## DEC-ORCH-006 — Una pasada de VERIFY docs-only deriva su propio ámbito

```logic
id: DEC-ORCH-006
type: decision
status: applied
date: 2026-08-16
decided_by: "Sergio"
trigger: "si una pasada de reparación no tocó código, motores/pipelines/tests/build siguen probados y lanzar las 10 lentes paga seis subagentes que no tienen nada que mirar. La regla ya estaba escrita en constitution.md ('re-run the doc<->code lenses and stop') y en next-pantalla §5.5, pero solo como prosa que el conductor debía recordar y traducir a mano a scope_to=..., así que en la práctica no corría nunca"
rejected_alternative: "un flag `docs_only` nuevo en la entrada de phase_runs[] que relajase, solo para él, la prohibición de que la entrada de cierre lleve full_set:false. Descartada por dos razones: el gate no puede contrastar ese flag contra nada objetivo (no lee changed-files.txt), así que sería el conductor autocertificándose; y el mecanismo que ya existe —full_set:false + carried_forward[]— es ESTRICTAMENTE mejor, porque obliga a nombrar de qué pasada completa se hereda cada veredicto en vez de afirmar que seis lentes no hacían falta. La otra descartada: encoger VERIFY_LENSES, que habría roto el sync .js<->.py de validate-structure.sh y cambiado `needed` para todas las unidades"
trip_wire: "el clasificador es la pieza frágil. Hoy solo cuentan como documentación las extensiones de prosa (.md/.mdx/.markdown/.txt/.rst/.adoc) y el propio árbol .orchestrator-state/; un .py/.js/.sh/.css/.sql basta para forzar la pasada completa. Si alguien amplía esa lista a extensiones que SÍ ejecutan (.json de configuración fuera del estado, .yaml de CI, .css de tokens), el derivador empezará a saltarse lentes que sí tenían algo que mirar y el fallo será silencioso en la dirección mala. Segundo trip-wire: si validate-state.py dejara de rechazar una entrada de CIERRE con full_set:false, esto pasaría de ahorro a agujero — esa prohibición es lo único que impide que una unidad cierre con 4 lentes"
supersedes: []
written_to: [.claude/workflows/verify-fanout.js, .claude/skills/next-pantalla/SKILL.md, .claude/rules/constitution.md]
affects_screens: [ninguna existente — no invalida ninguna evidencia ya escrita]
reopens: []
```

**Decisión:** cuando TODAS las rutas de `evidence/<ID>/logs/changed-files.txt` son documentación, blueprint, informe o evidencia, `verify-fanout.js` deriva su ámbito a las cuatro lentes doc↔código (`DOCUMENTARY_LENSES`) y no lanza las otras seis. No se pide y no se puede olvidar. Nunca dispara en una pasada baseline, nunca contra un `scope_to` explícito, y `# triage: full_verify` (o `args.full_verify`) lo desactiva para la pasada que se pretende de cierre.

**Por qué el conjunto derivado es `DOCUMENTARY_LENSES` y no una lista nueva:** "las lentes doc↔código" y "las lentes restringidas a herramientas de solo lectura" son los mismos cuatro agentes, y esa igualdad ya la impone fuera de banda `validate-structure.sh` contra el frontmatter `tools:` de cada agente. Una segunda lista escrita a mano sería una tercera fuente de verdad y derivaría en cuanto se re-scope una lente. El acoplamiento es deliberado.

**Por qué no puede fabricar un PASS**, que es la única dirección que importaría: devuelve `full_set:false`, y `validate-state.py` rechaza duro una entrada de CIERRE con `full_set:false`, y rechaza una no-de-cierre cuyo `lenses[]` ∪ `carried_forward[]` no cubra el set completo citando una pasada anterior genuinamente completa. El peor caso es una re-corrida desperdiciada, avisada a gritos. Nunca una unidad cerrando con cuatro lentes.

**Consecuencia:** un `blueprint/**.md` en la lista SÍ deriva — una edición de spec es el cambio más consecuente de este repositorio, no el menos, y las cuatro lentes a las que deriva son exactamente las que juzgan el código contra la spec. Una edición **contractual** sigue siendo `/reslice`, no una iteración de depurador. El clasificador se probó con 11 casos (incluidos `.css`, `.sh`, `.js`, `.sql` y `package.json`, todos → pasada completa).

---

## DEC-ORCH-007 — La racha docs-only tiene tope: el terminador que faltaba

```logic
id: DEC-ORCH-007
type: decision
status: applied
date: 2026-08-16
decided_by: "Sergio"
trigger: "el dueño pidió revisar que los VERIFY no entren en bucle infinito 'o que solo cambien texto y se lance el verify otra vez'. Tres lentes Sonnet independientes trazaron las 7 aristas que relanzan VERIFY y coincidieron: SEIS están acotadas por checkpoint.iteration (3) o total_repair_passes (12), impuestos por validate-state.py. La séptima —la pasada docs-only que introdujo DEC-ORCH-006— no consume ninguno de los dos POR DISEÑO, y grep de 'docs_only' en validate-state.py y en los schemas devolvía cero: no existía ningún otro tope. El bucle es el que la propia constitución ya nombra: una lente pide escribir en el blueprint, la escritura es docs-only, la pasada docs-only relanza esas mismas 4 lentes, y una puede pedir la siguiente escritura"
rejected_alternative: "que la pasada docs-only SÍ consuma checkpoint.iteration. Descartada porque anula entero el ahorro que motivó DEC-ORCH-006 y devuelve el problema original: gastar una de las 3 iteraciones del depurador escribiendo una frase en blueprint/logic/error.md. La otra descartada: un campo nuevo checkpoint.docs_only_streak en features.json — un contador que solo vive en un campo que el conductor debe acordarse de mantener reproduce la misma clase de fallo que obligó a mover el retry-once y la propia derivación docs-only DENTRO del workflow ('prose is not a control'). La racha se DERIVA de derived_scope, que el conductor ya está obligado a registrar en phase_runs[], así que no hay nada nuevo que recordar y no se puede gastar el presupuesto sin dejar el rastro"
trip_wire: "el tope se cuenta sobre `derived_scope:\"docs_only\"` en las entradas VERIFY de phase_runs[]. Si alguna vez el conductor deja de registrar ese campo —o si verify-fanout.js deja de devolverlo— el contador ve cero rachas y el bucle vuelve a no tener cota, en silencio. Segundo trip-wire, distinto y no cerrado aquí: al congelar checkpoint.iteration durante una racha, la guarda de frescura de changed-files.txt (que identifica la pasada solo por '# iteration:') pierde la unicidad por pasada. Con el tope en 2 la ventana es corta, pero si alguien sube el tope hay que darle a la cabecera un segundo valor que sí avance"
supersedes: []
written_to: [.orchestrator/scripts/validate-state.py, .claude/skills/next-pantalla/SKILL.md, .claude/rules/constitution.md, .orchestrator/scripts/smoke-golden-path.sh]
affects_screens: [ninguna existente — ningún proyecto tiene hoy rachas registradas]
reopens: []
```

**Decisión:** como máximo **2 pasadas docs-only consecutivas**. La tercera corre el set completo y cuesta una iteración como cualquier reparación, o la unidad va a `blocked`. `validate-state.py` cuenta la racha desde `derived_scope` en `phase_runs[]`; `DOCS_ONLY_STREAK_CAP = 2`.

**Por qué 2 y no otro número:** una pasada propaga la escritura que la lente pidió, una segunda absorbe lo que esa escritura implicó, y una tercera seguida es la firma de un bucle que se alimenta a sí mismo en vez de converger. No es una constante nueva sacada de la nada: es el mismo razonamiento que el tope de 3 del depurador, aplicado a una clase de pasada más barata.

**Lo que reemplaza:** una exención sin cota. DEC-ORCH-006 demostró que la derivación docs-only no puede fabricar un PASS —y sigue siendo cierto— pero eso es ausencia de FALSO POSITIVO, no TERMINACIÓN. Nunca contempló una cadena de pasadas consecutivas. Esta entrada cierra esa mitad.

**Consecuencia:** **es contractual.** Un `phase_runs[]` con 3 o más entradas VERIFY `docs_only` seguidas pasaba el gate y ahora sale 1 (aviso, no fallo, si la unidad ya está `accepted` — el mismo carve-out de retroactividad del resto del fichero). El smoke pasó de 122 a **124 casos**, ambos verificados por mutación: subiendo el tope a 999 el caso rojo deja de detectar.

---

## DEC-ORCH-008 — El adversario del diff: la pregunta que las diez lentes no pueden hacer

```logic
id: DEC-ORCH-008
type: decision
status: applied
date: 2026-08-16
decided_by: "Sergio"
trigger: "propuesta del dueño: 'cuando salte el develop (para reparar) lo suyo seria que hubiera 3 agentes... reparación (DEVELOP) → adversario del DIFF → arreglar → verify-fanout'. Su caso canónico, medido en su propio proyecto: 'mi arreglo no rompió nada visible, volvió inalcanzable la denegación auditada. Pasó las 10 lentes estáticas.' Es una clase de defecto que el fan-out no puede ver por construcción — las diez lentes preguntan si algo ESTÁ, ninguna puede preguntar si algo DEJÓ DE SER ALCANZABLE"
rejected_alternative: "un hook PostToolUse sobre Edit/Write. Descartado por tres límites duros y documentados del harness, no por gusto: PostToolUse NO bloquea ('the tool already ran', solo PreToolUse bloquea); los agent-hooks 'cannot spawn nested subagents', así que no pueden abanicar a cuatro; y la granularidad no encaja — PostToolUse dispara por CADA edición, no por 'la reparación terminó', que es un límite semántico que solo el conductor conoce. La otra descartada: hacerlo una fase con su lens set en validate-state.py — lo convertiría en un fan-out obligatorio con set completo, que es exactamente el generador de vueltas que su carta prohíbe"
trip_wire: "la carta es todo el diseño. Si alguna de estas cinco cláusulas se afloja, esto pasa de ahorrar vueltas a fabricarlas: (1) no es evidencia — nunca phase_runs[]/checks[]/advisory_findings[]; (2) no gasta iteración; (3) el hallazgo se pliega en la MISMA pasada, nunca abre una ronda; (4) corre como mucho UNA vez por pasada y jamás se re-invoca sobre su propio arreglo; (5) nothing_found es la respuesta esperada. Segundo trip-wire, y es medible: si alguien añade ADVERSARY_LENSES a validate-state.py 'por coherencia con los demás fan-outs', la pieza queda convertida en su contrario. Hay un caso de smoke que lo prohíbe explícitamente. Tercero: el punto de equilibrio medido es que debe cazar algo real en un 30-40% de las REPARACIONES para salir a cuenta en subagentes (4 contra los ~18 de una vuelta completa); en reloj sale a cuenta mucho antes, porque los 4 corren en paralelo y comparten prefijo de caché. Nadie lo mide todavía"
supersedes: []
written_to: [.claude/workflows/diff-adversary.js, .claude/agents/diff-adversary-regression.md, .claude/agents/diff-adversary-incomplete.md, .claude/agents/diff-adversary-unreachable.md, .claude/agents/diff-adversary-edge.md, .claude/skills/next-pantalla/SKILL.md, .claude/rules/constitution.md, .orchestrator/scripts/validate-structure.sh, .orchestrator/scripts/smoke-golden-path.sh]
affects_screens: [ninguna existente — solo pasadas de reparación futuras]
reopens: []
```

**Decisión:** en toda pasada de REPARACIÓN —nunca en el primer DEVELOP, nunca en una pasada docs-only— el conductor vuelca el diff a `evidence/<ID>/logs/repair-diff.patch` y lanza `diff-adversary.js`: cuatro agentes de solo lectura, cuatro preguntas fijas, en paralelo, entre la reparación y la prueba.

**La tercera pregunta es la razón de existir del resto.** *¿Qué ha vuelto inalcanzable, muerto o no ejecutado este diff — incluida una comprobación que antes se alcanzaba?* Ninguna de las diez lentes puede formularla: todas comprueban presencia. Una guarda de permiso que deja de evaluarse compila, pasa la suite, satisface las diez y se despliega.

**Por qué es contractual:** `validate-structure.sh` gana dos comprobaciones nuevas y un fichero requerido, así que un checkout que antes pasaba la validación de estructura —sin `diff-adversary.js`, o con uno de los cuatro agentes con `Bash`— ya no pasa.

**Lo que deliberadamente NO se hizo:** no hay `ADVERSARY_LENSES` en `validate-state.py`, y hay un caso de smoke que comprueba su ausencia. Las dos garantías que sí tiene son mecánicas: los cuatro existen, y los cuatro son de solo lectura. La tercera —"corrieron todos"— no se puede exigir sin convertirlo en fase, así que se resuelve en el retorno: `clean` solo es cierto si los cuatro RESPONDIERON y ninguno encontró nada; un adversario muerto nunca se lee como una pasada limpia. El smoke pasó de 124 a **127 casos**, los tres verificados por mutación.

---

## DEC-ORCH-009 — El listón va en el hallazgo, no en el recuento

```logic
id: DEC-ORCH-009
type: decision
status: applied
date: 2026-08-16
decided_by: "Sergio"
trigger: "el dueño, leyendo la carta que yo acababa de escribir: 'y esto no es así: debe devolver nada casi siempre. porque puede que encuentre algo pero tampoco obligar a acertar sino la realidad'. DEC-ORCH-008 formulaba su quinta cláusula como una expectativa de FRECUENCIA ('nothing_found es la respuesta esperada', 'la mayoría de las veces deberías') y el propio informe de coste añadía por el otro lado un umbral de acierto del 30-40%. Son dos cuotas apuntando en direcciones opuestas, y ambas caen sobre la RESPUESTA en vez de sobre el ESTÁNDAR"
rejected_alternative: "dejarlo como estaba argumentando que el sesgo hacia 'nada' es el conservador y por tanto el seguro. Es falso, y es el error más caro de los dos: la clase de defecto que motivó toda la pieza —una denegación auditada vuelta inalcanzable— es RARA y fácil de descartar dudando. Un adversario al que se le ha dicho que normalmente no encuentra nada tiene un motivo escrito para callarse justo en el caso para el que existe. La otra descartada: convertir el 30-40% en objetivo del agente — fabricaría hallazgos, que es el fallo simétrico"
trip_wire: "cualquier frase futura en estos ficheros que hable de CUÁNTAS veces debe encontrar algo —en cualquiera de las dos direcciones— reintroduce el defecto. La formulación correcta se reconoce por dónde cae el listón: sobre el hallazgo (concreto, falsable, causado por ESTE diff), nunca sobre el número. Segundo trip-wire: el umbral de rentabilidad del 30-40% sigue siendo real y sigue sin medirse, pero es una pregunta del DUEÑO sobre si la pieza compensa, no una instrucción al agente; si alguna vez aparece dentro de un prompt, se ha cruzado la línea"
supersedes: [DEC-ORCH-008]
written_to: [.claude/workflows/diff-adversary.js, .claude/agents/diff-adversary-regression.md, .claude/agents/diff-adversary-incomplete.md, .claude/agents/diff-adversary-unreachable.md, .claude/agents/diff-adversary-edge.md, .claude/skills/next-pantalla/SKILL.md, .claude/rules/constitution.md]
affects_screens: [ninguna]
reopens: []
```

**Decisión:** la quinta cláusula de la carta deja de ser *"`nothing_found` es la respuesta esperada"* y pasa a ser **el listón va en el hallazgo, no en el recuento**. `nothing_found` es una respuesta completa y correcta; un hallazgo real también. Ninguno de los dos es el objetivo, y no se espera ninguna tasa. Lo que un hallazgo debe superar es el listón: concreto, falsable y causado por ESE diff.

**Por qué es una corrección y no un matiz.** Una expectativa de frecuencia no informa al agente sobre su trabajo: le da un número que gestionar. Y las dos direcciones fallan distinto. *"Casi siempre nada"* **suprime**, y suprime precisamente la clase rara para la que se construyó la pieza — un revisor que ya sabe cuál es la respuesta normal encuentra siempre una razón para dudar de la anormal. *"Debes acertar un 30-40%"* **fabrica**. Ninguna de las dos habla del diff, que es lo único que el adversario tiene delante.

**Lo que NO cambia:** las otras cuatro cláusulas siguen intactas, y la protección contra el ruido tampoco se toca — sigue prohibido el estilo, el nombrado, la preferencia, la cobertura de tests que nadie pidió y los diseños alternativos. Lo que se quita no es la exigencia, es la cuota: la exigencia pasa de *"cuántos"* a *"cuál"*.

**Sobre el 30-40%:** sigue siendo el punto de equilibrio real (4 agentes contra los ~18 de una vuelta completa) y sigue sin medirse. Pero es una pregunta del dueño sobre si la pieza compensa, **nunca una instrucción al adversario** — el día que ese número aparezca dentro de un prompt, esta decisión se ha revertido sin que nadie lo note.

---

## DEC-ORCH-010 — Un hallazgo es una instancia de una clase, no un punto

```logic
id: DEC-ORCH-010
type: decision
status: applied
date: 2026-08-16
decided_by: "Sergio"
trigger: "diagnóstico del dueño, literal: 'cuando una lente encuentra un defecto, nada dice «esto es una INSTANCIA de una clase — busca las demás». Cada hallazgo se trata como un punto. Así que reparo la instancia, la lente encuentra la siguiente en la vuelta siguiente, y parece que «siempre aparece algo» cuando en realidad es el mismo algo tres veces.' Verificado contra el repo: la lección ya estaba aprendida TRES veces y generalizada NINGUNA — el reordenado de la cosecha ('piecemeal never converges'), la gradación de severidad de verify-coherence ('a flat major on every omission is what made this lens unable to converge') y el traslado de lo mecánicamente decidible al STATE GATE. Tres parches locales, una sola forma"
rejected_alternative: "seguir parcheando por caso, que es lo que llevaba haciéndose. Y una segunda, más tentadora: dejarlo como regla en prosa sin mecanismo — descartada porque este repo ya ha demostrado tres veces que sabe enunciar la lección y aun así no la aplica fuera del caso donde la aprendió; 'buscar las demás instancias' es además una tarea de BÚSQUEDA, que es exactamente lo que un subagente hace bien y barato"
trip_wire: "la frontera es lo único que separa esto de una refactorización del repositorio, y es estructural, no de criterio: el scan busca SOLO en el mapa de aceptación de plan.md, en los changed-files de esta pasada, y en el módulo del hallazgo citado si ya está en ese ámbito. Si alguna vez se amplía a 'todo el repo', o si un miembro out_of_scope se repara dentro del diff activo en vez de emitirse como SCR-FIX-CLASS-*, la disciplina de unidad activa queda rota. Segundo trip-wire: si el ámbito del scan se limita a código y deja fuera blueprint/**, no generaliza el caso que lo motivó (la cosecha de shell.md, que es puramente documental) y quedan dos mecanismos paralelos en vez de uno. Tercero: una afirmación de clase sin `matches_check` re-ejecutable por miembro es un parecido, no una clase, y barrer sobre un parecido edita ficheros que no compartían la causa"
supersedes: []
written_to: [.claude/agents/repair-class-scan.md, .claude/rules/constitution.md, .claude/rules/conventions.md, .claude/skills/next-pantalla/SKILL.md, .orchestrator/scripts/validate-structure.sh, .orchestrator/scripts/smoke-golden-path.sh]
affects_screens: [ninguna existente — solo pasadas de reparación futuras]
reopens: []
```

**Decisión:** antes de escribir el cambio de producto, el conductor lanza `Agent(repair-class-scan)` sobre el hallazgo: cuál es la causa raíz, dónde más se da, y con qué comprobación re-ejecutable se confirma cada miembro. Todos los miembros dentro del ámbito se reparan **en esa misma pasada**.

**No añade un cuarto paso a la reparación.** Hace que el paso 1 signifique *cerrar la clase en la superficie acotada* en vez de *arreglar la línea citada*; propagación y prueba quedan igual.

**La frontera, que es lo que hace esto viable:** el scan busca solo en lo que la unidad ya declaró. Un miembro fuera de esa superficie es real y se registra, pero **nunca entra en el diff activo** — sale como `SCR-FIX-CLASS-*`, el mismo exit que `/verify-app` y `/audit-motores` ya usan para un defecto fuera de su alcance.

**Aritmética.** Punto de equilibrio en **N≥2**: con el defecto actual, una clase de N instancias cuesta N vueltas (~12 subagentes cada una más la cola); con el scan cuesta 1 vuelta más 1 agente, plano para cualquier N. El impuesto sobre un hallazgo genuinamente puntual (`class_size: 1`) es **+1 subagente**. Para N=9 —el número que el dueño midió en un proyecto real— la diferencia no es de coste sino de convergencia: hoy agota el tope de 3 iteraciones sin terminar.

**Lo que NO se toca, y es deliberado:** ni `checkpoint.iteration` (3) ni `total_repair_passes` (12) ni el tope de racha docs-only (2) se bajan. La métrica a vigilar es cuántas veces se ALCANZA el tope, no su valor, y bajarlo antes de medir repetiría el error que originó todo esto: fijar una cifra por intuición. La frecuencia real de "hallazgo = clase" **no se sabe** — hay que instrumentarla, no suponerla.

---

## DEC-ORCH-011 — El límite de la unidad deja de ser prosa

```logic
id: DEC-ORCH-011
type: decision
status: applied
date: 2026-08-16
decided_by: "Sergio"
trigger: "el dueño enuncia el requisito en dos mitades: 'lo que no quiero es que arregle cosas que no toca de la unidad, y que arregle lo que las lentes del verify encuentren y cosas más que pueda que en el siguiente verify encuentre'. La segunda mitad ya estaba (tabla de §3, class scan, adversario). La primera estaba escrita en tres sitios y comprobada en NINGUNO: `changed_files` no aparecía ni una vez en validate-state.py, y ninguna lente contiene forma alguna de 'out of scope' / 'not in the plan' / 'unrequested' — verificado por grep antes de escribir nada"
rejected_alternative: "(a) dejarlo en prosa, argumentando que el scan es read-only y no puede ensanchar por sí mismo — falso consuelo: el scan no escribe, pero ENTREGA al conductor un out_of_scope[] de defectos reales y confirmados, que es exactamente la tentación que antes no existía. (b) hacerlo FALLAR el cierre: la autoridad es la columna 'ficheros a tocar' de plan.md, escrita en prosa antes de que el código exista; un fichero legítimo que no anticipó (una util compartida, una migración, un cliente generado) tumbaría una unidad correcta, y un gate que hace eso se aprende a rodear, llevándose por delante la señal buena"
trip_wire: "la asimetría que esto corrige es estructural y puede volver: TODO el aparato (10 lentes, plan_delivery[], plan_deviations[]) pregunta si lo PROMETIDO se entregó, y este aviso es lo único que pregunta si se entregó DE MÁS. Si alguna vez se silencia, se convierte en fail, o se le añaden exenciones más allá de la propagación obligatoria (blueprint/**, blueprint-templates/**, design/**, .orchestrator/**, .orchestrator-state/**), la mitad que falta vuelve a faltar. `.claude/**` NO está exento a propósito, el mismo carve-out que hace el clasificador docs-only: un fichero de agente es la definición de comportamiento de una lente, no documentación"
supersedes: []
written_to: [.orchestrator/scripts/validate-state.py, .claude/skills/next-pantalla/SKILL.md, .orchestrator/scripts/smoke-golden-path.sh]
affects_screens: [ninguna existente — solo pasadas futuras]
reopens: []
```

**Decisión:** `advise_unit_scope()` compara `changed-files.txt` contra los ficheros que el `plan.md` de esa unidad declara, y **avisa** de los que no salen en ninguna parte del plan. Nunca falla. Se salta las unidades ya `accepted` (su evidencia es historia) y calla cuando falta cualquiera de los dos ficheros — antes de EXPLORE, o en una pasada baseline sin ámbito en disco, no hay nada que comparar.

**Por qué avisa y no bloquea, que es la parte que hace que se lea:** un aviso que salta sobre trabajo correcto se aprende a ignorar, y con él se va la señal verdadera. Por eso la comparación es **generosa a propósito** — vale la ruta exacta, un directorio que el plan nombró, o el basename suelto (`notas.js` en el plan contra `web/notas.js` en git son el mismo fichero, y acertar ahí importa más que cazar una colisión).

**La propagación está exenta porque es obligatoria**, no porque sea tolerable: el paso 2 de una reparación barre los hechos de `blueprint/` / `shell.md` / `stack.md` que el cambio implica. Marcarla dispararía en toda reparación correcta.

**Por qué justo ahora.** `DEC-ORCH-010` existe para hacer una reparación MÁS ANCHA. Darle un acelerador y dejar su límite en prosa es la forma exacta de fallo que este repo ya ha pisado varias veces, y que él mismo enuncia: *prose is not a control*.

**Corrección de un hecho que yo tenía mal:** no existe ningún `--preflight` en `validate-state.py` (lo tenía anotado y era falso). El pre-flight real es `preflight-check.sh`, bash, lint+build, y corre **antes** de que `changed-files.txt` exista. De ahí que el aviso viva en la corrida normal del gate: no hay flag que se pueda olvidar, y siendo advisory no puede romper ninguna corrida existente.
