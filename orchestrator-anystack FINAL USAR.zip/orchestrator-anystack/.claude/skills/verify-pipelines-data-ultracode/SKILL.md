---
name: verify-pipelines-data-ultracode
description: "Deep verification and safe correction of pipelines and data for one screen/unit: UI-visible data, API/service flow, jobs/providers/cache, persistence, transformations, migrations and logs. Runs AUTOMATICALLY inside /next-pantalla after REVIEW (with --fix, sweeps on Sonnet); can also be re-run manually before /accept."
argument-hint: <screen-id|slug|name> [--fix|--report-only]
disable-model-invocation: true
model: sonnet
effort: xhigh
---

# /verify-pipelines-data-ultracode

Run inline in the current main session. This is the deep gate for pipeline and data correctness. It runs **automatically** as part of every `/next-pantalla` (§5.5, with `--fix`) and may also be invoked manually. It may use Claude Code Ultracode/dynamic workflows when available; otherwise run the same protocol inline with the existing agents.

`disable-model-invocation: true` above forbids the *harness* from spawning this skill as a separate agent — it does not forbid the conductor from running it. On the §5.5 auto-launch you get here by `Read`ing this file and following it inline with `$ARGUMENTS = "<ID> --fix"`; never by calling the `Skill` tool.

Arguments: `$ARGUMENTS`

Default mode is report-only. Repair only when `$ARGUMENTS` contains `--fix` (the auto-launch from `/next-pantalla` always passes `--fix`).

**Model:** spawn every subagent/workflow this gate uses with `model: 'sonnet'` — the sweep is Sonnet-tier by design; the conductor remains the single writer.

## 0. Safety boundary

Use local/dev/test environments unless the user explicitly authorizes another target. Never run destructive data changes against production. For real data correction, prefer idempotent migrations, seeds, backfills, repair scripts and dry-run reports before applying changes.

If a production data repair is required, stop with `BLOCKED`, write the safe plan, and require human approval outside this skill.

## 1. Rehydrate and resolve

1. Read `CLAUDE.md`, `.claude/rules/*.md`, `.orchestrator-state/spec.md`, `.orchestrator-state/features.json` and `.orchestrator-state/progress.md`.
2. Resolve the target from `$ARGUMENTS` by exact ID first, then slug/title/name. If ambiguous, list candidates and stop.
3. Read the selected feature entry, `acceptance[]`, `applies[]`, `verify.data_checks[]`, routes, platforms, implementation notes and evidence path.
3b. Read `.orchestrator-state/evidence/<ID>/result.json`'s `verify_digest` when present — `observed_values` (`db_value`/`api_value`), `findings[]` and `source_refs[]` the VERIFY synthesizer already established for `verify-engine`/`verify-pipeline`. Treat every relevant item the same way `pantalla-reviewer` does: confirm it by citing the same evidence, extend it with what only a live/deep pass can see, or refute it with your own command + literal output + artifact. This is a starting map, never a substitute for building your OWN pipeline map (§3) and single-value matrix independently.
4. Read cited `DATA-*`, `INT-*`, `APP-*`, `DOM-*`, `ST-*`, `PERM-*`, `ERR-*` and `UC-*` logic.
5. Read project commands from `.claude/rules/stack.md`.
6. Run `python3 .orchestrator/scripts/validate-state.py`.

If the unit has no data or pipeline contract, write `NOT_APPLICABLE` and do not invent DB/API checks.


If the unit cites `DATA-*`, has `verify.data_checks[]` or has `data_engine`, this skill is applicable and must prove the canonical value chain.

## Status guard (before any `--fix` edit and before writing any verdict)

Read the target's `status` from `.orchestrator-state/features.json` and branch:

- `accepted` -> run read-only even with `--fix`; recommend `/reslice` if the accepted contract must reopen. Never edit code or data under an accepted unit.
- `verified` -> its `result.json` is a PASS on the CURRENT code. A FAIL verdict or any `--fix` repair makes that evidence stale, and the STATE GATE rejects `verified` with `passes:false` and rejects a `verified` unit whose evidence verdict is not `PASS`. So do NOT write the FAIL or touch code first: reopen the unit through the protocol below, then fix. Never leave a failing or edited unit sitting at `verified`.
- `building` -> this is the normal auto-launch from `/next-pantalla` §5.5, or the conductor already owns the unit. Do NOT reopen: record the failing check and continue; a fix here is a debugger pass (`/next-pantalla` §5.5 and §6 — increment `checkpoint.iteration`, re-run VERIFY, and VALIDATE when runtime behavior changed).
- any other status -> report-only.

### Reopen protocol (`verified` -> `building`)

Follow the protocol in `constitution.md` §Minimal lifecycle (the reopen path and its two counters:
`checkpoint.iteration` per episode, cap 3; `total_repair_passes` lifetime, cap 12; at either cap
set `blocked` instead of reopening). This skill may use it only in the two cases above — checks
FAIL, or a `--fix` repair — and only on a manual re-run. What is specific to this skill:

1. In `result.json`: `verdict:"FAIL"`, `CHK-<ID>-PIPELINES-DATA-ULTRACODE` with
   `required:true, passed:false`, and the matching entry in `failures[]`.
2. Append `REOPENED <ID> (verify-pipelines-data-ultracode FAIL)` — or
   `(verify-pipelines-data-ultracode --fix)` when the reopen is for a repair — to
   `.orchestrator-state/progress.md`.
3. Run `python3 .orchestrator/scripts/validate-state.py`: it must pass in the reopened state.
4. Stop with `Next: /next-pantalla <ID>`. Its §6 debugger owns the repair and the
   re-VERIFY/re-VALIDATE; this skill does not.

Reopening drops the unit from the `verified_awaiting_accept` queue in `status.json`. That is
intended: the PASS no longer describes the code on disk.

## 2. Prefer Claude Code Ultracode

When Claude Code supports dynamic workflows and the user/session allows them, use a workflow-style audit for this exact unit. The task must be scoped like this:

```text
ultracode: verify pipelines and correct data for <ID> / <title>.
Scope: one orchestrator unit only.
Phases: map schemas, migrations, seeds, APIs, workers, providers, cache, UI-visible data; verify real pipeline execution; verify API/DB consistency; detect data drift; apply safe repairs only if --fix is present; write final evidence.
```

If Ultracode/workflows are unavailable, disabled or denied, run the same phases inline with the `explore-*` lens-agents, the `verify-engine`/`verify-pipeline` agents (static engine/pipeline proof) and the `validate-*` agents (live data check on the real UI). Record `inline-fallback` in the report. Do not fail only because workflow mode is unavailable.

Do not assume an external binary named `ultracode`. In this orchestrator, Ultracode refers to Claude Code's workflow/deep-orchestration mode unless `.claude/rules/stack.md` explicitly defines another trusted local command.

## 3. Build the pipeline map


The pipeline map must start from the compiled data engine, not from implementation guesswork.

First identify the architecture (AnyStack) from `data_engine.canonical_store.kind` and the cited logic, and adapt the map: relational/document DB (tables/collections), event sourcing (event log + projections/read models), stateful/LangGraph (persisted graph state + checkpointer + transitions), or external system of record (`INT-*` authoritative resource + sync/cache). Verify the canonical store for that architecture — do not assume SQL.

Before running checks, produce a grounded pipeline map:

```text
screen_id:
architecture: relational | event_sourcing | stateful_langgraph | external_sor | mixed
canonical store + resources:
visible data fields:
write actions / commands / transitions:
read endpoints/queries / projections:
backend use cases/services / graph nodes:
persistence (tables/collections/streams/state/checkpoints):
cache/search/projection/read-model layers:
external providers/jobs:
permission filters:
state transitions:
error cases:
expected invariants:
```

Every line must come from blueprint, code, schema, route/API discovery, logs or existing runtime behavior.


Also produce a single-value matrix:

```text
engine_ref | db_resource.field | generated_db_value | api/service field/value | frontend/mobile field/value | match
```

A mismatch blocks `PASS` even if tests are green.

## 4. Verify with real systems

Required proof when applicable:

- API request/response for reads and writes;
- service/use-case path observed by test, log or trace;
- persistence query before/after mutation;
- cache/search/projection invalidation or explicit non-use;
- permission-scoped query/result check;
- state transition check;
- clean backend/database/provider logs;
- UI-visible data equals API and persistence truth.

- the database contains the canonical value generated by the declared pipeline;
- every frontend/platform reads that value through the declared API/service/read model, not from local constants or duplicated fixtures.

Do not use fake data as acceptance proof unless the blueprint explicitly defines a prototype/mock unit.

## 5. Correct data or pipeline defects

If `--fix` is absent, do not change product code or data.

If `--fix` is present, apply the Status guard first, then repair only selected-scope defects whose expected behavior is clear:

- API/client contract mismatch;
- DTO/schema mapping;
- query filters, joins, ordering, pagination or tenancy/permission predicates;
- migration or schema mismatch;
- local seed/test fixture needed for verifiable data;
- cache/projection invalidation;
- state machine transition or error mapping;
- focused tests that fail on the defect.

Data correction is limited to local/dev/test data or migration/seed/backfill code. Maximum 3 repair iterations.

## 6. Evidence output

Create or update:

```text
.orchestrator-state/evidence/<ID>/reports/pipelines-data-ultracode.md
.orchestrator-state/evidence/<ID>/db/pipelines-data-check.txt
.orchestrator-state/evidence/<ID>/logs/pipelines-data-backend.txt
.orchestrator-state/evidence/<ID>/traces/pipelines-data-trace.json
```

**A finding that does not block is RECORDED, not repaired.** Classify every finding you raise:
one that breaks the data contract — a value that does not match across layers, a pipeline that
does not run, fabricated data — is **blocking** and goes to `failures[]`/`checks[]` as always. One
that does not (a missing index that costs nothing at this volume, a log line that could be
clearer, a naming inconsistency) goes to `result.json.advisory_findings[]` as
`{id, severity, source:"verify-pipelines-data-ultracode", detail, refs, status:"open"}` — and then
you leave it alone. Do not fix it, do not open a repair pass for it, do not fail a check with it.

This is what keeps the loop finite. A finding used to have exactly one way to be discharged — fix
it — so a finding of any size forced a repair, the repair produced new surface, and the next round
found something in that surface. Measured on a real run: more than half the debugger rounds did
not fix code, they fixed the trail. `advisory_findings[]` is carried forward, `/accept --auto`
weighs its severity against the ceiling in `.claude/rules/autonomy.md`, and a human reading the
evidence sees it named. `verified` still requires `verdict:"PASS"` with `failures` empty, and the
gate rejects a finding marked `accepted_as_debt` that also sits in `failures[]`: one or the other,
never both. Recording debt is not lowering the bar; pretending the debt was never found is.

Merge a check into `.orchestrator-state/evidence/<ID>/result.json`:

```json
{
  "id": "CHK-<ID>-PIPELINES-DATA-ULTRACODE",
  "name": "Ultracode pipeline and data verification",
  "type": "pipeline_data_verification",
  "required": true,
  "passed": true,
  "acceptance_ids": [],
  "artifacts": [".orchestrator-state/evidence/<ID>/reports/pipelines-data-ultracode.md", ".orchestrator-state/evidence/<ID>/db/pipelines-data-check.txt"],
  "notes": "Data shown by the screen matches API/service/persistence truth."
}
```


Also add `data_engine_assertions[]` to `result.json`, carrying the observed literal value at each layer (the validator recomputes `same_value` from them):

```json
{
  "id": "DE-SCR-001-001",
  "engine_refs": ["DATA-001", "APP-001", "UC-001"],
  "canonical_store": "the declared system of record (db | event_store | state_store | external_system)",
  "db_value": "<observed canonical value>",
  "api_value": "<observed API/read-model value>",
  "ui_value": "<observed client value>",
  "platform_values": { "web": "<value>", "android": "<value>", "ios": "<value>" },
  "db_evidence": ".orchestrator-state/evidence/SCR-001/db/pipelines-data-check.txt",
  "api_evidence": ".orchestrator-state/evidence/SCR-001/traces/pipelines-data-trace.json",
  "ui_evidence": ".orchestrator-state/evidence/SCR-001/screenshots/success.png",
  "same_value": true,
  "notes": "Same canonical value across store, read model and client."
}
```

`same_value:true` is rejected by the validator unless every observed literal (`db_value`/`api_value`/`ui_value` plus any `platform_values`) is present and equal. Aliases `source_value`/`transport_value`/`client_value` are accepted for non-DB stacks.

If checks fail, record the check as `passed:false` and list the exact failing invariant, reproduction and fix hint, then close per the Status guard:

- unit `building` -> leave `verdict:"FAIL"`, `passes:false` and the failing check for the conductor; it is a debugger pass, not a reopen.
- unit `verified` -> run the reopen protocol so the FAIL lands on a `building` unit. Never write `status:"verified"` with `passes:false` or with `verdict:"FAIL"`: the STATE GATE rejects both, so the run would invalidate the state it just wrote.

If checks are not applicable, record `required:false`, `passed:true` with `notes:"not applicable"`.

## 7. Close

Run the smallest relevant verification commands, then:

```bash
python3 .orchestrator/scripts/validate-state.py
bash .orchestrator/scripts/validate-structure.sh
```

Append `VERIFY_PIPELINES_DATA_ULTRACODE <ID>` to `.orchestrator-state/progress.md`.

Print:

```text
Pipelines/data Ultracode: PASS|FAIL|BLOCKED|NOT_APPLICABLE
Mode: ultracode|inline-fallback
Report: .orchestrator-state/evidence/<ID>/reports/pipelines-data-ultracode.md
Next (manual run): /production-code-review <ID> or /review-pantalla <ID> or /accept <ID>
Next (auto-launch from /next-pantalla): continue with /production-code-review <ID> --fix per §5.5
```

Never move a screen to `accepted`.
