---
name: build-loop
description: "Ralph-style batch runner: build every currently-ready unit one at a time, each with the FULL /next-pantalla pipeline, stopping at the first blocked unit or when nothing is ready. Never accepts. With --autonomous it also runs the outer loop: auto-accept by policy, run the cross gates, absorb the SCR-FIX-* units they emit, repeat until convergence or budget."
argument-hint: "[max-units] [--autonomous]"
disable-model-invocation: true
model: inherit
effort: xhigh
---

# /build-loop

Run inline in the current main session. You are `orchestrator-flow`: the single writer. This is the outer **Ralph loop** around `/next-pantalla`: the durable state lives on disk (`features.json`, evidence, checkpoint), every iteration is idempotent and rehydrates from disk, and the loop has hard stop conditions — so iterating converges instead of drifting.

Arguments: `$ARGUMENTS` (optional: maximum number of units to build in this batch)

## Loop

Repeat, one unit at a time — **never two in parallel** (`validate-state.py` enforces `building <= 1`):

1. **Rehydrate + gate.** Run `python3 .orchestrator/scripts/validate-state.py`. Recompute `ready` exactly as `/next-pantalla` step 1 does (a `todo` unit whose `after[]` are all BUILT — `verified` or `accepted` — becomes `ready`). This is why the loop can chain a whole product without accepting anything. Read from disk, not chat memory.

   **Rehydrate the BATCH too, not just the state.** Read `.orchestrator-state/batch.json` (schema `orchestrator.batch.v1`, `.orchestrator/schemas/batch.schema.json`). If one exists with `status:"running"`, you are RESUMING it: keep its `run_id`, `max_requested` and `units_built[]` and continue counting from there. Otherwise start a new one with `status:"running"`, `mode:"build-loop"`, `started_at`, `run_id` and the `$ARGUMENTS` cap in `max_requested`. Write it before building anything.

   This exists because the batch's own progress was the one thing the orchestrator kept only in chat. `features.json` records what each UNIT reached; nothing recorded what the BATCH had done — so after a compaction `/build-loop 5` could not tell it had already built 3, and would happily build 5 more. The unit was resumable and the loop around it was not.

   `validate-state.py --emit-status` does NOT write this file: it owns `status.json` and `evidence/index.json`, which are projections of the plan. This one is the loop's own state, so the loop writes it. Also read `status.json.promotable_todo` — if it is non-empty while nothing is `ready`, promotion was missed and "nothing ready" does not mean "nothing left".
2. **Stop conditions — check BEFORE building:**
   - no `ready` unit left → stop with the batch summary;
   - the previous iteration ended `blocked` AND no independent `ready` unit remains → stop with the batch summary. A blocked unit never gets retried or worked around, but it does not cancel its independent siblings: skip it, keep its `blocked_reason` in the summary, and continue with the units that do not depend on it. Stopping the whole wave for one unanswered product question wastes the rest of the batch;
   - `$ARGUMENTS` max reached → stop with the batch summary;
   - the state gate fails → stop and report; never build on a broken base.
3. **Iterate.** Execute the FULL `/next-pantalla` procedure (its SKILL.md end to end: RESEARCH → EXPLORE → DEVELOP → VERIFY → VALIDATE → REVIEW → auto-gates, with CLARIFY, checkpoint, phase pushes and the debugger cap) for the `ready` unit with the lowest `order`, **invoking it with that explicit ID** (`/next-pantalla <ID>`). Passing the ID is required, not cosmetic: without it the procedure stops on the first `verified` unit the loop itself produced. No batch shortcut exists: skipping a phase or a lens to "go faster" makes the unit un-`verifiable` at the gate anyway.
4. **After the unit reaches `verified`:** run `python3 .orchestrator/scripts/validate-state.py --emit-status`, append a `BUILD_LOOP` line to `progress.md`, update `batch.json` (`units_built[]`, `budget_consumed`, `updated_at`; a unit that blocked goes to `units_blocked[]` with its reason), and continue the loop.

   When the loop stops for any of the reasons in step 2, write `status:"stopped"`, `ended_at` and the matching `stop_reason` (`no_ready` | `blocked` | `max_reached` | `gate_failed`) before printing the summary. The stop output below is then a RENDERING of `batch.json`, not a separate account of the run assembled from memory — which is what makes the summary survive a compaction that lands between the last unit and the report.

CLARIFY during a loop iteration follows *Think first, then ask* (`next-pantalla` §Cross-cutting): resolve it from the sources, then from `.claude/rules/autonomy.md`, and only then ask. In an interactive session ask the human and persist the answer to `blueprint/**`. If the question is Tier 3, or the policy does not cover it and nobody answers, the unit goes `blocked` with the exact question and the loop continues with its independent siblings.

Under `--autonomous` nothing about this relaxes — that is the point. A Tier-3 question blocks; it is never guessed to keep the loop moving. A run that stops with one precise unanswered question, having built everything that did not depend on it, is the intended outcome.

## Autonomous mode (`--autonomous`)

Without this flag everything above is unchanged: build until nothing is ready, never accept, stop. `--autonomous` adds the OUTER loop — the one that was missing, and the reason a "full product" run still needed a human between every wave.

Read the budget from `$ARGUMENTS`, or from `.claude/rules/autonomy.md`'s **Autonomous-run budget** when the invocation names none. Record it in `batch.json.budget` and set `mode: "build-loop --autonomous"`.

**Refuse to start on an unresolved policy.** Before the first round, check `.claude/rules/autonomy.md` for unresolved `<PLACEHOLDER>` tokens in the **Autonomous-run budget** and **Auto-accept policy** sections. If any remain, stop with `stop_reason: "clarify_needed"` and say which — an unfilled budget is not "unlimited", it is "nobody chose", and starting an unattended run on it is how a loop with no ceiling gets launched by accident. Same reasoning as `/accept --auto` step 3b, and the STATE GATE enforces the acceptance half independently.

```text
repeat:
  1. BUILD    — the inner loop above until no ready unit remains
  2. ACCEPT   — for each `verified` unit in after[] order: /accept <ID> --auto
                (inline: Read .claude/skills/accept/SKILL.md and follow it)
                units the policy does not cover stay `verified` on the review queue
  3. GATES    — an acceptance that completed a JOUR-* triggers /verify-app + /audit-motores
                automatically, as accept step 8/9 already specifies. Their SCR-FIX-* units
                land in blueprint/SCREENS.md
  4. ABSORB   — /accept step 9b already runs /reslice inline whenever a gate emitted
                SCR-FIX-*, so by the time control returns here the units are normally
                already compiled into features.json and round 1 picks them up next pass.
                This step is now the CHECK, not the mechanism: re-read
                meta.verify_app.emitted_fixes[]/meta.audit_motores.emitted_fixes[] and
                confirm each emitted id exists in features.json. If any is missing —
                accept stopped on a CLARIFY, or the run was interrupted between the two —
                run /reslice inline here to finish the job.
                Absorbing used to live ONLY here, which is why the ordinary (non-autonomous)
                path silently never compiled its repair units: the unattended loop worked
                and nobody noticed the attended one did not.
                /reslice MAY STOP AND ASK — its step 4 requires CLARIFY before changing
                scope, deleting accepted work, changing IDs or breaking dependencies.
                Compiling a new SCR-FIX-* does none of those, so the normal path needs
                nobody. But if this /reslice does raise a CLARIFY, that is a Tier-3
                question: do NOT answer it to keep the loop alive. Record it, stop the
                round with stop_reason "clarify_needed", and leave the emitted units in
                `todo` — they are not lost, they are waiting
  5. RECORD   — append the round to batch.json.rounds[], refresh telemetry
  6. STOP?    — see below; otherwise loop
```

**Stop conditions, checked at the top of every round.** Write the matching `stop_reason` to `batch.json`:

- `no_new_units` — `max_rounds_without_new_units` consecutive rounds (default 2) built nothing, accepted nothing and emitted nothing. This is CONVERGENCE, the normal ending;
- `budget_exhausted` / `wall_clock_exhausted` — a `batch.json.budget` ceiling reached;
- `max_reached` — the `$ARGUMENTS` cap;
- `clarify_needed` — every remaining unit is blocked on a Tier-3 question. Stop and ask; do not guess to keep the loop alive. A loop that reaches this has done its job — it built everything that did not need you;
- `gate_failed` — the STATE GATE failed. Stop immediately; never build on a broken base.

Requiring TWO empty rounds rather than one is deliberate: a single round can be empty because everything was waiting on an accept that the same round just performed. Stopping there would leave work that was about to become ready.

**Telemetry.** Keep `batch.json.telemetry` current: `units_auto_accepted`, `units_left_for_human[]`, `journeys_closed[]`, `wall_clock_elapsed_minutes`, and `subagents_spawned_estimate` — computed for REAL, not guessed. Every unit's `result.json.subagents_spawned` is already a real count (`next-pantalla` SKILL.md, "Tally real subagent launches" — summed live from what each fan-out actually returned: loader + lenses run + retries + scout/synth where they exist). After each unit in step 4, ADD its `result.json.subagents_spawned` to the running `batch.json.telemetry.subagents_spawned_estimate` instead of leaving it at 0 or re-deriving a static guess. The field name stays `_estimate` (the schema's, unchanged) because a subagent's own token spend still is not directly observable — but the LAUNCH COUNT this now reports is exact, not the 45-60/120-160 heuristic, which remains useful only for sizing `budget.max_subagents` before a run starts, never for reporting what one actually cost.

**What autonomy does NOT do.** It never lowers a bar. Every unit still runs the full pipeline with complete lens sets, still earns real evidence, still passes the STATE GATE, and still faces the same `/accept` preconditions. It never decides a Tier-3 question. And it never accepts a unit in a sensitive area — those wait for you no matter how green they are. The output of a good autonomous run is a built product **and** a short, precise list of what needs your eyes.

## Hard rules

- **Never `/accept` — except under `--autonomous`, and then only via `/accept <ID> --auto`.** Plain `/build-loop` produces a batch of `verified` units and promotes nothing. Under `--autonomous` the acceptance authority is unchanged (`/accept` is still the only path to `accepted`, with the same preconditions and the same STATE GATE); what the flag changes is that a written policy may invoke it for the units that policy covers. Everything else stays `verified` for a human.
- Compaction mid-loop is safe by design, at BOTH levels: the active unit's `checkpoint` records phase + iteration, and `batch.json` records the batch's own cap and progress. After compaction (or a crash), re-running `/build-loop` resumes the in-flight unit from its checkpoint AND the batch from its file, instead of restarting either. The `PreCompact` hook (`.claude/hooks/precompact-checkpoint.sh`) refreshes the projections and surfaces both anchors as a best-effort `systemMessage` before the summary happens. It does NOT inject them into the post-compaction context — no PreCompact hook can, the event supports no such field — so what makes a batch survive is that `batch.json` is on disk and you re-read it, not that the hook printed anything.
- **Answer CLARIFY to disk before you act on it.** The checkpoint is phase-grained, so an answer given in chat and not yet written into `blueprint/**` is the one thing a compaction can still destroy — the window is small and it is real. This is the standing write-before-act rule (`constitution.md`, Blueprint write-back), and a long unattended loop is where it gets tested.
- If the session's harness offers `/goal` or `/loop`, they may WRAP this skill (e.g. "keep running /build-loop until nothing is ready") — optional sugar, never a replacement for the stop conditions above.

## Stop output

Rendered from `batch.json`, never reassembled from memory:

```text
Batch: <n> units built this run          (stop reason: <stop_reason>)
Verified awaiting accept: <IDs>
Blocked: <ID + exact question/next action, or none>
Remaining (todo, waiting on accepts): <IDs>
Next: /accept <first verified ID>   (then /build-loop again to continue the wave)
```

Under `--autonomous`, add what the outer loop did — otherwise the one thing the human must act on is buried under the ninety things they do not:

```text
Rounds: <n>                              (stop reason: <stop_reason>)
Auto-accepted: <IDs>
NEEDS YOU — verified, not auto-acceptable: <ID: reason>   <- the review queue
NEEDS YOU — blocked on a product decision: <ID: the exact question>
Emitted by gates: <SCR-FIX-* IDs and what they repair>
Cost: ~<n> subagents, <n> min wall clock
```
