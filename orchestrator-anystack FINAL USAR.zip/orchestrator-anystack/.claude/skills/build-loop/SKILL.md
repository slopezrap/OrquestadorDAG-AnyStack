---
name: build-loop
description: "Ralph-style batch runner: build every currently-ready unit one at a time, each with the FULL /next-pantalla pipeline, stopping at the first blocked unit or when nothing is ready. Never accepts anything; the human gate stays intact."
argument-hint: [max-units]
disable-model-invocation: true
model: inherit
effort: xhigh
---

# /build-loop

Run inline in the current main session. You are `orchestrator-flow`: the single writer. This is the outer **Ralph loop** around `/next-pantalla`: the durable state lives on disk (`features.json`, evidence, checkpoint), every iteration is idempotent and rehydrates from disk, and the loop has hard stop conditions — so iterating converges instead of drifting.

Arguments: `$ARGUMENTS` (optional: maximum number of units to build in this batch)

## Loop

Repeat, one unit at a time — **never two in parallel** (`validate-state.py` enforces `building <= 1`):

1. **Rehydrate + gate.** Run `python3 .orchestrator/scripts/validate-state.py`. Recompute `ready` exactly as `/next-pantalla` step 1 does (a `todo` unit whose `after[]` are all BUILT — `verified` or `accepted` — becomes `ready`). This is why the loop can chain a whole product without accepting anything. Read from disk, not chat memory.
2. **Stop conditions — check BEFORE building:**
   - no `ready` unit left → stop with the batch summary;
   - the previous iteration ended `blocked` AND no independent `ready` unit remains → stop with the batch summary. A blocked unit never gets retried or worked around, but it does not cancel its independent siblings: skip it, keep its `blocked_reason` in the summary, and continue with the units that do not depend on it. Stopping the whole wave for one unanswered product question wastes the rest of the batch;
   - `$ARGUMENTS` max reached → stop with the batch summary;
   - the state gate fails → stop and report; never build on a broken base.
3. **Iterate.** Execute the FULL `/next-pantalla` procedure (its SKILL.md end to end: RESEARCH → EXPLORE → DEVELOP → VERIFY → VALIDATE → REVIEW → auto-gates, with CLARIFY, checkpoint, phase pushes and the debugger cap) for the `ready` unit with the lowest `order`, **invoking it with that explicit ID** (`/next-pantalla <ID>`). Passing the ID is required, not cosmetic: without it the procedure stops on the first `verified` unit the loop itself produced. No batch shortcut exists: skipping a phase or a lens to "go faster" makes the unit un-`verifiable` at the gate anyway.
4. **After the unit reaches `verified`:** run `python3 .orchestrator/scripts/validate-state.py --emit-status`, append a `BUILD_LOOP` line to `progress.md`, and continue the loop.

CLARIFY during a loop iteration works as always (this is an interactive session — ask the human, persist answers to `blueprint/**`). If a genuine product decision stays unanswered, the unit goes `blocked` and the loop stops with the exact question.

## Hard rules

- **Never `/accept`.** The loop produces a batch of `verified` units; promotion stays human, one `/accept <ID>` at a time (each may auto-trigger `/verify-app` when it completes a journey).
- Compaction mid-loop is safe by design: state is disk-first and the active unit's `checkpoint` records phase + iteration. After compaction (or a crash), re-running `/build-loop` resumes the in-flight unit from its checkpoint instead of restarting it.
- If the session's harness offers `/goal` or `/loop`, they may WRAP this skill (e.g. "keep running /build-loop until nothing is ready") — optional sugar, never a replacement for the stop conditions above.

## Stop output

```text
Batch: <n> units built this run
Verified awaiting accept: <IDs>
Blocked: <ID + exact question/next action, or none>
Remaining (todo, waiting on accepts): <IDs>
Next: /accept <first verified ID>   (then /build-loop again to continue the wave)
```
