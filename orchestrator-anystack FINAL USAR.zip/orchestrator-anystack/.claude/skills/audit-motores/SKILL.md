---
name: audit-motores
description: "Optional cross-architecture gate: audit the engines (ENG-*) and pipelines (PIPE-*) behind the already verified/accepted screens — module contracts, reuse vs re-implementation, blueprint drift, architecture debt. Reports and recommends; never changes any unit's status."
argument-hint: [ENG-ID|PIPE-ID|all]
disable-model-invocation: true
model: inherit
effort: xhigh
---

# /audit-motores

Run inline in the current main session. You are `orchestrator-flow`: the single writer. This is the anti-Frankenstein check one layer below `/verify-app` — per-screen VERIFY/VALIDATE proves each screen's slice of an engine or pipeline; this proves the engines and pipelines built screen by screen are still **one architecture**.

Arguments: `$ARGUMENTS`

## When to run

**Automatically:** `/accept` launches it when an acceptance completes a journey — the same trigger as `/verify-app` (see accept step 8): `/verify-app` crosses the seams the user walks, this one audits the engines and pipelines underneath them. **Manually:** any time on demand. Either way it needs at least one `verified`/`accepted` screen citing `ENG-*`/`PIPE-*`; otherwise it stops and says exactly which engines/pipelines have no shipped screen behind them yet.

## Flow

1. Read `.orchestrator-state/features.json`, `blueprint/logic/engine.md`, `blueprint/logic/pipeline.md` and `blueprint/logic/data.md` (the canonical-store contract the engines write through). Run `python3 .orchestrator/scripts/validate-state.py` first — do not audit a broken state.
2. **Always launch the `audit-architecture` workflow** (mandatory, not a preference): a read-only loader resolves from disk the `ENG-*`/`PIPE-*` actually implemented behind the screens already `verified`/`accepted` (`$ARGUMENTS` may pin one `ENG-ID`/`PIPE-ID`), then all **5** `audit-*` lenses run in parallel over that scope and `audit-synthesizer` reduces them into one digest. Only if the Workflow capability is genuinely unavailable, run the same full lens set sequentially and record `inline-fallback`; never as a shortcut.
3. Consolidate (you are the writer) into `.orchestrator-state/evidence/APP-INTEGRATION/reports/audit-motores.md`: the synthesizer's `findings_by_target[]` — per module/engine/pipeline, its two buckets, **blueprint write-back debt** (truth that must go back to `blueprint/**`) and **architecture debt** (debt that lives in the code) — each finding with severity, cited `ENG-*`/`PIPE-*`/`DATA-*`/`SCR-*` refs, file/paths and evidence, plus `cross_lens_contradictions[]`, `clarify_questions[]` and `unmerged[]`. Real code and real observations only; a lens that could not run is reported `n/a` with the reason, never invented.
4. **Route each finding to its owner — you never change a status here:**
   - blueprint write-back debt that is structural/derivable → write it yourself into the file its ID family owns, then `python3 .orchestrator/scripts/lint-blueprint.py` and reflect it in `spec.md`;
   - a screen implemented out of the audited engine/pipeline contract → its evidence is stale: recommend re-VERIFY/re-VALIDATE of that `SCR-*` (via `/next-pantalla <ID>` on a reopened unit if the human agrees);
   - the shared contract itself is wrong or outgrown (a write-back that touches an already-compiled or `accepted` contract) → recommend `/reslice`, never a silent patch;
   - a genuine product decision (which engine owns the rule, which pipeline owns the freshness SLA) → CLARIFY with the human, persist the answer in `blueprint/logic/engine.md` or `blueprint/logic/pipeline.md`.
5. Append an `AUDIT_MOTORES` entry to `.orchestrator-state/progress.md`, push the checkpoint (`bash .orchestrator/scripts/phase-push.sh "AUDIT_MOTORES" "APP-INTEGRATION"`), and print the report path plus the exact recommended next command.

## Hard rules

- Real code, real runtime artifacts, real observations — the evidence standard applies unchanged. The audit reads what was built; it never re-runs a screen's acceptance on its behalf.
- This skill never moves any unit's lifecycle: not to `accepted`, not out of it. The STATE GATE and the human `/accept` remain the only anchors.
- Its findings NEVER enter the required `phase_runs[]` lens sets checked by `validate-state.py`, and it adds no required check to any `result.json`. AUDIT is not a `/next-pantalla` phase: counting it would retroactively invalidate the evidence of every unit already `verified`.
- Write-backs are proposed here and written by `orchestrator-flow` under the constitution's write-back discipline — never by the lenses, never by the synthesizer, which propose only.
- Active-unit discipline does not apply here (this gate is cross-architecture by design), but write access stays limited to `.orchestrator-state/evidence/APP-INTEGRATION/**`, `progress.md` and the `blueprint/**` write-backs you decide to persist.
