---
name: next-pantalla
description: Build and verify exactly one screen/unit vertically using disk state and specialist agents, then stop at the human gate.
argument-hint: [screen-id]
disable-model-invocation: true
model: inherit
effort: xhigh
---

# /next-pantalla

Run inline in the current main session. This command may write product code and orchestrator state. Do not use `context: fork` or `agent:`. Do not call `Agent(orchestrator-flow)`.

Arguments: `$ARGUMENTS`

Build exactly one unit from `.orchestrator-state/features.json`. A unit is usually a screen; it can also be a required foundation.

## Cross-cutting discipline

These disciplines apply to every phase below: the expert roles you embody, *think first then ask*, the phase checkpoint push, and recording each phase in `phase_runs[]`.

### You are the whole delivery team (expert roles)

You do not build a screen as a single generalist. You hold every role needed to ship the unit, each at **senior** level — with a senior's judgment: name the trade-offs, prefer the proven option over the clever one, and design for the whole application (architecture, data model, rules engine, pipelines, clients), not just the active screen — and reason from each one before and while you write code. Each phase materializes those roles as lens-agents or as hats you wear directly:

| Phase | Expert roles (how they materialize) |
| --- | --- |
| RESEARCH | one lens per blueprint file = product owner (`product`), architect (`core`/`screens`), DBA (`data`), backend (`application`), security (`permission`), UX (`ui`/`design`), cross-screen shell (`shell`), state engineer (`state`), reliability/errors (`error`), integration (`integration`), domain expert (`domain`), use-case analyst (`usecases`), journey/flow (`journey`) |
| EXPLORE | `explore-scout` + experts by scope: `data`, `backend`, `ui`, `tests`, `existing`, `engine`, `pipeline`, `config` |
| DEVELOP | you write as **architect + backend + frontend/mobile + DBA + data engineer + DevOps + security + QA at once** (no fan-out) |
| VERIFY | lenses: `tests` (QA), `conformance` (requirements analyst), `engine`/`pipeline` (data/runtime engineer), `design`+`frontend` (UX), `logs` (SRE), `quality` (production reviewer), `coherence` (cross-screen consistency vs shell + accepted siblings) |
| VALIDATE | `web`/`android`/`ios`/`logs` = manual tester per platform |
| REVIEW | `pantalla-reviewer` = tech lead / contractual sign-off |

For the active unit, **extract the information each role needs** from the blueprint, design and code (architecture, data model and canonical store, API/service contract, deploy/runtime/env and CI, permission gates, acceptance/test plan). DevOps/infra concerns that no lens owns (environment, runtime wiring, the phase-checkpoint push below) are owned directly by you. When a role's required input is missing or ambiguous, follow **Think first, then ask** below.

### Think first, then ask

When any role hits something it does not know — in **any** phase — think before you ask:

1. **Resolve it yourself first.** Re-read the relevant blueprint/design/code, consult official docs (provider/framework/MCP) when version-sensitive, and reason from that role's expertise.
2. **If it stays genuinely unresolved** and you need it to proceed correctly, **ask the human one precise question** instead of guessing. You may ask in any phase, not only RESEARCH — but prefer to batch product decisions in RESEARCH (§1.5), the cheapest point to resolve them.
3. **Persist the answer.** Product intent goes into `blueprint/**` so it is never lost; a technical answer just unblocks the current step.
4. **Block only as a last resort** — when the answer needs human setup/action beyond an answer, or the human cannot unblock inline. Then set `blocked`, write `verdict:"BLOCKED"` evidence with the exact question and next action, and stop.

Never invent product intent, fake a value or guess past a real unknown.

### Blueprint write-back (any phase)

The blueprint absorbs new truth the moment it appears — you are the only writer:

- **The human says something with product intent** — at any moment of any phase, even as an aside — write it into its blueprint file (`BR→PRODUCT`, `SCR→SCREENS`, ID family → `logic/*.md`, stack → `stack.md`) BEFORE acting on it. Chat is never the storage: compaction erases chat, disk survives.
- **You discover a blueprint-relevant fact while building** (an error case VERIFY surfaced, a state transition, a data constraint, a provider quirk) — write it back where it belongs: structural/derivable facts directly (note the source); product decisions via one precise CLARIFY first.

After every write-back: run `python3 .orchestrator/scripts/lint-blueprint.py` and reflect the change in the affected `spec.md` section. If the new truth changes an already-compiled or `accepted` contract, stop and route through `/reslice` — never patch state silently.

### Phase checkpoint push

After **every** phase below (RESEARCH, EXPLORE, DEVELOP, VERIFY, VALIDATE, REVIEW — including any debugger re-runs in §6), commit the work done in that phase and push it to `origin/main`:

```bash
bash .orchestrator/scripts/phase-push.sh "<PHASE>" "<ID>"
```

This is a DevOps-role side effect, not a lifecycle transition: it never changes a unit's `status` and the STATE GATE (`validate-state.py`) plus the human `/accept` remain the only trust anchors. The script is non-fatal — when there is no git work tree or no `origin` remote it logs and continues, so a checkpoint never blocks building a screen.

### Record each phase in result.json (`phase_runs`) — enforced

As each fan-out phase runs, append its entry to `result.json.phase_runs[]`: `{phase, workflow, mode, lenses[]}`, where `lenses[]` is the **actual** set of lens-agents that ran. This is not bookkeeping — **the STATE GATE rejects a PASS whose `phase_runs` is missing a phase or whose lens set is incomplete**, so skipping EXPLORE/VERIFY/VALIDATE or hand-picking a subset of lenses makes the unit un-`verifiable`. Required full sets: RESEARCH → all 17 `research-*`; EXPLORE → `explore-scout` + 8 `explore-*`; VERIFY → all 10 `verify-*`; VALIDATE → `validate-logs` + `validate-{web,android,ios}` for every owned platform + `validate-engine`/`validate-pipeline` when the unit cites `ENG-*`/`PIPE-*`; REVIEW → `pantalla-reviewer`. Use `mode:"workflow"` (or `"inline-fallback"` only when Workflows are genuinely unavailable, carrying the same full set); DEVELOP uses `"inline"`, REVIEW `"agent"`. Do not write `phase_runs` for a phase you did not actually run — that is fabricated evidence.

**A lens that returned nothing did not run.** Every fan-out workflow reports the lenses that produced no result (`failed_lenses[]`; `validate-journeys` reports a `failed_count` — derive the missing ones from `journeys[]` minus `lenses[].journey`). Apply the constitution's policy literally, in order: (1) re-launch ONLY those lenses once, same phase, same arguments — never the whole fan-out again; (2) if any still returns nothing, do NOT list it in `phase_runs[].lenses` — the set is then incomplete and the unit cannot reach `verified`; (3) record each one in `result.json.failures[]` with the phase, the lens name and the reason; (4) set the unit `blocked` with `blocked_reason` naming those lenses and the phase, plus reproduction and next action. Retry, then block — there is no third option, and a degraded fan-out is never silently smaller.

## 0. Rehydrate

Start from disk:

1. `pwd`
2. read `CLAUDE.md` and `.claude/rules/*.md`
3. read `.orchestrator-state/spec.md`
4. read `.orchestrator-state/progress.md`
5. read `.orchestrator-state/features.json` and require `initialized:true`
6. inspect current filesystem/runtime state relevant to the active unit
7. run `python3 .orchestrator/scripts/validate-state.py`
8. run the setup command recorded in `.claude/rules/stack.md` only if needed to prepare the environment
9. run the smoke command recorded in `.claude/rules/stack.md` when a smoke command is known

If the environment is broken, fix the environment first. Do not start a new screen on a broken base.

## 1. Choose one unit

If `$ARGUMENTS` contains an ID:

- it must exist;
- `ready`, `building` or `blocked` may be retried;
- `todo` may be used only if every dependency is BUILT (`verified` or `accepted`), then mark it `ready` first;
- `verified` stops with instruction to run `/accept <id>`;
- `accepted` stops as already complete.

If no ID is provided:

1. If any unit is `verified`, stop and ask for `/accept <id>` — EXCEPT when an explicit ID was passed (which is how `/build-loop` drives each iteration): with an ID, build that unit and do not stop on unrelated `verified` units.
2. Recompute `ready` for `todo` units whose dependencies are all BUILT (`verified` or `accepted`).
3. Choose the `ready` unit with lowest `order`.
4. If none is ready, report complete, blocked or dependency status.

For the chosen unit, set `status:"building"`, `passes:false` and `checkpoint: {"phase":"RESEARCH","iteration":0}`, save `features.json` and append `BUILDING` to progress.

The `checkpoint` field is the crash/compaction anchor: update `checkpoint.phase` in `features.json` as each phase starts (RESEARCH/EXPLORE/DEVELOP/VERIFY/VALIDATE/REVIEW), and `checkpoint.iteration` on each debugger re-run (§6). If step 0 found the unit already `building` with a `checkpoint`, resume from that phase — do not restart the whole pipeline (already-recorded `phase_runs` stay valid).

## 1.5 Research the blueprint for this unit (phase 0, fan-out)

Before touching code, make sure the blueprint — the product source of truth — fully specifies THIS screen across front, back, data engine, pipelines, tables, infra and permissions. Run a deep RESEARCH:

- **Always launch the `research-fanout` workflow** — mandatory, not a preference — (it fans out one `research-*` lens-agent per blueprint file: 14 `logic/*.md` — including `shell.md` (cross-screen contract), `engine.md` (`ENG-*`) and `pipeline.md` (`PIPE-*`) — + `research-product` + `research-screens` + `research-design`). It MUST fan out to **all 17** lenses every time; never hand-pick a subset (a non-applicable lens self-reports `covered:n/a`).
- Only if the Workflow capability is genuinely unavailable in this session, fall back to the `research-*` agents sequentially and record `inline-fallback` — never as a shortcut.

It returns coverage, gaps (`auto_fill` or `clarify`) and CLARIFY questions. As the single writer, complete the blueprint so nothing is lost:

- apply `auto_fill` proposals to `blueprint/**` (structural/derivable only);
- ask the human the `clarify_questions` in ONE round — RESEARCH is the **main** place to ask, batching product decisions pre-build (later phases may still ask per *Think first, then ask*) — and write the agreed answers into `blueprint/**`;
- after writing any fill/answer into `blueprint/**`, run `python3 .orchestrator/scripts/lint-blueprint.py` — your writes must leave the blueprint referentially intact (no duplicate IDs, no dangling refs, no cycles);
- if a blocking product gap cannot be resolved, set `blocked`, write `BLOCKED` evidence and stop.

Proceed to explore only when the blueprint specifies this screen unambiguously. Re-read the updated feature/blueprint before planning.

Then push the RESEARCH checkpoint: `bash .orchestrator/scripts/phase-push.sh "RESEARCH" "<ID>"`.

## 2. Explore and plan (agents feed you; you hold the thread)

With the blueprint complete, get an actionable context contract from a DEEP explore over the code — always fan out, never a single shallow pass:

- **Always launch the `explore-fanout` workflow** — mandatory, not a preference — (`explore-scout` lists relevant files by scope, then `explore-{data,backend,ui,existing,tests,engine,pipeline,config}` audit their files in parallel). It MUST launch `explore-scout` + **all 8** `explore-*` lenses every time; never a subset.
- Only if the Workflow capability is genuinely unavailable in this session, fall back to `explore-scout` then the `explore-*` agents sequentially and record `inline-fallback` — never as a shortcut.

You own the single consolidated context; lenses cover disjoint scopes so the maps never conflict. The explore lenses audit the existing code and flag gaps. Handle gaps with *Think first, then ask*:

- a `block_signal` (missing/contradictory product intent, undeclared data owner, ambiguous architecture) -> first resolve what you can from the sources; if it stays genuinely unresolved, ask the human one precise question (prefer to have caught it in RESEARCH); block only as a last resort, writing `verdict:"BLOCKED"` evidence with the exact question and next action. Never guess. (Most product gaps should already be resolved by RESEARCH at `/init-build`.)
- a technical-context `risk` -> resolve it yourself and proceed.

From the consolidated `acceptance_map[]`, write the vertical plan in dependency/layer order:

```text
data/schema -> backend/API -> UI/flow -> tests -> verification/evidence
```

Map every acceptance criterion to implementation and evidence. For data units, map every critical value through the architecture-appropriate path:

```text
engine refs -> generation (migration/seed/backfill/job/api_write/replay/transition) -> canonical store value -> service/API/read model -> client field
```

Do not plan UI before the canonical data path is clear. Bind the `verification_route` from EXPLORE now; step 5 uses it and does not re-derive verification from journey refs.

Then push the EXPLORE checkpoint: `bash .orchestrator/scripts/phase-push.sh "EXPLORE" "<ID>"`.

## 3. Build vertically

The main conductor writes code, wearing every DEVELOP hat at once, each at senior level — **architect + backend + frontend/mobile + DBA + data engineer + DevOps + security + QA** (see Cross-cutting discipline). Decide the layering as the senior architect, the canonical store and migrations/seeds as the DBA, the pipelines/generation as the data engineer, the API/service contract and business rules as the backend, the client UI/flow (inside the shared shell, reusing the component inventory) as the frontend/mobile engineer, the runtime/env/wiring as DevOps, the permission/input gates as security, and the test/evidence plan as QA — in one coherent vertical. Every role's input should have been extracted in RESEARCH/EXPLORE; if one is still missing now, apply *Think first, then ask* (resolve yourself, ask one precise question if genuinely stuck, block as a last resort) — never guess.

Implement only the selected unit and necessary support:

1. data model/schema/migration/seed;

   - compile the selected unit's `data_engine` into concrete schema, seeds/generator, backfill/job or write path;
   - generate verification data in the canonical store, not in frontend constants or local mock files;
2. domain/application/core logic;
3. API/service/integration boundary;
4. UI or mobile flow;
5. tests and verification hooks for this unit.

No final stubs, fake data, TODOs, placeholder behavior or mocks unless the acceptance explicitly requires a prototype/mock. If verification needs data that does not exist yet, produce it through the unit's declared REAL generation path (migration/seed/backfill/job/api_write/event replay/state transition) into the canonical store — never invent it at any layer.

Library coherence: before adding any dependency, check the existing manifest and `.claude/rules/stack.md`; reuse what already solves the concern, never introduce a competing library, prefer the current officially recommended option (consult official docs when version-sensitive) and record new dependencies in `stack.md`.

All frontends for the unit must read product values through the same API/service/read model backed by the database. Do not create separate web/mobile copies of the same business value.

If the unit cannot be completed, set `blocked`, write `.orchestrator-state/evidence/<ID>/result.json` with `verdict:"BLOCKED"`, append progress and stop.

## 4. Evidence skeleton

Create:

```text
.orchestrator-state/evidence/<ID>/
├── result.json
├── screenshots/
├── logs/
├── traces/
├── db/
├── recordings/
├── videos/
└── reports/
```

Start `result.json` as `FAIL`. Upgrade only after real verification.

Then push the DEVELOP checkpoint: `bash .orchestrator/scripts/phase-push.sh "DEVELOP" "<ID>"`.

## 5. Verify → Validate → Review (from the bound route)

Run the three quality phases from the bound `verification_route` (EXPLORE), not from journey refs. Each phase **always launches its fan-out workflow** (mandatory, not a preference), fanning out to its **FULL** set of lenses every time — VERIFY → **all 10** `verify-*`; VALIDATE → `validate-logs` + `validate-{web,android,ios}` for every owned platform + `validate-engine`/`validate-pipeline` when the unit cites `ENG-*`/`PIPE-*` — never a hand-picked subset. Only if the Workflow capability is genuinely unavailable does it degrade to sequential `Agent(...)` calls running the same full set (record `inline-fallback`, never as a shortcut). Lens-agents save only their own evidence artifacts under `.orchestrator-state/evidence/<ID>/` and RETURN their findings (checks, observed values, failures); you (orchestrator-flow) write the consolidated `result.json` and verdict — never the lens-agents (this avoids parallel writes to the same file).

### VERIFY — static, against the documents
Workflow `verify-fanout.js` (fallback: the `verify-*` lens-agents, sequential). Lenses: run/read tests; logic conformance vs the cited docs; design fidelity; data-engine/pipeline proof for the detected architecture; back/front/db/engine logs and code quality; cross-screen coherence vs the shell contract (`UI-SHELL-*`) and the sibling `verified`/`accepted` screens. It records `db_value`/`api_value` and emits `expected_ui_values[]`. Does not drive the live UI. After consolidating the static verdict, persist the digest's `expected_ui_values[]` **verbatim** into `result.json.expected_ui_values` (canonical shape: `{db_key, permission_context, api_field_path, expected_visible_value, ui_field, transform?}`) — VALIDATE's loader lifts them from that field on disk, so never leave them only in chat context. Then push the VERIFY checkpoint: `bash .orchestrator/scripts/phase-push.sh "VERIFY" "<ID>"`.

### VALIDATE — live, human-like (owned UI surfaces only)
Workflow `validate-live.js` (fallback: the `validate-*` lens-agents per runtime — `validate-web`/`validate-android`/`validate-ios` — plus `validate-logs`, sequential). Drive the real product like a human: web (Claude-in-Chrome → Chrome DevTools MCP → Playwright fallback), Android (Dart MCP + emulator + adb/logcat), iOS (Dart MCP + simulator + idb). Exercise every state/flow, inspect logs, confirm no errors. Assert each observed client value **derives from** `expected_ui_values` (value + transform), not blind equality; record `ui_value`/`platform_values`. Hybrid: web and mobile must show the same canonical value. Never PASS without the live runtime. Backend-only units skip VALIDATE. After consolidating the live verdict, push the VALIDATE checkpoint: `bash .orchestrator/scripts/phase-push.sh "VALIDATE" "<ID>"`.

### REVIEW — one contractual verdict
`Agent(pantalla-reviewer)` consolidates VERIFY + VALIDATE evidence into a single contractual verdict against `acceptance[]`, `applies[]` and the blueprint source text. It cannot move the unit to `accepted`. After recording the verdict, push the REVIEW checkpoint: `bash .orchestrator/scripts/phase-push.sh "REVIEW" "<ID>"`.

### 5.5 AUTO-GATES — pipelines/data + production readiness (automatic, Sonnet)

After REVIEW passes, run BOTH deep gates automatically — they are part of every `/next-pantalla`, not optional extras (manual re-runs before `/accept` remain possible):

1. **`/verify-pipelines-data-ultracode <ID> --fix`** — follow `.claude/skills/verify-pipelines-data-ultracode/SKILL.md` inline. A unit with no data/pipeline contract self-reports `NOT_APPLICABLE` (record it; that is a pass).
2. **`/production-code-review <ID> --fix`** — follow `.claude/skills/production-code-review/SKILL.md` inline.

**How to run them:** `Read` each `SKILL.md` and execute its protocol yourself in this session, with `$ARGUMENTS = "<ID> --fix"`. Do NOT call the `Skill` tool: both are `disable-model-invocation: true` by design (that flag exists to keep you the single writer, not to make the gates unreachable). Being unable to invoke `/verify-pipelines-data-ultracode` or `/production-code-review` as a slash command is NOT a blocker and is never a reason to close a unit without their checks, nor to hand the run back to the human.

**Model:** spawn every subagent/workflow these two gates use with `model: 'sonnet'` — the deep sweeps are Sonnet-tier by design; you (the conductor) stay on the session model and remain the single writer.

Consequences:
- Their required checks merge into `result.json` and must pass — a failing gate check keeps the unit un-`verified`.
- If a gate applied a fix, the touched evidence is stale: treat it as a debugger pass (§6) — increment `checkpoint.iteration`, re-run VERIFY (and VALIDATE when the fix changed runtime behavior), then re-check the failing gate check.
- Push a checkpoint after each gate: `bash .orchestrator/scripts/phase-push.sh "GATE_DATA" "<ID>"` and `bash .orchestrator/scripts/phase-push.sh "GATE_PROD" "<ID>"`.

## 6. Debugger loop (DEVELOP repairs; re-run downstream)

DEVELOP is also the debugger: every phase result feeds you (the single writer), and on failure you repair in-thread, then re-run the affected phases. Maximum 3 iterations — enforced: increment the unit's `checkpoint.iteration` in `features.json` on EACH repair pass; the STATE GATE rejects `iteration > 3`, so past the cap the only honest moves are `blocked` (with reason and reproduction) or a human decision.

- **VERIFY fails** → debug (repair this unit + necessary support) → **re-run VERIFY**; when it passes, continue to VALIDATE.
- **VALIDATE fails** → debug → **re-run VERIFY and VALIDATE** (a code fix can invalidate the static evidence, so re-prove both).
- Each repair marks the touched-layer evidence **stale**; rewrite `result.json` from the fresh runs. Re-run only the affected phase(s), not the whole pipeline.
- A repair is a DEVELOP pass: push a `DEVELOP` checkpoint after it, then a fresh checkpoint for each re-run phase (re-VERIFY / re-VALIDATE), so `origin/main` tracks every iteration.

If the same failure repeats without progress across the iteration cap, mark `blocked` with a concrete reason, reproduction and next action.

## 7. Close

Write BOTH fields in the same `features.json` save — `status:"verified"` **and** `passes:true`. `passes` mirrors the status, it is not an extra judgment: the STATE GATE rejects `verified` with `passes:false`, and `/accept` requires `passes:true` as a precondition. Do this only when:

- every required check passed;
- `result.json.verdict == "PASS"`;
- failures are empty;
- required artifacts exist and are non-empty (no 0-byte/placeholder files);
- data checks are real or explicitly not applicable;
- every required `data_engine` assertion carries the observed literal value at each layer (`db_value`/`api_value`/`ui_value` plus `platform_values` when multi-client) and they are equal, proving canonical-store -> API/read-model -> client equality;
- `result.json` includes a `source_manifest` (path + sha256 of the unit's implementation files) so stale evidence is detectable after any later fix;
- `result.json.phase_runs[]` proves the full workflow cycle ran with complete lens sets (RESEARCH, EXPLORE, DEVELOP, VERIFY, VALIDATE when the unit owns a UI surface, REVIEW) — the STATE GATE rejects a PASS that skipped a fan-out workflow or ran a partial lens set;
- the two §5.5 auto-gates recorded their checks by id in `result.json.checks[]`, each `passed:true`: `CHK-<ID>-PRODUCTION-CODE-REVIEW` (always) and `CHK-<ID>-PIPELINES-DATA-ULTRACODE` (or, when the unit has no data engine, present with `required:false, passed:true, notes:"not applicable"`). Their ABSENCE means a gate never ran; `/accept` looks for them by id;
- `python3 .orchestrator/scripts/validate-state.py` passes.

**Harvest (do not lose what this screen learned).** Before closing, write back everything blueprint-relevant this unit produced, as the single writer:
- anything SHARED — a reusable component, a route pattern, an API convention, a shell/navigation piece, a helper other screens will need — goes into `blueprint/logic/shell.md` (component inventory `UI-SHELL-003`, navigation `UI-SHELL-002`, conventions);
- any OTHER discovery that belongs in the spec — an error case surfaced by VERIFY/VALIDATE, a state transition, a data constraint, a provider quirk, a new dependency — goes into its `logic/*.md` / `stack.md` per the Blueprint write-back discipline (structural facts directly, product decisions via CLARIFY).
Then run `python3 .orchestrator/scripts/lint-blueprint.py`. The next screen's RESEARCH and `verify-coherence` read the contract, not your memory: knowledge that exists only in code or chat is knowledge already being lost.

Then update the feature entry (`status:"verified"`, `passes:true`, and clear its `checkpoint` — the build is no longer in flight), append `VERIFIED`, run `python3 .orchestrator/scripts/validate-state.py --emit-status` (refreshes `status.json` + `evidence/index.json` for external readers) and `bash .orchestrator/scripts/validate-structure.sh`, and stop with:

```text
Evidence: .orchestrator-state/evidence/<ID>/result.json
Auto-gates already run (Sonnet): pipelines/data + production review — see evidence/<ID>/reports/
Recommended next: /review-pantalla <ID> if the UI deserves an extra live-parity pass, then /accept <ID>.
When an /accept completes a journey (JOUR-*), /verify-app runs automatically on it.
```

Never start the next unit automatically — the one sanctioned exception is `/build-loop`, which is an outer loop that re-invokes this procedure with an explicit ID per iteration and still never accepts.
