---
name: reslice
description: Reconcile changed blueprint/design into orchestrator state while preserving accepted work, history and evidence.
argument-hint: [reason]
disable-model-invocation: true
model: inherit
effort: xhigh
---

# /reslice

Run inline in the current main session. Recalculate state without rebuilding accepted work. You are `orchestrator-flow`: the single writer.

Arguments: `$ARGUMENTS`

## Flow

1. **Deterministic preflight.** Run `python3 .orchestrator/scripts/lint-blueprint.py` on the updated blueprint (duplicate IDs, dangling `applies[]`/`after[]`/`related_screens[]` refs, dependency cycles, leftover stubs). Fix structural errors in `blueprint/**` (you are the writer) or turn genuine product gaps into CLARIFY questions before touching state. When `blueprint/ORIGINAL.md` exists, also run `python3 .orchestrator/scripts/original-coverage.py --extract` then `python3 .orchestrator/scripts/original-coverage.py`: a reslice is exactly when claims drift, and its `unclaimed`/`drifted`/`orphaned` rows are CLARIFY input (never a blocker). Then run `python3 .orchestrator/scripts/validate-state.py` so you start from a valid state.
2. Read current `features.json`, `spec.md`, `progress.md` and relevant evidence.
3. Read updated `blueprint/` and `design/` (including `blueprint/logic/shell.md` and `design/tokens.css` — the cross-screen contracts).
4. Ask CLARIFY before changing scope, deleting accepted work, changing IDs, breaking dependencies, or whenever a new/changed unit's platform, route, owner or canonical store is ambiguous. Resolve it with the human and persist the answer to `blueprint/**`, exactly as `/init-build` does; never guess.
4.5. **Architecture re-gate (hash-triggered, deterministic).** Compare `python3 .orchestrator/scripts/validate-state.py --arch-hash` against `features.json.meta.architecture_review.architecture_hash`. If they differ, the blueprint change touched an architecture-bearing file: re-run `/arch-review` (full 6-lens set) by following `.claude/skills/arch-review/SKILL.md` inline — like every skill it is `disable-model-invocation: true` by design, so you `Read` the file and execute its protocol, never the `Skill` tool (see the inline-chaining rule in `constitution.md`) — before regenerating state, and refresh `meta.architecture_review` with the new hash. Deferred findings whose `trip_wire` names a changed ID are reopened. If the hashes match, skip — never re-run it on unrelated blueprint edits.

5. Regenerate candidate spec/features. Re-read the blueprint the same way `/init-build` does (launch the `compile-blueprint` workflow with its full research lens set; `inline-fallback` only if the Workflow capability is genuinely unavailable) so new and changed units are **compiled from source, not sketched**. Every new or changed unit must carry the **same full per-unit field contract as `/init-build` step 4** — `id`/`slug`/`title`/`kind`/`platforms`/`order`/`after`/source refs/`route`/`applies`/`acceptance`/`verify` (with `data_checks[]`) and, for data units, a compiled `data_engine` — derived from `SCREENS.md`/`logic/*`, never invented. Derive `platforms` from the `SCREENS.md` platform map and **never leave a UI unit with empty `platforms`**: the STATE GATE rejects a UI surface (kind `ui` / UI `primary_verifier` / client route) that declares no platform, so a half-filled new screen fails validation in step 8 instead of silently skipping the VALIDATE phase later.
6. Merge with prior state:
   - new units, compiled per step 5, enter `todo` or `ready` based on dependencies;
   - preserve IDs when meaning is stable;
   - preserve `accepted` only if the new contract is compatible;
   - if an accepted contract changed, reopen with a note;
   - **cross-screen contracts propagate:** if a shared contract changed — `UI-SHELL-*` (shell/navigation/shared components), `design/tokens.css`, a shared route convention or a shared API contract — every non-deprecated UI unit that depends on it has stale evidence: reopen it or mark its evidence stale with a note; screens must stay coherent with each other, not only with their own spec;
   - keep old evidence but do not reuse it as PASS for changed contracts;
   - regenerate `data_engine` for changed `DATA-*`, `APP-*`, `UC-*`, `PERM-*`, `ST-*`, `ERR-*` or `INT-*` refs;
   - if canonical store resources, pipeline generation or single-value contracts changed, mark related evidence stale and require re-verification;
   - missing screens become `deprecated`, not deleted.
7. Write updated state with `generated_by:"/reslice"`, new hashes, `initialized:true` and `meta.lifecycle:"resliced"`.
8. Validate: `python3 .orchestrator/scripts/validate-state.py --emit-status` (also refreshes `status.json` + `evidence/index.json` for external readers) and `bash .orchestrator/scripts/validate-structure.sh`.
9. Append `RESLICE` (with the reason from `$ARGUMENTS`) to progress, then push the checkpoint: `bash .orchestrator/scripts/phase-push.sh "RESLICE" "state"`.
10. Print what changed (new / reopened / deprecated / stale-evidence units) and the next suggested `/next-pantalla` command.

Never auto-accept new or changed work. Never delete evidence.
