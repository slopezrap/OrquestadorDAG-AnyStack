---
name: status
description: Read-only summary of orchestrator state from disk.
disable-model-invocation: true
model: inherit
effort: xhigh
---

# /status

Run inline in the current main session. Read-only.

1. Read `.orchestrator-state/spec.md`, `.orchestrator-state/features.json` and `.orchestrator-state/progress.md`.
2. Run `python3 .orchestrator/scripts/validate-state.py --emit-status`; if it fails, show the exact failure. On success this also refreshes the machine-readable projections `.orchestrator-state/status.json` and `.orchestrator-state/evidence/index.json` (the stable read contract for dashboards and external surfaces).
3. Summarize counts by status, current `building` (with its `checkpoint.phase` when present), `verified` awaiting accept, next `ready`, blockers, data-engine coverage/gaps and last progress event.
4. Recommend exactly one next command.
