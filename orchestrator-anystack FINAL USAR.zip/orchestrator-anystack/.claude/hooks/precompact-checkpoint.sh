#!/usr/bin/env bash
# PreCompact guardrail — flush the disk anchor before the conversation is summarized.
#
# WHY THIS EXISTS
# Compaction erases chat. The whole orchestrator is built on that premise ("Read disk
# first. Do not rely on chat memory."), and the resume anchor is real: features.json
# carries the active unit's `checkpoint {phase, iteration}` and result.json carries
# `phase_runs[]`. But nothing GUARANTEED those were current at the moment of compaction —
# the projections (status.json, evidence/index.json) are only refreshed when a skill
# happens to run `--emit-status`, and a batch's own progress was not written down at all.
#
# So this hook does the one thing that is always safe and always useful: it makes the
# disk say what the session knows, immediately before the session forgets it. It writes
# no lifecycle state and decides nothing (constitution.md: "Do not use hooks to mutate
# lifecycle by default") — it refreshes derived projections and prints the anchor.
#
# It is UNCONDITIONALLY NON-FATAL. A hook that can fail here would turn "the context got
# long" into "the run died", which is a strictly worse outcome than a stale projection.
# Every branch below ends at exit 0, on purpose.
set -uo pipefail

PROJECT_DIR="${CLAUDE_PROJECT_DIR:-$PWD}"
cd "$PROJECT_DIR" 2>/dev/null || exit 0

STATE=".orchestrator-state"
FEAT="$STATE/features.json"
BATCH="$STATE/batch.json"

[ -f "$FEAT" ] || exit 0

# Refresh the derived projections so an external reader — and the post-compaction rehydrate —
# sees the current plan rather than whatever the last skill happened to leave behind.
# Failure is fine and expected on an invalid state: the STATE GATE reports that elsewhere,
# loudly, and this is not the place to relitigate it.
python3 .orchestrator/scripts/validate-state.py --emit-status >/dev/null 2>&1 || true

# Emit the resume anchor as the universal `systemMessage` field on STDOUT.
#
# READ THIS BEFORE CHANGING IT BACK. This block used to emit
# `hookSpecificOutput.additionalContext` and to claim, right here, that it was "the ONLY form
# that reaches the model" and "what survives into the post-compaction context". Both were
# FALSE: the documented PreCompact contract supports only the universal fields (`continue`,
# `stopReason`, `systemMessage`, `terminalSequence`) plus exit-2 blocking — `additionalContext`
# is not among them. Nothing this hook prints is injected into the model's post-compaction
# context, by any field. `systemMessage` is documented as a message shown to the USER, and even
# that is event-dependent, so treat it as best-effort surfacing and nothing more.
#
# What actually survives a compaction is DISK, and that half is real: the --emit-status call
# above refreshes status.json and evidence/index.json, and the anchors themselves
# (features.json.checkpoint, result.json.phase_runs[], batch.json) are written live by
# /next-pantalla and /build-loop. CLAUDE.md "After a compaction" tells the conductor to
# re-read exactly those, and that instruction is sufficient on its own — this hook is a
# convenience on top of it, never the mechanism it depends on.
#
# The irony is worth leaving in writing: a safeguard against silent state loss was itself a
# silent no-op, asserted in a comment nobody could falsify without reading the hook docs.
#
# Read from disk, never from arguments: the point is to prove what disk actually holds at
# this instant, not to echo back something the session believed.
python3 - "$FEAT" "$BATCH" <<'PY' || true
import json, sys
from pathlib import Path

feat_path, batch_path = Path(sys.argv[1]), Path(sys.argv[2])
try:
    data = json.loads(feat_path.read_text(encoding="utf-8"))
except Exception:
    sys.exit(0)

screens = data.get("screens") or []
lines = ["[precompact] resume anchor — read this from disk, not from memory:"]

building = [s for s in screens if s.get("status") == "building"]
if building:
    for unit in building:
        cp = unit.get("checkpoint") or {}
        lines.append(
            f"  ACTIVE UNIT {unit.get('id')} — resume at phase "
            f"{cp.get('phase', '?')}, iteration {cp.get('iteration', 0)}. "
            f"Re-read {unit.get('evidence_path')} phase_runs[] and continue from that phase; "
            f"do NOT restart the unit."
        )
        if not cp:
            lines.append(
                "  WARNING: it is building with NO checkpoint. Nothing on disk says which "
                "phase it reached — re-derive it from result.json phase_runs[] before doing "
                "any work, and write the checkpoint back."
            )
else:
    verified = [s.get("id") for s in screens if s.get("status") == "verified"]
    lines.append(f"  no unit is building. verified awaiting accept: {verified or 'none'}")

if batch_path.exists():
    try:
        batch = json.loads(batch_path.read_text(encoding="utf-8"))
        if batch.get("status") == "running":
            lines.append(
                f"  BATCH IN FLIGHT ({batch.get('mode', 'build-loop')}): "
                f"{len(batch.get('units_built') or [])} built"
                + (f" of max {batch['max_requested']}" if batch.get("max_requested") else "")
                + f", blocked {batch.get('units_blocked') or []}. "
                f"Resume the batch from {batch_path}, not from the count you remember."
            )
    except Exception:
        lines.append(f"  WARNING: {batch_path} exists but does not parse; treat the batch "
                     f"count as unknown and re-derive it from features.json.")

# The standing risk compaction creates, stated where it will be read: an answer that exists
# only in chat is about to stop existing. The rule already says write-before-act; this is the
# last moment it can still be obeyed.
lines.append("  Before continuing: any product intent the human stated in chat and you have "
             "NOT yet written into blueprint/** is about to be lost. Write it now.")

print(json.dumps({"systemMessage": "\n".join(lines)}))
PY

exit 0
