# Stack and canonical commands

This file must contain real project commands. Placeholders are allowed in the scaffold but must be resolved during `/init-build` before implementation starts.

## Stack

- Runtime:
- Backend framework:
- Frontend framework:
- Mobile framework:
- Canonical store (database / event store / state store / ledger / external system / file store):
- ORM / migrations / schema tooling (if any):
- Testing:
- UI verification:
- Local URLs (web / API / other surfaces):

## Deployment & infra

Filled by the `/discovery` gate (Q-INFRA-*) and kept current by write-backs; deployment/infra decisions live here — infra is stack governance, not a product layer. The *why* behind each non-obvious choice goes to `blueprint/DECISIONS.md` as a `DEC-*`.

- Pilot runtime (where it runs now — local, containers, host):
- Production target (and when the jump is decided):
- Tenancy (multi-tenant / instance per client) and isolation mechanism:
- Object/file storage (if any):
- Job queue / workers (if any):
- Backups and restore drill:
- Who operates it (client-facing or abstracted):
- Environments (dev/staging/prod) and promotion path:
- Observability (logs / metrics / alerts destinations):
- SLO / expected load / cost budget (if load-bearing):

## Canonical commands

```bash
# install dependencies
<COMMAND_INSTALL>

# prepare local environment
<COMMAND_SETUP>

# start development server
<COMMAND_DEV>

# apply migrations
<COMMAND_MIGRATE>

# load minimal verifiable seed
<COMMAND_SEED>

# reset the verifiable test-data store to a clean, reproducible state (COMMAND_RESET_TEST_DATA)
# Read by .orchestrator/scripts/reset-test-data.sh, which the CONDUCTOR runs ONCE before any
# phase that executes the suite (VERIFY / VALIDATE and their debugger re-runs). Lenses never
# call it. MUST be idempotent: running it twice leaves the same state. Compose it from the
# commands above when that is what a reset means for this stack (typically migrate + seed);
# whatever this project's canonical store is, this is the one command that returns it to a
# known baseline. Leave the placeholder if the project genuinely has no test-data store —
# the script reports that distinctly and never blocks.
<COMMAND_RESET_TEST_DATA>

# lint/static checks
<COMMAND_LINT>

# unit/integration tests
<COMMAND_TEST>

# build
<COMMAND_BUILD>

# minimal smoke check
<COMMAND_SMOKE>
```

## Verification tool defaults

- Web: Claude in Chrome when active; otherwise Chrome DevTools MCP/plugin; Playwright only as explicit fallback.
- Flutter/mobile: Dart/Flutter MCP plus Android Emulator/ADB/logcat or iPhone Simulator/IDB/simctl.
- Backend/data: real test commands, real endpoints, real logs and real DB/API checks.
- Provider/integration: real adapter probe, SDK/CLI call or explicit degraded/not-applicable reason.

## Runtime evidence policy

- The setup command must be idempotent. The dev command may be long-running and should be used only when a live runtime is needed.
- Verifiers must prefer these commands over invented alternatives.
- If a command is unknown, `/init-build` must ask CLARIFY or mark init blocked; `/next-pantalla` must not guess.
- Do not use orchestrator reset/clean commands as acceptance evidence for an active screen.
- Do not accept tests that pass only because the real backend, DB, provider, emulator or browser runtime is absent when that runtime is required.
- Use isolated test data, disposable local state or safe cleanup when a verification mutates persistence.
- Redact secrets from command output before storing evidence.

## Useful log targets

Record the real project-specific sources during `/init-build`:

- frontend/browser console logs;
- backend/server logs;
- worker/job logs;
- database/query logs;
- Android `adb logcat` logs;
- iOS simulator/device logs;
- provider/integration diagnostic logs.

If no log source exists for a required runtime, record the limitation in evidence instead of inventing logs.
