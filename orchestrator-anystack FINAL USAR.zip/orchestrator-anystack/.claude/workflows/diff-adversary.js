export const meta = {
  name: 'diff-adversary',
  description: 'Bounded adversarial read of ONE repair diff, between the repair and the VERIFY that proves it. Four read-only agents ask four fixed questions in parallel — what broke, what is half-done, what became unreachable, which edge case would cost a future iteration. It is NOT a phase: nothing it returns is evidence, it never enters phase_runs[], and it never spends an iteration. It exists to fold a defect into the repair that is already happening, instead of paying a 12-subagent VERIFY fan-out plus a full round to discover it.',
  phases: [
    { title: 'Adversary', detail: 'four fixed questions over the repair diff, in parallel, read-only' },
  ],
}

// ---------------------------------------------------------------------------------------------
// WHY THIS EXISTS, AND WHY IT IS FOUR AGENTS AND NOT TEN.
//
// The ten VERIFY lenses each ask whether something IS THERE: the tests pass, the code matches the
// doc, the engine honours its contract, the logs are clean. None of them can ask whether something
// STOPPED BEING REACHABLE — and a repair that quietly makes an audited denial unreachable compiles,
// passes the suite, and satisfies all ten. That defect ships. The third question below is aimed at
// exactly that class, and it is the reason this file exists; the other three earn their place by
// being the same shape of question about the same diff.
//
// On what these four are NOT told: how often to find something. Four agents on a bounded diff is
// cheap next to a 12-subagent VERIFY fan-out and the repair round behind a failed one — but that
// arithmetic is the OWNER's question, never the adversary's, and it must not leak into the prompt.
// An adversary told "you should usually find nothing" suppresses the rare finding, which is exactly
// the class this file exists for; one told "you must hit N%" invents findings. Both are quotas, and
// a quota in either direction stops the agent reading the diff and starts it managing a number.
// So the bar sits on the FINDING — concrete, falsifiable, caused by this diff — and the count is
// whatever the diff earned. "nothing_found" is a first-class answer, not a preferred one.
// ---------------------------------------------------------------------------------------------

const ARGS = (() => {
  if (args === undefined || args === null) return {}
  if (typeof args === 'object') return args
  if (typeof args === 'string') {
    const raw = args.trim()
    if (!raw) return {}
    try {
      const parsed = JSON.parse(raw)
      return (parsed && typeof parsed === 'object') ? parsed : {}
    } catch (e) {
      log(`diff-adversary: args arrived as a non-JSON string (${raw.slice(0, 80)}); ignoring it and reading the diff from disk.`)
      return {}
    }
  }
  return {}
})()

const sid = (ARGS.screen_id || ARGS.id) ? String(ARGS.screen_id || ARGS.id) : ''
const root = ARGS.root ? String(ARGS.root) : '.'

// The four questions. These names are quoted literals on purpose: they are the agent files under
// .claude/agents/, and validate-structure.sh extracts them lexically to prove this list matches the
// roster on disk. Deriving them at runtime would make the set invisible to that check.
const ADVERSARIES = [
  'diff-adversary-regression',
  'diff-adversary-incomplete',
  'diff-adversary-unreachable',
  'diff-adversary-edge',
]

// No context-loader here, deliberately. Every other fan-out has one because it must RESOLVE which
// unit is active out of a large state file. This one has nothing to resolve: it runs inline in a
// repair the conductor is already holding, so the id and the diff path are known facts, not a
// lookup. `pantalla-reviewer` is the precedent — REVIEW is a single Agent() call with its context
// passed in, no loader. A loader here would be one more subagent per repair buying nothing.

// Degrade, never throw. Its charter says this step blocks nothing, and a workflow that throws IS a
// block: the conductor gets an error where the contract promised, at worst, an unasked question.
// Every other fan-out throws on a bad load for the opposite reason — they ARE the evidence, so a
// silent wrong-unit run would be fabricated. This one is not evidence, so the failure mode differs:
// say loudly that the questions went unasked, return not-clean, and let VERIFY do its job.
if (!sid) {
  log('diff-adversary: no args.screen_id, so there is no diff to read and the four questions go unasked. This step never blocks a unit — proceed to VERIFY, but do not read the pass as adversary-clean.')
  return { screen_id: null, clean: false, findings: [], answered: [], failed_adversaries: ADVERSARIES, retried_adversaries: [], not_run_reason: 'no screen_id' }
}

const DIFF_PATH = `.orchestrator-state/evidence/${sid}/logs/repair-diff.patch`


// A finding is REQUIRED to be structured, and that is not tidiness — it is the only way to tell
// "ran and found nothing" from "did not run". In every other fan-out a synthesizer absorbs that
// distinction; here there is none, and the two readings have opposite consequences: the first means
// launch VERIFY, the second means an adversary silently skipped its question. Schema-forcing the
// verdict makes an empty return impossible to mistake for a clean one.
const FINDING_SCHEMA = {
  type: 'object',
  additionalProperties: true,
  required: ['verdict', 'findings'],
  properties: {
    verdict: { type: 'string', enum: ['nothing_found', 'found'] },
    findings: { type: 'array', items: { type: 'object', additionalProperties: true } },
  },
}

const prompt = (name) => [
  `DIFF ADVERSARY ${name} for unit ${sid}. Repo root: ${root}.`,
  '',
  `Read the repair diff at ${DIFF_PATH}. Its first line is a "# iteration: <n>" header; everything`,
  'after it is the literal diff of the repair that was just made. That diff is your ENTIRE subject.',
  '',
  'Ask ONLY the one question your own agent file defines. Grep outward when your question requires',
  'it — a thing is unreachable, or a caller is affected, only relative to code the diff did not',
  'touch — but never audit anything the diff did not cause.',
  '',
  '**The bar is on the finding, not on the count.** Report what this diff actually did: if that is',
  'nothing, set verdict: nothing_found with an empty findings list — a complete, correct answer. If',
  'it is three things, report three. Neither number is a target and no rate is expected of you.',
  'Do not pad to look useful and do not suppress to look disciplined. What a finding must clear is',
  'the bar: concrete, falsifiable, caused by THIS diff. Style, naming, preference, missing test',
  'coverage nobody asked for and alternative designs never clear it and must never be reported.',
  '',
  'Return the structured object your agent file specifies.',
].join('\n')

phase('Adversary')

// All four in parallel: every one is restricted to Read/Grep/Glob in its frontmatter, so none can
// run a command and there is nothing for them to collide over. They do NOT share a prompt-cache
// prefix — that needs the same agentType, and these are four different agents by design; the
// parallelism is what makes this cheap in wall clock, not caching.
const runs = await parallel(ADVERSARIES.map(a => () =>
  agent(prompt(a), { label: a, phase: 'Adversary', agentType: a, schema: FINDING_SCHEMA })
    .then(r => ({ adversary: a, result: r }))
    .catch(e => ({ adversary: a, result: null, error: String(e && e.message ? e.message : e) }))
))

// Retry once, for the same reason every other fan-out does: a transient miss is indistinguishable
// from a clean answer, and here that ambiguity is the whole risk. What it must NOT do is retry an
// agent that answered nothing_found — that is a real answer, not an empty one.
const answered = runs.filter(r => r.result && typeof r.result === 'object' && r.result.verdict)
const missing = ADVERSARIES.filter(a => !answered.some(r => r.adversary === a))
const retried = []
if (missing.length) {
  const again = (await parallel(missing.map(a => () =>
    agent(prompt(a), { label: a, phase: 'Adversary', agentType: a, schema: FINDING_SCHEMA })
      .then(r => ({ adversary: a, result: r }))
      .catch(() => ({ adversary: a, result: null }))
  ))).filter(r => r.result && r.result.verdict)
  answered.push(...again)
  retried.push(...again.map(r => r.adversary))
}

const failed = ADVERSARIES.filter(a => !answered.some(r => r.adversary === a))
const findings = answered.flatMap(r =>
  (Array.isArray(r.result.findings) ? r.result.findings : []).map(f => ({ ...f, adversary: r.adversary })))

if (failed.length) {
  log(`diff-adversary: ${failed.join(', ')} returned nothing twice. That is NOT "found nothing" — those questions went unasked. Proceed to VERIFY (this step never blocks a unit), but do not record the pass as adversary-clean.`)
}
log(`diff-adversary: ${answered.length}/${ADVERSARIES.length} answered, ${findings.length} finding(s). ${findings.length === 0 ? 'Clean — fold nothing, launch VERIFY.' : 'Fold these into THIS repair pass before launching VERIFY; do not re-run this workflow to check its own fix.'}`)

// `clean` is deliberately three-valued in effect: true only when all four ANSWERED and none found
// anything. A pass where an adversary died is never "clean" — that is the silent failure this
// return shape exists to make loud.
return {
  screen_id: sid,
  clean: failed.length === 0 && findings.length === 0,
  findings,
  answered: answered.map(r => ({ adversary: r.adversary, verdict: r.result.verdict })),
  failed_adversaries: failed,
  retried_adversaries: retried,
}
