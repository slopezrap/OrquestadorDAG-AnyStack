export const meta = {
  name: 'arch-review',
  description: 'ARCHITECTURE gate at time zero (documents only, no code yet). Runs inside /init-build after COMPILE and BEFORE features.json is written, so the loader does NOT read features.json: a read-only loader inventories blueprint/ directly (PRODUCT, SCREENS, logic layers, ORIGINAL/DECISIONS presence, unresolved stack placeholders). Then fan out 6 arch-* lens-agents in parallel (fit, data-model, identity, engines, pipelines, risk) over the blueprint documents, and a read-only synthesis reducer collapses their findings into ONE digest for orchestrator-flow, which writes the report and meta.architecture_review. research-* owns the ABSENCE, arch-* owns the ERROR. Reports and recommends; never emits a lifecycle verdict, never touches state, and its lenses NEVER enter phase_runs[].',
  phases: [
    { title: 'Load', detail: 'read-only loader inventories blueprint/ from disk (no features.json yet at time zero)' },
    { title: 'Lenses', detail: 'arch-* agents in parallel (fit/data-model/identity/engines/pipelines/risk)' },
    { title: 'Synthesize', detail: 'read-only reducer → one digest (open_blockers, findings, proposed_foundations, recommendations)' },
  ],
}

// Disk-first context: do NOT depend on the caller passing args correctly. args is only an
// optional hint (e.g. the COMPILE digest summary); correctness comes from blueprint/ on disk.
// This workflow runs at TIME ZERO: features.json does not exist yet, so blueprint/ is the subject.
const hint = (args && args.hint) ? String(args.hint) : null
const root = (args && args.root) ? String(args.root) : '.'

const CTX_SCHEMA = {
  type: 'object', additionalProperties: false,
  required: ['ok', 'layers', 'original_md', 'decisions_md', 'stack_placeholders'],
  properties: {
    ok: { type: 'boolean' },
    error: { type: 'string' },
    layers: { type: 'array', items: { type: 'string' } },
    original_md: { type: 'boolean' },
    decisions_md: { type: 'boolean' },
    stack_placeholders: { type: 'array', items: { type: 'string' } },
  },
}

phase('Load')
const ctx = await agent(
  `CONTEXT LOADER (read-only; read ONLY from disk under ${root}; never guess or invent). This runs at TIME ZERO inside /init-build, after COMPILE and BEFORE features.json exists — do NOT read .orchestrator-state/features.json; blueprint/ is the subject.\n` +
  `1. Check that blueprint/PRODUCT.md and blueprint/SCREENS.md exist and are non-empty. If either is missing set ok=false and error naming the missing file; otherwise set ok=true.\n` +
  `2. List the blueprint layers present as layers[]: every blueprint/logic/*.md file that exists (e.g. "logic/data.md", "logic/engine.md"), plus "PRODUCT.md" and "SCREENS.md".\n` +
  `3. Set original_md / decisions_md to whether blueprint/ORIGINAL.md and blueprint/DECISIONS.md exist.\n` +
  `4. Read .claude/rules/stack.md and return every unresolved <COMMAND_*> placeholder token still present as stack_placeholders[] (empty array if all are resolved).\n` +
  `Write nothing. Return the structured object.`,
  { label: 'load-blueprint', phase: 'Load', schema: CTX_SCHEMA, agentType: 'context-loader', model: 'haiku', effort: 'low' }
)

// Fail LOUD instead of silently reviewing an absent blueprint (a clear verdict over zero
// documents is worse than no review). Same discipline as audit-architecture/validate-live.
if (!ctx || !ctx.ok || !Array.isArray(ctx.layers) || ctx.layers.length === 0) {
  throw new Error(`arch-review: nothing to review — ${ctx && ctx.error ? ctx.error : 'blueprint/PRODUCT.md or blueprint/SCREENS.md is missing'}. Fill the blueprint and re-run /init-build; this gate does not degrade to an empty blueprint.`)
}

// 6 document lenses at time zero. They judge the DESIGN while changing it is still free:
// store/architecture fit, data-model retrofit traps, tenancy/identity, engine decomposition,
// pipeline guarantee semantics, and the one adversarial lens (dominant failure mode).
const LENSES = [
  'arch-fit', 'arch-data-model', 'arch-identity',
  'arch-engines', 'arch-pipelines', 'arch-risk',
]

const inventoryJson = JSON.stringify({
  layers: ctx.layers,
  original_md: ctx.original_md,
  decisions_md: ctx.decisions_md,
  stack_placeholders: ctx.stack_placeholders || [],
})

phase('Lenses')
const results = await parallel(LENSES.map(a => () =>
  agent(
    `ARCHITECTURE lens ${a} over the WHOLE blueprint at TIME ZERO (documents only — no code exists yet). Repo root: ${root}. Judge the blueprint documents per your spec. research-* owns the ABSENCE, arch-* owns the ERROR: a field that is undeclared or identical to its template default is ABSENCE — return n/a for it, never a blocker. You REPORT: you do not repair, you do not write state, and your findings NEVER enter phase_runs[] or any result.json. Every finding cites a doc_ref (file + ID). A blocker is ONLY a one-way door and MUST carry retrofit_cost (what would have to be rewritten later); without retrofit_cost it is major at most. Also return undecided_fields[]: the fields you consulted that are still template defaults or undecided — a finding whose only support is an undecided field is not a finding.\n\nBlueprint inventory: ${inventoryJson}${hint ? `\n\nCOMPILE hint (context only, disk wins): ${hint}` : ''}`,
    { label: a, phase: 'Lenses', agentType: a }
  ).then(r => ({ lens: a, result: r }))
))
const lenses = results.filter(r => r && r.result)
// A lens whose agent returned nothing must surface in failed_lenses[]/unmerged[], never vanish silently.
const failed_lenses = LENSES.filter(a => !lenses.some(l => l.lens === a))

const DIGEST = {
  type: 'object', additionalProperties: false,
  required: ['scope', 'undecided_fields_count', 'open_blockers', 'findings', 'recommendations', 'proposed_foundations', 'source_refs', 'failed_lenses', 'unmerged'],
  properties: {
    scope: { type: 'object', additionalProperties: true },
    undecided_fields_count: { type: 'number' },
    open_blockers: { type: 'array', items: { type: 'object', additionalProperties: true } },
    findings: { type: 'array', items: { type: 'object', additionalProperties: true } },
    recommendations: { type: 'array', items: { type: 'object', additionalProperties: true } },
    proposed_foundations: { type: 'array', items: { type: 'object', additionalProperties: true } },
    source_refs: { type: 'array', items: { type: 'object', additionalProperties: true } },
    failed_lenses: { type: 'array', items: { type: 'string' } },
    unmerged: { type: 'array', items: { type: 'object', additionalProperties: true } },
  },
}

phase('Synthesize')
const digest = await agent(
  `You are a READ-ONLY synthesis reducer for the ARCHITECTURE gate at time zero. Consolidate the per-lens results below into ONE digest. You WRITE NOTHING (no files, no state, no result.json) and you emit NO lifecycle verdict — this gate REPORTS; orchestrator-flow writes the report and meta.architecture_review. research-* owns the ABSENCE, arch-* owns the ERROR.\nRules: scope = {layers, lenses run} actually covered — copy from the loader inventory, never widen it. Discard every finding whose ONLY support is an undecided field (a value still equal to its template default) and report those as undecided_fields_count instead — "N fields undecided" is the useful message, not 200 findings over defaults. open_blockers[]: ONLY one-way doors carrying retrofit_cost (what would have to be rewritten later); a blocker without retrofit_cost is demoted to a major finding; cap at 3 globally, ranked by retrofit_cost; mark every finding downstream of an arch-fit blocker with conditional:true. findings[]: merge all lens findings, sort blocker→nit, dedupe by (ref, detail), keep each finding's lens, severity, retrofit_cost when present and doc_refs (cited files + IDs); a finding without a concrete file/ID behind it is dropped, not softened. proposed_foundations[]: the SCR-FOUNDATION-* units the lenses propose {id, title, rationale, refs} — proposals only; orchestrator-flow writes SCREENS.md. recommendations: proposals for the conductor {action, target, rationale, refs}, phrased as options (foundation, CLARIFY, accepted_with_risk, deferred) — you decide nothing. source_refs[]: the blueprint files + IDs cited across the findings, a navigable index so orchestrator-flow can re-open the source. If any lens output is missing/unparseable, list it in unmerged[] rather than guessing. Copy the lens names below into failed_lenses[] verbatim and also list each in unmerged[] with reason "no result returned" — a degraded review must be visible in the report, never silently smaller.\n\nLenses that returned NO result: ${JSON.stringify(failed_lenses)}\n\nBlueprint inventory: ${inventoryJson}\n\nLens results:\n${JSON.stringify(lenses, null, 1)}`,
  { label: 'synthesize', phase: 'Synthesize', schema: DIGEST, agentType: 'arch-synthesizer' }
)


// A synthesizer that returns nothing must not travel on as `{digest: undefined}`: the
// conductor would consume an absent digest as if the phase had produced one.
if (!digest) {
  throw new Error(`arch-review: the synthesis reducer returned no digest for the architecture review. Re-run the workflow; a phase that produced no digest must not be reported as if it had.`)
}

// orchestrator-flow consumes `digest` and writes the report + meta.architecture_review. This
// workflow is advisory at time zero: it reports, it does not block, it changes no state, and
// its lenses NEVER enter phase_runs[] or add checks to any result.json. `lenses` kept for traceability.
return { inventory: JSON.parse(inventoryJson), digest, lenses, failed_lenses }
