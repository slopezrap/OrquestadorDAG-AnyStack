export const meta = {
  name: 'verify-fanout',
  description: 'Phase 3 VERIFY (static, against the documents) for one unit. Disk-first: a read-only loader reads .orchestrator-state/features.json and returns the single building unit’s context (args is only an optional hint). Then fan out 10 specialized lens-agents in parallel (tests, conformance, design, frontend, engine, pipeline, logs, quality, coherence, blueprint-drift), and a read-only synthesis reducer collapses their findings into ONE digest for orchestrator-flow (advisory verdict + literal values lifted verbatim). The conductor consolidates result.json and decides; this never emits a lifecycle verdict.',
  phases: [
    { title: 'Load', detail: 'read-only loader resolves the active unit + feature_excerpt from disk, and classifies the lenses documentary/executing from their tools: frontmatter' },
    { title: 'Lenses', detail: 'the same 10 verify-* agents: read-only ones in parallel, command-running ones serialized so they cannot collide over the tree/store/ports' },
    { title: 'Synthesize', detail: 'read-only reducer → one digest (advisory static verdict, observed literals, expected_ui_values, contradicts_prior_claim)' },
  ],
}

// Disk-first context: do NOT depend on the caller passing args correctly. args is only an
// optional hint for WHICH unit/root; correctness comes from .orchestrator-state on disk.
const hint = (args && (args.screen_id || args.id)) ? String(args.screen_id || args.id) : null
const root = (args && args.root) ? String(args.root) : '.'

// 10 static lenses; verify-engine returns db_value, verify-pipeline returns api_value + expected_ui_values,
// verify-coherence compares against the shell contract (UI-SHELL-*) and the sibling verified/accepted screens.
// Declared BEFORE the loader because the loader is asked to classify these exact names (const is not hoisted).
// These names must stay written here as quoted literals: validate-structure.sh extracts them lexically from
// this file to prove the fan-out set matches VERIFY_LENSES in validate-state.py. Deriving them at runtime
// would make the set invisible to that check and silently break the sync gate.
const LENSES = [
  'verify-tests', 'verify-conformance', 'verify-design', 'verify-frontend',
  'verify-engine', 'verify-pipeline', 'verify-logs', 'verify-quality',
  'verify-coherence', 'verify-blueprint-drift',
]

// The same 10 names, split by CAPABILITY. See the isolation note at the Lenses phase.
// DOCUMENTARY = restricted to read-only tools in its agent frontmatter, so it cannot run a
// command and has nothing to collide over. Everything else executes and must be serialized.
//
// Why literal lists and not derived here: a Workflow script has NO filesystem access, so this
// .js cannot open .claude/agents/*.md to read `tools:`. It could ask an agent to do it — but
// that puts an LLM's reading of YAML in the scheduler's decision path on every single run, and
// a mis-classification silently re-creates the exact collision this exists to prevent. A literal
// list is deterministic. The anti-drift lives in .orchestrator/scripts/validate-structure.sh,
// which DOES read files: it re-derives this split from the agents' frontmatter and fails loudly
// when these lists disagree with it. Loud at gate time beats silent at runtime.
const DOCUMENTARY_LENSES = [
  'verify-conformance', 'verify-design', 'verify-coherence', 'verify-blueprint-drift',
]

const CTX_SCHEMA = {
  type: 'object', additionalProperties: false,
  required: ['ok', 'screen_id', 'feature_excerpt'],
  properties: {
    ok: { type: 'boolean' },
    error: { type: 'string' },
    screen_id: { type: 'string' },
    slug: { type: 'string' },
    title: { type: 'string' },
    feature_excerpt: { type: 'object', additionalProperties: true },
  },
}

phase('Load')
const ctx = await agent(
  `CONTEXT LOADER (read-only; read ONLY from disk under ${root}; never guess or invent).\n` +
  `1. Read .orchestrator-state/features.json (the screens[] array is the runtime plan).\n` +
  `2. Select the active unit: ${hint ? `the screen whose id === "${hint}"` : 'the single screen whose status === "building" (validate-state.py guarantees at most one)'}. ` +
  `If exactly one matches set ok=true; otherwise set ok=false, screen_id="" and error="<n> screens matched: <ids>".\n` +
  `3. Return its id (as screen_id), slug, title and a compact feature_excerpt {kind, platforms, acceptance, applies, data_engine, architecture, design_ref} lifted VERBATIM from the unit.\n` +
  `Write nothing. Return the structured object.`,
  { label: 'load-context', phase: 'Load', schema: CTX_SCHEMA, agentType: 'context-loader', model: 'haiku', effort: 'low' }
)

// Fail LOUD instead of silently degrading to '<unit>'/{} (10 lenses verifying an empty feature
// return a complete lens set with nothing behind it, and the STATE GATE accepts it).
if (!ctx || !ctx.ok || !ctx.screen_id) {
  throw new Error(`verify-fanout: could not load the active unit from disk — ${ctx && ctx.error ? ctx.error : 'no unit is building'}. Leave exactly one unit in status:"building" (or pass args.screen_id) and re-run; this workflow no longer degrades to <unit>/{}.`)
}

const sid = ctx.screen_id

// ---------------------------------------------------------------------------------------------
// SCOPED RE-RUN (optional; triage only, never evidence).
// After a repair, re-running all 10 lenses to re-check a docs-only or scaffolding-only change is
// the single most expensive habit in the loop. args.scope_to lets the conductor re-run just the
// lenses whose scope intersects the change. HARD RULE: a scoped pass is NOT a fan-out phase and
// may never be recorded in result.json.phase_runs[] — the returned `full_set:false` says so, and
// validate-state.py independently rejects a partial VERIFY lens set, so a scoped pass cannot be
// laundered into a PASS. The last VERIFY before a unit closes must be a full one.
// ---------------------------------------------------------------------------------------------
// ---------------------------------------------------------------------------------------------
// PROPORTIONALITY — the repair pass must cost what the repair was worth.
//
// The measured problem: re-running all 10 lenses to re-check a one-line or docs-only fix was the
// single most expensive habit in the loop, and most of those lenses had nothing in scope. The fix
// is NOT to run fewer lenses — the set stays at 10 and the phase stays recordable in phase_runs[].
// The fix is to stop each lens re-discovering the whole repo when it can see, in one line, that
// nothing it owns moved.
//
// args.changed_files carries what the repair actually touched (the conductor computes it from the
// DEVELOP checkpoint; it cannot be derived here — a Workflow script has no filesystem access and
// the read-only loader has no Bash). Empty means BASELINE: a first or closing pass, full work.
//
// The lens decides, not the caller. We hand it the facts and its own contract judges whether its
// scope intersects — because a file list looks unrelated right up until a shared component moves
// under verify-coherence's feet. Deciding for it, from out here, is exactly the kind of guess that
// turns a cheap pass into a missed defect.
const changedRaw = Array.isArray(args && args.changed_files) ? args.changed_files.filter(f => typeof f === 'string' && f) : []
// A repair touching hundreds of files is not a small repair: past this point the list stops being
// a focusing aid and just bloats 10 prompts, so fall back to a baseline pass and say so.
const CHANGED_CAP = 150
const changed = changedRaw.length > CHANGED_CAP ? [] : changedRaw
if (changedRaw.length > CHANGED_CAP) log(`verify-fanout: ${changedRaw.length} changed files exceeds the ${CHANGED_CAP}-file cap — running as a BASELINE pass (no scope hint). A change this size is not a small repair.`)

const scopeTo = Array.isArray(args && args.scope_to) ? args.scope_to.filter(a => LENSES.includes(a)) : []
const ACTIVE = scopeTo.length ? scopeTo : LENSES
const full_set = ACTIVE.length === LENSES.length
if (!full_set) log(`verify-fanout: SCOPED re-run (${ACTIVE.length}/${LENSES.length} lenses) — triage only, NOT recordable in phase_runs[]; a full pass is still required before close.`)

// ---------------------------------------------------------------------------------------------
// ISOLATION — why executing lenses are serialized and documentary ones stay parallel.
//
// Several VERIFY lenses compile, run the suite, start the app or write to the shared test store.
// Claude Code subagents are isolated in CONTEXT, not on the machine: they share one working tree,
// one set of ports and one store. Two of them running at once produce failures that belong to the
// neighbour — tests that fail and then pass alone, half-built apps, one lens's data poisoning
// another's read. That does not just cost a debugger iteration; it teaches the conductor that a
// failure might not be real, and a signal nobody must act on is worse than no signal.
//
// The partition is declared literally above (DOCUMENTARY_LENSES) and its truth is enforced OUT
// OF BAND: validate-structure.sh re-derives it from each agent's `tools:` frontmatter and fails
// when the two disagree. The constitution already names that frontmatter field the only real
// guarantee — a workflow subagent runs with edits auto-approved, so prose asking a lens not to
// write controls nothing. Keeping the list here and the check there is deliberate: the scheduler
// stays deterministic, and drift is caught loudly at gate time instead of silently at runtime.
//
// STRATEGY: a serialized stage for the executing lenses; the documentary ones keep running in
// parallel (they are read-only, so there is nothing for them to collide over).
//   - Rejected — worktree isolation per lens: it isolates the FILE TREE, which is only half the
//     problem. The shared test store, the ports and the running app live outside the worktree, so
//     the data contamination survives it. It also costs a worktree per lens, and it would strand
//     each lens's evidence artifacts in a throwaway tree instead of .orchestrator-state/evidence/.
//   - Rejected — one executor whose artifact the others consume: it collapses distinct lens
//     contracts into one agent's judgement. The 10 lenses would stop being 10 independent
//     verifications, and phase_runs[] would be recording a set that no longer ran as a set.
//   - Chosen — serialize: it removes every shared-resource collision, keeps all 10 lenses running
//     with their own contracts and their own evidence, and needs no new machinery. It costs wall
//     clock on the executing half only. That is the right thing to trade for a trustworthy signal.
// ---------------------------------------------------------------------------------------------
const documentary = new Set(DOCUMENTARY_LENSES)
const DOC_LENSES = ACTIVE.filter(a => documentary.has(a))
const EXEC_LENSES = ACTIVE.filter(a => !documentary.has(a))

// On a repair pass the lens gets the file list and judges its own relevance. Note what this is
// NOT: it is not permission to skip. A lens that re-affirms a prior verdict must say it did so and
// why nothing in its scope moved — that is a real verdict a reader can challenge, and it is the
// difference between a cheap pass and a fabricated one.
const scopeHint = changed.length
  ? `\n\nREPAIR PASS — these are the ONLY files this repair touched:\n${changed.map(f => `  ${f}`).join('\n')}\n` +
    `Judge for YOURSELF whether any of them falls in your scope; you own that call, nobody upstream made it for you. If your scope is genuinely untouched, do NOT re-derive your whole analysis: re-affirm your previous verdict, state that no file in your scope changed, and name the scope you checked. If ANY of them touches your concern — directly, or through something you compare against, such as a shared component, a token file or a sibling screen's contract — do the full work as usual. When you cannot tell, do the full work: the cost of a redundant check is minutes, the cost of a missed regression is a wrong PASS.`
  : `\n\nBASELINE PASS — no repair scope given. Do the full work per your spec.`

const lensPrompt = a =>
  `VERIFY (static) lens ${a} for screen ${sid}. Repo root: ${root}. Verify against the documents per your spec — do NOT drive the live UI (that is VALIDATE).${scopeHint}\n\nFeature: ${JSON.stringify(ctx.feature_excerpt)}`

phase('Lenses')
// Documentary lenses: read-only, no shared resource, safe to fan out.
const docRuns = await parallel(DOC_LENSES.map(a => () =>
  agent(lensPrompt(a), { label: a, phase: 'Lenses', agentType: a }).then(r => ({ lens: a, result: r }))
))

// Executing lenses: one at a time, each with sole ownership of the tree/store/ports while it runs.
// A throw here must not kill the phase — a dead lens has to surface in failed_lenses[], exactly as
// parallel() would have reported it, so the conductor retries it once and then blocks.
const execRuns = []
for (const a of EXEC_LENSES) {
  try {
    const r = await agent(lensPrompt(a), { label: a, phase: 'Lenses', agentType: a })
    execRuns.push({ lens: a, result: r })
  } catch (e) {
    execRuns.push({ lens: a, result: null, error: String(e && e.message ? e.message : e) })
  }
}

const lenses = [...docRuns, ...execRuns].filter(r => r && r.result)
// A lens whose agent returned nothing must surface in unmerged[], never vanish silently.
const failed_lenses = ACTIVE.filter(a => !lenses.some(l => l.lens === a))

const DIGEST = {
  type: 'object', additionalProperties: false,
  // contradicts_prior_claim is REQUIRED, not optional-when-empty: an absent field reads as
  // "not checked" and an empty one reads as "checked, nothing found". Only the second is true,
  // and the conductor cannot tell them apart after the fact.
  required: ['screen_id', 'static_verdict', 'verdict_by_lens', 'findings', 'observed_values', 'expected_ui_values', 'artifacts', 'source_refs', 'contradicts_prior_claim', 'unmerged'],
  properties: {
    screen_id: { type: 'string' },
    static_verdict: { type: 'string', enum: ['pass', 'fail', 'n/a'] },
    verdict_by_lens: { type: 'array', items: { type: 'object', additionalProperties: true } },
    findings: { type: 'array', items: { type: 'object', additionalProperties: true } },
    observed_values: { type: 'object', additionalProperties: true },
    expected_ui_values: { type: 'array', items: { type: 'object', additionalProperties: true } },
    artifacts: { type: 'array', items: { type: 'string' } },
    source_refs: { type: 'array', items: { type: 'object', additionalProperties: true } },
    contradicts_prior_claim: { type: 'array', items: { type: 'object', additionalProperties: true } },
    unmerged: { type: 'array', items: { type: 'object', additionalProperties: true } },
  },
}

phase('Synthesize')
const digest = await agent(
  `You are a READ-ONLY synthesis reducer for the VERIFY phase of screen ${sid}. Consolidate the per-lens results below into ONE digest. You WRITE NOTHING (no files, no state, no result.json) and you do NOT emit a lifecycle verdict — orchestrator-flow decides and writes.\nRules: static_verdict is MECHANICAL + ADVISORY only — fail if ANY lens is fail, n/a if all are n/a, else pass (the conductor may override). findings: merge all lens findings, sort blocker→nit, dedupe by (acceptance_ref, detail), keep each finding's lens. observed_values {db_value, api_value} and expected_ui_values[] must be lifted VERBATIM from the verify-engine / verify-pipeline lenses (they are load-bearing for VALIDATE derives-from and the validator's same_value recompute — never paraphrase or invent). artifacts: union of artifact paths. If any lens output is missing/unparseable, list it in unmerged[] rather than guessing. Also list every lens named below as returning no result in unmerged[] with reason "no result returned". Keep each finding's acceptance_ref and doc_refs (the cited blueprint rule IDs); also build source_refs[] = the blueprint rule IDs + files cited across the findings, a navigable index so orchestrator-flow can re-open the source rule when repairing.\ncontradicts_prior_claim[]: ALWAYS emit it, empty when there is nothing. One entry per lens finding that contradicts a recorded DEC-* decision, a blueprint assertion or an earlier verdict — {lens, finding_quote, finding_evidence, contradicted_claim_quote, contradicted_claim_source} — with BOTH quotes literal/verbatim (a paraphrased disagreement is a lost disagreement). Also enter here any lens asserting a NEGATIVE ("does not exist / is not supported / I ran it and it failed") WITHOUT the exact command, its literal output and an artifact path: the evidence standard gives a negative the same burden as a PASS, so an unproven one may not reach result.json or blueprint/**. Flag, never adjudicate.\n\nLenses that returned NO result: ${JSON.stringify(failed_lenses)}\n\nLens results:\n${JSON.stringify(lenses, null, 1)}`,
  { label: 'synthesize', phase: 'Synthesize', schema: DIGEST, agentType: 'verify-synthesizer' }
)

// The digest carries the observed literals VALIDATE derives from: returning `digest: undefined`
// would close VERIFY on nothing. Fail LOUD, and say how many lenses had already returned.
if (!digest || typeof digest !== 'object') {
  throw new Error(`verify-fanout: the synthesizer returned no digest for ${sid} (${lenses.length}/${ACTIVE.length} lenses returned). Re-run the workflow; orchestrator-flow must never receive digest:undefined and must not persist expected_ui_values from an empty VERIFY.`)
}

// orchestrator-flow consumes `digest`, writes the consolidated result.json and decides; pantalla-reviewer
// remains the sole contractual REVIEW verdict; validate-state.py remains the only gate. `lenses` kept for traceability.
// `full_set` is the honesty flag for phase_runs[]: false means this was a scoped triage pass and MUST NOT be
// recorded as a VERIFY phase. `lenses_run` is what actually ran, so the conductor never records a name it did not get.
// `scoped_to_changes` records that the lenses were given a repair scope. It does NOT weaken the
// pass: all 10 ran and each judged its own relevance, so this stays a full, recordable VERIFY.
return { screen_id: sid, digest, lenses, failed_lenses, full_set, lenses_run: ACTIVE, documentary_lenses: DOC_LENSES, serialized_lenses: EXEC_LENSES, scoped_to_changes: changed }
