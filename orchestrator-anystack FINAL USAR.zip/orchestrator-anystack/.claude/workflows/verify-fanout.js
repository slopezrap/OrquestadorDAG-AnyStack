export const meta = {
  name: 'verify-fanout',
  description: 'Phase 3 VERIFY (static, against the documents) for one unit. Disk-first: a read-only loader reads .orchestrator-state/features.json and returns the single building unit’s context (args is only an optional hint). Then fan out 10 specialized lens-agents in parallel (tests, conformance, design, frontend, engine, pipeline, logs, quality, coherence, blueprint-drift), and a read-only synthesis reducer collapses their findings into ONE digest for orchestrator-flow (advisory verdict + literal values lifted verbatim). The conductor consolidates result.json and decides; this never emits a lifecycle verdict.',
  phases: [
    { title: 'Load', detail: 'read-only loader resolves the active unit + feature_excerpt from disk, and classifies the lenses documentary/executing from their tools: frontmatter' },
    { title: 'Lenses', detail: 'the same 10 verify-* agents: read-only ones in parallel, command-running ones serialized so they cannot collide over the tree/store/ports' },
    { title: 'Synthesize', detail: 'read-only reducer → one digest (advisory static verdict, observed literals, expected_ui_values, contradicts_prior_claim)' },
  ],
}

// ---------------------------------------------------------------------------------------------
// `args` NORMALISATION — do not remove, and do not assume it is an object.
//
// MEASURED IN THIS BUILD: `typeof args === "string"`. The harness hands the script a JSON
// STRING, not the object the tool contract describes. Every `args.screen_id`, `args.root`,
// `args.changed_files`, `args.scope_to` and `args.fail_fast` was therefore `undefined` —
// reading a property off a String silently yields undefined rather than throwing.
//
// It hid for as long as it did because the failure was INVISIBLE and pointed the safe way:
// each workflow fell back to its disk-first default ("the single unit in `building`") and ran
// correctly on the right unit, so nothing broke. What silently stopped working was every
// OPTIONAL argument — the whole repair-scoping optimisation of next-pantalla §5 never once
// took effect, and `fail_fast` never once stopped a chain.
//
// Parse defensively: a non-JSON string is not an error to throw on, it is an argument to
// ignore — the loader still resolves the truth from disk. But say so out loud, because an
// argument that vanishes without a word is exactly what produced this bug.
// ---------------------------------------------------------------------------------------------
const ARGS = (() => {
  if (args === undefined || args === null) return {}
  if (typeof args === 'object') return args
  if (typeof args === 'string') {
    const raw = args.trim()
    if (!raw) return {}
    try {
      const parsed = JSON.parse(raw)
      return (parsed && typeof parsed === 'object') ? parsed : {}
    } catch (e) {
      log(`verify-fanout: args arrived as a string that is not JSON (${raw.slice(0, 80)}); ignoring it. Everything load-bearing is read from disk, so this degrades to a default run rather than a wrong one.`)
      return {}
    }
  }
  return {}
})()

// Disk-first context: do NOT depend on the caller passing args correctly. args is only an
// optional hint for WHICH unit/root; correctness comes from .orchestrator-state on disk.
const hint = (ARGS.screen_id || ARGS.id) ? String(ARGS.screen_id || ARGS.id) : null
const root = ARGS.root ? String(ARGS.root) : '.'

// 10 static lenses; verify-engine returns db_value, verify-pipeline returns api_value + expected_ui_values,
// verify-coherence compares against the shell contract (UI-SHELL-*) and the sibling verified/accepted screens.
// Declared BEFORE the loader because the loader is asked to classify these exact names (const is not hoisted).
// These names must stay written here as quoted literals: validate-structure.sh extracts them lexically from
// this file to prove the fan-out set matches VERIFY_LENSES in validate-state.py. Deriving them at runtime
// would make the set invisible to that check and silently break the sync gate.
// ORDER MATTERS for the serialized half: EXEC_LENSES is derived from this list by filtering
// out the documentary ones, so it inherits this order. verify-frontend is FIRST on purpose —
// it is the cheapest executing lens and it fails on the thing that invalidates everything
// downstream (the code does not build). Running it ahead of verify-tests costs nothing when
// the build is fine (the serial sum is unchanged) and saves the rest of the chain when it is
// not. Both sync gates compare SETS, not sequences (validate-structure.sh builds a set() from
// a lexical scan, and VERIFY_LENSES in validate-state.py is a set), so reordering is safe.
const LENSES = [
  'verify-frontend', 'verify-tests', 'verify-conformance', 'verify-design',
  'verify-engine', 'verify-pipeline', 'verify-logs', 'verify-quality',
  'verify-coherence', 'verify-blueprint-drift',
]

// The same 10 names, split by CAPABILITY. See the isolation note at the Lenses phase.
// DOCUMENTARY = restricted to read-only tools in its agent frontmatter, so it cannot run a
// command and has nothing to collide over. Everything else executes and must be serialized.
//
// Why literal lists and not derived here: a Workflow script has NO filesystem access, so this
// .js cannot open .claude/agents/*.md to read `tools:`. It could ask an agent to do it — but
// that puts an LLM's reading of YAML in the scheduler's decision path on every single run, and
// a mis-classification silently re-creates the exact collision this exists to prevent. A literal
// list is deterministic. The anti-drift lives in .orchestrator/scripts/validate-structure.sh,
// which DOES read files: it re-derives this split from the agents' frontmatter and fails loudly
// when these lists disagree with it. Loud at gate time beats silent at runtime.
const DOCUMENTARY_LENSES = [
  'verify-conformance', 'verify-design', 'verify-coherence', 'verify-blueprint-drift',
]

const CTX_SCHEMA = {
  type: 'object', additionalProperties: false,
  required: ['ok', 'screen_id', 'feature_excerpt'],
  properties: {
    ok: { type: 'boolean' },
    error: { type: 'string' },
    screen_id: { type: 'string' },
    slug: { type: 'string' },
    title: { type: 'string' },
    feature_excerpt: { type: 'object', additionalProperties: true },
    checkpoint_iteration: { type: 'number' },
    changed_files_on_disk: { type: 'array', items: { type: 'string' } },
    changed_files_iteration: { type: 'number' },
    triage_fail_fast: { type: 'boolean' },
    triage_scope_to: { type: 'array', items: { type: 'string' } },
    triage_full_verify: { type: 'boolean' },
  },
}

phase('Load')
const ctx = await agent(
  `CONTEXT LOADER (read-only; read ONLY from disk under ${root}; never guess or invent).\n` +
  `1. Read .orchestrator-state/features.json (the screens[] array is the runtime plan).\n` +
  `2. Select the active unit: ${hint ? `the screen whose id === "${hint}"` : 'the single screen whose status === "building" (validate-state.py guarantees at most one)'}. ` +
  `If exactly one matches set ok=true; otherwise set ok=false, screen_id="" and error="<n> screens matched: <ids>".\n` +
  `3. Return its id (as screen_id), slug, title and a compact feature_excerpt {kind, platforms, acceptance, applies, data_engine, architecture, design_ref} lifted VERBATIM from the unit. Also return the unit's checkpoint.iteration as checkpoint_iteration (0 when absent).\n` +
  `4. REPAIR SCOPE FROM DISK. Try to read .orchestrator-state/evidence/<screen_id>/logs/changed-files.txt. If it does not exist, return changed_files_on_disk=[] and changed_files_iteration=-1 — that is normal and means a baseline pass. If it exists: its first line SHOULD be a header of the form "# iteration: <n>"; return that <n> as changed_files_iteration (-1 if the header is missing or unparseable), and return every remaining non-empty, non-comment line as one repo-relative path in changed_files_on_disk. Copy the paths VERBATIM; do not resolve, glob, filter or invent any.\n` +
  `5. TRIAGE DIRECTIVES, from that same file's header. Return triage_fail_fast=true ONLY if a header line reads exactly "# triage: fail_fast"; otherwise false. Return triage_scope_to as the comma-separated lens names in a header line of the form "# triage: scope_to=<a>,<b>"; otherwise []. Return triage_full_verify=true ONLY if a header line reads exactly "# triage: full_verify"; otherwise false. Absent headers are the normal case — return false, [] and false. Never infer any of them from the paths. Read nothing else.\n` +
  `Write nothing. Return the structured object.`,
  { label: 'load-context', phase: 'Load', schema: CTX_SCHEMA, agentType: 'context-loader', model: 'haiku', effort: 'low' }
)

// Fail LOUD instead of silently degrading to '<unit>'/{} (10 lenses verifying an empty feature
// return a complete lens set with nothing behind it, and the STATE GATE accepts it).
if (!ctx || !ctx.ok || !ctx.screen_id) {
  throw new Error(`verify-fanout: could not load the active unit from disk — ${ctx && ctx.error ? ctx.error : 'no unit is building'}. Leave exactly one unit in status:"building" (or pass args.screen_id) and re-run; this workflow no longer degrades to <unit>/{}.`)
}

const sid = ctx.screen_id

// The hint is honoured, not merely consulted. Without this, a loader that resolves a DIFFERENT
// unit than the one asked for returns ok:true and the whole fan-out runs looking perfectly
// healthy — on the wrong screen. That failure is silent by construction: every lens reports on
// the unit it was handed, so the evidence is internally consistent and simply about something
// else. Cheap to close, and the alternative is spending full phases before anyone notices.
if (hint && sid !== hint) {
  throw new Error(`verify-fanout: asked for "${hint}" but the loader resolved "${sid}". Refusing to run the phase on a unit that was not requested — re-check args.screen_id and the status of both units.`)
}

// ---------------------------------------------------------------------------------------------
// SCOPED RE-RUN (optional; triage only, never evidence).
// After a repair, re-running all 10 lenses to re-check a docs-only or scaffolding-only change is
// the single most expensive habit in the loop. args.scope_to lets the conductor re-run just the
// lenses whose scope intersects the change. RULE: a scoped pass is NOT a fan-out phase, but it MAY
// be recorded in result.json.phase_runs[] as a NON-CLOSING VERIFY entry — the returned
// `full_set:false` says it did not run natively, not that it may never be written down. To record
// it, the conductor names every lens it did not re-run in that entry's `carried_forward[]`, citing
// the iteration of the last complete VERIFY pass; validate-state.py checks this mechanically
// (require_verify_fanout) and independently rejects both an incomplete VERIFY lens set with no
// carried_forward AND any carried_forward on the CLOSING entry — the last VERIFY before a unit
// closes must always be a full, untruncated pass with nothing carried forward.
// ---------------------------------------------------------------------------------------------
// ---------------------------------------------------------------------------------------------
// PROPORTIONALITY — the repair pass must cost what the repair was worth.
//
// The measured problem: re-running all 10 lenses to re-check a one-line or docs-only fix was the
// single most expensive habit in the loop, and most of those lenses had nothing in scope. The fix
// is NOT to run fewer lenses — the set stays at 10 and the phase stays recordable in phase_runs[].
// The fix is to stop each lens re-discovering the whole repo when it can see, in one line, that
// nothing it owns moved.
//
// args.changed_files carries what the repair actually touched (the conductor computes it from the
// DEVELOP checkpoint; it cannot be derived here — a Workflow script has no filesystem access and
// the read-only loader has no Bash). Empty means BASELINE: a first or closing pass, full work.
//
// The lens decides, not the caller. We hand it the facts and its own contract judges whether its
// scope intersects — because a file list looks unrelated right up until a shared component moves
// under verify-coherence's feet. Deciding for it, from out here, is exactly the kind of guess that
// turns a cheap pass into a missed defect.
// DISK FIRST, args only as a hint — the same rule this workflow already applies to screen_id,
// extended to the one argument whose loss was invisible.
//
// Measured: `args` sometimes does not reach the script at all. It is not an error and there is no
// way to tell "nothing was passed" from "something was passed and lost" — the global is simply
// `undefined` either way. When that happened, changed_files/scope_to/fail_fast all collapsed to
// empty and every repair pass silently ran as a BASELINE. It degraded toward MORE work, so it was
// correct and nobody noticed; but §5's whole "a repair should cost what the repair was worth"
// optimization was never actually running.
//
// The fix is the orchestrator's own principle. next-pantalla §5 ALREADY requires the conductor to
// save the diff to evidence/<ID>/logs/changed-files.txt with its literal output — so the fact is
// on disk, and the read-only loader can read it. args stays as a hint for callers that do get
// through; disk is what makes it survive.
const argsChanged = Array.isArray(ARGS.changed_files) ? ARGS.changed_files.filter(f => typeof f === 'string' && f) : []

// STALENESS GUARD. The file persists between passes, and a scope from iteration 2 applied to
// iteration 3 is worse than no scope at all — §5 says so plainly ("an incomplete one is worse
// than none, because ten lenses will trust it"). It is honoured only when its header names the
// iteration currently being verified; anything else is treated as absent and runs as a baseline.
const diskIter = typeof ctx.changed_files_iteration === 'number' ? ctx.changed_files_iteration : -1
const nowIter = typeof ctx.checkpoint_iteration === 'number' ? ctx.checkpoint_iteration : 0
const diskChanged = (Array.isArray(ctx.changed_files_on_disk) && diskIter === nowIter && nowIter > 0)
  ? ctx.changed_files_on_disk.filter(f => typeof f === 'string' && f)
  : []
if (Array.isArray(ctx.changed_files_on_disk) && ctx.changed_files_on_disk.length && !diskChanged.length) {
  log(`verify-fanout: ignoring changed-files.txt — it declares iteration ${diskIter} but the unit is at iteration ${nowIter}. A stale scope is worse than none; running as a BASELINE pass.`)
}

const changedRaw = argsChanged.length ? argsChanged : diskChanged
const scope_source = argsChanged.length ? 'args' : (diskChanged.length ? 'disk' : 'none')
if (!argsChanged.length && diskChanged.length) log(`verify-fanout: args carried no changed_files; recovered ${diskChanged.length} from evidence/${sid}/logs/changed-files.txt (iteration ${nowIter}).`)

// The two TRIAGE directives ride in the same file's header, behind the same freshness guard.
//
// Same root problem as changed_files — they arrive only through `args`, and `args` has been
// measured not to reach the script, silently. The consequence differs though: a lost
// changed_files costs MONEY (every repair pass re-derives everything), while a lost fail_fast
// costs WALL CLOCK — the serialized chain keeps launching lenses after one has already reported
// fail, paying the rest of the chain to be told the same thing again. On a unit that burns its
// three debugger iterations that is the largest block of dead time in the whole loop.
//
// One file, not three: all three are parameters of the SAME repair pass, written at the same
// moment by the same step, and they must go stale TOGETHER. A second file would be a second
// thing to keep in sync, which is how a freshness guard eventually gets defeated.
//
// SAFETY, stated plainly because this is the direction that could hurt: both directives force
// `full_set:false` — a pass the conductor may not write into phase_runs[], and one that
// validate-state.py independently rejects as an incomplete VERIFY. So a directive leaking into
// a closing pass wastes one run and is caught loudly; it cannot manufacture a PASS. That is what
// makes reading them from disk acceptable at all, and it is why the log lines below are not
// optional decoration.
const triageFresh = diskIter === nowIter && nowIter > 0
const diskFailFast = triageFresh && ctx.triage_fail_fast === true
const diskScopeTo = (triageFresh && Array.isArray(ctx.triage_scope_to)) ? ctx.triage_scope_to : []
// A repair touching hundreds of files is not a small repair: past this point the list stops being
// a focusing aid and just bloats 10 prompts, so fall back to a baseline pass and say so.
const CHANGED_CAP = 150
const changed = changedRaw.length > CHANGED_CAP ? [] : changedRaw
if (changedRaw.length > CHANGED_CAP) log(`verify-fanout: ${changedRaw.length} changed files exceeds the ${CHANGED_CAP}-file cap — running as a BASELINE pass (no scope hint). A change this size is not a small repair.`)

// Deduplicated: a caller listing the same lens twice would otherwise run it twice (pure waste in
// the very mechanism that exists to cut waste) and, worse, pad the count — see full_set below.
const argsScopeTo = Array.isArray(ARGS.scope_to) ? [...new Set(ARGS.scope_to.filter(a => LENSES.includes(a)))] : []
const scopeTo = argsScopeTo.length
  ? argsScopeTo
  : [...new Set(diskScopeTo.filter(a => LENSES.includes(a)))]
const scope_to_source = argsScopeTo.length ? 'args' : (scopeTo.length ? 'disk' : 'none')
if (scope_to_source === 'disk') log(`verify-fanout: scope_to recovered from the changed-files.txt header (iteration ${nowIter}): ${JSON.stringify(scopeTo)}. TRIAGE — full_set:false; recordable ONLY as a non-closing phase_runs[] entry with carried_forward[] for every lens not in this list, citing iteration ${nowIter}.`)

// ---------------------------------------------------------------------------------------------
// DOCS-ONLY DERIVATION — the one scope the workflow can compute for itself.
//
// constitution.md already states the rule, and next-pantalla §5.5 repeats it: "A repair that
// changed no implementation or test file does not re-prove the unit. When a pass touched only
// documentation, blueprint, report or evidence files, re-run the doc<->code lenses and stop."
// It was PROSE the conductor had to remember, spell out as `scope_to=...` by hand, and get right
// — so in practice every docs-only repair paid all ten lenses, six of which have nothing to look
// at. That is this repository's own rule turned on itself: what a script can decide must never
// cost a fan-out, and "did this diff touch any code?" is decidable from the file list in
// microseconds. Six subagents per docs-only round is the most mechanical waste left in the loop.
//
// The derived set is DOCUMENTARY_LENSES and not a new list on purpose: "the doc<->code lenses"
// and "the lenses restricted to read-only tools" are the same four agents, and that equality is
// already enforced out of band by validate-structure.sh against each agent's `tools:` frontmatter.
// A second hand-kept list would be a third source of truth and would drift the first time a lens
// is re-scoped. The coupling is deliberate; if a documentary lens ever gains Bash, BOTH meanings
// change together, which is the correct behaviour, not a bug.
//
// SAFETY — why this cannot manufacture a PASS, which is the only direction that would matter:
//   * it returns full_set:false, and validate-state.py hard-fails a CLOSING VERIFY entry with
//     full_set:false, and hard-fails a non-closing one whose lenses[] + carried_forward[] do not
//     cover the complete ten-lens set, citing a genuinely complete earlier pass. So the worst
//     case is one wasted run, caught loudly — never a unit closing on four lenses.
//   * it never fires on a BASELINE pass (no scope) and never on an explicit scope_to (the
//     conductor's own list wins), so the first VERIFY of a unit is untouched.
//   * `# triage: full_verify` (or args.full_verify) opts out, for the pass a conductor knows
//     will be the closing one while a docs-only scope is still on disk.
//
// The classifier is deliberately STRICT and errs toward the full pass: only genuine prose
// extensions and this unit's own evidence tree count as documentation. A .py/.js/.sh/.json/.css
// under blueprint/ or .claude/ is machinery, not prose, and takes the full ten lenses.
// Note what IS included: blueprint/**.md. A spec edit is the most consequential change in this
// repository, not the least — and the four lenses this derives to are exactly the ones that judge
// code against the spec, which is why scoping to them is the right answer rather than a shortcut.
// `.claude/**` is excluded even when it is a .md, and that exception is not pedantry: an agent
// file or a SKILL.md is the DEFINITION OF BEHAVIOUR of a lens or a command, not prose about the
// product. Editing one changes what the machinery does, which is the opposite of "no code moved"
// — so it takes the full ten lenses like any other change to executable material.
const DOC_EXTENSION = /\.(md|mdx|markdown|txt|rst|adoc)$/i
const isDocPath = f =>
  !f.startsWith('.claude/') &&
  (DOC_EXTENSION.test(f) || f.startsWith('.orchestrator-state/'))
const docsOnly = changed.length > 0 && changed.every(isDocPath)
const argsFullVerify = !!ARGS.full_verify
const fullVerify = argsFullVerify || (triageFresh && ctx.triage_full_verify === true)
let derived_scope = 'none'
let scopeToUse = scopeTo
if (!scopeTo.length && docsOnly) {
  if (fullVerify) {
    log(`verify-fanout: this repair pass is DOCS-ONLY (${changed.length} file(s), none of them implementation or test code), but full_verify was requested — running the complete ${LENSES.length}-lens set anyway. Use this on the pass you intend to be the CLOSING one.`)
  } else {
    scopeToUse = DOCUMENTARY_LENSES.slice()
    derived_scope = 'docs_only'
    log(`verify-fanout: DOCS-ONLY repair pass — every one of the ${changed.length} changed file(s) is documentation, blueprint, report or evidence, so no implementation or test code moved. Deriving the scope to the ${DOCUMENTARY_LENSES.length} doc<->code lenses (${DOCUMENTARY_LENSES.join(', ')}) per constitution.md; the other ${LENSES.length - DOCUMENTARY_LENSES.length} have nothing in scope to re-derive. TRIAGE — full_set:false; recordable ONLY as a NON-CLOSING phase_runs[] entry, with carried_forward[] naming each lens in carried_forward_lenses[] and citing the iteration of the last COMPLETE VERIFY pass. The CLOSING VERIFY must still run all ${LENSES.length} natively: clear logs/changed-files.txt, or pass "# triage: full_verify".`)
  }
}
const ACTIVE = scopeToUse.length ? scopeToUse : LENSES
// full_set is the honesty flag for phase_runs[], so it must compare SETS, not lengths. A length
// check calls ['a','a',...9 more] a full set: it would report `true` for a pass that never ran one
// of the ten. validate-state.py would still reject that downstream, but a flag whose whole job is
// to be trustworthy cannot rely on something else catching it lying.
const activeSet = new Set(ACTIVE)
const scoped_full_set = activeSet.size === LENSES.length && LENSES.every(l => activeSet.has(l))
if (!scoped_full_set) log(`verify-fanout: SCOPED re-run (${activeSet.size}/${LENSES.length} lenses) — recordable ONLY as a non-closing phase_runs[] entry, carrying the other ${LENSES.length - activeSet.size} lenses forward from the last complete pass; the CLOSING VERIFY must still run the full ${LENSES.length}.`)

// ---------------------------------------------------------------------------------------------
// FAIL-FAST (optional; triage only, never evidence).
//
// The serialized chain runs every lens even after one has already reported a failure, so a repair
// that did not work pays the whole chain to be told twice. args.fail_fast lets the conductor stop
// the chain at the first lens that reports `verdict: fail`. It is OPT-IN: without it, nothing here
// changes, and a first or closing pass must never use it.
//
// Detection reuses the contract the 10 agent files ALREADY declare (their `## Return (YAML)` block
// opens with `verdict: pass | fail | n/a`) rather than forcing a schema on the lenses, which would
// mean auditing 10 agents and would turn a lens that answers in prose into a spurious failure.
// But that contract is prose, and the constitution is explicit that prose is not a control — so
// this only ever fires in the FAIL direction: a missing, malformed or ambiguous verdict line does
// NOT stop the chain. Losing a chance to stop early costs minutes; stopping on a misread would
// corrupt the triage itself.
const argsFailFast = !!ARGS.fail_fast
const failFast = argsFailFast || diskFailFast
const fail_fast_source = argsFailFast ? 'args' : (diskFailFast ? 'disk' : 'none')
if (fail_fast_source === 'disk') log(`verify-fanout: fail_fast recovered from the changed-files.txt header (iteration ${nowIter}). TRIAGE — full_set:false; recordable ONLY as a non-closing, verdict:fail phase_runs[] entry with carried_forward[] for every lens this pass does not launch; the closing VERIFY must run all ${LENSES.length} lenses and can never carry fail_fast.`)
const FAIL_VERDICT = /^\s*verdict\s*:\s*["']?fail\b/im
// Tolerant of shape on PURPOSE. A lens without a `schema` returns its final text as a string,
// which is the case today — but the moment anyone gives one of the ten a schema, `r` becomes an
// object and a strict `typeof r === 'string'` would make fail-fast stop firing FOREVER, silently
// and in the safe direction. That is the exact shape of the `args` bug: a type assumption whose
// failure reads as "nothing to report". Serialise whatever arrives and look for the verdict line.
const reportsFail = r => {
  if (r === null || r === undefined) return false
  const text = typeof r === 'string' ? r : (() => { try { return JSON.stringify(r) } catch (e) { return '' } })()
  return FAIL_VERDICT.test(text)
}

// ---------------------------------------------------------------------------------------------
// ISOLATION — why executing lenses are serialized and documentary ones stay parallel.
//
// Several VERIFY lenses compile, run the suite, start the app or write to the shared test store.
// Claude Code subagents are isolated in CONTEXT, not on the machine: they share one working tree,
// one set of ports and one store. Two of them running at once produce failures that belong to the
// neighbour — tests that fail and then pass alone, half-built apps, one lens's data poisoning
// another's read. That does not just cost a debugger iteration; it teaches the conductor that a
// failure might not be real, and a signal nobody must act on is worse than no signal.
//
// The partition is declared literally above (DOCUMENTARY_LENSES) and its truth is enforced OUT
// OF BAND: validate-structure.sh re-derives it from each agent's `tools:` frontmatter and fails
// when the two disagree. The constitution already names that frontmatter field the only real
// guarantee — a workflow subagent runs with edits auto-approved, so prose asking a lens not to
// write controls nothing. Keeping the list here and the check there is deliberate: the scheduler
// stays deterministic, and drift is caught loudly at gate time instead of silently at runtime.
//
// STRATEGY: a serialized stage for the executing lenses; the documentary ones keep running in
// parallel (they are read-only, so there is nothing for them to collide over).
//   - Rejected — worktree isolation per lens: it isolates the FILE TREE, which is only half the
//     problem. The shared test store, the ports and the running app live outside the worktree, so
//     the data contamination survives it. It also costs a worktree per lens, and it would strand
//     each lens's evidence artifacts in a throwaway tree instead of .orchestrator-state/evidence/.
//   - Rejected — one executor whose artifact the others consume: it collapses distinct lens
//     contracts into one agent's judgement. The 10 lenses would stop being 10 independent
//     verifications, and phase_runs[] would be recording a set that no longer ran as a set.
//   - Chosen — serialize: it removes every shared-resource collision, keeps all 10 lenses running
//     with their own contracts and their own evidence, and needs no new machinery. It costs wall
//     clock on the executing half only. That is the right thing to trade for a trustworthy signal.
// ---------------------------------------------------------------------------------------------
const documentary = new Set(DOCUMENTARY_LENSES)
const DOC_LENSES = ACTIVE.filter(a => documentary.has(a))
const EXEC_LENSES = ACTIVE.filter(a => !documentary.has(a))

// On a repair pass the lens gets the file list and judges its own relevance. Note what this is
// NOT: it is not permission to skip. A lens that re-affirms a prior verdict must say it did so and
// why nothing in its scope moved — that is a real verdict a reader can challenge, and it is the
// difference between a cheap pass and a fabricated one.
// The spec layers. In a spec-driven orchestrator these are NOT "just documentation": everything
// downstream is derived from them, so a lens reading `blueprint/logic/data.md` in the list and
// thinking "that's a .md, not my concern" has it exactly backwards — the target moved.
const SPEC_PREFIXES = ['blueprint/', 'design/', '.claude/rules/']
const specTouched = changed.filter(f => SPEC_PREFIXES.some(p => f.startsWith(p)))

const scopeHint = changed.length
  ? `\n\nREPAIR PASS. The conductor reports that this repair touched the files below. Treat it as a HINT, not as proof of completeness: it was computed outside this workflow and nothing here can verify it is exhaustive. It narrows where to look FIRST; it never licenses concluding that something did not change.\n${changed.map(f => `  ${f}`).join('\n')}\n` +
    (specTouched.length
      ? `\nSPEC CHANGE — the list includes files from the specification layers:\n${specTouched.map(f => `  ${f}`).join('\n')}\nThis is the most consequential kind of change in this repository, not the least: the whole build is derived from these documents, so a moved spec means the thing your code is judged AGAINST moved. If your contract compares code to documents (conformance, blueprint drift, the shell contract, design fidelity), you may NOT declare yourself out of scope on this pass. And if the edit changed a contract that a compiled or accepted unit relies on, say so as a finding: that is a /reslice, not a debugger iteration, and it is not yours or the conductor's to absorb quietly.\n`
      : '') +
    `\nJudge for YOURSELF whether any of this falls in your scope; you own that call, nobody upstream made it for you. If your scope is genuinely untouched, do NOT re-derive your whole analysis: re-affirm your previous verdict, state that no file in your scope changed, and name the scope you checked. If ANY of it touches your concern — directly, or through something you compare against, such as a shared component, a token file or a sibling screen's contract — do the full work as usual. When you cannot tell, do the full work: the cost of a redundant check is minutes, the cost of a missed regression is a wrong PASS.\n` +
    `UNCONDITIONAL DUTIES ARE NEVER SCOPED AWAY. If any part of your contract is by definition independent of what this repair touched — a full regression suite, a whole-project audit, a check whose purpose is to catch damage coming from OUTSIDE the active change — run that part in full, every time. This list contains only what THIS repair touched, so it structurally cannot contain the collateral damage such a check exists to find. Re-affirming there would be citing a stale run as current evidence.`
  : `\n\nBASELINE PASS — no repair scope given. Do the full work per your spec.`

const lensPrompt = a =>
  `VERIFY (static) lens ${a} for screen ${sid}. Repo root: ${root}. Verify against the documents per your spec — do NOT drive the live UI (that is VALIDATE).${scopeHint}\n\nFeature: ${JSON.stringify(ctx.feature_excerpt)}`

phase('Lenses')
// Documentary lenses: read-only, no shared resource, safe to fan out.
const docRuns = await parallel(DOC_LENSES.map(a => () =>
  agent(lensPrompt(a), { label: a, phase: 'Lenses', agentType: a }).then(r => ({ lens: a, result: r }))
))

// Executing lenses: one at a time, each with sole ownership of the tree/store/ports while it runs.
// A throw here must not kill the phase — a dead lens has to surface in failed_lenses[], exactly as
// parallel() would have reported it, so the conductor retries it once and then blocks.
const execRuns = []
let fail_fast_stopped_at = null
const fail_fast_skipped = []
for (const a of EXEC_LENSES) {
  // Once a lens has reported fail under fail_fast, the rest of the chain is not launched. They are
  // recorded as SKIPPED, not as failed: they never ran, so they never "returned nothing".
  if (fail_fast_stopped_at) { fail_fast_skipped.push(a); continue }
  try {
    const r = await agent(lensPrompt(a), { label: a, phase: 'Lenses', agentType: a })
    execRuns.push({ lens: a, result: r })
    if (failFast && reportsFail(r)) {
      fail_fast_stopped_at = a
      log(`verify-fanout: FAIL-FAST — ${a} reported verdict:fail; stopping the serialized chain. Recordable ONLY as a non-closing, verdict:fail phase_runs[] entry (never the closing one) with carried_forward[] for every lens in fail_fast_skipped[]; the closing VERIFY must still run all ${LENSES.length} lenses.`)
    }
  } catch (e) {
    execRuns.push({ lens: a, result: null, error: String(e && e.message ? e.message : e) })
  }
}

const lenses = [...docRuns, ...execRuns].filter(r => r && r.result)

// RETRY-ONCE inside the workflow (see research-fanout.js for the full rationale): the rule
// was stated in constitution.md and in next-pantalla §Cross-cutting and implemented nowhere,
// so a transient miss blocked a unit outright — and on an unattended run nobody was there to
// see it was transient. It runs ONCE, and `retried_lenses[]` says so, because fixing this in
// both the workflow and the conductor means paying for every dead lens twice.
//
// Two things this retry must NOT do, both of which would break invariants this file already holds:
//
//  - It must not touch `fail_fast_skipped`. Those lenses were never launched, so they never
//    "returned nothing" — there is nothing to retry, and retrying them would silently undo
//    the very saving fail-fast exists to produce.
//  - It must not collapse the parallel/serialized partition. A documentary lens is read-only
//    and retries in parallel; an executing lens owns the tree, the ports and the store while
//    it runs, so its retry is serialized exactly like its first attempt. Retrying an executing
//    lens concurrently would produce a failure belonging to the neighbour, arriving disguised
//    as a repaired lens.
const missingDoc = DOC_LENSES.filter(a => !lenses.some(l => l.lens === a))
const missingExec = EXEC_LENSES.filter(a =>
  !lenses.some(l => l.lens === a) && !fail_fast_skipped.includes(a))

const retried_lenses = []
if (missingDoc.length) {
  const again = (await parallel(missingDoc.map(a => () =>
    agent(lensPrompt(a), { label: a, phase: 'Lenses', agentType: a }).then(r => ({ lens: a, result: r }))
  ))).filter(r => r && r.result)
  lenses.push(...again)
  retried_lenses.push(...again.map(r => r.lens))
}
for (const a of missingExec) {
  try {
    const r = await agent(lensPrompt(a), { label: a, phase: 'Lenses', agentType: a })
    if (r) { lenses.push({ lens: a, result: r }); retried_lenses.push(a) }
  } catch (e) {
    // Second failure. Nothing more to do here — it belongs in failed_lenses[] below.
  }
}

// A lens that returned nothing TWICE must surface in unmerged[], never vanish silently.
// Lenses never launched because of fail-fast stay EXCLUDED, for the reason above.
const failed_lenses = ACTIVE.filter(a => !lenses.some(l => l.lens === a) && !fail_fast_skipped.includes(a))
// A pass that skipped part of the chain is not a full set, whatever args.scope_to said.
const full_set = scoped_full_set && !fail_fast_skipped.length

const DIGEST = {
  type: 'object', additionalProperties: false,
  // contradicts_prior_claim is REQUIRED, not optional-when-empty: an absent field reads as
  // "not checked" and an empty one reads as "checked, nothing found". Only the second is true,
  // and the conductor cannot tell them apart after the fact.
  required: ['screen_id', 'static_verdict', 'verdict_by_lens', 'findings', 'advisory_candidates', 'observed_values', 'expected_ui_values', 'artifacts', 'source_refs', 'contradicts_prior_claim', 'unmerged'],
  properties: {
    screen_id: { type: 'string' },
    static_verdict: { type: 'string', enum: ['pass', 'fail', 'n/a'] },
    verdict_by_lens: { type: 'array', items: { type: 'object', additionalProperties: true } },
    findings: { type: 'array', items: { type: 'object', additionalProperties: true } },
    // A finding raised by a lens that ITSELF returned `verdict: pass`. Required, emitted even when
    // empty, for the same reason contradicts_prior_claim[] is: absent reads as "not classified",
    // empty reads as "classified, none". See the long note above the phase('Synthesize') call.
    advisory_candidates: { type: 'array', items: { type: 'object', additionalProperties: true } },
    observed_values: { type: 'object', additionalProperties: true },
    expected_ui_values: { type: 'array', items: { type: 'object', additionalProperties: true } },
    artifacts: { type: 'array', items: { type: 'string' } },
    source_refs: { type: 'array', items: { type: 'object', additionalProperties: true } },
    contradicts_prior_claim: { type: 'array', items: { type: 'object', additionalProperties: true } },
    unmerged: { type: 'array', items: { type: 'object', additionalProperties: true } },
  },
}

// ---------------------------------------------------------------------------------------------
// ADVISORY CANDIDATES — the finding a passing lens raised, which until now had nowhere to go.
//
// MEASURED, and it is the largest structural round-generator left: the two §5.5 gates can classify
// a finding as non-blocking and send it to result.json.advisory_findings[]. The ten VERIFY lenses
// cannot. So when a lens returns `verdict: pass` and three `minor` findings, those three have no
// route at all — not failures[] (the lens passed), not advisory_findings[] (lenses are barred) —
// and the conductor's only available reading is "work". Each one then costs a repair, the repair
// is new surface, and the next round finds something in it.
//
// This is NOT the waiver the constitution forbids. That clause protects a MEASUREMENT from being
// excused by policy — a lens that says `fail` still fails, and every finding attached to a failing
// verdict stays exactly where it was. Here the lens itself already ruled: it looked at its own
// finding and returned `pass`. The defect was never the verdict; it was that the digest threw away
// the join between `findings[].lens` and `verdict_by_lens[]`, so a finding from a passing lens and
// a finding from a failing one arrived indistinguishable in one flat, severity-sorted array.
//
// So the split is a JOIN on data the synthesizer already holds, not a judgement — which is what
// keeps it inside its "flag, don't adjudicate" charter. It classifies nothing on its own account:
// it reports which lens raised each finding and what that lens concluded. The conductor still
// decides whether to repair now or record as debt, and validate-state.py still demands an owner
// and a trip-wire before an advisory entry sourced from a lens counts as recorded rather than
// dropped.
// ---------------------------------------------------------------------------------------------
phase('Synthesize')
const digest = await agent(
  `You are a READ-ONLY synthesis reducer for the VERIFY phase of screen ${sid}. Consolidate the per-lens results below into ONE digest. You WRITE NOTHING (no files, no state, no result.json) and you do NOT emit a lifecycle verdict — orchestrator-flow decides and writes.\nRules: static_verdict is MECHANICAL + ADVISORY only — fail if ANY lens is fail, n/a if all are n/a, else pass (the conductor may override). findings: merge all lens findings, sort blocker→nit, dedupe by (acceptance_ref, detail), keep each finding's lens. observed_values {db_value, api_value} and expected_ui_values[] must be lifted VERBATIM from the verify-engine / verify-pipeline lenses (they are load-bearing for VALIDATE derives-from and the validator's same_value recompute — never paraphrase or invent). artifacts: union of artifact paths. If any lens output is missing/unparseable, list it in unmerged[] rather than guessing. Also list every lens named below as returning no result in unmerged[] with reason "no result returned". Keep each finding's acceptance_ref and doc_refs (the cited blueprint rule IDs); also build source_refs[] = the blueprint rule IDs + files cited across the findings, a navigable index so orchestrator-flow can re-open the source rule when repairing.\nadvisory_candidates[]: ALWAYS emit it, empty when there is nothing. It is a JOIN, not a judgement, and you make no classification of your own: for every entry of findings[] whose emitting lens appears in verdict_by_lens[] with verdict "pass", copy that finding here and add {lens, lens_verdict:"pass"}. A finding from a lens that returned fail (or whose lens verdict you cannot read) NEVER enters this array — when in doubt, leave it out, because the conservative direction here is the blocking one. Entries stay in findings[] as well; this array is a view, not a move. Why it exists: the two §5.5 gates can route a non-blocking finding to result.json.advisory_findings[] and the ten lenses cannot, so a minor raised by a lens that passed had no route at all and was read as work — a repair, a re-VERIFY, and new surface for the next round.\ncontradicts_prior_claim[]: ALWAYS emit it, empty when there is nothing. One entry per lens finding that contradicts a recorded DEC-* decision, a blueprint assertion or an earlier verdict — {lens, finding_quote, finding_evidence, contradicted_claim_quote, contradicted_claim_source} — with BOTH quotes literal/verbatim (a paraphrased disagreement is a lost disagreement). Also enter here any lens asserting a NEGATIVE ("does not exist / is not supported / I ran it and it failed") WITHOUT the exact command, its literal output and an artifact path: the evidence standard gives a negative the same burden as a PASS, so an unproven one may not reach result.json or blueprint/**. Flag, never adjudicate.\n\nLenses that returned NO result: ${JSON.stringify(failed_lenses)}${fail_fast_skipped.length ? `\n\nFAIL-FAST TRIAGE PASS: the serialized chain stopped at ${fail_fast_stopped_at}, so these lenses were NEVER LAUNCHED: ${JSON.stringify(fail_fast_skipped)}. List each in unmerged[] with reason "not launched (fail-fast triage)" — they did not return nothing, they were never asked. Your static_verdict therefore describes a TRUNCATED pass and may not be read as full coverage.` : ''}\n\nLens results:\n${JSON.stringify(lenses, null, 1)}`,
  { label: 'synthesize', phase: 'Synthesize', schema: DIGEST, agentType: 'verify-synthesizer' }
)

// The digest carries the observed literals VALIDATE derives from: returning `digest: undefined`
// would close VERIFY on nothing. Fail LOUD, and say how many lenses had already returned.
if (!digest || typeof digest !== 'object') {
  throw new Error(`verify-fanout: the synthesizer returned no digest for ${sid} (${lenses.length}/${ACTIVE.length} lenses returned). Re-run the workflow; orchestrator-flow must never receive digest:undefined and must not persist expected_ui_values from an empty VERIFY.`)
}

// orchestrator-flow consumes `digest`, writes the consolidated result.json and decides; pantalla-reviewer
// remains the sole contractual REVIEW verdict; validate-state.py remains the only gate. `lenses` kept for traceability.
// `full_set` is the honesty flag for phase_runs[]: false means this was a scoped/fail-fast triage
// pass that did NOT run every lens natively. It may still be recorded as a NON-CLOSING VERIFY entry
// if the conductor fills `carried_forward[]` for every lens this pass skipped, citing the last
// complete iteration (validate-state.py checks this); it may NEVER be the CLOSING entry, which
// must always have `full_set:true` and nothing carried forward. `lenses_run` is what was LAUNCHED
// (ACTIVE minus fail-fast skips), not what returned — a launched lens that came back empty is still
// in here and shows up in failed_lenses[]. The conductor records phase_runs[] from `lenses`, never from this.
// `scoped_to_changes` records that the lenses were given a repair scope. It does NOT weaken the
// pass: all 10 ran and each judged its own relevance, so this stays a full, recordable VERIFY.
// args_seen makes the loss LOUD. The conductor knows what it passed; if this comes back all-false
// while it passed a scope, args did not arrive — and it can say so in phase_runs[] instead of
// recording a baseline that looks deliberate.
const args_seen = {
  received: typeof args !== 'undefined' && args !== null,
  raw_type: typeof args,
  coerced_from_string: typeof args === 'string',
  keys: Object.keys(ARGS),
  changed_files: argsChanged.length,
  scope_to: Array.isArray(ARGS.scope_to) ? ARGS.scope_to.length : 0,
  fail_fast: argsFailFast,
  full_verify: argsFullVerify,
}
// `carried_forward_lenses` is the conductor's shopping list, not a finished record: it names the
// lenses this pass did not launch, and the conductor still owes each one a `from_iteration`
// citing the last COMPLETE VERIFY entry. The workflow deliberately does NOT invent that number —
// it cannot see phase_runs[], and a citation the workflow guessed would be exactly the
// unverifiable claim validate-state.py exists to reject.
const carried_forward_lenses = LENSES.filter(l => !ACTIVE.includes(l))
return { screen_id: sid, digest, lenses, failed_lenses, retried_lenses, full_set, args_seen, scope_source, scope_to_source, fail_fast_source, derived_scope, docs_only: docsOnly, carried_forward_lenses, lenses_run: ACTIVE.filter(a => !fail_fast_skipped.includes(a)), documentary_lenses: DOC_LENSES, serialized_lenses: EXEC_LENSES, scoped_to_changes: changed, fail_fast: failFast, fail_fast_stopped_at, fail_fast_skipped }
