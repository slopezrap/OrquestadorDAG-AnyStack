export const meta = {
  name: 'verify-fanout',
  description: 'Phase 3 VERIFY (static, against the documents) for one unit. Disk-first: a read-only loader reads .orchestrator-state/features.json and returns the single building unit’s context (args is only an optional hint). Then fan out 10 specialized lens-agents in parallel (tests, conformance, design, frontend, engine, pipeline, logs, quality, coherence, blueprint-drift), and a read-only synthesis reducer collapses their findings into ONE digest for orchestrator-flow (advisory verdict + literal values lifted verbatim). The conductor consolidates result.json and decides; this never emits a lifecycle verdict.',
  phases: [
    { title: 'Load', detail: 'read-only loader resolves the active unit + feature_excerpt from disk, and classifies the lenses documentary/executing from their tools: frontmatter' },
    { title: 'Lenses', detail: 'the same 10 verify-* agents: read-only ones in parallel, command-running ones serialized so they cannot collide over the tree/store/ports' },
    { title: 'Synthesize', detail: 'read-only reducer → one digest (advisory static verdict, observed literals, expected_ui_values, contradicts_prior_claim)' },
  ],
}

// Disk-first context: do NOT depend on the caller passing args correctly. args is only an
// optional hint for WHICH unit/root; correctness comes from .orchestrator-state on disk.
const hint = (args && (args.screen_id || args.id)) ? String(args.screen_id || args.id) : null
const root = (args && args.root) ? String(args.root) : '.'

// 10 static lenses; verify-engine returns db_value, verify-pipeline returns api_value + expected_ui_values,
// verify-coherence compares against the shell contract (UI-SHELL-*) and the sibling verified/accepted screens.
// Declared BEFORE the loader because the loader is asked to classify these exact names (const is not hoisted).
// These names must stay written here as quoted literals: validate-structure.sh extracts them lexically from
// this file to prove the fan-out set matches VERIFY_LENSES in validate-state.py. Deriving them at runtime
// would make the set invisible to that check and silently break the sync gate.
// ORDER MATTERS for the serialized half: EXEC_LENSES is derived from this list by filtering
// out the documentary ones, so it inherits this order. verify-frontend is FIRST on purpose —
// it is the cheapest executing lens and it fails on the thing that invalidates everything
// downstream (the code does not build). Running it ahead of verify-tests costs nothing when
// the build is fine (the serial sum is unchanged) and saves the rest of the chain when it is
// not. Both sync gates compare SETS, not sequences (validate-structure.sh builds a set() from
// a lexical scan, and VERIFY_LENSES in validate-state.py is a set), so reordering is safe.
const LENSES = [
  'verify-frontend', 'verify-tests', 'verify-conformance', 'verify-design',
  'verify-engine', 'verify-pipeline', 'verify-logs', 'verify-quality',
  'verify-coherence', 'verify-blueprint-drift',
]

// The same 10 names, split by CAPABILITY. See the isolation note at the Lenses phase.
// DOCUMENTARY = restricted to read-only tools in its agent frontmatter, so it cannot run a
// command and has nothing to collide over. Everything else executes and must be serialized.
//
// Why literal lists and not derived here: a Workflow script has NO filesystem access, so this
// .js cannot open .claude/agents/*.md to read `tools:`. It could ask an agent to do it — but
// that puts an LLM's reading of YAML in the scheduler's decision path on every single run, and
// a mis-classification silently re-creates the exact collision this exists to prevent. A literal
// list is deterministic. The anti-drift lives in .orchestrator/scripts/validate-structure.sh,
// which DOES read files: it re-derives this split from the agents' frontmatter and fails loudly
// when these lists disagree with it. Loud at gate time beats silent at runtime.
const DOCUMENTARY_LENSES = [
  'verify-conformance', 'verify-design', 'verify-coherence', 'verify-blueprint-drift',
]

const CTX_SCHEMA = {
  type: 'object', additionalProperties: false,
  required: ['ok', 'screen_id', 'feature_excerpt'],
  properties: {
    ok: { type: 'boolean' },
    error: { type: 'string' },
    screen_id: { type: 'string' },
    slug: { type: 'string' },
    title: { type: 'string' },
    feature_excerpt: { type: 'object', additionalProperties: true },
  },
}

phase('Load')
const ctx = await agent(
  `CONTEXT LOADER (read-only; read ONLY from disk under ${root}; never guess or invent).\n` +
  `1. Read .orchestrator-state/features.json (the screens[] array is the runtime plan).\n` +
  `2. Select the active unit: ${hint ? `the screen whose id === "${hint}"` : 'the single screen whose status === "building" (validate-state.py guarantees at most one)'}. ` +
  `If exactly one matches set ok=true; otherwise set ok=false, screen_id="" and error="<n> screens matched: <ids>".\n` +
  `3. Return its id (as screen_id), slug, title and a compact feature_excerpt {kind, platforms, acceptance, applies, data_engine, architecture, design_ref} lifted VERBATIM from the unit.\n` +
  `Write nothing. Return the structured object.`,
  { label: 'load-context', phase: 'Load', schema: CTX_SCHEMA, agentType: 'context-loader', model: 'haiku', effort: 'low' }
)

// Fail LOUD instead of silently degrading to '<unit>'/{} (10 lenses verifying an empty feature
// return a complete lens set with nothing behind it, and the STATE GATE accepts it).
if (!ctx || !ctx.ok || !ctx.screen_id) {
  throw new Error(`verify-fanout: could not load the active unit from disk — ${ctx && ctx.error ? ctx.error : 'no unit is building'}. Leave exactly one unit in status:"building" (or pass args.screen_id) and re-run; this workflow no longer degrades to <unit>/{}.`)
}

const sid = ctx.screen_id

// The hint is honoured, not merely consulted. Without this, a loader that resolves a DIFFERENT
// unit than the one asked for returns ok:true and the whole fan-out runs looking perfectly
// healthy — on the wrong screen. That failure is silent by construction: every lens reports on
// the unit it was handed, so the evidence is internally consistent and simply about something
// else. Cheap to close, and the alternative is spending full phases before anyone notices.
if (hint && sid !== hint) {
  throw new Error(`verify-fanout: asked for "${hint}" but the loader resolved "${sid}". Refusing to run the phase on a unit that was not requested — re-check args.screen_id and the status of both units.`)
}

// ---------------------------------------------------------------------------------------------
// SCOPED RE-RUN (optional; triage only, never evidence).
// After a repair, re-running all 10 lenses to re-check a docs-only or scaffolding-only change is
// the single most expensive habit in the loop. args.scope_to lets the conductor re-run just the
// lenses whose scope intersects the change. HARD RULE: a scoped pass is NOT a fan-out phase and
// may never be recorded in result.json.phase_runs[] — the returned `full_set:false` says so, and
// validate-state.py independently rejects a partial VERIFY lens set, so a scoped pass cannot be
// laundered into a PASS. The last VERIFY before a unit closes must be a full one.
// ---------------------------------------------------------------------------------------------
// ---------------------------------------------------------------------------------------------
// PROPORTIONALITY — the repair pass must cost what the repair was worth.
//
// The measured problem: re-running all 10 lenses to re-check a one-line or docs-only fix was the
// single most expensive habit in the loop, and most of those lenses had nothing in scope. The fix
// is NOT to run fewer lenses — the set stays at 10 and the phase stays recordable in phase_runs[].
// The fix is to stop each lens re-discovering the whole repo when it can see, in one line, that
// nothing it owns moved.
//
// args.changed_files carries what the repair actually touched (the conductor computes it from the
// DEVELOP checkpoint; it cannot be derived here — a Workflow script has no filesystem access and
// the read-only loader has no Bash). Empty means BASELINE: a first or closing pass, full work.
//
// The lens decides, not the caller. We hand it the facts and its own contract judges whether its
// scope intersects — because a file list looks unrelated right up until a shared component moves
// under verify-coherence's feet. Deciding for it, from out here, is exactly the kind of guess that
// turns a cheap pass into a missed defect.
const changedRaw = Array.isArray(args && args.changed_files) ? args.changed_files.filter(f => typeof f === 'string' && f) : []
// A repair touching hundreds of files is not a small repair: past this point the list stops being
// a focusing aid and just bloats 10 prompts, so fall back to a baseline pass and say so.
const CHANGED_CAP = 150
const changed = changedRaw.length > CHANGED_CAP ? [] : changedRaw
if (changedRaw.length > CHANGED_CAP) log(`verify-fanout: ${changedRaw.length} changed files exceeds the ${CHANGED_CAP}-file cap — running as a BASELINE pass (no scope hint). A change this size is not a small repair.`)

// Deduplicated: a caller listing the same lens twice would otherwise run it twice (pure waste in
// the very mechanism that exists to cut waste) and, worse, pad the count — see full_set below.
const scopeTo = Array.isArray(args && args.scope_to) ? [...new Set(args.scope_to.filter(a => LENSES.includes(a)))] : []
const ACTIVE = scopeTo.length ? scopeTo : LENSES
// full_set is the honesty flag for phase_runs[], so it must compare SETS, not lengths. A length
// check calls ['a','a',...9 more] a full set: it would report `true` for a pass that never ran one
// of the ten. validate-state.py would still reject that downstream, but a flag whose whole job is
// to be trustworthy cannot rely on something else catching it lying.
const activeSet = new Set(ACTIVE)
const scoped_full_set = activeSet.size === LENSES.length && LENSES.every(l => activeSet.has(l))
if (!scoped_full_set) log(`verify-fanout: SCOPED re-run (${activeSet.size}/${LENSES.length} lenses) — triage only, NOT recordable in phase_runs[]; a full pass is still required before close.`)

// ---------------------------------------------------------------------------------------------
// FAIL-FAST (optional; triage only, never evidence).
//
// The serialized chain runs every lens even after one has already reported a failure, so a repair
// that did not work pays the whole chain to be told twice. args.fail_fast lets the conductor stop
// the chain at the first lens that reports `verdict: fail`. It is OPT-IN: without it, nothing here
// changes, and a first or closing pass must never use it.
//
// Detection reuses the contract the 10 agent files ALREADY declare (their `## Return (YAML)` block
// opens with `verdict: pass | fail | n/a`) rather than forcing a schema on the lenses, which would
// mean auditing 10 agents and would turn a lens that answers in prose into a spurious failure.
// But that contract is prose, and the constitution is explicit that prose is not a control — so
// this only ever fires in the FAIL direction: a missing, malformed or ambiguous verdict line does
// NOT stop the chain. Losing a chance to stop early costs minutes; stopping on a misread would
// corrupt the triage itself.
const failFast = !!(args && args.fail_fast)
const FAIL_VERDICT = /^\s*verdict\s*:\s*["']?fail\b/im
const reportsFail = r => typeof r === 'string' && FAIL_VERDICT.test(r)

// ---------------------------------------------------------------------------------------------
// ISOLATION — why executing lenses are serialized and documentary ones stay parallel.
//
// Several VERIFY lenses compile, run the suite, start the app or write to the shared test store.
// Claude Code subagents are isolated in CONTEXT, not on the machine: they share one working tree,
// one set of ports and one store. Two of them running at once produce failures that belong to the
// neighbour — tests that fail and then pass alone, half-built apps, one lens's data poisoning
// another's read. That does not just cost a debugger iteration; it teaches the conductor that a
// failure might not be real, and a signal nobody must act on is worse than no signal.
//
// The partition is declared literally above (DOCUMENTARY_LENSES) and its truth is enforced OUT
// OF BAND: validate-structure.sh re-derives it from each agent's `tools:` frontmatter and fails
// when the two disagree. The constitution already names that frontmatter field the only real
// guarantee — a workflow subagent runs with edits auto-approved, so prose asking a lens not to
// write controls nothing. Keeping the list here and the check there is deliberate: the scheduler
// stays deterministic, and drift is caught loudly at gate time instead of silently at runtime.
//
// STRATEGY: a serialized stage for the executing lenses; the documentary ones keep running in
// parallel (they are read-only, so there is nothing for them to collide over).
//   - Rejected — worktree isolation per lens: it isolates the FILE TREE, which is only half the
//     problem. The shared test store, the ports and the running app live outside the worktree, so
//     the data contamination survives it. It also costs a worktree per lens, and it would strand
//     each lens's evidence artifacts in a throwaway tree instead of .orchestrator-state/evidence/.
//   - Rejected — one executor whose artifact the others consume: it collapses distinct lens
//     contracts into one agent's judgement. The 10 lenses would stop being 10 independent
//     verifications, and phase_runs[] would be recording a set that no longer ran as a set.
//   - Chosen — serialize: it removes every shared-resource collision, keeps all 10 lenses running
//     with their own contracts and their own evidence, and needs no new machinery. It costs wall
//     clock on the executing half only. That is the right thing to trade for a trustworthy signal.
// ---------------------------------------------------------------------------------------------
const documentary = new Set(DOCUMENTARY_LENSES)
const DOC_LENSES = ACTIVE.filter(a => documentary.has(a))
const EXEC_LENSES = ACTIVE.filter(a => !documentary.has(a))

// On a repair pass the lens gets the file list and judges its own relevance. Note what this is
// NOT: it is not permission to skip. A lens that re-affirms a prior verdict must say it did so and
// why nothing in its scope moved — that is a real verdict a reader can challenge, and it is the
// difference between a cheap pass and a fabricated one.
// The spec layers. In a spec-driven orchestrator these are NOT "just documentation": everything
// downstream is derived from them, so a lens reading `blueprint/logic/data.md` in the list and
// thinking "that's a .md, not my concern" has it exactly backwards — the target moved.
const SPEC_PREFIXES = ['blueprint/', 'design/', '.claude/rules/']
const specTouched = changed.filter(f => SPEC_PREFIXES.some(p => f.startsWith(p)))

const scopeHint = changed.length
  ? `\n\nREPAIR PASS. The conductor reports that this repair touched the files below. Treat it as a HINT, not as proof of completeness: it was computed outside this workflow and nothing here can verify it is exhaustive. It narrows where to look FIRST; it never licenses concluding that something did not change.\n${changed.map(f => `  ${f}`).join('\n')}\n` +
    (specTouched.length
      ? `\nSPEC CHANGE — the list includes files from the specification layers:\n${specTouched.map(f => `  ${f}`).join('\n')}\nThis is the most consequential kind of change in this repository, not the least: the whole build is derived from these documents, so a moved spec means the thing your code is judged AGAINST moved. If your contract compares code to documents (conformance, blueprint drift, the shell contract, design fidelity), you may NOT declare yourself out of scope on this pass. And if the edit changed a contract that a compiled or accepted unit relies on, say so as a finding: that is a /reslice, not a debugger iteration, and it is not yours or the conductor's to absorb quietly.\n`
      : '') +
    `\nJudge for YOURSELF whether any of this falls in your scope; you own that call, nobody upstream made it for you. If your scope is genuinely untouched, do NOT re-derive your whole analysis: re-affirm your previous verdict, state that no file in your scope changed, and name the scope you checked. If ANY of it touches your concern — directly, or through something you compare against, such as a shared component, a token file or a sibling screen's contract — do the full work as usual. When you cannot tell, do the full work: the cost of a redundant check is minutes, the cost of a missed regression is a wrong PASS.\n` +
    `UNCONDITIONAL DUTIES ARE NEVER SCOPED AWAY. If any part of your contract is by definition independent of what this repair touched — a full regression suite, a whole-project audit, a check whose purpose is to catch damage coming from OUTSIDE the active change — run that part in full, every time. This list contains only what THIS repair touched, so it structurally cannot contain the collateral damage such a check exists to find. Re-affirming there would be citing a stale run as current evidence.`
  : `\n\nBASELINE PASS — no repair scope given. Do the full work per your spec.`

const lensPrompt = a =>
  `VERIFY (static) lens ${a} for screen ${sid}. Repo root: ${root}. Verify against the documents per your spec — do NOT drive the live UI (that is VALIDATE).${scopeHint}\n\nFeature: ${JSON.stringify(ctx.feature_excerpt)}`

phase('Lenses')
// Documentary lenses: read-only, no shared resource, safe to fan out.
const docRuns = await parallel(DOC_LENSES.map(a => () =>
  agent(lensPrompt(a), { label: a, phase: 'Lenses', agentType: a }).then(r => ({ lens: a, result: r }))
))

// Executing lenses: one at a time, each with sole ownership of the tree/store/ports while it runs.
// A throw here must not kill the phase — a dead lens has to surface in failed_lenses[], exactly as
// parallel() would have reported it, so the conductor retries it once and then blocks.
const execRuns = []
let fail_fast_stopped_at = null
const fail_fast_skipped = []
for (const a of EXEC_LENSES) {
  // Once a lens has reported fail under fail_fast, the rest of the chain is not launched. They are
  // recorded as SKIPPED, not as failed: they never ran, so they never "returned nothing".
  if (fail_fast_stopped_at) { fail_fast_skipped.push(a); continue }
  try {
    const r = await agent(lensPrompt(a), { label: a, phase: 'Lenses', agentType: a })
    execRuns.push({ lens: a, result: r })
    if (failFast && reportsFail(r)) {
      fail_fast_stopped_at = a
      log(`verify-fanout: FAIL-FAST — ${a} reported verdict:fail; stopping the serialized chain. Triage only, NOT recordable in phase_runs[]; the closing VERIFY must run all ${LENSES.length} lenses.`)
    }
  } catch (e) {
    execRuns.push({ lens: a, result: null, error: String(e && e.message ? e.message : e) })
  }
}

const lenses = [...docRuns, ...execRuns].filter(r => r && r.result)
// A lens whose agent returned nothing must surface in unmerged[], never vanish silently.
// Lenses never launched because of fail-fast are EXCLUDED: the conductor's retry-once-then-block
// rule is for a lens that ran and returned nothing, and applying it here would block the unit for
// lenses that were deliberately not started.
const failed_lenses = ACTIVE.filter(a => !lenses.some(l => l.lens === a) && !fail_fast_skipped.includes(a))
// A pass that skipped part of the chain is not a full set, whatever args.scope_to said.
const full_set = scoped_full_set && !fail_fast_skipped.length

const DIGEST = {
  type: 'object', additionalProperties: false,
  // contradicts_prior_claim is REQUIRED, not optional-when-empty: an absent field reads as
  // "not checked" and an empty one reads as "checked, nothing found". Only the second is true,
  // and the conductor cannot tell them apart after the fact.
  required: ['screen_id', 'static_verdict', 'verdict_by_lens', 'findings', 'observed_values', 'expected_ui_values', 'artifacts', 'source_refs', 'contradicts_prior_claim', 'unmerged'],
  properties: {
    screen_id: { type: 'string' },
    static_verdict: { type: 'string', enum: ['pass', 'fail', 'n/a'] },
    verdict_by_lens: { type: 'array', items: { type: 'object', additionalProperties: true } },
    findings: { type: 'array', items: { type: 'object', additionalProperties: true } },
    observed_values: { type: 'object', additionalProperties: true },
    expected_ui_values: { type: 'array', items: { type: 'object', additionalProperties: true } },
    artifacts: { type: 'array', items: { type: 'string' } },
    source_refs: { type: 'array', items: { type: 'object', additionalProperties: true } },
    contradicts_prior_claim: { type: 'array', items: { type: 'object', additionalProperties: true } },
    unmerged: { type: 'array', items: { type: 'object', additionalProperties: true } },
  },
}

phase('Synthesize')
const digest = await agent(
  `You are a READ-ONLY synthesis reducer for the VERIFY phase of screen ${sid}. Consolidate the per-lens results below into ONE digest. You WRITE NOTHING (no files, no state, no result.json) and you do NOT emit a lifecycle verdict — orchestrator-flow decides and writes.\nRules: static_verdict is MECHANICAL + ADVISORY only — fail if ANY lens is fail, n/a if all are n/a, else pass (the conductor may override). findings: merge all lens findings, sort blocker→nit, dedupe by (acceptance_ref, detail), keep each finding's lens. observed_values {db_value, api_value} and expected_ui_values[] must be lifted VERBATIM from the verify-engine / verify-pipeline lenses (they are load-bearing for VALIDATE derives-from and the validator's same_value recompute — never paraphrase or invent). artifacts: union of artifact paths. If any lens output is missing/unparseable, list it in unmerged[] rather than guessing. Also list every lens named below as returning no result in unmerged[] with reason "no result returned". Keep each finding's acceptance_ref and doc_refs (the cited blueprint rule IDs); also build source_refs[] = the blueprint rule IDs + files cited across the findings, a navigable index so orchestrator-flow can re-open the source rule when repairing.\ncontradicts_prior_claim[]: ALWAYS emit it, empty when there is nothing. One entry per lens finding that contradicts a recorded DEC-* decision, a blueprint assertion or an earlier verdict — {lens, finding_quote, finding_evidence, contradicted_claim_quote, contradicted_claim_source} — with BOTH quotes literal/verbatim (a paraphrased disagreement is a lost disagreement). Also enter here any lens asserting a NEGATIVE ("does not exist / is not supported / I ran it and it failed") WITHOUT the exact command, its literal output and an artifact path: the evidence standard gives a negative the same burden as a PASS, so an unproven one may not reach result.json or blueprint/**. Flag, never adjudicate.\n\nLenses that returned NO result: ${JSON.stringify(failed_lenses)}${fail_fast_skipped.length ? `\n\nFAIL-FAST TRIAGE PASS: the serialized chain stopped at ${fail_fast_stopped_at}, so these lenses were NEVER LAUNCHED: ${JSON.stringify(fail_fast_skipped)}. List each in unmerged[] with reason "not launched (fail-fast triage)" — they did not return nothing, they were never asked. Your static_verdict therefore describes a TRUNCATED pass and may not be read as full coverage.` : ''}\n\nLens results:\n${JSON.stringify(lenses, null, 1)}`,
  { label: 'synthesize', phase: 'Synthesize', schema: DIGEST, agentType: 'verify-synthesizer' }
)

// The digest carries the observed literals VALIDATE derives from: returning `digest: undefined`
// would close VERIFY on nothing. Fail LOUD, and say how many lenses had already returned.
if (!digest || typeof digest !== 'object') {
  throw new Error(`verify-fanout: the synthesizer returned no digest for ${sid} (${lenses.length}/${ACTIVE.length} lenses returned). Re-run the workflow; orchestrator-flow must never receive digest:undefined and must not persist expected_ui_values from an empty VERIFY.`)
}

// orchestrator-flow consumes `digest`, writes the consolidated result.json and decides; pantalla-reviewer
// remains the sole contractual REVIEW verdict; validate-state.py remains the only gate. `lenses` kept for traceability.
// `full_set` is the honesty flag for phase_runs[]: false means this was a scoped triage pass and MUST NOT be
// recorded as a VERIFY phase. `lenses_run` is what actually ran, so the conductor never records a name it did not get.
// `scoped_to_changes` records that the lenses were given a repair scope. It does NOT weaken the
// pass: all 10 ran and each judged its own relevance, so this stays a full, recordable VERIFY.
return { screen_id: sid, digest, lenses, failed_lenses, full_set, lenses_run: ACTIVE.filter(a => !fail_fast_skipped.includes(a)), documentary_lenses: DOC_LENSES, serialized_lenses: EXEC_LENSES, scoped_to_changes: changed, fail_fast: failFast, fail_fast_stopped_at, fail_fast_skipped }
