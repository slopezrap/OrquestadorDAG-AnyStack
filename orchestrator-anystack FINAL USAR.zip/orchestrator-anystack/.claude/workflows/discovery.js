export const meta = {
  name: 'discovery',
  description: 'DISCOVERY gate at time zero (inside /init-build, after the preflight lint and BEFORE COMPILE). Fan out 6 discovery-* lens-agents in parallel over the universal intake checklist (.orchestrator/templates/discovery-checklist.md) — product, data, architecture, stack, infra, ux — each returning one disposition per checklist item (answered/propose_fill/ask/n-a). A read-only synthesis reducer collapses them into ONE digest (per-item table, missing_ids completeness proof, deduped question round, write_plan) for orchestrator-flow, which asks the human ONE batched round and writes every fill/answer into blueprint/**, stack.md and DECISIONS.md. discovery-* owns the UNASKED, research-* owns the ABSENCE, arch-* owns the ERROR. An underspecified or empty blueprint is the NORMAL input here — this gate exists to interrogate it, so unlike arch-review it never refuses to run over silence.',
  phases: [
    { title: 'Lenses', detail: 'discovery-* agents in parallel (product/data/architecture/stack/infra/ux), one disposition per checklist item' },
    { title: 'Synthesize', detail: 'read-only reducer → one digest (items, missing_ids, question round, write_plan)' },
  ],
}

// Disk-first context: args is only an optional hint; correctness comes from the checklist and
// blueprint/ on disk. This runs at TIME ZERO before COMPILE: features.json does not exist yet.
const hint = (args && args.hint) ? String(args.hint) : null
const root = (args && args.root) ? String(args.root) : '.'
const CHECKLIST = '.orchestrator/templates/discovery-checklist.md'

const LENSES = [
  'discovery-product', 'discovery-data', 'discovery-architecture',
  'discovery-stack', 'discovery-infra', 'discovery-ux',
]

phase('Lenses')
const results = await parallel(LENSES.map(a => () =>
  agent(
    `DISCOVERY lens ${a} at TIME ZERO (inside /init-build, before COMPILE — no features.json exists yet). Repo root: ${root}. Read YOUR section of ${CHECKLIST} and walk it per your spec: for EVERY item in your section return exactly one disposition — answered (cite file+ID or ORIGINAL/DEC quote; never re-ask what the human already wrote), propose_fill (exact text + target from the checklist routing), ask (one precise question, 2-4 options, ALWAYS a recommended option, target file), or n/a (concrete reason; [if applies] items still get a row). An empty or underspecified blueprint is the NORMAL input — silence on a genuine product decision is ask, never a finding and never a guess. You REPORT: you do not write, you do not decide, and your output never enters phase_runs[] or any result.json.${hint ? `\n\nConductor hint (context only, disk wins): ${hint}` : ''}`,
    { label: a, phase: 'Lenses', agentType: a }
  ).then(r => ({ lens: a, result: r }))
))
const lenses = results.filter(r => r && r.result)
// A lens whose agent returned nothing must surface in failed_lenses[]/unmerged[], never vanish silently.
const failed_lenses = LENSES.filter(a => !lenses.some(l => l.lens === a))

const DIGEST = {
  type: 'object', additionalProperties: false,
  required: ['checklist_version', 'items', 'coverage', 'missing_ids', 'questions', 'overflow_questions', 'write_plan', 'covered_by_orchestrator', 'flags', 'source_refs', 'failed_lenses', 'unmerged'],
  properties: {
    checklist_version: { type: 'number' },
    items: { type: 'array', items: { type: 'object', additionalProperties: true } },
    coverage: { type: 'object', additionalProperties: true },
    missing_ids: { type: 'array', items: { type: 'string' } },
    questions: { type: 'array', items: { type: 'object', additionalProperties: true } },
    overflow_questions: { type: 'array', items: { type: 'object', additionalProperties: true } },
    write_plan: { type: 'array', items: { type: 'object', additionalProperties: true } },
    covered_by_orchestrator: { type: 'array', items: { type: 'string' } },
    flags: { type: 'array', items: { type: 'object', additionalProperties: true } },
    source_refs: { type: 'array', items: { type: 'object', additionalProperties: true } },
    failed_lenses: { type: 'array', items: { type: 'string' } },
    unmerged: { type: 'array', items: { type: 'object', additionalProperties: true } },
  },
}

phase('Synthesize')
const digest = await agent(
  `You are a READ-ONLY synthesis reducer for the DISCOVERY gate at time zero. Consolidate the per-lens dispositions below into ONE digest per your spec. Read ${CHECKLIST} yourself, extract every Q-* item ID, and prove completeness: any ID with no row from any lens goes into missing_ids[] — the forgotten question is exactly what this gate exists to prevent. Keep literals verbatim, dedupe overlapping questions into single human decisions carrying all their item_ids, group and cap the question round (~16, overflow with defaults preserved in overflow_questions[]), and assemble write_plan[] ordered by target file. You WRITE NOTHING and DECIDE NOTHING — orchestrator-flow asks the human and writes.\n\nLenses that returned NO result (copy verbatim into failed_lenses[] and list each in unmerged[] with reason "no result returned"): ${JSON.stringify(failed_lenses)}\n\nLens results:\n${JSON.stringify(lenses, null, 1)}`,
  { label: 'synthesize', phase: 'Synthesize', schema: DIGEST, agentType: 'discovery-synthesizer' }
)

// A synthesizer that returns nothing must not travel on as `{digest: undefined}`: the
// conductor would consume an absent digest as if the phase had produced one.
if (!digest) {
  throw new Error(`discovery: the synthesis reducer returned no digest for the discovery gate. Re-run the workflow; a phase that produced no digest must not be reported as if it had.`)
}

// orchestrator-flow consumes `digest`: runs the ONE batched CLARIFY round over questions[],
// executes write_plan[] (blueprint/**, stack.md, DECISIONS.md), then writes the report and
// meta.discovery. This workflow reports; it changes no state and never enters phase_runs[].
return { digest, lenses, failed_lenses }
