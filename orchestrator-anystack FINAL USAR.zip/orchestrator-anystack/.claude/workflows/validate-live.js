export const meta = {
  name: 'validate-live',
  description: 'Phase 4 VALIDATE (live, human-like) for one unit. Disk-first: a read-only loader reads .orchestrator-state/features.json + the unit evidence and returns the single building unit’s context (args is only an optional hint). Then fan out one specialized lens-agent per owned runtime (validate-web / validate-android / validate-ios) plus validate-logs, in parallel. Consumes expected_ui_values from VERIFY evidence; returns observed client literals + verdicts to orchestrator-flow. Thin orchestration; each lens contract lives in its agent.',
  phases: [
    { title: 'Load', detail: 'read-only loader resolves the active unit + platforms + expected_ui_values from disk' },
    { title: 'Drive', detail: 'validate-* lens-agents per owned runtime + validate-logs, in parallel' },
  ],
}

// Disk-first context: do NOT depend on the caller passing args correctly. args is only an
// optional hint for WHICH unit/root; correctness comes from .orchestrator-state on disk.
const hint = (args && (args.screen_id || args.id)) ? String(args.screen_id || args.id) : null
const root = (args && args.root) ? String(args.root) : '.'

const CTX_SCHEMA = {
  type: 'object', additionalProperties: false,
  required: ['ok', 'screen_id', 'platforms', 'expected_ui_values', 'engine_refs', 'pipeline_refs'],
  properties: {
    ok: { type: 'boolean' },
    error: { type: 'string' },
    screen_id: { type: 'string' },
    slug: { type: 'string' },
    title: { type: 'string' },
    kind: { type: 'string' },
    platforms: { type: 'array', items: { type: 'string' } },
    route: { type: 'object', additionalProperties: true },
    acceptance: { type: 'array', items: {} },
    feature_excerpt: { type: 'object', additionalProperties: true },
    expected_ui_values: { type: 'array', items: { type: 'object', additionalProperties: true } },
    engine_refs: { type: 'array', items: { type: 'string' } },
    pipeline_refs: { type: 'array', items: { type: 'string' } },
  },
}

phase('Load')
const ctx = await agent(
  `CONTEXT LOADER (read-only; read ONLY from disk under ${root}; never guess or invent).\n` +
  `1. Read .orchestrator-state/features.json (the screens[] array is the runtime plan).\n` +
  `2. Select the active unit: ${hint ? `the screen whose id === "${hint}"` : 'the single screen whose status === "building" (validate-state.py guarantees at most one)'}. ` +
  `If exactly one matches set ok=true; otherwise set ok=false, screen_id="" and error="<n> screens matched: <ids>".\n` +
  `3. Return its id (as screen_id), slug, title, kind, platforms[] (verbatim from the unit), route, acceptance[], and a compact feature_excerpt {kind, platforms, acceptance, applies, data_engine, architecture, design_ref}.\n` +
  `4. Read .orchestrator-state/evidence/<screen_id>/result.json if it exists and lift expected_ui_values[] VERBATIM from its top-level expected_ui_values field (canonical shape: {db_key, permission_context, api_field_path, expected_visible_value, ui_field, transform?} — written by orchestrator-flow after VERIFY). Only if that field is absent, fall back to deriving rows from data_engine_assertions[] (map db_value->expected_visible_value, ui_value->ui_field context) and say so in the returned rows; if neither exists, return [].\n` +
  `5. Return engine_refs[] = every ENG-* and pipeline_refs[] = every PIPE-* the unit cites, collected from its applies[], its top-level engine_refs/pipeline_refs and its data_engine block. These decide whether the engine/pipeline runtimes must be driven too.\n` +
  `Write nothing. Return the structured object.`,
  { label: 'load-context', phase: 'Load', schema: CTX_SCHEMA, agentType: 'context-loader', model: 'haiku', effort: 'low' }
)

// Fail LOUD instead of silently degrading to '<unit>'/[] (the old bug that skipped android/ios).
if (!ctx || !ctx.ok || !ctx.screen_id) {
  throw new Error(`validate-live: could not load the active unit from disk — ${ctx && ctx.error ? ctx.error : 'no unit is building'}. Leave exactly one unit in status:"building" (or pass args.screen_id) and re-run; this workflow no longer degrades to <unit>/[].`)
}

const sid = ctx.screen_id
const plats = (Array.isArray(ctx.platforms) ? ctx.platforms : []).map(p => String(p).toLowerCase())
const expected = ctx.expected_ui_values || []
const engineRefs = Array.isArray(ctx.engine_refs) ? ctx.engine_refs : []
const pipelineRefs = Array.isArray(ctx.pipeline_refs) ? ctx.pipeline_refs : []

// VALIDATE is no longer UI-only. A unit qualifies for the live phase through EITHER an owned UI
// surface OR a declared ENG-*/PIPE-* contract — because an engine that is only verified statically
// never actually ran, and "it does what it should" cannot be proven by reading code.
if (plats.length === 0 && engineRefs.length === 0 && pipelineRefs.length === 0) {
  throw new Error(`validate-live: unit ${sid} owns no runtime on disk — no platforms[] (web/android/ios) and no ENG-*/PIPE-* contract. A UI unit must declare platforms[]; a unit with neither surface should skip VALIDATE entirely. Refusing to run a degraded validation.`)
}

// Select live lens-agents by the unit's owned runtimes; always inspect runtime logs.
const LENSES = []
if (plats.includes('web')) LENSES.push('validate-web')
if (plats.includes('android') || plats.includes('mobile')) LENSES.push('validate-android')
if (plats.includes('ios') || plats.includes('mobile')) LENSES.push('validate-ios')
if (engineRefs.length) LENSES.push('validate-engine')
if (pipelineRefs.length) LENSES.push('validate-pipeline')
LENSES.push('validate-logs')

phase('Drive')
const lenses = await parallel(LENSES.map(a => () =>
  agent(
    `VALIDATE (live) lens ${a} for screen ${sid}. Repo root: ${root}. Drive the real runtime like a human per your spec; assert observed client value derives from expected_ui_values; never PASS without the live runtime.\n\nexpected_ui_values: ${JSON.stringify(expected)}\nroute: ${JSON.stringify(ctx.route || {})}\nengine_refs: ${JSON.stringify(engineRefs)}\npipeline_refs: ${JSON.stringify(pipelineRefs)}\nFeature: ${JSON.stringify(ctx.feature_excerpt || { kind: ctx.kind, platforms: ctx.platforms, acceptance: ctx.acceptance })}`,
    { label: a, phase: 'Drive', agentType: a }
  ).then(r => ({ lens: a, result: r }))
))

// orchestrator-flow consolidates the live verdict + observed ui_value/platform_values.
// A lens whose agent returned nothing is reported by name, never dropped silently.
const ok = lenses.filter(r => r && r.result)
const failed_lenses = LENSES.filter(a => !ok.some(l => l.lens === a))
return { screen_id: sid, platforms: plats, lenses: ok, failed_lenses }
