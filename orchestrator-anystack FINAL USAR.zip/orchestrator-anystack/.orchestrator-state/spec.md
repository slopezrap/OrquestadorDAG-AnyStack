# Orchestrator Spec

> Generated file. Do not edit by hand except for inspection. The human source lives in `blueprint/`.

## Metadata

- schema: `orchestrator.spec.v1`
- lifecycle: `generated`
- generated_by: `scaffold`
- generated_at: `<ISO-8601 UTC>`
- blueprint_hash: `sha256:<hash>`

## State

`/init-build` must replace this placeholder with the consolidated project specification.

## Must contain after `/init-build`

### 1. Consolidated product

- What the product is.
- Why it exists.
- Users/actors.
- Included scope.
- Excluded scope.
- Business rules `BR-*`.

### 2. Logic index

Table with all IDs defined in `blueprint/logic/*.md`:

| id | layer | summary | source |
|---|---|---|---|

### 3. Screen map

Table derived from `blueprint/SCREENS.md`:

| id | slug | title | type | platforms | order | after | applies |
|---|---|---|---|---|---:|---|---|

### 4. Contract per screen

For each `SCR-*` or foundation: purpose, routes, applies, acceptance, UI states, data, verify/validate lenses and minimum evidence.

### 4.1 Data engine

For each unit with `DATA-*`, include `data_engine`: source rules, canonical resource in the database, generation/pipeline method, read path DB -> API/read model -> frontend/mobile and single-value contract.


### 5. CLARIFY decisions

| date | question | decision | impact |
|---|---|---|---|
