# Core Logic — invariantes sistémicas

Define identidad, tenant, auditoría, tiempo, idempotencia, seguridad y consistencia transversal. Plantilla completa: `blueprint-templates/logic/core-template.md`.

## Reglas

### CORE-001 — Pendiente de definir

```logic
id: CORE-001
status: draft
summary: "Pendiente de definir"
related_screens: []
depends_on: []
severity: must
verification:
  observable_by: []
  evidence: []
```

**Regla:** Pendiente.

**Verificable:** Pendiente.
