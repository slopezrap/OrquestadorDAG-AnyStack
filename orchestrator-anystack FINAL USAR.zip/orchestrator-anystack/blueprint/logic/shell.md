# Shell Logic — contrato compartido entre pantallas

Define lo que TODAS las pantallas comparten para que, construidas de una en una, encajen entre sí: shell/layout global, mapa de navegación, inventario de componentes reutilizables, convención de rutas y contrato de API interna. Plantilla completa: `blueprint-templates/logic/shell-template.md`.

`verify-coherence` y `pantalla-reviewer` comprueban cada pantalla contra este fichero. `related_screens: [ALL]` significa toda pantalla `kind: ui`, presente y futura.

## Reglas

### UI-SHELL-001 — Pendiente de definir

```logic
id: UI-SHELL-001
status: draft
summary: "Pendiente de definir"
related_screens: [ALL]
depends_on: []
severity: must
verification:
  observable_by: []
  evidence: []
```

**Regla:** Pendiente.

**Verificable:** Pendiente.
