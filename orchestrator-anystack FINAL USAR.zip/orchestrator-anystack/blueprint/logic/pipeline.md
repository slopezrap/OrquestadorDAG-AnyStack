# Pipeline Logic — producción y movimiento del dato

Define cada pipeline como artefacto de primera clase: trigger, source/transform/sink, garantías de entrega, backfill/replay, reintentos, SLA de frescura, perfil de escala, runbook de fallo y observabilidad. Plantilla completa: `blueprint-templates/logic/pipeline-template.md`.

Regla central: `source -> PIPE-* -> almacén canónico -> ENG-*/read model -> pantallas`. El pipeline es la única vía sancionada para llevar dato de producto al almacén canónico, y todo lo que escribe se genera por una ruta REAL (`migration|seed|backfill|job|api_write|user_action|event_replay|state_transition`): nunca fixtures, mocks, stubs ni valores inventados, en ninguna capa. Un pipeline que no se puede probar que ha corrido no ha corrido.

`PIPE-*` posee CÓMO y CUÁNDO se mueve el dato; el esquema de lo que escribe es de `DATA-*` —que lo cita con `pipeline_ref` en vez de anidar su propio bloque `pipeline:`— y las reglas que aplica son de `ENG-*`/`DOM-*`. Una unidad que no consume ningún pipeline lo declara con `not_applicable: true` y una `not_applicable_reason` concreta, nunca dejando el contrato a medias.

## Reglas

### PIPE-001 — Pendiente de definir

```logic
id: PIPE-001
type: pipeline
status: draft
summary: "Pendiente de definir"
product_refs: []
feeds: []
writes: []
related_screens: []
severity: must
not_applicable: false
not_applicable_reason: null
trigger:
  kind: "schedule|event|on_write|manual|replay|pending"
  spec: "Pendiente de definir"
source: []
transform: []
sink:
  store: "database|event_store|state_store|ledger|external_system|file_store|pending"
  resource: "Pendiente de definir"
guarantees:
  ordering: "none|per_key|global|pending"
  delivery: "at_least_once|exactly_once|pending"
  idempotency_key: "Pendiente de definir"
backfill:
  supported: true
  procedure: "Pendiente de definir"
  replay_safe: true
retry:
  policy: "none|linear|exponential|pending"
  max_attempts: 3
  dead_letter: "Pendiente de definir"
freshness:
  sla: "Pendiente de definir"
  max_lag: "Pendiente de definir"
  measured_by: "Pendiente de definir"
scale:
  volume_profile: "Pendiente de definir"
  batch_size: 500
  concurrency: 1
  breaks_at: "Pendiente de definir"
failure_runbook: "Pendiente de definir"
observability:
  run_log: "Pendiente de definir"
  metrics: []
  how_to_prove_it_ran: "Pendiente de definir"
real_data:
  generation_method: "migration|seed|backfill|job|api_write|user_action|event_replay|state_transition|pending"
  no_fixtures: true
  verification_path: "Pendiente de definir"
verification:
  observable_by: [job, db, api, log]
  evidence: [pipeline_run_log, db_query, api_response]
```

**Regla:** Pendiente.

**Verificable:** Pendiente.
