# Use Case Logic — objetivos de usuario/sistema

Define actor, objetivo, precondiciones, flujo principal, alternativas y aceptación. Plantilla completa: `blueprint-templates/logic/usecases-template.md`.

## Reglas

### UC-001 — Pendiente de definir

```logic
id: UC-001
status: draft
summary: "Pendiente de definir"
related_screens: []
depends_on: []
severity: must
verification:
  observable_by: []
  evidence: []
```

**Regla:** Pendiente.

**Verificable:** Pendiente.
