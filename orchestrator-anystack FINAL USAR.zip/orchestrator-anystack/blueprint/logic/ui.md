# UI Logic — comportamiento visible y UX

Define estados visibles, accesibilidad, responsive, microcopy y reglas de interacción. Plantilla completa: `blueprint-templates/logic/ui-template.md`.

## Reglas

### UI-001 — Pendiente de definir

```logic
id: UI-001
status: draft
summary: "Pendiente de definir"
related_screens: []
depends_on: []
severity: must
verification:
  observable_by: []
  evidence: []
```

**Regla:** Pendiente.

**Verificable:** Pendiente.
