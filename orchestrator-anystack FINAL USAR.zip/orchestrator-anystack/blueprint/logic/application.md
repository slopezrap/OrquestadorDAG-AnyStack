# Application Logic — comandos, queries y efectos

Define casos técnicos de aplicación, servicios, transacciones, validaciones y efectos. Plantilla completa: `blueprint-templates/logic/application-template.md`.

## Reglas

### APP-001 — Pendiente de definir

```logic
id: APP-001
status: draft
summary: "Pendiente de definir"
related_screens: []
depends_on: []
severity: must
verification:
  observable_by: []
  evidence: []
```

**Regla:** Pendiente.

**Verificable:** Pendiente.

### APP-002 — Pendiente de definir (caso backend/data sin UI — lo cita SCR-002)

```logic
id: APP-002
status: draft
summary: "Pendiente de definir"
related_screens: []
depends_on: []
severity: must
verification:
  observable_by: []
  evidence: []
```

**Regla:** Pendiente.

**Verificable:** Pendiente.
