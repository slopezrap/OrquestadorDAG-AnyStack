# Engine Logic — decisión, cálculo y grafos de agente

Define cada motor como módulo con contrato: frontera, entradas/salidas tipadas, determinismo, versionado, observabilidad, modo de fallo y evidencia. La capa es polimórfica por `kind` —igual que el orquestador es AnyStack para el almacén—, así que al resolver `kind` hay que añadir su bloque propio con ese mismo nombre: `rules_engine` (`rules`/`precedence`/`conflict_resolution`/`explainability`/`edge_cases`), `compute_engine` (`transforms`/`window`/`aggregation`/`reprocess`/`numeric_exactness`/`invariants`) o `agent_graph` (`nodes`/`edges`/`state_schema`/`checkpointer`/`tools`/`prompts`/`stop_criteria`/`eval`/`fallback`). Plantilla completa: `blueprint-templates/logic/engine-template.md`.

Regla central: `BR-*/DOM-* -> ENG-* -> salidas declaradas -> DATA-*/read model -> API/servicio -> pantallas`. Un motor es el ÚNICO sitio donde vive su decisión o su cálculo: comandos, casos de uso y pantallas lo consumen por `inputs`/`outputs` y nunca lo reimplementan inline ni alcanzan sus internos.

`ENG-*` posee QUÉ se decide o se calcula; el esquema durable de lo que escribe es de `DATA-*`, el movimiento del dato de `PIPE-*`, la orquestación del comando de `APP-*` y las invariantes de sistema de `CORE-*`. La forma de la evidencia (`engine_assertions[]`) depende de `determinism`: los kinds deterministas deben igualdad literal recomputable por el gate (`input_value -> engine_value -> stored_value`), mientras que un `agent_graph` no promete igualdad entre ejecuciones y debe `eval_result` sobre su golden set, checkpoint persistido y fallback realmente ejercitado. Un producto sin motores lo declara con `not_applicable: true` y una `not_applicable_reason` concreta, nunca dejando el contrato a medias.

## Reglas

### ENG-001 — Pendiente de definir

```logic
id: ENG-001
type: engine
kind: "rules_engine|compute_engine|agent_graph|pending"
status: draft
summary: "Pendiente de definir"
product_refs: []
related_screens: []
depends_on: []
severity: must
not_applicable: false
not_applicable_reason: null
module:
  boundary: "Pendiente de definir"
  owns: []
  does_not_own: []
  consumed_by: []
inputs: []
outputs: []
determinism: "deterministic|non_deterministic|pending"
versioning:
  version: "1.0.0"
  migration_on_change: "recompute|backfill|pin_existing_records|re_run_golden_set|none|pending"
observability:
  decision_trace: true
  log_target: "Pendiente de definir"
failure:
  on_error: null
  degraded_mode: "safe_default|deny|serve_last_good_value|deterministic_fallback|pending"
verification:
  observable_by: [test, db, api, log]
  evidence: [test_output, db_query, decision_trace]
```

**Regla:** Pendiente.

**Verificable:** Pendiente.
