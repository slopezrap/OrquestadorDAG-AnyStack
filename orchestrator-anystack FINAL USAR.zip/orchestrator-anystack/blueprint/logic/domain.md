# Domain Logic — dominio, entidades e invariantes

Define conceptos de negocio, entidades, relaciones e invariantes. Plantilla completa: `blueprint-templates/logic/domain-template.md`.

## Reglas

### DOM-001 — Pendiente de definir

```logic
id: DOM-001
status: draft
summary: "Pendiente de definir"
related_screens: []
depends_on: []
severity: must
verification:
  observable_by: []
  evidence: []
```

**Regla:** Pendiente.

**Verificable:** Pendiente.
