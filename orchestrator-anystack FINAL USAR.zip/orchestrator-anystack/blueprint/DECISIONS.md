# DECISIONS.md — registro de decisiones

> Toda decisión de producto tomada DESPUÉS de escribir el blueprint inicial. Append-only.
>
> El *qué* de una decisión sobrevive (acaba escrito en su capa). El *porqué* no: se queda en un chat que la compactación borra. Este fichero guarda el porqué, y es lo que permite distinguir una regla deliberada de una deriva.
>
> Molde completo con todos los campos: `blueprint-templates/DECISIONS-template.md`.

## Reglas

- **Append-only.** Una decisión no se edita ni se borra: se revierte con una decisión NUEVA que la supersede. La antigua queda como historia.
- **La decisión no es la verdad, es el registro del cambio.** La verdad operativa sigue en su capa; `written_to` dice dónde aterrizó.
- **La escribe `orchestrator-flow`, la toma el humano.** `decided_by` es una persona. Una decisión que el humano no tomó es intención de producto inventada.

## Índice

| ID | Fecha | Decisión | Supersede | Escrita en |
|---|---|---|---|---|
| — | — | *(sin decisiones todavía)* | — | — |

<!-- Añade cada decisión como una sección ## DEC-00N con su bloque ```logic, siguiendo el molde. -->
