# ORIGINAL.md — tu documento, tal cual

> **Opcional.** Si no lo usas, bórralo o déjalo vacío: el orquestador funciona igual.

Pega aquí el documento que ya tenías **antes** del repo: el brief, el correo al socio, la
transcripción de la reunión, las notas del cuaderno, el hilo de WhatsApp pasado a limpio.
Tal cual, sin ordenarlo.

**No tiene formato.** Prosa libre, tan larga como haga falta, sin IDs, sin bloques, sin
tablas obligatorias, sin plantilla. Contradicciones, cosas a medio decidir y frases de
color son bienvenidas: así es como se escribe un producto de verdad.

## Para qué sirve

Cuando una lente audita su capa y se encuentra un hueco, antes de preguntarte **lee esto**.
Si la respuesta ya está aquí, la escribe en su capa citando de dónde la sacó, y no te
molesta. Solo te pregunta lo que de verdad no has dicho en ninguna parte.

O sea: **cuantas más cosas cuentes aquí, menos preguntas te hacen.** Y las que te hagan
serán decisiones reales, no cosas que ya habías explicado.

## Qué NO es

- **No es `PRODUCT.md`.** Ese ya es una capa: tiene metadatos, tabla de actores y reglas
  `BR-*` con IDs. Esto es el material en bruto del que sale aquello.
- **No es el contrato.** Las 14 capas son el contrato; esto es el recibo. Si el original y
  una capa se contradicen, **gana la capa** — porque la capa es lo que revisaste y
  aprobaste, y esto es lo que dijiste antes de pensarlo del todo.
- **No es un canal de cambios.** Cuando decidas algo nuevo a mitad del build, va a su capa
  y queda registrado en `DECISIONS.md` con el porqué. Este fichero se queda como estaba: es
  el punto de partida, no el diario.

## Quién escribe aquí

Solo tú. El orquestador nunca escribe en este fichero — lo lee y nada más.

---

<!-- A partir de aquí, tu texto. Borra esta línea y escribe (o pega) lo que sea. -->
