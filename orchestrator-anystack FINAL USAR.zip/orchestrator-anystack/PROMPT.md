# Prompt para rellenar el blueprint

Usa este documento como cuestionario antes de rellenar los archivos de `blueprint/`. Su objetivo es recoger decisiones de producto y operación completas, comprensibles para una persona y verificables después. No hace falta conocer programación, arquitectura ni los identificadores internos del orquestador.

No respondas con frases genéricas como "que sea seguro", "que funcione rápido" o "como una app normal". Describe qué debe pasar, para quién, en qué condiciones y cómo sabremos que ha ocurrido. Si una parte no aplica, escribe `No aplica` y explica por qué. Si aún no hay decisión, escríbela como pregunta abierta: no la inventes.

## Instrucciones para quien responda

Responde con ejemplos concretos. Cuando hables de datos, usa valores ficticios pero realistas. Cuando hables de reglas, incluye un caso permitido y uno que debe rechazarse. Cuando haya varios roles, explica las diferencias entre ellos.

Puedes responder por apartados, adjuntar un documento existente o describir el producto libremente primero. Después completa las preguntas que falten. Una nota, correo o brief previo puede guardarse sin editar en `blueprint/ORIGINAL.md`; sirve como contexto, pero las decisiones finales deben quedar distribuidas en los documentos del blueprint.

El resultado se escribirá en estos archivos:

```text
blueprint/PRODUCT.md
blueprint/SCREENS.md
blueprint/logic/domain.md
blueprint/logic/application.md
blueprint/logic/core.md
blueprint/logic/journey.md
blueprint/logic/permission.md
blueprint/logic/state.md
blueprint/logic/error.md
blueprint/logic/integration.md
blueprint/logic/ui.md
blueprint/logic/shell.md
blueprint/logic/data.md
blueprint/logic/usecases.md
blueprint/logic/engine.md
blueprint/logic/pipeline.md
blueprint/DECISIONS.md
```

## 1. Producto y alcance

Explica el producto como se lo explicarías a la persona que lo va a usar:

- ¿Cómo se llama y qué problema concreto resuelve?
- ¿Quién lo usa? Para cada tipo de usuario, ¿qué objetivo persigue, qué sabe hacer hoy y qué limitaciones tiene?
- ¿Qué resultado observable debe obtener cada usuario al usarlo?
- ¿Qué hace que sea preferible a hacerlo manualmente o con una alternativa existente?
- ¿Qué capacidades deben estar sí o sí en la primera versión?
- ¿Qué queda expresamente fuera de la primera versión, aunque parezca útil?
- ¿Qué reglas de negocio no se pueden romper? Para cada una, describe por qué existe, cuándo se aplica, un ejemplo válido, uno inválido y cómo una persona comprobaría que se cumple.
- ¿Qué tono debe tener el producto? ¿Qué expresiones o formas de hablar deben evitarse? ¿Hay textos, avisos o términos que deban usarse siempre?
- ¿Qué restricciones legales, sectoriales, de privacidad, seguridad o accesibilidad existen?
- ¿Cómo se medirá que la primera versión ha tenido éxito?
- ¿Qué supuestos se están haciendo y cuáles son las dudas todavía abiertas?

## 2. Arquitectura y decisiones transversales

Describe el diseño técnico en términos de responsabilidades y consecuencias, no como una lista de tecnologías. Esta parte cumple la función de `arc42`: una forma estructurada de explicar la arquitectura, sus límites, decisiones, riesgos y cómo opera el sistema.

- ¿Cuáles son los objetivos de calidad más importantes: privacidad, disponibilidad, rapidez, trazabilidad, coste, facilidad de operación u otros? Ordénalos si entran en conflicto.
- ¿Qué restricciones son innegociables: tecnología impuesta, presupuesto, región, regulación, conexión intermitente, dispositivos, plazos o equipo disponible?
- ¿Qué queda dentro del sistema y qué sistemas, proveedores o equipos están fuera?
- ¿Cuál es la estrategia principal: aplicación web, móvil, API, procesos en segundo plano, eventos, automatizaciones o una combinación? ¿Por qué?
- ¿Cuáles son los grandes bloques del producto y qué responsabilidad tiene cada uno? Por ejemplo: interfaz, API, autenticación, lógica de negocio, almacenamiento, trabajos en segundo plano, observabilidad o integraciones.
- Describe los escenarios que más importan en ejecución: una operación normal, un fallo de proveedor, un pico de carga, una actualización de datos y una recuperación tras un error.
- ¿Dónde se ejecutará durante el piloto y cuál es el destino de producción? ¿Qué entornos habrá y cómo se promueven los cambios?
- ¿Cómo se separan clientes, organizaciones o cuentas? ¿Qué datos nunca pueden mezclarse?
- ¿Quién operará el sistema, cómo se harán copias de seguridad y cómo se probará una restauración?
- ¿Qué se registrará en logs, qué métricas y alertas habrá, qué nivel de servicio se espera y qué coste o volumen se considera aceptable?
- ¿Qué decisiones técnicas son difíciles de revertir? Para cada una, indica alternativas consideradas, la opción elegida, el motivo y su consecuencia.
- ¿Qué riesgos técnicos, operativos, de datos o de producto son relevantes? Indica impacto, probabilidad, mitigación y señal que avisaría de que el riesgo se ha materializado.

## 3. Conceptos y reglas de dominio

La lógica de dominio define el vocabulario y las reglas del negocio. No depende de la interfaz ni del framework: debe seguir siendo cierta aunque mañana cambie la tecnología o no exista pantalla.

- ¿Cuáles son los conceptos, entidades y términos del negocio? Define cada uno en lenguaje sencillo.
- ¿Qué nombres alternativos son ambiguos o no deben usarse?
- ¿Qué atributos tiene cada concepto, qué significan y cuáles son obligatorios?
- ¿Cómo se relacionan entre sí los conceptos? ¿Quién posee cada elemento?
- ¿Qué condiciones deben ser siempre verdaderas? Incluye contraejemplos que el sistema debe impedir.
- ¿Qué reglas afectan a fechas, zonas horarias, importes, unidades, redondeos, límites, cantidades o caducidades?

## 4. Lógica de aplicación

La lógica de aplicación describe qué hace internamente el sistema para cumplir una acción o una operación. Separa los comandos que cambian algo de las consultas que solo leen información. No define el aspecto visual.

Para cada acción o consulta relevante, explica:

- Quién la inicia y qué evento la dispara.
- Qué datos recibe, cuáles son obligatorios y cómo se validan.
- Qué debe comprobar antes de actuar, incluidos permisos y estado actual.
- Qué pasos realiza en orden.
- Qué datos guarda, modifica o consulta; qué respuesta, evento, registro o aviso produce.
- Si debe ejecutarse como una única operación atómica.
- Si repetir la misma petición debe ser seguro o puede crear duplicados; si debe ser segura, qué identifica una repetición.
- Qué errores puede producir y cómo se recupera de cada uno.
- Qué debe quedar observable en datos, logs, API o interfaz.
- En las consultas, qué filtros, orden, paginación, visibilidad y política de caché necesita.

## 5. Lógica central especializada

La lógica central describe decisiones, cálculos o mecanismos especializados que no deben quedar dispersos por pantallas o acciones. Puede abarcar reglas globales de identidad, aislamiento, auditoría, tiempo, idempotencia, trazabilidad y consistencia.

- ¿Qué decisiones o cálculos importantes deben tener un único lugar de implementación?
- ¿Cuáles aplican a todo el producto, no solo a una pantalla?
- ¿Cómo se identifica al usuario autenticado y cómo se demuestra que nadie puede suplantar a otro usuario?
- Si existen organizaciones o clientes, ¿cómo se aísla cada uno en lecturas y escrituras?
- ¿Cuál es la fuente de hora y zona horaria para cada fecha de negocio?
- ¿Qué acciones críticas necesitan auditoría? Indica actor, recurso, acción, resultado y fecha que deben quedar registrados.
- ¿Qué operaciones repetibles necesitan una clave de idempotencia?
- ¿Qué debe registrarse para investigar un fallo sin exponer secretos ni datos privados?

## 6. Recorridos completos

Un recorrido representa la experiencia de principio a fin de una persona o de un actor del sistema. Conecta pantallas, acciones, cambios de estado, permisos, datos y errores.

Para cada recorrido importante, indica:

- Quién lo realiza, desde dónde empieza y qué quiere conseguir.
- Qué datos, permisos o contexto ya deben existir.
- Cada paso, con la pantalla o canal, acción, resultado esperado y datos que cambian o se muestran.
- Ramas alternativas: cancelación, datos vacíos, permiso denegado, error, pérdida de red, conflicto o abandono.
- Cómo termina con éxito y qué resultado queda persistido o visible.
- Qué debe pasar si se abandona a mitad de camino.
- Cómo se recorrerá y comprobará de extremo a extremo con datos reales.

## 7. Permisos y aislamiento

La lógica de permisos define quién puede hacer qué, sobre qué recurso y bajo qué condición. Los permisos se aplican en el sistema, no solo ocultando botones.

- Lista los roles o tipos de actor.
- Para cada recurso importante, indica quién puede crear, leer, modificar, eliminar o ejecutar acciones.
- ¿Qué condición debe cumplirse para permitir una acción? Por ejemplo, propiedad, pertenencia a una organización, estado del recurso o aprobación previa.
- ¿Cuándo debe denegarse? Incluye casos de acceso a datos de otra persona u organización.
- ¿Qué ve la persona cuando se le deniega una acción y qué respuesta recibe la integración o API?
- ¿Qué intentos o acciones requieren registro de auditoría?
- Define, como mínimo, un caso permitido y otro denegado por cada permiso crítico.

## 8. Estados, transiciones y concurrencia

La lógica de estado describe los estados de entidades o procesos de la aplicación. No describe el ciclo de vida interno del orquestador.

- ¿Qué entidades o procesos cambian de estado?
- Para cada uno, ¿cuál es el estado inicial, cuáles son los estados finales y qué significa exactamente cada estado?
- ¿Qué eventos, actores o sistemas pueden moverlo de un estado a otro?
- ¿Qué condiciones deben cumplirse y qué efectos produce cada transición?
- ¿Qué transiciones deben prohibirse y qué error debe devolverse?
- ¿Qué estados se guardan y cuáles se muestran al usuario?
- Si dos personas o procesos modifican lo mismo a la vez, ¿qué debe pasar?
- ¿Cómo se comporta el sistema si el cliente está sin conexión, llega tarde o tiene información desactualizada?

## 9. Errores, recuperación y comunicación

La lógica de errores cubre fallos previsibles y su recuperación, tanto visibles como técnicos.

Para cada error relevante, describe:

- Qué condición lo provoca.
- Si es de validación, permiso, ausencia de datos, conflicto, red, servidor o integración externa.
- El mensaje claro que debe ver la persona, sin jerga ni trazas técnicas.
- Qué puede hacer para recuperarse: corregir, reintentar, volver, solicitar acceso o esperar.
- Qué respuesta estructurada debe recibir un cliente técnico o una API.
- Qué se registra, con qué severidad y sin qué datos sensibles.
- Si se conserva o revierte cualquier cambio parcial.
- Qué nunca debe ocurrir: perder datos introducidos, reintentar infinitamente, mostrar secretos o dejar información incoherente.

## 10. Integraciones y proveedores externos

Describe cada sistema externo: APIs, webhooks, colas, correo, pagos, almacenamiento, analítica, mapas, modelos de IA u otros proveedores.

- ¿Qué sistema es, para qué se usa y en qué dirección fluye la información?
- ¿Qué la activa y qué datos entran y salen? Incluye campos necesarios, tipos lógicos y reglas.
- ¿Cómo se autentica? Nombra solo variables de entorno o mecanismos, nunca secretos reales.
- ¿Qué límite de tiempo se acepta y cómo se reintenta?
- ¿Cómo se evita procesar dos veces el mismo webhook, envío o petición?
- ¿Qué ocurre ante caída, respuesta inválida, demora, cuota agotada o resultado incompleto? ¿Hay modo degradado o alternativa?
- ¿Qué se persiste y qué se audita?
- ¿Qué logs, métricas e identificadores de correlación permiten diagnosticarlo?
- ¿Cómo se verificará: entorno sandbox, llamada real autorizada, contrato, logs o prueba alternativa justificada?

## 11. Datos, fuente de verdad y privacidad

Esta sección es esencial. Declara qué dato es canónico, cómo se genera y cómo llega a cada interfaz. La fuente de verdad nunca puede ser una constante local del cliente.

- ¿Cuál es el almacén canónico de cada dato: base de datos, documentos, eventos, estado persistido, ledger, sistema externo o archivos?
- Para cada entidad o conjunto de datos, ¿quién es propietario, cómo se crea, qué campos cambian, cuáles no y qué validaciones o restricciones tiene?
- ¿Qué consultas necesita el producto? Indica filtros, orden, paginación, permisos y el volumen esperado.
- ¿Qué índices, restricciones de unicidad o relaciones son necesarios para esas consultas y reglas?
- Para cada valor importante que se muestra, indica de dónde sale en el almacén, cómo llega por API, servicio o modelo de lectura y dónde se ve en web o móvil. Debe ser posible comprobar que es el mismo valor para el mismo contexto de usuario, organización y permiso.
- ¿Cómo se generan datos reales para desarrollo y verificación: migración, semilla, trabajo, escritura por API, acción de usuario, reproducción de eventos o transición de estado?
- ¿Qué escenarios reales deben poder crearse: vacío, éxito, error, permiso denegado, conflicto y datos antiguos o desactualizados?
- ¿Hay datos personales, sensibles o regulados? Indica retención, borrado, exportación, cifrado, acceso y auditoría.
- ¿Hay cachés, proyecciones o modelos de lectura? ¿Cómo se invalidan o reconstruyen?

## 12. Motores de reglas, cálculo o agentes

Un motor es un módulo que toma datos y produce una decisión, cálculo o resultado especializado. Debe tener un único propósito y los demás componentes lo consumen mediante su contrato; no se duplica la misma regla en varias pantallas.

Para cada motor, responde:

- ¿Qué decisión, cálculo o tarea resuelve exactamente?
- ¿Qué queda dentro de su responsabilidad y qué queda fuera: persistencia, orquestación de acciones, permisos globales o integración externa?
- ¿Quién lo consume y qué entrada recibe? ¿Qué salida produce y dónde queda disponible?
- ¿El resultado es determinista? Si se repite con la misma entrada, ¿debe obtenerse exactamente el mismo resultado?
- Si aplica reglas, ¿cuáles son, en qué orden se evalúan, cómo se resuelven conflictos y cuál es el resultado cuando ninguna coincide?
- Si calcula valores, ¿qué fórmula, ventana temporal, agregación, unidad, precisión y regla de redondeo usa? Incluye un ejemplo trabajado con entradas y resultado esperado.
- Si usa IA o un grafo de agentes, ¿qué nodos y herramientas tiene, dónde persiste su estado, cuándo se detiene, cómo se versionan instrucciones, cómo se evalúa con un conjunto de casos y cuál es su alternativa segura si falla?
- ¿Cómo evoluciona una regla o versión sin corromper resultados anteriores: recalcular, hacer backfill, fijar resultados o ejecutar una migración?
- ¿Qué traza de decisión, logs, valor persistido o evaluación permite demostrar que funciona?

## 13. Pipelines y procesos que alimentan los datos

Un pipeline es el camino ejecutable que lleva datos reales desde un origen hasta el almacén canónico, un motor, una proyección o una pantalla. Describe cómo y cuándo se mueven los datos, no el esquema que almacenan.

Para cada pipeline o proceso automático, indica:

- Qué lo activa: horario concreto, evento, acción de usuario, API, trabajo manual o reproducción.
- De qué origen toma datos, qué transformaciones realiza y a qué recurso o almacén escribe.
- Qué datos o motores alimenta y qué pantallas dependen de su resultado.
- Qué orden garantiza, qué garantía de entrega tiene y cuál es la clave que evita duplicados.
- Si admite reproceso o backfill: procedimiento, rango, seguridad de repetición y cómo se comprueba el resultado.
- Política de reintentos, intentos máximos y destino de elementos fallidos.
- Cuánto puede tardar un dato en ser visible, cómo se mide el retraso y qué debe mostrar o hacer la interfaz si está obsoleto.
- Volumen esperado, tamaño de lote, concurrencia y qué se rompería con diez veces más carga.
- Qué hacer primero cuando falla, se retrasa o deja una escritura parcial.
- Dónde queda el log de ejecución, qué métricas registra y qué comando o consulta real prueba que se ejecutó y escribió su resultado.
- Cómo se ejecutará una prueba real sin fixtures, mocks, stubs ni valores inventados.

## 14. Interfaz, experiencia y diseño visual

La lógica de interfaz define el comportamiento visible. No debe esconder reglas de negocio, permisos ni cálculos: los muestra y consume sus resultados.

Para cada pantalla o superficie visible, describe:

- Nombre, objetivo, usuario principal, plataforma y ruta o enlace profundo.
- Desde qué lugar se entra, con qué datos previos y cuál debe ser el estado inicial.
- Qué ve y qué puede hacer el usuario; qué se guarda o cambia y a dónde navega después.
- Estados de carga, sin datos, error, permiso denegado, éxito, datos obsoletos y acciones deshabilitadas cuando correspondan.
- Textos visibles, acciones disponibles, confirmaciones y recuperación de errores.
- Datos reales que muestra y su origen.
- Diseño de referencia, tokens visuales, reglas de responsive y componentes existentes que debe reutilizar.
- Reglas de accesibilidad: teclado, lector de pantalla, etiquetas, contraste, foco y tamaño de objetivos táctiles.
- Diferencias necesarias entre web, Android e iOS.
- Cómo se comprobará con una interacción real, capturas de los estados importantes y logs limpios.

## 15. Shell compartido, navegación y contratos comunes

El shell es el contrato común para que todas las pantallas encajen entre sí. Describe una vez lo que se comparte y no permitas que cada pantalla lo reinvente.

- ¿Qué estructura global tienen las pantallas: cabecera, navegación, pie, barra de pestañas, contexto de sesión y zonas de contenido?
- ¿Cómo cambia esa estructura entre web y móvil?
- ¿Qué opciones de navegación existen, en qué orden y para qué roles o permisos se muestran?
- ¿Cuál es el punto de entrada de cada pantalla y cuál es el camino de vuelta?
- ¿Qué componentes reutilizables hay: botones, formularios, tablas, estados vacíos, errores, diálogos, avisos, navegación? Indica estados que deben soportar y dónde vivirán cuando se implementen.
- ¿Cuál es la convención única para rutas y enlaces profundos? Define plural/singular, nombres, parámetros y excepciones.
- ¿Qué convenciones comparten las APIs internas: versión, autenticación, formato de respuesta, errores, paginación y filtros?
- ¿Dónde están los tokens de color, tipografía, espaciado, radio y elevación? Las pantallas deben reutilizarlos, no inventar valores aislados.

## 16. Casos de uso y criterios de aceptación

Un caso de uso expresa un objetivo atómico de una persona o sistema. Puede abarcar una o varias pantallas, pero debe terminar en un resultado claro.

Para cada caso de uso, especifica:

- Quién lo realiza, qué quiere conseguir y qué beneficio obtiene.
- Qué lo dispara y qué condiciones deben existir antes de empezar.
- Flujo principal paso a paso.
- Flujos alternativos y excepciones.
- Qué datos recibe, qué persiste y qué resultado consulta.
- Qué permisos necesita y qué estados puede modificar.
- Qué criterio observable demuestra que terminó bien.
- Criterios de aceptación redactados de forma comprobable: "Cuando ocurra X, el sistema debe hacer Y"; "Si ocurre X, debe mostrar o devolver Y"; "En el contexto X, debe respetar Y".

## 17. Plan de construcción y evidencia

Define las unidades que se construirán y el orden en que deben estar disponibles. Una unidad puede ser una pantalla, un esquema de datos, autenticación, un shell, una integración, un motor o un pipeline común.

Para cada unidad, indica:

- Qué entrega y por qué aporta valor o habilita otras unidades.
- Qué debe existir antes de empezar y de qué otras unidades depende.
- Qué documentos, reglas, datos, permisos, estados, errores, integraciones, motores o pipelines le aplican.
- Qué plataformas afecta y cuál es su ruta si es visible.
- Qué criterios de aceptación debe cumplir.
- Qué pruebas reales se ejecutarán: pruebas automáticas, migraciones, API, trabajos, consultas al almacén, navegador, emulador o simulador.
- Qué evidencia debe quedar: salida de pruebas, logs, consultas, respuesta de API, capturas, grabaciones o trazas de decisión.
- Qué datos reales se necesitan antes de verificarla y cómo se crearán de forma repetible.

Incluye como cimientos separados, cuando apliquen, el esquema inicial, autenticación, shell compartido y cualquier motor o pipeline que vaya a ser usado por más de una unidad. No crees cimientos especulativos: si algo solo lo usa una pantalla, puede construirse dentro de esa pantalla.

## 18. Stack, comandos y operación local

Para poder construir y verificar sin adivinar, aporta:

- Runtime, backend, frontend, móvil, almacén canónico, migraciones, pruebas y herramienta de verificación visual.
- Direcciones locales de web, API y otros servicios.
- Comandos reales para instalar dependencias, preparar el entorno, arrancar, aplicar migraciones, cargar datos verificables, ejecutar lint, pruebas, build y smoke test.
- Dónde se consultan los logs de navegador, servidor, worker, base de datos, móvil y proveedores.
- Qué variables de configuración existen, para qué sirven, valor seguro por defecto, dónde se definen y cómo se validan. Nunca incluyas secretos.

## 19. Checklist antes de dar el blueprint por completo

- [ ] El problema, usuarios, alcance y fuera de alcance son comprensibles sin leer código.
- [ ] Cada regla importante tiene ejemplos permitidos y prohibidos.
- [ ] Cada dato visible tiene un origen canónico y una ruta hasta la interfaz.
- [ ] Existen datos reales y reproducibles para comprobar vacío, éxito, error y permisos.
- [ ] Los permisos cubren tanto permitir como denegar.
- [ ] Los estados tienen transiciones permitidas y prohibidas.
- [ ] Los errores indican mensaje, recuperación, respuesta técnica y registro.
- [ ] Las integraciones declaran fallo, timeout, reintento, idempotencia y observabilidad.
- [ ] Los cálculos, reglas y uso de IA tienen un contrato, trazabilidad y evidencia apropiada.
- [ ] Los pipelines tienen activación, fuente, destino, idempotencia, reproceso, frescura, escala y runbook.
- [ ] Cada pantalla declara estados, accesibilidad, responsive, datos reales y navegación.
- [ ] El shell, las rutas, los componentes compartidos y las APIs internas están definidos una vez.
- [ ] Cada unidad de construcción tiene dependencias, criterios observables y una forma de verificarse con evidencia real.
- [ ] Las decisiones nuevas posteriores quedan registradas con qué se decidió, por qué, quién lo decidió y dónde se escribió.
- [ ] Todo lo que no está decidido queda como pregunta abierta, no como una suposición del modelo.