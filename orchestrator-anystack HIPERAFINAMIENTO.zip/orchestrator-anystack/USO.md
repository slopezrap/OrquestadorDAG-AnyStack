# Cómo usar este orquestador

Guía de arranque: **qué copiar, qué rellenar, qué no tocar, y en qué orden**.

Para el detalle de cada comando está `README.md`; para las reglas, `.claude/rules/`. Esto es lo
mínimo para pasar de una carpeta vacía a un producto en construcción sin equivocarse.

---

## 1. Copiar

Copia el contenido de esta carpeta a la raíz de tu proyecto. Son cuatro directorios y dos ficheros:

```
.claude/            la maquinaria (agentes, skills, workflows, hooks) + tus reglas
.orchestrator/      definición estable: scripts, schemas, plantillas, ejemplo
.orchestrator-state/  estado en ejecución (nace vacío, lo escribe el orquestador)
blueprint/          TU especificación — es lo único que de verdad escribes
blueprint-templates/  los moldes que copias al escribir el blueprint
CLAUDE.md           memoria de proyecto
```

Si tu proyecto ya tiene código, cópialo igual: el orquestador explora lo que existe antes de
construir.

---

## 1b. Abre Claude Code EN la raíz del proyecto

Antes de nada, y es la causa de fallo más tonta de todas: **lanza Claude Code desde la carpeta que
contiene `.claude/`**, no desde su padre.

```bash
cd /ruta/a/tu-proyecto      # aquí dentro está .claude/
claude
```

Claude Code resuelve los subagentes desde la raíz del proyecto. Si abres la sesión un nivel por
encima, los 69 agentes **no existen** y cualquier abanico falla con:

```
agent type 'arch-risk' not found.
Available agents: claude, Explore, general-purpose, Plan, ...
```

No es que el orquestador esté roto: es que no lo está viendo. Compruébalo con `/context`, que lista
lo que la sesión cargó de verdad.

---

## 2. Qué rellenas tú y qué no

Esta es la tabla que evita el 90% de los errores de arranque.

| Ruta | ¿Lo tocas? | Qué es |
|---|---|---|
| `blueprint/PRODUCT.md` | **Sí** | Actores, alcance y reglas de negocio (`BR-*`) |
| `blueprint/SCREENS.md` | **Sí** | El plan de obra: unidades, orden y dependencias |
| `blueprint/logic/*.md` (14) | **Sí** | La verdad por capas: dominio, datos, motores, pipelines, UI… |
| `blueprint/ORIGINAL.md` | **Opcional** | Tu brief original pegado tal cual, sin formato |
| `blueprint/DECISIONS.md` | Lo escribe el orquestador | Registro de decisiones (`DEC-*`) |
| `.claude/rules/stack.md` | **Sí** | Los comandos reales de tu stack |
| `.claude/rules/autonomy.md` | **Sí, si usas `--auto`** | Qué puede decidirse sin preguntarte |
| `.claude/policy/stack-infra.md` | **Sí** | Despliegue, infra y destinos de log |
| `.claude/rules/constitution.md` | **No** | Las reglas del orquestador |
| `.claude/rules/conventions.md` | **No** | Convenciones de IDs y evidencia |
| `.claude/agents/` (69) | **No** | Las lentes especializadas |
| `.claude/skills/` (14) | **No** | Los comandos (`/init-build`, `/next-pantalla`…) |
| `.claude/workflows/` (9) | **No** | Los abanicos de lentes |
| `.orchestrator/` | **No** | Scripts, schemas y el ejemplo de referencia |
| `.orchestrator-state/` | **No** | Lo escribe el orquestador; no lo edites a mano |

**Regla corta:** tocas `blueprint/**` y tres ficheros de configuración. Todo lo demás es maquinaria.

---

## 3. Cómo rellenar el blueprint

### El orden que funciona

1. **`blueprint/ORIGINAL.md`** — pega tu brief, correo o notas **tal cual**. Sin formato, sin IDs.
   No es una capa ni es la verdad: es el recibo. Cuando una capa quede ambigua, el orquestador lo
   consulta antes de preguntarte, y así no te pregunta lo que ya escribiste.
2. **`blueprint/PRODUCT.md`** — para quién es, qué hace, y las reglas que no puede romper (`BR-*`).
3. **`blueprint/logic/*.md`** — la verdad por capas. Empieza por `domain`, `data` y `usecases`;
   el resto sale solo.
4. **`blueprint/SCREENS.md`** — el último, porque necesita saber a qué IDs apunta cada unidad.

### La forma de cada fichero

Cada `blueprint/*.md` tiene su molde en `blueprint-templates/`. **Cópialo y rellénalo**: los moldes
enseñan los campos que el validador exige. Un bloque tiene esta pinta:

````
### DATA-001 — Lecturas de contador

```logic
id: DATA-001
type: data_engine
status: ready
summary: "Cada lectura registrada queda persistida con su contador, fecha y valor"
related_screens: [SCR-001]
depends_on: [DOM-002]
severity: must
canonical_store:
  kind: database          # ← el validador lo exige y ningún molde lo enseña. No lo olvides.
  source_of_truth: postgres
  resources: [lecturas]
...
```
````

### Los cinco errores que más cuestan

1. **Olvidar `canonical_store.kind`.** El gate lo exige y las plantillas no lo enseñan. Si te
   falla el `--init-gate` por `data_engine`, mira esto primero. La forma exacta está en el bloque
   JSON de `.claude/rules/conventions.md`.
2. **Citar un ID que no existe.** `applies:` y `after:` solo pueden apuntar a IDs definidos en
   alguna capa. Corre `python3 .orchestrator/scripts/lint-blueprint.py` cada vez que escribas: caza
   referencias colgantes, IDs duplicados y ciclos.
3. **Dejar un `<PLACEHOLDER>` sin resolver.** El lint avisa; el gate bloquea si es un `<COMMAND_*>`.
4. **Criterios de aceptación no observables.** «La pantalla funciona bien» no es verificable.
   Escribe «Cuando el operario guarda una lectura menor que la anterior, el sistema muestra el error
   ERR-001 y no persiste nada».
5. **Clasificar el producto como cimiento.** Es el error caro, y tiene su propia sección abajo.

---

## 4. Lo que más determina cuánto tarda: el orden de construcción

El orquestador construye en el orden que declaras en `SCREENS.md` (`order` + `after[]`). Ese orden
no es burocracia: **es la decisión que más dinero cuesta o ahorra.**

Medido en un proyecto real con esta misma maquinaria:

| Unidad | ¿Algo la consumía? | Vueltas de VERIFY | Coste |
|---|---|---:|---:|
| Un repositorio con consumidor | sí | 3 | 78 lanzamientos |
| Un esquema de 75 tablas sin consumidor | no | **14** | **307 lanzamientos** |

Misma maquinaria, **4× el coste**. La razón: sin nada que la ejecute, una unidad no falla en la
primera pasada — falla en la ronda 4, cuando algo por fin la usa, y cada ronda cuesta una reparación
completa.

**La regla práctica:** por cada `SCR-FOUNDATION-*` de motor o pipeline que declares, declara en la
misma pasada su consumidor delgado — el molde `SCR-WALKING-SKELETON-*` de
`blueprint-templates/SCREENS-template.md` — con su `order` **justo detrás**, nunca varios cimientos
después. Una foundation sin consumidor cerca es andamiaje sin probar.

El gate te avisa (no bloquea) si detecta cimientos sin consumidor a menos de 8 posiciones.

---

## 5. Los comandos, en orden

```bash
# 0. Comprueba que el blueprint es coherente antes de nada
python3 .orchestrator/scripts/lint-blueprint.py

# 1. Compila el blueprint a un plan ejecutable. Te hará preguntas: contéstalas.
/init-build

# 2. Construye una unidad de punta a punta y para en 'verified'
/next-pantalla

# 3. Revisa y acepta. Es la única puerta a 'accepted'.
/accept <ID>

# …o construye toda la ola de una vez
/build-loop
```

Otros útiles: `/status` (resumen), `/fix "<lo que falla>"` (mantenimiento), `/reslice` (cuando
cambias el blueprint después de haber compilado).

---

## 6. Comprobar que va bien

```bash
python3 .orchestrator/scripts/validate-state.py      # el guardián: rechaza evidencia incompleta
bash .orchestrator/scripts/validate-structure.sh     # coherencia interna de la maquinaria
bash .orchestrator/scripts/smoke-golden-path.sh      # 77 pruebas de la maquinaria determinista
```

El primero es el que importa: si pasa, el estado es honesto. Si falla, **lee el mensaje** — están
escritos para decir qué falta y qué hacer, no solo que algo va mal.

---

## 7. Lo que este orquestador NO hace

Dicho por delante, para que no te lleves la sorpresa a mitad de proyecto:

- **No decide qué construir.** Ejecuta el orden que le des. Si tu `SCREENS.md` clasifica el producto
  como cimiento, lo construirá así, y te costará 4× (§4).
- **No valida que el fan-out ocurriera.** El gate comprueba que `phase_runs[]` sea completo y
  coherente, no que los subagentes corrieran de verdad. Está pensado contra el despiste, no contra
  la falsificación.
- **No prueba su propia mitad agéntica.** Las 77 pruebas cubren scripts y gates; los 69 agentes y
  los 9 workflows no los ejecuta ningún test.
- **No es barato.** Entre 78 y 207 lanzamientos de subagente por unidad. Si eso importa, lee §4
  antes de escribir `SCREENS.md`: ahí está el ahorro grande, no en la configuración.

---

## 8. Coste y memoria

Todo lo que vive en `CLAUDE.md` y en `.claude/rules/*.md` se carga **al arrancar cada sesión y en
cada subagente**. Con ~140 lanzamientos por unidad, cada línea de más ahí se paga 140 veces.

Por eso `.claude/policy/stack-infra.md` está **fuera** de `.claude/rules/`: se lee con `Read` cuando
hace falta y no cuesta nada el resto del tiempo. **Escribe ahí las decisiones de infra**, nunca de
vuelta en `stack.md`.

El gate avisa si la memoria permanente pasa de 1.200 líneas y te dice cuál es el fichero mayor.
