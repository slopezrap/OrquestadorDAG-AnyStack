# orchestrator-anystack

Orquestador para **Claude Code** que construye una aplicación **pantalla a pantalla**, en vertical (datos → API → UI), con **verificación real** y una **puerta de aceptación** — que pulsas tú, o una política escrita (`.claude/rules/autonomy.md`) para las unidades que esa política cubra. Es **AnyStack**: la fuente de verdad de producto vive en `blueprint/` y el almacén canónico es el que tú declares (DB relacional, document DB, event store, state store/checkpointer estilo LangGraph, ledger, sistema externo, file store).

Este README es la **referencia completa**: explica el modelo y trae la cheat sheet para operarlo. Hay otros dos documentos raíz, y ninguno duplica a este — `USO.md` es la guía de arranque (qué copiar, qué rellenar, qué no tocar) y `PROMPT.md` es el cuestionario para escribir el blueprint. Si dudas por dónde empezar, empieza por `USO.md`.

---

## 1. Idea en una frase

> Tú escribes el producto en `blueprint/`. El conductor (`orchestrator-flow`) construye **un único** unidad/pantalla por vez, apoyándose en **agentes-lente especializados** que leen y verifican en paralelo, y solo cierra cuando hay **evidencia real** y se da el visto bueno con `/accept` — tuyo, o de la política bajo `--auto`, que comprueba estrictamente más cosas que tú tecleando el comando.

Reglas de oro:
- **Escritor único:** solo `orchestrator-flow` escribe estado, código y el `result.json` consolidado. Las lentes **devuelven hallazgos**; las de verificación viva guardan sus propios artefactos (capturas/logs).
- **Nada inventado:** no se fabrica evidencia ni datos. La verdad de producto sale de `blueprint/`; el dato canónico, del almacén declarado.
- **Determinista donde importa:** el *state gate* (`validate-state.py`) y `/accept` son las anclas de confianza; el criterio del agente nunca las sustituye. El gate comprueba también, por ID, que los dos auto-gates de §5.5 corrieron, y que una aceptación automática cita la regla que la autorizó contra una política sin placeholders.

---

## 2. El flujo (fases → workflows → lentes → agentes)

Cada fase paralela **siempre** se lanza como un **workflow** (`.claude/workflows/*.js`, mecanismo oficial de Claude Code / ultracode) que abre en paralelo **agentes-lente** especializados; el conductor consolida y escribe. Lanzar el workflow es **obligatorio**, no una preferencia, y cada workflow hace fan-out a **TODAS** sus lentes-subagente —**todas, cada vez**— nunca a un subconjunto elegido a mano (DISCOVERY → las 6 `discovery-*`; RESEARCH/COMPILE → las 17 `research-*`; EXPLORE → `explore-scout` + las 8 `explore-*`; VERIFY → las 10 `verify-*`; VALIDATE → `validate-logs` + `validate-{web,android,ios}` por plataforma propia + `validate-engine`/`validate-pipeline` si la unidad cita `ENG-*`/`PIPE-*`). Una lente que no aplica igualmente se lanza y devuelve `n/a`. Solo si la capacidad de Workflows no está disponible en la sesión se degrada a `Agent(<lente>)` secuencial con el **mismo set completo** (`inline-fallback`, más lento; **nunca** como atajo).

```
/init-build:
  DISCOVERY ▶ discovery.js          → 6 discovery-* (checklist universal ANTES de compilar nada: producto, papel de la IA,
                                       origen de datos, event sourcing, arquitectura, stack, auth, despliegue/tenancy, UX;
                                       cada ítem acaba answered/filled/asked/deferred/n-a y se escribe en blueprint/stack/DECISIONS)
  INIT      ▶ compile-blueprint.js  → 17 research-* (modo COMPILE, leen todo el blueprint en paralelo)
            → orchestrator-flow compila spec.md + features.json → STATE GATE → stop

/next-pantalla [ID]  (una sola unidad):
  (0) RESEARCH ▶ research-fanout.js → 17 research-*  (¿blueprint completo para ESTA pantalla? si falta → CLARIFY y se escribe en blueprint)
  (1) EXPLORE  ▶ explore-fanout.js  → explore-scout + 8 explore-*  (audita el código, mapea el build, fija la ruta de verificación;
                                                       incluye motores y pipelines YA existentes, y la config/dependencias)
               ↳ y deja su ENTREGABLE en disco: evidence/<ID>/plan.md — mapa de aceptación (una fila por criterio:
                 IDs que lo rigen · ficheros · cómo se probará · artefacto), orden vertical y el CONSUMIDOR declarado
                 de la unidad. El gate lo exige vía phase_runs[EXPLORE].plan; DEVELOP cierra su `## Delivery`
  (2) DEVELOP  ✗ orchestrator-flow ESCRIBE el código (sin fan-out). También es el debugger.
  (3) VERIFY   ▶ verify-fanout.js   → 10 verify-* (ESTÁTICO: tests, conformidad con docs, diseño, motor/pipeline, logs back/front/db/motor,
                                                     coherencia cross-pantalla, y deriva blueprint↔código) → emite expected_ui_values
  (4) VALIDATE ▶ validate-live.js   → validate-{web,android,ios,logs} + validate-{engine,pipeline} si cita ENG-*/PIPE-*
                                       (VIVO/humano: MCP navegador + emulador/simulador + logs; y el motor/pipeline se EJECUTA de verdad)
  (5) REVIEW   · pantalla-reviewer  (un único veredicto contractual sobre VERIFY+VALIDATE)
  (5.5) GATES  ▶ AUTOMÁTICOS, lentes en Sonnet: /verify-pipelines-data-ultracode --fix (motor/pipelines/datos)
               + /production-code-review --fix (producción). Sus checks required entran en result.json;
               si arreglan algo → pasa de debugger (re-VERIFY/re-VALIDATE).
      STATE GATE ✗ validate-state.py (determinista)  → stop en `verified`

  ↳ tras CADA fase: phase-push.sh → commit + push a origin/main (checkpoint, no-fatal; no cambia status)

/accept <ID>:  verified → accepted   (única transición que la hace; --auto la invoca por política)
               ↳ si el accept completa un journey (JOUR-*), lanza AUTOMÁTICAMENTE:
                 · /verify-app <JOUR-ID>   (costuras cross-pantalla en runtime real)
                 · /audit-motores          (arquitectura cross-producto: motores, pipelines, escala)
                 ambos reportan y recomiendan; ninguno mueve estados
```

**Bucle debugger** (DEVELOP repara y se re-corre aguas abajo, máx 3 iteraciones). **Cuatro disparadores, no dos** — lo que cambia es qué se RE-CORRE, nunca lo que una reparación DEBE:
- VERIFY falla → debug → **re-VERIFY** → (al pasar) VALIDATE.
- VALIDATE falla → debug → **re-VERIFY + re-VALIDATE** (un fix de código puede invalidar lo estático).
- REVIEW falla → debug → **re-VERIFY + re-VALIDATE + re-REVIEW** (el reviewer juzga evidencia consolidada).
- una puerta §5.5 aplica un fix → pasada de depurador completa: re-VERIFY, re-VALIDATE si movió runtime, re-REVIEW si tocó implementación, y **las dos puertas otra vez**.

En las cuatro, antes de volver a VERIFY: `repair-class-scan` por hallazgo → la reparación → pre-flight → **los 4 adversarios del diff** → `adversary-check.py`, que se niega a lanzar el abanico si esa pasada no registró su corrida.

**Estados:** `todo → ready → building → verified → accepted` ( `→ blocked` si falta una decisión; `deprecated` en `/reslice`).

**Construir por delante, aceptar en orden.** Una unidad pasa a `ready` cuando sus dependencias están **construidas** (`verified` o `accepted`) — basta con que tengan evidencia PASS real. Pero `/accept` sigue el orden de `after[]`: no puedes aceptar una unidad cuya dependencia no esté aceptada. Por eso `/build-loop` puede encadenar el producto entero dejándolo todo en `verified`, y se promociona después en orden. La puerta no se debilita: pasa de ser *permiso para trabajar* a *permiso para darlo por bueno*. `status.json` publica `acceptable_now` para que sepas cuáles puedes aceptar ya.

**Roles expertos:** el conductor no es un generalista: encarna **todos los roles**, cada uno a nivel **senior**, para montar la pantalla (product owner, arquitecto de software senior, DBA, ingeniero de datos, backend, frontend, mobile, DevOps, seguridad, UX, QA, SRE, tech lead). Senior significa: nombrar los trade-offs, elegir la opción probada sobre la ingeniosa, y diseñar para la aplicación completa (arquitectura, modelo de datos, motor de reglas, pipelines, clientes), no solo para la pantalla activa. Cada fase los materializa como lentes (RESEARCH/EXPLORE/VERIFY/VALIDATE/REVIEW) o como sombreros que lleva a la vez en DEVELOP (arquitecto + backend + frontend/mobile + DBA + ingeniero de datos + DevOps + seguridad + QA). Extrae lo que cada rol necesita del blueprint/diseño/código.

**Pensar primero, luego preguntar:** cuando un rol no sabe algo —en **cualquier** fase— primero lo resuelve él (relee fuentes/docs, razona desde ese rol); si tras pensarlo sigue genuinamente sin resolverse, **pregunta al humano** una pregunta precisa en vez de adivinar (mejor agrupar decisiones de producto en RESEARCH, y persistir las respuestas en `blueprint/`). Bloquear es el último recurso. Nunca inventa intención de producto ni falsea un valor.

**Checkpoint por fase:** tras cada fase (incluidas las re-corridas del debugger) el conductor ejecuta `.orchestrator/scripts/phase-push.sh "<FASE>" "<ID>"` → commit + push a `origin/main`. Es un efecto secundario (rol DevOps), **no** una transición de ciclo de vida: no cambia el `status`; el STATE GATE y tu `/accept` siguen siendo las únicas anclas. Es no-fatal: sin repo git o sin remoto `origin`, avisa y continúa (no bloquea construir). Remoto/rama configurables con `ORCH_PUSH_REMOTE`/`ORCH_PUSH_BRANCH`.

---

## 3. AnyStack y evidencia falsificable

- `data_engine.canonical_store.kind` / `source_of_truth` es el sistema de registro que declares (nunca un cliente). El validador hace cumplir las invariantes, no una tecnología.
- La evidencia (`data_engine_assertions[]`) lleva el **valor literal observado en cada capa** (`db_value`/`api_value`/`ui_value`, alias `source_value`/`transport_value`/`client_value`, + `platform_values`). El *state gate* **recalcula** `same_value` de esos literales: prueba `almacén → API/read-model → cliente`. Una pantalla bonita con datos mock no pasa.
- **El ciclo de workflows es obligatorio y está verificado por máquina, no solo por prosa.** Cada `result.json` lleva `phase_runs[]` (fase · workflow · modo · lentes que corrieron de verdad). El *state gate* (`validate-state.py`) **rechaza un PASS** que se saltó una fase de fan-out o corrió un set de lentes incompleto (RESEARCH 17 · EXPLORE scout+8 · VERIFY 10 · VALIDATE logs+plataforma propia+motor/pipeline citados · REVIEW pantalla-reviewer). Además, el hook `validate-state.sh` corre el gate completo al escribir `features.json`, así que marcar `verified` saltándose un workflow falla en el acto. Inventar `phase_runs` de una fase no ejecutada es fabricar evidencia (prohibido).

---

## 4. Estructura (todo lo que hay, y nada más)

```
CLAUDE.md                      memoria de proyecto (Claude Code la auto-carga; importa las rules)
README.md                      este documento

.claude/
  settings.json                arranca como orchestrator-flow + 3 hooks
  rules/                        constitution.md · conventions.md · stack.md (memoria de proyecto, importados en CLAUDE.md)
                                autonomy.md (política de decisión y auto-aceptación; se consulta en momentos concretos)
  policy/stack-infra.md         despliegue, infra y destinos de log. Vive FUERA de rules/ a propósito: es gobernanza
                                FRÍA, se lee con Read cuando hace falta y NO carga como memoria permanente (USO.md §8)
  agents/                       74 agentes (ver §5)
  skills/<cmd>/SKILL.md         init-build · next-pantalla · build-loop · accept · status · reslice
                                review-pantalla · verify-pipelines-data-ultracode · production-code-review · verify-app
                                audit-motores · arch-review · discovery · fix
  workflows/*.js                compile-blueprint · research-fanout · explore-fanout · verify-fanout · validate-live · validate-journeys
                                audit-architecture · arch-review · discovery
  hooks/                        block-rm.sh (PreToolUse) · validate-state.sh (PostToolUse) · precompact-checkpoint.sh (PreCompact:
                                refresca las proyecciones y expone el ancla de reanudación como `systemMessage`, best-effort: ningún hook PreCompact puede inyectar nada en el contexto post-compactación, así que lo que salva el estado es releerlo de disco; siempre sale 0 — un exit 2 aquí cancelaría la compactación)

.orchestrator/                  definición estable (no es estado vivo)
  DECISIONS.md                  ledger append-only de las decisiones sobre la MAQUINARIA (gates, contratos de
                                evidencia, fases). No confundir con blueprint/DECISIONS.md, que es el de TU producto.
                                Solo entra lo contractual: un cambio que hace que un estado antes válido deje de serlo
  scripts/                      validate-state.py (STATE GATE, --emit-status escribe status.json + evidence/index.json) · lint-blueprint.py (linter determinista del blueprint) · original-coverage.py (reconcilia ORIGINAL.md↔capas, alimenta CLARIFY) · validate-structure.sh (estructura + sync de lentes .js↔.py) · reset-state.sh · reset-test-data.sh (resetea el almacén de PRUEBAS delegando en stack.md; solo el conductor, antes de cada fase que ejecuta) · preflight-check.sh (corre COMMAND_LINT/COMMAND_BUILD antes de cada abanico de VERIFY; no es evidencia) · adversary-check.py (se niega a lanzar el abanico en una pasada de reparación cuyo adversario del diff no ha corrido; no es evidencia) · derived-figures.py (re-deriva toda cifra marcada `<!-- derived: -->` y falla las que mienten) · lib/stack-command.sh (parser compartido de stack.md) · phase-push.sh (commit+push por fase)
  schemas/                      features.schema.json · result.schema.json · batch.schema.json (forma ilustrativa; el .py manda)
  templates/                    features.empty.json · spec.template.md · discovery-checklist.md (banco de preguntas del gate /discovery, editable) · evidence/ (esqueleto)
  examples/                     features.example.json · result.example.json (cómo es un "bueno")
                                golden-path/ — producto mínimo COMPLETO de ejemplo ("Notas rápidas"):
                                blueprint entero (14 logic + PRODUCT + SCREENS con SHELL) + estado canónico;
                                lo ejercita .orchestrator/scripts/smoke-golden-path.sh

.orchestrator-state/            estado vivo en disco
  features.json                 plan ejecutable (la pieza clave)
  spec.md · progress.md         contexto consolidado · handoff append-only
  evidence/<ID>/result.json     evidencia por unidad
  status.json · evidence/index.json   proyecciones derivadas de SOLO LECTURA para superficies externas
                                (dashboards/CI): las emite validate-state.py --emit-status, atómicas,
                                con schema_version; nunca se editan a mano ni son fuente de verdad

blueprint/                      TU entrada (fuente de verdad): PRODUCT.md · SCREENS.md · logic/*.md (14, incl. shell.md cross-pantalla,
                                engine.md ENG-* y pipeline.md PIPE-*)
blueprint-templates/            moldes para escribir el blueprint
design/                         tokens.css · screens/  (referencias visuales)
.env.example                    variables de entorno de ejemplo
```

---

## 5. Roster de agentes (74) y workflows (10)

- **Conductor (escribe):** `orchestrator-flow`.
- **DISCOVERY t=0 (7, gate `/discovery` dentro de `/init-build`, ANTES de COMPILE):** `discovery-{product,data,architecture,stack,infra,ux}` + `discovery-synthesizer` — recorren el checklist universal (`.orchestrator/templates/discovery-checklist.md`): lo que ningún blueprint suele escribir (papel de la IA, tenancy, alcance de event sourcing, postura de auth, backups, coste IA...). Regla de familia: `discovery-*` posee lo NO PREGUNTADO, `research-*` posee la AUSENCIA, `arch-*` posee el ERROR. Cada ítem acaba con disposición explícita (answered con cita · filled con default · asked en UNA ronda agrupada con opción recomendada · deferred como `DEC-*` abierto · n/a con razón); el conductor escribe las respuestas en `blueprint/**`/`stack.md`/`DECISIONS.md` y `--init-gate` exige `meta.discovery` para nacer. Nunca entra en `phase_runs[]`.
- **RESEARCH/INIT (17, uno por fichero de blueprint/ + el HTML de design/):** `research-{domain,application,core,journey,permission,state,error,integration,ui,shell,data,usecases,engine,pipeline,product,screens,design}` — dual-mode: cobertura por-pantalla (`/next-pantalla`) o COMPILE de todo el blueprint (`/init-build`). `research-shell` cubre el contrato cross-pantalla (`blueprint/logic/shell.md`, `UI-SHELL-*`); `research-engine` los motores (`ENG-*`) y `research-pipeline` lo que los alimenta (`PIPE-*`).
- **EXPLORE (9):** `explore-scout` + `explore-{data,backend,ui,existing,tests,engine,pipeline,config}` — `explore-engine`/`explore-pipeline` inventarían los motores y pipelines que YA existen en el código (para que la pantalla N no reimplemente lo que construyó la 3); `explore-config` cierra el ámbito `config` que el scout siempre descubrió y ninguna lente recibía (manifiesto de dependencias, lockfile, CI, entorno, `stack.md`).
- **VERIFY estático (10):** `verify-{tests,conformance,design,frontend,engine,pipeline,logs,quality,coherence,blueprint-drift}` — dos lentes miran más allá del código de la pantalla: `verify-coherence` la compara contra el contrato de shell y las pantallas hermanas ya `verified`/`accepted` (deriva HORIZONTAL: componentes duplicados, rutas, tokens hardcodeados), y `verify-blueprint-drift` compara el código contra CADA capa de blueprint que la unidad cita (deriva VERTICAL: conocimiento que vive solo en código y hay que devolver al blueprint). Antes esa segunda comprobación existía solo para `shell.md`.
- **VALIDATE vivo (6):** `validate-{web,android,ios,logs,engine,pipeline}` — VALIDATE dejó de ser solo-UI: si la unidad cita `ENG-*`/`PIPE-*`, el motor se EJECUTA con entrada real y el pipeline se CORRE de verdad contra el almacén canónico. Un motor ya no puede llegar a `verified` con verificación estática sola.
- **CROSS-PANTALLA vivo (1, gate opcional `/verify-app`):** `validate-journey` — recorre un journey (`JOUR-*`) completo por las pantallas ya aceptadas en el runtime real: navegación entre pantallas (costuras), mismo valor canónico en cada pantalla que lo muestre, shell coherente en movimiento. Es lo que ninguna fase por-pantalla puede ver.
- **ARCH t=0 (7, gate `/arch-review`):** `arch-{fit,data-model,identity,engines,pipelines,risk}` + `arch-synthesizer` — juzgan el DISEÑO antes de construir nada, dentro de `/init-build` (tras CLARIFY, antes de compilar `features.json`) y re-disparado por `/reslice` cuando deriva el hash de arquitectura. La regla de la familia: `research-*` posee la AUSENCIA, `arch-*` posee el ERROR. Un blocker exige `retrofit_cost` y se resuelve por tres salidas humanas: cimiento `SCR-FOUNDATION-*`, riesgo aceptado como `DEC-*`, o aplazado con trip-wire. Sus hallazgos NUNCA entran en `phase_runs[]`; el registro máquina vive en `features.json.meta.architecture_review` y `validate-state.py --init-gate` impide nacer sin él.
- **AUDIT cross-arquitectura (6, gate `/audit-motores`):** `audit-{engine-inventory,engine-contract,pipeline-topology,data-reality,scale}` + `audit-synthesizer` — miran TODO el producto a la vez, no una pantalla: ¿cada `ENG-*` implementado una sola vez y fiel a su contrato? ¿la topología `PIPE-* → almacén → ENG-* → read-model → pantallas` está sana? ¿todo dato traza a una ruta de generación real? ¿qué se rompe a 10x? Reportan y recomiendan; nunca mueven estados y NO entran en los sets requeridos de `phase_runs[]`.
- **REVIEW (1):** `pantalla-reviewer` (síntesis contractual).
- **ADVERSARIO DEL DIFF (4, solo en pasadas de REPARACIÓN):** `diff-adversary-{regression,incomplete,unreachable,edge}` — cuatro preguntas fijas de solo lectura sobre el diff de la reparación, entre el arreglo y la prueba. La tercera es la razón de existir del resto: *¿qué ha vuelto inalcanzable este diff, incluida una comprobación que antes se alcanzaba?* Las diez lentes preguntan si algo ESTÁ; ninguna puede preguntar si algo DEJÓ DE SER ALCANZABLE, así que una guarda de permiso que deja de evaluarse compila, pasa la suite, satisface las diez y se despliega. **No es evidencia, no gasta iteración, no bloquea nada** y `nothing_found` es su respuesta esperada — un adversario que siempre encuentra algo es ruido. Y **no es prosa**: `adversary-check.py` se niega a lanzar `verify-fanout` en una pasada de reparación sin corrida registrada contra ESE diff (medido antes de existir: corría en 1 de cada 5). Carta completa en `next-pantalla/SKILL.md` §6.
- **Síntesis (6, una por fase pesada):** `compile-synthesizer` · `research-synthesizer` · `verify-synthesizer` · `audit-synthesizer` · `arch-synthesizer` · `discovery-synthesizer`
- **Utilidad (1):** `context-loader` — cargador read-only disk-first (fase Load de `validate-live`/`validate-journeys`/`audit-architecture`/`arch-review`; `model: haiku`) — reductores read-only que consolidan las lentes de `compile-blueprint`/`research-fanout`/`verify-fanout` en **un único digest** con `source_refs` al blueprint (para que el conductor reabra la fuente al desarrollar); no deciden ni escriben. Los workflows finos `explore-fanout`/`validate-live` devuelven las lentes en crudo.

**Política de modelos:** las lentes son trabajo de checklist con ámbito cerrado → `model: sonnet` explícito (59 agentes, incluidas las 7 `discovery-*`). El juicio caro de equivocarse hereda el modelo de la sesión (`model: inherit` → Fable): `orchestrator-flow` (conductor), `pantalla-reviewer` (veredicto contractual) y la familia `arch-*` (corre una vez por proyecto). `context-loader` va en `haiku`. Para cambiar una lente, edita su `model:` en `.claude/agents/<lente>.md`. Los workflows solo orquestan (no duplican la lógica).

**Reintento único, en el código y no en la memoria del conductor.** Los **6** fan-outs (`research`, `explore`, `verify`, `validate-live`, `validate-journeys`, `audit-architecture`) relanzan sus propias lentes vacías UNA vez, con el prompt idéntico, y lo declaran en `retried_lenses[]`. Por tanto `failed_lenses[]` viene **post-reintento**: el conductor no vuelve a relanzarlas, va directo a bloquear. Antes esto era una instrucción escrita que un modelo podía olvidar — y su modo de fallo era invisible justo donde más importaba: un lote sin nadie delante, donde una lente que falló una vez bloqueaba una unidad que un segundo intento habría terminado. Lo único que nunca se reintenta es `fail_fast_skipped[]`: esas lentes no se llegaron a lanzar, así que no hay nada que relanzar.

**Política de effort (la palanca de coste).** La constitución prohíbe correr MENOS lentes; no dice nada sobre cuánto piensa cada una. Ahí está el margen, y se reparte por lo que la lente **hace**, no por la fase en que vive:

- **`medium`** — comprobación de checklist sobre ámbito estrecho: leer un documento o unos ficheros y clasificar. Equivocarse es barato y hay suelo mecánico debajo (`lint-blueprint.py`, `--decidedness`, el propio gate). Aquí van las 10 capas lógicas de ámbito acotado, las 8 lentes de ámbito de EXPLORE y `validate-logs`.
- **`high`** — la lente carga peso contractual (lo que declare condiciona lo que se construye después) o conduce un runtime real, donde un fallo cuesta una re-ejecución lenta. Aquí van `research-{data,engine,pipeline,shell,screens,product,application}`, `explore-scout` y todos los `validate-*` que arrancan navegador/emulador.
- **`xhigh`** — se reserva para **reducir** y para el **veredicto**: los tres synthesizers (una reducción pierde información por construcción, y lo único que no puede perderse es el hallazgo que contradice), `verify-quality`, `verify-coherence`, `verify-blueprint-drift` y `pantalla-reviewer`.

Reparto por unidad limpia: **21 `medium` · 14 `high` · 6 `xhigh`** (antes: 42 `xhigh`). Para reajustar una lente, edita su `effort:` en `.claude/agents/<lente>.md` — es un número por fichero, sin nada que sincronizar.

**Y las lentes se declaran fuera de ámbito rápido.** `research-fanout` y `explore-fanout` piden explícitamente a cada lente que mire primero si el `applies[]` de la unidad (o el reparto del scout) toca lo suyo, y que devuelva `n/a` con su motivo sin re-derivar la capa entera cuando no. Todas siguen corriendo y todas devuelven veredicto — lo que se recorta es el precio de decir "no es mío", no la cobertura. La excepción está escrita en el propio prompt: un `block_signal` o una ausencia real se levantan igual, por pocos ficheros que te hayan tocado.

**Cómo encaja en Claude Code:** main session = `orchestrator-flow` (vía `settings.json`); subagentes = aislados, devuelven solo su mensaje final; skills = inline (sin `context: fork`); workflows = fan-out paralelo (≤16 concurrentes); hooks = guardarraíles de sesión (3: `PreToolUse`, `PostToolUse`, `PreCompact`).

*Nota sobre `context: fork`:* la prohibición vive solo en prosa **porque hoy no existe mecanismo**. `permissions.deny` opera sobre herramientas y agentes (`Agent(orchestrator-flow)` sí se bloquea así), no sobre el frontmatter de una skill. Hay issue abierto; hasta entonces es una limitación conocida, no un descuido. **Nunca `claude -p` / headless / SDK** — esto es interactivo.

### Autonomía (opcional, apagada mientras no la configures)

`.claude/rules/autonomy.md` responde POR ADELANTADO lo que si no pararía la ejecución. Es a las decisiones de producto lo que `stack.md` a los comandos: un fichero de placeholders que `/init-build` resuelve por proyecto, leído de disco en vez de reconstruido de una conversación.

- **Precedencia:** `blueprint/**` > `DECISIONS.md` (`DEC-*`) > `ORIGINAL.md` > `autonomy.md`. **Solo gobierna el SILENCIO.** Un default que contradice lo que declara una capa no es un conflicto: es irrelevante, y aplicarlo sería inventarse la intención de producto.
- **Tres niveles.** *Tier 1* se decide en silencio (reversible, dentro de una capa, sin coste externo). *Tier 2* se decide y deja un `DEC-*` con `decided_by: "auto:<regla>"`, **la alternativa que descartó** y una `trip_wire` — la condición observable que lo invalidaría. *Tier 3* nunca se decide: gasto real, envío a terceros, datos personales, seguridad, borrado, o cambiar un contrato ya `accepted`. Si no hay nadie para responder, la unidad se bloquea con la pregunta, que es el resultado correcto.
- **`/accept --auto`** aplica las mismas 7 precondiciones de siempre más el mismo STATE GATE, y añade tres barras: ninguna **área sensible** (auth, pagos, datos personales, acciones irreversibles, el shell compartido, migraciones destructivas), ningún hallazgo abierto por encima del techo de severidad, y ningún placeholder sin resolver en la política. Lo demás se queda en `verified` en una cola para ti — que es un resultado sano, no un fallo.
- **`/build-loop --autonomous`** añade el bucle exterior: construir → auto-aceptar por política → gates cruzados si se cerró un journey → absorber con `/reslice` las `SCR-FIX-*` que emitan → repetir. Para por convergencia (2 rondas sin unidades nuevas), presupuesto, reloj o una pregunta Tier 3. Su estado, presupuesto y telemetría viven en `.orchestrator-state/batch.json` (`orchestrator.batch.v1`), que es lo que hace que un lote sobreviva a una compactación: `features.json` registra lo que alcanzó cada UNIDAD, este registra lo que lleva el LOTE.

**Lo que la autonomía NO relaja:** ninguna barra. Todas las lentes siguen corriendo, la evidencia sigue siendo real y falsificable, el gate sigue siendo el mismo. Y la carga de la prueba tampoco se toca: un default es una DECISIÓN, nunca una MEDICIÓN — cualquier negativo (*no existe*, *no está soportado*, *lo probé y falla*) sigue exigiendo comando, salida literal y artefacto. La política compra el derecho a DECIDIR sin preguntar; nunca el derecho a AFIRMAR sin probar.

Mientras `autonomy.md` conserve placeholders, `--auto` no acepta nada y `--autonomous` se niega a arrancar. El gate lo impone: falla en la dirección segura.

**Los gates cruzados emiten trabajo, no informes.** `/verify-app` y `/audit-motores` ya no dejan recomendaciones que nadie recoge: cada defecto concreto sale como una unidad `SCR-FIX-VERIFY-APP-*` / `SCR-FIX-AUDIT-*` que el bucle construye como cualquier otra, con el pipeline completo y el estándar de evidencia completo — el mismo patrón que `/arch-review` usa con sus blockers (*"the gate generates work, it does not raise a wall"*). Máximo 3 por ejecución, las peores primero, deduplicadas por huella `sha256` sobre `remediates[]` + refs. Emitir una unidad NUEVA no es mover el status de ninguna existente: nace en `todo` y no toca nada.

**Encadenado de skills (importante):** las 14 skills llevan `disable-model-invocation: true` a propósito — impide que el harness abra un segundo escritor por detrás del conductor. **No las hace inalcanzables.** Cuando una skill encadena a otra (`/next-pantalla` §5.5 → los dos auto-gates; `/accept` → `/verify-app` + `/audit-motores`; `/init-build` → `/discovery` + `/arch-review`; `/build-loop` → `/next-pantalla`; `/fix` → los gates), el conductor **lee el `SKILL.md` destino y ejecuta su protocolo inline en la misma sesión**, sustituyendo `$ARGUMENTS`. Nunca llama a la herramienta `Skill`. Que una skill no sea invocable por el modelo **jamás** es motivo para saltarse un gate, bloquear una unidad ni pedirte que teclees el comando.

---

## 6. CHEAT SHEET — cómo hacerlo funcionar

### Requisitos de entorno (léelo antes: el motor es real, pero descansa en estas precondiciones)

El núcleo —workflows + lentes + gate determinista— se ejecuta de verdad en Claude Code (verificado contra el binario y ejecutando los scripts). Pero **no es plug-and-play para un clon limpio** hasta que se cumple esto:

- **Claude Code ≥ v2.1.154** y **plan de pago** (Pro/Max/Team/Enterprise o API/Bedrock/Vertex). En **Free no existe la herramienta Workflow** y los 9 `.js` quedan inertes (el sistema degrada a `inline-fallback` secuencial con el mismo set de lentes: misma cobertura, más lento y más tokens).
- **En plan Pro:** activa **"Dynamic workflows"** a mano en `/config` (no viene por defecto).
- **`permissions.defaultMode: "auto"`** en tu config **personal** (`~/.claude/settings.json`) — no en la del proyecto (Claude Code la ignora ahí desde v2.1.142). Sin esto, el primer uso de cada workflow interrumpe pidiendo aprobación.
- **`python3`, `bash` y `node` en el PATH.** Claude Code no los provee. En **Windows nativo** los scripts `.sh` del gate necesitan **Git for Windows o WSL2** (PowerShell no los interpreta); `validate-state.py`/`lint-blueprint.py` son multiplataforma.
- **MCP de verificación viva:** `validate-web` usa Claude-in-Chrome (extensión, con permisos de sitio) o Chrome DevTools MCP; `validate-{android,ios,journey}` usan emulador/simulador **ya arrancado** (adb/logcat, idb/simctl) más el tooling que declare el `Mobile framework` de `stack.md` — para un proyecto Flutter, el MCP de Dart; para otro, lo que ese ecosistema traiga. Cada lente declara su `mcpServers` en el frontmatter (mecanismo oficial), pero las herramientas y runtimes hay que tenerlos instalados; una unidad backend/data no necesita ninguno.
- **git:** si el repo no es un repositorio git, `phase-push.sh` avisa y sigue (no-fatal) — pero pierdes el checkpoint por fase y la red bajo el debugger. `git init` + un commit inicial recomendado.

### Puesta en marcha (una vez)
1. Copia esta carpeta a tu proyecto y abre Claude Code **desde la raíz** (carga `orchestrator-flow` por `settings.json`).
   - `blueprint/DECISIONS.md` arranca **vacío** (solo su índice). No copies `DECISIONS-template.md` verbatim como decisión real: es un molde.
2. Rellena el blueprint usando los moldes de `blueprint-templates/`:
   - `blueprint/PRODUCT.md` (alcance, actores, reglas `BR-*`), `blueprint/SCREENS.md` (pantallas, orden, rutas, plataformas), `blueprint/logic/*.md` (las 14 capas: `DOM/APP/CORE/JOUR/PERM/ST/ERR/INT/UI/DATA/UC` + `shell.md` con el contrato cross-pantalla `UI-SHELL-*` + `engine.md` con los motores `ENG-*` + `pipeline.md` con los pipelines `PIPE-*`).
3. Comandos reales del stack: no hace falta `init.sh`. Deja `<COMMAND_*>` en `.claude/rules/stack.md`; `/init-build` los resuelve contigo (install/dev/test/migrate/seed/smoke/build) y el conductor los ejecuta cuando hace falta.
4. (Opcional) Mira `.orchestrator/examples/` para ver cómo queda un `features.json`/`result.json` "bueno".

### Ciclo de trabajo
```
/init-build            # blueprint → spec.md + features.json (lee TODO el blueprint en paralelo; pregunta CLARIFY si falta algo;
                       #   incluye DOS gates t=0: /discovery — el checklist universal, ¿qué quedó en el tintero? —
                       #   y /arch-review — ¿es CORRECTA la arquitectura? — ambos antes de compilar nada)
/status                # resumen de estado (solo lectura)
/next-pantalla         # construye y verifica la siguiente unidad ready (o pasa un ID); para en `verified` o `blocked`
                       #   piensa primero; si sigue sin saber algo pregunta (mejor agrupar en RESEARCH) y escribe la respuesta en blueprint/
                       #   tras CADA fase hace commit + push a origin/main (phase-push.sh, no-fatal)
/build-loop [max] [--autonomous]   # bucle Ralph: encadena todas las unidades ready DE UNA EN UNA (cada una con su
                       #   /next-pantalla completo); para en el primer blocked o cuando no queda ready.
                       #   NUNCA acepta: produce una tanda de verified y tú las apruebas con /accept
/accept <ID> [--auto]  # puerta de aceptación: verified → accepted   (revisa la evidencia antes)
                       #   --auto la invoca según .claude/rules/autonomy.md: nunca en un área sensible,
                       #   nunca por encima del techo de severidad, nunca contra una política con
                       #   placeholders. Lo que no cumple se queda en verified, en cola para ti.
                       #   Cada aceptación deja constancia de quién fue en result.json.human_gate
/reslice [motivo]      # reconcilia cambios de blueprint/design conservando historia y evidencia
/fix "<prompt>"        # mantenimiento: describe en texto libre un bug visto probando (o una mejora pequeña);
                       #   localiza la(s) pantalla(s) dueñas, carga contexto (blueprint citado + EXPLORE completo
                       #   sobre el código), repara y re-prueba TODO (VERIFY/VALIDATE/REVIEW con sets completos de
                       #   lentes) — de punta a punta en automático, parando solo en CLARIFY o blocked.
                       #   verified → reabre y cierra en verified (Next: /accept); accepted → repara in situ con
                       #   evidencia y source_manifest frescos; cambios de producto → blueprint + /reslice. NUNCA acepta
```

### Gates profundos — AUTOMÁTICOS (relanzables a mano)
```
/verify-pipelines-data-ultracode <ID>  # pipelines + datos + logs (motor de datos) en profundidad
/production-code-review <ID>           # producción: DRY/YAGNI/KISS, sin placeholders
```
> Ambos corren AUTOMÁTICAMENTE dentro de /next-pantalla tras el REVIEW (con --fix, lentes en Sonnet);
> aquí solo hace falta relanzarlos a mano si quieres repetirlos antes de /accept.

### Gate opcional manual
```
/review-pantalla <ID>                  # paridad UI/diseño/controles en vivo (pasada extra a demanda)
/discovery [--report-only]             # re-recorre el checklist universal a demanda (p. ej. tras ampliar
                                       # .orchestrator/templates/discovery-checklist.md); AUTO dentro de /init-build
```

### Gates cross (AUTOMÁTICOS al completar un journey con /accept; también a mano)
```
/audit-motores [ENG-ID|PIPE-ID|all]    # arquitectura de TODO el producto: cada motor implementado una vez y
                                       # fiel a su contrato, topología de pipelines, procedencia real de los
                                       # datos, acoplamiento entre módulos y perfil de escala. Estático.
/verify-app [JOUR-ID|all]              # recorre los journeys completos (todas sus pantallas accepted) en el
                                       # runtime real: navegación entre pantallas, mismo valor canónico en
                                       # todas las pantallas, shell coherente. Reporta y recomienda; NUNCA
                                       # mueve estados. El anti-Frankenstein de las costuras.
```
> Estas skills pueden escribir fixes y evidencia, pero **nunca** mueven a `accepted`. Si tocan un `verified`, su evidencia previa queda *stale* hasta re-VERIFY/re-VALIDATE.

### Scripts (los usa el conductor / tú; no las lentes)
```bash
python3 .orchestrator/scripts/validate-state.py        # STATE GATE: valida features.json + evidencia (verdict PASS real, same_value, artefactos, building<=1, checkpoint<=3, ...)
python3 .orchestrator/scripts/validate-state.py --emit-status  # + escribe status.json y evidence/index.json (contrato de lectura para dashboards/superficies externas)
python3 .orchestrator/scripts/lint-blueprint.py        # linter determinista del blueprint: IDs duplicados, referencias colgantes, ciclos, stubs (errores rompen; warnings → CLARIFY)
python3 .orchestrator/scripts/lint-blueprint.py --decidedness --json   # ¿está DECIDIDO el blueprint? undecided_fields[]: cada escalar
                       #   que sigue en su default de blueprint-templates/ o en <PLACEHOLDER>. Nunca es fatal — la ausencia
                       #   no es un error. Lo consume /arch-review, que se niega a revisar un blueprint sin decidir, y las
                       #   lentes arch-*, cuya regla es "research-* posee la AUSENCIA, arch-* posee el ERROR".
                       #   Úsalo como semáforo antes de gastar: mide cuánta spec hay de verdad frente a plantilla sin tocar
python3 .orchestrator/scripts/original-coverage.py     # reconcilia ORIGINAL.md contra las capas (--extract primero): qué dijo el humano que ninguna capa recoge → CLARIFY, nunca bloquea (lo corren /init-build y /reslice)
bash    .orchestrator/scripts/validate-structure.sh    # estructura del scaffold + referencias de lentes + sincronía de sets de lentes .js↔.py
bash    .orchestrator/scripts/reset-state.sh --force   # resetea SOLO .orchestrator-state/ a scaffold limpio
bash    .orchestrator/scripts/preflight-check.sh "<FASE>"  # CONDUCTOR: corre COMMAND_LINT y COMMAND_BUILD de stack.md ANTES de cada
                                                       #   lanzamiento de verify-fanout (incluidas las re-corridas del debugger).
                                                       #   exit 1 = un comando declarado fallo · exit 2 = no se pudo comprobar ·
                                                       #   exit 0 = limpio o no aplica. Repara y re-corre SIN lanzar el abanico y
                                                       #   SIN gastar iteracion. No es evidencia: verify-frontend sigue corriendo.
python3 .orchestrator/scripts/adversary-check.py "<FASE>"  # CONDUCTOR: ÚLTIMO paso antes de lanzar verify-fanout en una pasada de
                                                       #   REPARACIÓN. exit 1 = esta pasada no ha corrido su adversario del diff (§6):
                                                       #   no lances el abanico. Mismo contrato de salida que el pre-flight. Deriva él
                                                       #   solo cuándo NO aplica: primera pasada de construcción (iteration 0) y pasada
                                                       #   sólo-documental (clasificada con el isDocPath de verify-fanout.js, extraído
                                                       #   de allí, nunca copiado). `--record -` registra lo que devolvió el workflow.
                                                       #   NO es evidencia: su marcador no entra en phase_runs[]/checks[] y el STATE
                                                       #   GATE ni lo lee. "nothing_found" en los 4 levanta el gate igual que un hallazgo.
python3 .orchestrator/scripts/rehearse-close.py "<ID>"  # ENSAYO del cierre. Aplica el flip de §7 (status/passes/checkpoint) a una COPIA
                                                       #   desechable y corre el gate REAL, sin modificar, contra ella — porque la superficie
                                                       #   de cierre vive tras `if status in PASS_STATUSES` y una unidad en `building` no la
                                                       #   alcanza: correr el gate antes de cerrar sale verde y rechaza un instante después.
                                                       #   exit 0 aceptaría · 1 rechazaría (con el mensaje del gate y cómo reproducirlo) ·
                                                       #   2 demasiado pronto (calla hasta que existe source_manifest, así que nunca
                                                       #   reporta trabajo en curso como defecto). No escribe nada. No es evidencia.
python3 .orchestrator/scripts/derived-figures.py       # toda cifra en prosa marcada con `<!-- derived: <spec> -->` se re-deriva de su
                                                       #   fuente y falla si no cuadra. Tres formas: jsarray:<fichero>:<CONST> · glob:<patrón> ·
                                                       #   sh:<comando>. `--list` enseña lo marcado sin veredicto. Nace de las CELDAS ACOPLADAS:
                                                       #   cuatro afirmaciones de un mismo hecho corregidas de una en una, tres mintiendo cada
                                                       #   vez. Corre dentro de validate-structure.sh. Sin marcador no comprueba nada.
bash    .orchestrator/scripts/reset-test-data.sh "<FASE>"  # deja el almacén de PRUEBAS limpio antes de una fase que ejecuta la suite.
                                                       #   No sabe qué almacén es (AnyStack): delega en la clave COMMAND_RESET_TEST_DATA
                                                       #   declarada en .claude/rules/stack.md. Lo llama el CONDUCTOR, UNA vez, ANTES de
                                                       #   VERIFY/VALIDATE (y de cada re-corrida del debugger). Las lentes NO pueden llamarlo:
                                                       #   un reset a mitad de fase borra los datos que otra lente ya había probado. No fatal.
bash    .orchestrator/scripts/phase-push.sh "<FASE>" "<ID>"  # commit + push a origin/main tras cada fase (no-fatal sin git/remoto)
bash    .orchestrator/scripts/smoke-golden-path.sh     # smoke end-to-end con el golden path: prueba TODA la maquinaria determinista en positivo y negativo
```

### Qué esperar
- `/next-pantalla` **nunca** construye más de una unidad y **nunca** pasa a `accepted` solo.
- Si falta una decisión de producto a mitad de build → la unidad queda `blocked` con reproducción y siguiente acción exacta (las preguntas de producto se resuelven antes, en RESEARCH).
- La evidencia es real: acciones en runtime real, logs limpios, y el valor canónico coincide store→API→cliente.
