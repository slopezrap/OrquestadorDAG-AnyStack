---
name: next-pantalla
description: Build and verify exactly one screen/unit vertically using disk state and specialist agents, then stop at the acceptance gate.
argument-hint: [screen-id]
disable-model-invocation: true
model: inherit
effort: xhigh
---

# /next-pantalla

Run inline in the current main session. This command may write product code and orchestrator state. Do not use `context: fork` or `agent:`. Do not call `Agent(orchestrator-flow)`.

Arguments: `$ARGUMENTS`

Build exactly one unit from `.orchestrator-state/features.json`. A unit is usually a screen; it can also be a required foundation.

## Cross-cutting discipline

These disciplines apply to every phase below: the expert roles you embody, *think first then ask*, the phase checkpoint push, and recording each phase in `phase_runs[]`.

### You are the whole delivery team (expert roles)

You do not build a screen as a single generalist. You hold every role needed to ship the unit, each at **senior** level — with a senior's judgment: name the trade-offs, prefer the proven option over the clever one, and design for the whole application (architecture, data model, rules engine, pipelines, clients), not just the active screen — and reason from each one before and while you write code. Each phase materializes those roles as lens-agents or as hats you wear directly:

| Phase | Expert roles (how they materialize) |
| --- | --- |
| RESEARCH | all **17**, one lens per blueprint file = product owner (`product`), architect (`core`/`screens`), DBA (`data`), backend (`application`), security (`permission`), UX (`ui`/`design`), cross-screen shell (`shell`), state engineer (`state`), reliability/errors (`error`), integration (`integration`), domain expert (`domain`), use-case analyst (`usecases`), journey/flow (`journey`), engine owner (`engine`), data engineer (`pipeline`) |
| EXPLORE | `explore-scout` + experts by scope: `data`, `backend`, `ui`, `tests`, `existing`, `engine`, `pipeline`, `config` |
| DEVELOP | you write as **architect + backend + frontend/mobile + DBA + data engineer + DevOps + security + QA at once** (no fan-out) |
| VERIFY | all **10**: `tests` (QA), `conformance` (requirements analyst), `engine`/`pipeline` (data/runtime engineer), `design`+`frontend` (UX), `logs` (SRE), `quality` (production reviewer), `coherence` (cross-screen drift vs shell + accepted siblings), `blueprint-drift` (doc↔code drift) |
| VALIDATE | `logs` + `web`/`android`/`ios` per owned platform + `engine`/`pipeline` when cited = manual tester per runtime |
| REVIEW | `pantalla-reviewer` = tech lead / contractual sign-off |

For the active unit, **extract the information each role needs** from the blueprint, design and code (architecture, data model and canonical store, API/service contract, deploy/runtime/env and CI, permission gates, acceptance/test plan). DevOps/infra concerns that no lens owns (environment, runtime wiring, the phase-checkpoint push below) are owned directly by you. When a role's required input is missing or ambiguous, follow **Think first, then ask** below.

### Think first, then ask

When any role hits something it does not know — in **any** phase — think before you ask:

1. **Resolve it yourself first.** Re-read the relevant blueprint/design/code (including `ORIGINAL.md` and the `DEC-*` ledger), consult official docs (provider/framework/MCP) when version-sensitive, and reason from that role's expertise.
1b. **Then consult the policy.** If the sources are silent, read `.claude/rules/autonomy.md`. A Tier-1 default applies silently; a Tier-2 one applies with a `DEC-*` (`decided_by: "auto:<rule>"`, the rejected alternative, a trip-wire). A Tier-3 question is never decided here — go to step 2. Applying a written policy is not guessing; it is the difference between a run that continues and one that stops for something already answered.
2. **If it stays genuinely unresolved** and you need it to proceed correctly, **ask the human one precise question** instead of guessing. You may ask in any phase, not only RESEARCH — but prefer to batch product decisions in RESEARCH (§1.5), the cheapest point to resolve them.
3. **Persist the answer.** Product intent goes into `blueprint/**` so it is never lost; a technical answer just unblocks the current step.
4. **Block only as a last resort** — when the answer needs human setup/action beyond an answer, or the human cannot unblock inline. Then set `blocked`, write `verdict:"BLOCKED"` evidence with the exact question and next action, and stop.

Never invent product intent, fake a value or guess past a real unknown.

### Blueprint write-back (any phase)

The blueprint absorbs new truth the moment it appears — you are the only writer:

- **The human says something with product intent** — at any moment of any phase, even as an aside — write it into its blueprint file (`BR→PRODUCT`, `SCR→SCREENS`, ID family → `logic/*.md`, stack → `stack.md`) BEFORE acting on it. Chat is never the storage: compaction erases chat, disk survives.
- **You discover a blueprint-relevant fact while building** (an error case VERIFY surfaced, a state transition, a data constraint, a provider quirk) — write it back where it belongs: structural/derivable facts directly (note the source); product decisions via one precise CLARIFY first.

After every write-back: run `python3 .orchestrator/scripts/lint-blueprint.py` and reflect the change in the affected `spec.md` section. If the new truth changes an already-compiled or `accepted` contract, stop and route through `/reslice` — never patch state silently.

### Phase checkpoint push

After **every** phase below (RESEARCH, EXPLORE, DEVELOP, VERIFY, VALIDATE, REVIEW — including any debugger re-runs in §6), commit the work done in that phase and push it to `origin/main`:

```bash
bash .orchestrator/scripts/phase-push.sh "<PHASE>" "<ID>"
```

This is a DevOps-role side effect, not a lifecycle transition: it never changes a unit's `status` and the STATE GATE (`validate-state.py`) plus `/accept` remain the only trust anchors. The script is non-fatal — when there is no git work tree or no `origin` remote it logs and continues, so a checkpoint never blocks building a screen.

### Record each phase in result.json (`phase_runs`) — enforced

As each fan-out phase runs, append its entry to `result.json.phase_runs[]`: `{phase, workflow, mode, lenses[]}`, where `lenses[]` is the **actual** set of lens-agents that ran. This is not bookkeeping — **the STATE GATE rejects a PASS whose `phase_runs` is missing a phase or whose lens set is incomplete**, so skipping EXPLORE/VERIFY/VALIDATE or hand-picking a subset of lenses makes the unit un-`verifiable`. Required full sets: RESEARCH → all 17 `research-*`; EXPLORE → `explore-scout` + 8 `explore-*`; VERIFY → all 10 `verify-*`; VALIDATE → `validate-logs` + `validate-{web,android,ios}` for every owned platform + `validate-engine`/`validate-pipeline` when the unit cites `ENG-*`/`PIPE-*`; REVIEW → `pantalla-reviewer`. Use `mode:"workflow"` (or `"inline-fallback"` only when Workflows are genuinely unavailable, carrying the same full set); DEVELOP uses `"inline"`, REVIEW `"agent"`. The EXPLORE entry additionally carries `plan: ".orchestrator-state/evidence/<ID>/plan.md"` — the gate rejects a PASS whose EXPLORE entry has no `plan`, or whose `plan` is not a real, non-empty file (see §2). Do not write `phase_runs` for a phase you did not actually run — that is fabricated evidence.

**A lens that returned nothing did not run.** Every fan-out workflow reports the lenses that produced no result in `failed_lenses[]`, by name — including `validate-journeys`, which names each missing journey as `validate-journey:<JOUR-ID>` rather than returning a count you would have to reconstruct.

**The retry already happened — do not repeat it.** EVERY fan-out workflow re-launches its own empty lenses ONCE internally, with the identical prompt, and tells you which in `retried_lenses[]`. So `failed_lenses[]` is **post-retry**: every name in it has already had two attempts. Re-launching them is paying twice for the same dead lens, and it delays the block rather than preventing it.

What you own is the consequence, in order: (1) do NOT list them in `phase_runs[].lenses` — the set is then incomplete and the unit cannot reach `verified`; (2) record each one in `result.json.failures[]` with the phase, the lens name and the reason; (3) set the unit `blocked` with `blocked_reason` naming those lenses and the phase, plus reproduction and next action. Retry (theirs), then block (yours) — there is no third option, and a degraded fan-out is never silently smaller.

There is no longer any fan-out you retry by hand — `validate-journeys` and `audit-architecture` were the last two without it, and they were the ones that most needed it: both launch UNATTENDED from `/accept`, so a transient miss there is the case with the fewest humans watching.

### Tally real subagent launches (telemetry, not evidence)

`batch.json.telemetry.subagents_spawned_estimate` reads 0 on every real run today — nobody actually counts, so the field is dead weight, and the closest thing to a live number is `.claude/rules/autonomy.md`'s static "45-60 clean / 120-160 capped" heuristic, which was never meant to describe one run's actual spend. Every fan-out workflow already returns what it needs to be counted for real: `lenses` (succeeded), `failed_lenses` (never returned, post-retry), `retried_lenses` (relaunched once) — plus `scout` for EXPLORE and `digest` for the workflows with a synthesis reducer (RESEARCH, VERIFY; not EXPLORE/VALIDATE/`validate-journeys`). After every fan-out call, add to a running per-unit total:

```text
launches += 1                                                # the loader (every fan-out has one)
launches += (result.lenses.length + result.failed_lenses.length)   # every lens actually attempted
launches += result.retried_lenses.length                     # the extra relaunch for each retried one
launches += 1   if result.scout !== undefined                 # EXPLORE only: scout is its own call
launches += 1   if result.digest !== undefined                 # RESEARCH/VERIFY: the synth reducer
```

REVIEW adds exactly 1 (`pantalla-reviewer`, no fan-out). The two §5.5 gates add whatever `explore-*`/`verify-engine`/`verify-pipeline`/`validate-*` calls THEY make internally, counted the same way. At §7 Close, persist the running total verbatim as `result.json.subagents_spawned` — a REAL count for this unit's whole build, including every debugger re-run, not an estimate. `/build-loop` sums this field across `units_built[]` into `batch.json.telemetry.subagents_spawned_estimate` (see its SKILL.md) instead of guessing.

## 0. Rehydrate

Start from disk:

1. `pwd`
2. read `CLAUDE.md` and `.claude/rules/*.md`
3. read `.orchestrator-state/spec.md`
4. read `.orchestrator-state/progress.md`
5. read `.orchestrator-state/features.json` and require `initialized:true`
6. inspect current filesystem/runtime state relevant to the active unit
7. run `python3 .orchestrator/scripts/validate-state.py`
8. run the setup command recorded in `.claude/rules/stack.md` only if needed to prepare the environment
9. run the smoke command recorded in `.claude/rules/stack.md` when a smoke command is known

If the environment is broken, fix the environment first. Do not start a new screen on a broken base.

## 1. Choose one unit

If `$ARGUMENTS` contains an ID:

- it must exist;
- `ready`, `building` or `blocked` may be retried;
- `todo` may be used only if every dependency is BUILT (`verified` or `accepted`), then mark it `ready` first;
- `verified` stops with instruction to run `/accept <id>`;
- `accepted` stops as already complete.

If no ID is provided:

1. If any unit is `verified`, stop and ask for `/accept <id>` — EXCEPT when an explicit ID was passed (which is how `/build-loop` drives each iteration): with an ID, build that unit and do not stop on unrelated `verified` units.
2. Recompute `ready` for `todo` units whose dependencies are all BUILT (`verified` or `accepted`).
3. Choose the `ready` unit with lowest `order`.
4. If none is ready, report complete, blocked or dependency status.

For the chosen unit, set `status:"building"`, `passes:false` and `checkpoint: {"phase":"RESEARCH","iteration":0}`, save `features.json` and append `BUILDING` to progress.

The `checkpoint` field is the crash/compaction anchor: update `checkpoint.phase` in `features.json` as each phase starts (RESEARCH/EXPLORE/DEVELOP/VERIFY/VALIDATE/REVIEW), and `checkpoint.iteration` on each debugger re-run (§6). If step 0 found the unit already `building` with a `checkpoint`, resume from that phase — do not restart the whole pipeline (already-recorded `phase_runs` stay valid).

## 1.5 Research the blueprint for this unit (phase 0, fan-out)

Before touching code, make sure the blueprint — the product source of truth — fully specifies THIS screen across front, back, data engine, pipelines, tables, infra and permissions. Run a deep RESEARCH:

- **Always launch the `research-fanout` workflow** — mandatory, not a preference — (it fans out one `research-*` lens-agent per blueprint file: 14 `logic/*.md` — including `shell.md` (cross-screen contract), `engine.md` (`ENG-*`) and `pipeline.md` (`PIPE-*`) — + `research-product` + `research-screens` + `research-design`). It MUST fan out to **all 17** lenses every time; never hand-pick a subset (a non-applicable lens self-reports `covered:n/a`).
- Only if the Workflow capability is genuinely unavailable in this session, fall back to the `research-*` agents sequentially and record `inline-fallback` — never as a shortcut.

It returns coverage, gaps (`auto_fill` or `clarify`) and CLARIFY questions. As the single writer, complete the blueprint so nothing is lost:

- apply `auto_fill` proposals to `blueprint/**` (structural/derivable only);
- ask the human the `clarify_questions` in ONE round — RESEARCH is the **main** place to ask, batching product decisions pre-build (later phases may still ask per *Think first, then ask*) — and write the agreed answers into `blueprint/**`;
- after writing any fill/answer into `blueprint/**`, run `python3 .orchestrator/scripts/lint-blueprint.py` — your writes must leave the blueprint referentially intact (no duplicate IDs, no dangling refs, no cycles);
- if a blocking product gap cannot be resolved, set `blocked`, write `BLOCKED` evidence and stop.

Proceed to explore only when the blueprint specifies this screen unambiguously. Re-read the updated feature/blueprint before planning.

Then push the RESEARCH checkpoint: `bash .orchestrator/scripts/phase-push.sh "RESEARCH" "<ID>"`.

## 2. Explore and plan (agents feed you; you hold the thread)

With the blueprint complete, get an actionable context contract from a DEEP explore over the code — always fan out, never a single shallow pass:

- **Always launch the `explore-fanout` workflow** — mandatory, not a preference — (`explore-scout` lists relevant files by scope, then `explore-{data,backend,ui,existing,tests,engine,pipeline,config}` audit their files in parallel). It MUST launch `explore-scout` + **all 8** `explore-*` lenses every time; never a subset.
- Only if the Workflow capability is genuinely unavailable in this session, fall back to `explore-scout` then the `explore-*` agents sequentially and record `inline-fallback` — never as a shortcut.

You own the single consolidated context; lenses cover disjoint scopes so the maps never conflict. The explore lenses audit the existing code and flag gaps. Handle gaps with *Think first, then ask*:

- a `block_signal` (missing/contradictory product intent, undeclared data owner, ambiguous architecture) -> first resolve what you can from the sources; if it stays genuinely unresolved, ask the human one precise question (prefer to have caught it in RESEARCH); block only as a last resort, writing `verdict:"BLOCKED"` evidence with the exact question and next action. Never guess. (Most product gaps should already be resolved by RESEARCH at `/init-build`.)
- a technical-context `risk` -> resolve it yourself and proceed.

From the consolidated `acceptance_map[]`, write the vertical plan in dependency/layer order:

```text
data/schema -> backend/API -> UI/flow -> tests -> verification/evidence
```

Map every acceptance criterion to implementation and evidence. For data units, map every critical value through the architecture-appropriate path:

```text
engine refs -> generation (migration/seed/backfill/job/api_write/replay/transition) -> canonical store value -> service/API/read model -> client field
```

Do not plan UI before the canonical data path is clear. Bind the `verification_route` from EXPLORE now; step 5 uses it and does not re-derive verification from journey refs.

### Write the plan to disk — enforced

**The plan is EXPLORE's deliverable, not a note to yourself.** Write it to
`.orchestrator-state/evidence/<ID>/plan.md` and cite it from the EXPLORE entry of
`phase_runs[]` as `plan: ".orchestrator-state/evidence/<ID>/plan.md"`. The STATE GATE
requires that field and checks the file exists and is non-empty, exactly as it checks any
other artifact. Shape:

```markdown
# PLAN <ID> — <title>

- **verification_route**: <what EXPLORE bound: platforms, engine/pipeline, log sources>
- **consumer** (who exercises this unit): <for a `kind: foundation`, the SCR-* that will
  actually run it and how far behind it sits in build order; for a ui/backend unit, itself>

## Acceptance map            <- one row per acceptance criterion, no exceptions
| criterion | governing IDs | files to touch | how it will be proven | expected artifact |

## Vertical order            <- data/schema -> backend/API -> UI/flow -> tests
## Risks accepted            <- each with the trip-wire that would reopen it
## Delivery                  <- left empty here; you fill it at the end of DEVELOP (§3)
```

Three things this buys, and the third is the one worth writing it for:

- **It survives compaction.** The plan used to live only in your context, so a crash or a
  compaction mid-DEVELOP re-derived it — badly, since that is exactly the moment your
  judgment about what you already decided is weakest.
- **It makes delivery checkable.** Nothing could previously ask *was what was built what was
  planned?* — `pantalla-reviewer` judges code against `acceptance[]`, which is a different
  question, and `verify-conformance` judged code against the blueprint, which is another.
- **A criterion with no answer in the "how it will be proven" column is a criterion that
  will fail VERIFY.** Filling that column is the cheapest possible moment to find out: now,
  before a line is written, instead of after a 12-launch VERIFY fan-out. If you cannot fill
  it, you have not finished EXPLORE — go back to the lenses or ask, do not write code and
  hope the proof appears later.

The **consumer** line exists because the most expensive defect this orchestrator has ever
measured was a foundation nothing exercised for many units (4x cost, `USO.md` §4). The gate
catches that globally at `/init-build`; this line is the same question asked per unit, at the
moment you can still answer it honestly.

Then push the EXPLORE checkpoint: `bash .orchestrator/scripts/phase-push.sh "EXPLORE" "<ID>"`.

## 3. Build vertically

The main conductor writes code, wearing every DEVELOP hat at once, each at senior level — **architect + backend + frontend/mobile + DBA + data engineer + DevOps + security + QA** (see Cross-cutting discipline). Decide the layering as the senior architect, the canonical store and migrations/seeds as the DBA, the pipelines/generation as the data engineer, the API/service contract and business rules as the backend, the client UI/flow (inside the shared shell, reusing the component inventory) as the frontend/mobile engineer, the runtime/env/wiring as DevOps, the permission/input gates as security, and the test/evidence plan as QA — in one coherent vertical. Every role's input should have been extracted in RESEARCH/EXPLORE; if one is still missing now, apply *Think first, then ask* (resolve yourself, ask one precise question if genuinely stuck, block as a last resort) — never guess.

Implement only the selected unit and necessary support:

1. data model/schema/migration/seed;

   - compile the selected unit's `data_engine` into concrete schema, seeds/generator, backfill/job or write path;
   - generate verification data in the canonical store, not in frontend constants or local mock files;
2. domain/application/core logic;
3. API/service/integration boundary;
4. UI or mobile flow;
5. tests and verification hooks for this unit.

No final stubs, fake data, TODOs, placeholder behavior or mocks unless the acceptance explicitly requires a prototype/mock. If verification needs data that does not exist yet, produce it through the unit's declared REAL generation path (migration/seed/backfill/job/api_write/event replay/state transition) into the canonical store — never invent it at any layer.

Library coherence: before adding any dependency, check the existing manifest and `.claude/rules/stack.md`; reuse what already solves the concern, never introduce a competing library, prefer the current officially recommended option (consult official docs when version-sensitive) and record new dependencies in `stack.md`.

All frontends for the unit must read product values through the same API/service/read model backed by the database. Do not create separate web/mobile copies of the same business value.

If the unit cannot be completed, set `blocked`, write `.orchestrator-state/evidence/<ID>/result.json` with `verdict:"BLOCKED"`, append progress and stop.

## 4. Evidence skeleton

Create:

```text
.orchestrator-state/evidence/<ID>/
├── result.json
├── plan.md                 # ya escrito al cerrar EXPLORE (§2); aquí solo se completa su ## Delivery
├── screenshots/
├── logs/
├── traces/
├── db/
├── recordings/
├── videos/
└── reports/
```

Start `result.json` as `FAIL`. Upgrade only after real verification.

### Close the plan: DECLARE what you delivered

Before VERIFY, fill the `## Delivery` section of `.orchestrator-state/evidence/<ID>/plan.md`
— one line per acceptance row: **delivered**, **delivered with a deviation** (and what
changed and why), or **not delivered** (and why not).

**This is a declaration, not a self-review.** You just wrote the code; asking yourself
whether you did it right, in the same context, minutes later, is the weakest check that
exists and this is not it. What you are doing is making a claim someone else can falsify:
`verify-conformance` reads this section and confirms or refutes each line against the code,
and `pantalla-reviewer` reads it before writing its contractual verdict. Deviating from the
plan is legal and normal — you learn things while building. Deviating in **silence** is not,
because it removes the only record of what the code was supposed to be.

Costs nothing: no subagent, no fan-out, one edit to a file you already wrote. Then push the
DEVELOP checkpoint: `bash .orchestrator/scripts/phase-push.sh "DEVELOP" "<ID>"`.

## 5. Verify → Validate → Review (from the bound route)

Run the three quality phases from the bound `verification_route` (EXPLORE), not from journey refs. Each phase **always launches its fan-out workflow** (mandatory, not a preference), fanning out to its **FULL** set of lenses every time — VERIFY → **all 10** `verify-*`; VALIDATE → `validate-logs` + `validate-{web,android,ios}` for every owned platform + `validate-engine`/`validate-pipeline` when the unit cites `ENG-*`/`PIPE-*` — never a hand-picked subset. Only if the Workflow capability is genuinely unavailable does it degrade to sequential `Agent(...)` calls running the same full set (record `inline-fallback`, never as a shortcut). Lens-agents save only their own evidence artifacts under `.orchestrator-state/evidence/<ID>/` and RETURN their findings (checks, observed values, failures); you (orchestrator-flow) write the consolidated `result.json` and verdict — never the lens-agents (this avoids parallel writes to the same file).

**Before each of these phases, reset the test-data store — once, and only you.** Run `bash .orchestrator/scripts/reset-test-data.sh "<PHASE>"` immediately before VERIFY, before VALIDATE, and before every debugger re-run of either. It delegates to `COMMAND_RESET_TEST_DATA` in `.claude/rules/stack.md`, so it stays stack-agnostic; it is non-fatal, and it reports distinctly when the key is undeclared or still an unresolved placeholder — read that line, because an unreset store means the phase's data is whatever the previous phase left behind. **Lens-agents must never call it.** One reset, one owner, before the phase.

**And the reset is a FLOOR, not a substitute for scoping.** Because the executing lenses run serialized, one reset leaves a pristine store for the *first* lens only — the second inherits what the first wrote. Do not fix that by resetting between lenses: you would erase rows an earlier lens already cited as evidence, leaving its saved artifact describing data that no longer exists. The existing rule is the one that carries this (`stack.md`, "Runtime evidence policy": isolated test data, disposable local state or safe cleanup when a verification mutates persistence): **every lens that writes scopes itself to identifiers it generated, and concludes nothing from a global count** — "3 rows exist" is not a finding when a neighbour also writes. Say this to the lenses when you brief them. A reset that gets read as permission to stop scoping makes the contamination harder to see, not rarer.

**Consolidation is a CONTRAST, not a transcription.** Before you write any conclusion into `result.json` or `blueprint/**`, open `.orchestrator-state/evidence/<ID>/` and read the artifacts the lenses actually saved — then check them against what you are about to write. The digest is a lossy reduction of what the lenses returned, and what the lenses returned is itself narrower than what they wrote to disk; a finding can be true, saved, and still absent from the summary you are reading. Start with the synthesizer's `contradicts_prior_claim[]` (VERIFY and RESEARCH both emit it on every run, empty when there is nothing) — but that array is your read-list, not a substitute for opening the directory.

A lens finding that contradicts your conclusion has exactly two legal exits: it is **reflected** (the conclusion changes), or it is **refuted with its own proof** — the exact command, its literal output and the artifact path. "It did not come through in the digest" is not an exit: the artifact is on disk, so the lens ran. And a NEGATIVE you are about to write anywhere — *it does not exist*, *it is not supported*, *I tried it and it failed* — carries the same burden as a PASS (constitution, "The burden of proof is symmetric"). Without command, literal output and artifact it is a hypothesis; write it as one or go prove it. This is the step where a bad negative becomes a product decision, and the cheapest place in the whole loop to catch it.

### VERIFY — static, against the documents

**On a REPAIR pass, tell the lenses what the repair touched.** The first VERIFY of a unit is a baseline: launch it with no scope. Every LATER VERIFY (every debugger re-run) is re-checking a specific repair, so compute the changed files and pass them in:

```bash
git diff --name-only HEAD~1..HEAD    # or against the DEVELOP checkpoint phase-push.sh left
```

**Write the scope to DISK, then launch.** `.orchestrator-state/evidence/<ID>/logs/changed-files.txt`, in this exact shape — the first line is load-bearing:

```text
# iteration: <the checkpoint.iteration this repair belongs to>
# command: git diff --name-only HEAD~1..HEAD
# triage: fail_fast                      <- optional, see §6
# triage: scope_to=verify-tests,verify-design   <- optional, see §6
<literal output, one path per line>
```

The two `# triage:` lines are OPTIONAL and belong only on a triage pass. Omit them — which is the normal case — and the pass runs the full ten lenses. They live in this file rather than one of their own because all three are parameters of the SAME repair pass: written at the same moment, and they must go stale together. **Delete them before the closing pass.**

Then launch `verify-fanout.js` with `args.changed_files = [<those paths>]` as well, and record the list in `result.json.phase_runs[]` for that VERIFY entry (`changed_files`).

**Both, not either — and disk is the one that counts.** `args` has been measured NOT to reach the workflow on some runs: not as an error, just `undefined` inside the script, with no way for it to tell "nothing was passed" from "something was passed and lost". Every one of those passes silently ran as a baseline, so this whole optimization was not actually running. The workflow now reads the file when `args` arrives empty, and honours it ONLY when its `# iteration:` header matches the unit's current `checkpoint.iteration` — a scope from a previous iteration is worse than no scope, exactly as the paragraph below says.

**Check what came back.** `verify-fanout` returns `args_seen` plus `scope_source`, `scope_to_source` and `fail_fast_source` (each `args` | `disk` | `none`). If you asked for something and got `none`, it did not arrive by either route: say so in `phase_runs[]` rather than recording a scope it never used.

**And clear the triage lines before you close.** A leftover `# triage:` header on the closing pass forces `full_set:false`, which you may not record and which `validate-state.py` rejects as an incomplete VERIFY — so it fails loudly and safely, but it costs you a full re-run. Rewriting the file for the closing pass (or deleting it) is one line and saves that. Non-fatal throughout: no git work tree, no commits, or any doubt about which range is right → write nothing, pass nothing, run the baseline.

**Never pass a guessed list.** An incomplete one is worse than none, because ten lenses will trust it — and the list is itself a claim ("nothing else moved") that nothing inside the workflow can verify. That is the negative-without-proof pattern this same skill forbids everywhere else, so it gets the same treatment: a command, its literal output, an artifact. If you cannot produce those three, you do not have a scope; run the baseline. The risk is highest exactly where your judgement is weakest — resuming after a compaction or crash, when picking the right commit range is guesswork — and there the honest move is to pass nothing.

**A spec file in the list is not a small change.** Anything under `blueprint/`, `design/` or `.claude/rules/` is a change to what the code is judged *against*, and in a spec-driven build that is the most consequential kind of edit, not the least. The workflow flags it to the lenses, and the doc↔code lenses may not declare themselves out of scope on that pass. If the edit changed a contract a compiled or `accepted` unit relies on, it is a `/reslice`, not a debugger iteration — see the three tiers in `constitution.md` (editorial / additive / contractual) and its one-question test: *would every already-recorded PASS still prove what it claims after this edit?*

**Why this exists, and what it is not.** Re-running all 10 lenses to re-check a one-line or docs-only fix was the most expensive habit in this loop — most of those lenses had nothing in scope and re-read the repo to discover it. This does **not** run fewer lenses: all 10 still run, each still returns a verdict, and the pass stays fully recordable in `phase_runs[]`. It only lets a lens whose scope did not move say so in seconds instead of re-deriving everything. **Each lens judges its own relevance — you never decide for it.** A file list looks unrelated right up until a shared component moves under `verify-coherence`'s feet, and that call belongs to the lens that owns the contract, not to you. A lens that re-affirms a prior verdict must say so and name the scope it checked; that is a verdict a reader can challenge, and it is the whole difference between a cheap pass and a fabricated one.

Workflow `verify-fanout.js` (fallback: the `verify-*` lens-agents, sequential). Lenses: run/read tests; logic conformance vs the cited docs; design fidelity; data-engine/pipeline proof for the detected architecture; back/front/db/engine logs and code quality; cross-screen coherence vs the shell contract (`UI-SHELL-*`) and the sibling `verified`/`accepted` screens. It records `db_value`/`api_value` and emits `expected_ui_values[]`. Does not drive the live UI. After consolidating the static verdict, persist the digest's `expected_ui_values[]` **verbatim** into `result.json.expected_ui_values` (canonical shape: `{db_key, permission_context, api_field_path, expected_visible_value, ui_field, transform?}`) — VALIDATE's loader lifts them from that field on disk, so never leave them only in chat context. Also persist the REST of the digest — `findings[]`, `observed_values`, `source_refs[]`, `contradicts_prior_claim[]`, `verdict_by_lens[]`, `artifacts[]` — verbatim into `result.json.verify_digest`, so REVIEW and the two §5.5 gates can confirm/extend/refute against it instead of re-deriving it from scratch (never a substitute for their own independent walk). Then push the VERIFY checkpoint: `bash .orchestrator/scripts/phase-push.sh "VERIFY" "<ID>"`.

### VALIDATE — live, human-like (owned UI surfaces only)
Workflow `validate-live.js` (fallback: the `validate-*` lens-agents per runtime — `validate-web`/`validate-android`/`validate-ios` — plus `validate-logs`, sequential). Drive the real product like a human: web (Claude-in-Chrome → Chrome DevTools MCP → Playwright fallback), Android (emulator + adb/logcat), iOS (simulator + idb/simctl) — plus the framework tooling the declared `Mobile framework` in `.claude/rules/stack.md` calls for, and none when it declares a framework that needs none. Exercise every state/flow, inspect logs, confirm no errors. Assert each observed client value **derives from** `expected_ui_values` (value + transform), not blind equality; record `ui_value`/`platform_values`. Hybrid: web and mobile must show the same canonical value. Never PASS without the live runtime. Backend-only units skip VALIDATE. After consolidating the live verdict, push the VALIDATE checkpoint: `bash .orchestrator/scripts/phase-push.sh "VALIDATE" "<ID>"`.

### REVIEW — one contractual verdict
`Agent(pantalla-reviewer)` consolidates VERIFY + VALIDATE evidence into a single contractual verdict against `acceptance[]`, `applies[]` and the blueprint source text. It cannot move the unit to `accepted`. After recording the verdict, push the REVIEW checkpoint: `bash .orchestrator/scripts/phase-push.sh "REVIEW" "<ID>"`.

### 5.5 AUTO-GATES — pipelines/data + production readiness (automatic, Sonnet)

After REVIEW passes, run BOTH deep gates automatically — they are part of every `/next-pantalla`, not optional extras (manual re-runs before `/accept` remain possible):

1. **`/verify-pipelines-data-ultracode <ID> --fix`** — follow `.claude/skills/verify-pipelines-data-ultracode/SKILL.md` inline. A unit with no data/pipeline contract self-reports `NOT_APPLICABLE` (record it; that is a pass).
2. **`/production-code-review <ID> --fix`** — follow `.claude/skills/production-code-review/SKILL.md` inline.

**How to run them:** `Read` each `SKILL.md` and execute its protocol yourself in this session, with `$ARGUMENTS = "<ID> --fix"`. Do NOT call the `Skill` tool: both are `disable-model-invocation: true` by design (that flag exists to keep you the single writer, not to make the gates unreachable). Being unable to invoke `/verify-pipelines-data-ultracode` or `/production-code-review` as a slash command is NOT a blocker and is never a reason to close a unit without their checks, nor to hand the run back to the human.

**Model:** spawn every subagent/workflow these two gates use with `model: 'sonnet'` — the deep sweeps are Sonnet-tier by design; you (the conductor) stay on the session model and remain the single writer.

**ORDER: the gates go LAST — after the FINAL VERIFY/VALIDATE, not merely after the first REVIEW.** Do not run them while repairs are still landing: let VERIFY/VALIDATE/REVIEW stabilize first, then run them once. A gate report is a reading of the evidence files at a moment in time; a later phase overwrites those files and leaves the report citing numbers the file no longer contains — a document that looks like proof, was true when written, and describes a state that no longer exists. That is worse than a missing report: a missing one gets re-run, a stale one gets believed. The invariant is simply *the last thing that touched the evidence must be the thing the gate read*.

**Run BOTH, every time — on the first pass and on every re-run.** If a repair re-runs VERIFY or VALIDATE after a gate has already run, re-run both `/verify-pipelines-data-ultracode` and `/production-code-review`, whatever domain the repair looks like it touched.

An earlier version of this file routed re-runs by domain and justified it by asserting these gates "cost more than a VERIFY fan-out each". **That was written as a measurement and never measured, and the measurement contradicts it**: against a VERIFY fan-out, the two gates together cost a fraction of one, not more than one each. Routing therefore bought very little wall clock, and it bought it by putting a judgment call — *which domain did this repair touch?* — on the hot path, where guessing wrong means skipping the gate that would have caught the defect. The cheap option and the safe option turned out to be the same option, so there is no trade-off left to manage.

Two consequences worth keeping in mind. Re-derive the medians for your own project before assuming the ratio holds here (§9 of any cost report you keep, or the per-agent transcripts); and if a future measurement ever makes a gate genuinely expensive, the fix is to make that gate cheaper, not to reintroduce a rule that decides by feel which proof to skip.

**Cite identifiers that do not drift.** In both gate reports, anchor every claim to something stable — check ids (`CHK-<ID>-...`), rule ids (`DATA-004`, `ENG-002`), artifact paths, content hashes, exit codes. Never anchor to a count ("3 failing tests", "12 findings", "a 400-line file"): counts age the moment anything is repaired, and a report full of aged counts cannot be told apart from a report that is simply wrong. An identifier still resolves after the next fix; a count silently stops matching.

Consequences:
- Their required checks merge into `result.json` and must pass — a failing gate check keeps the unit un-`verified`.
- If a gate applied a fix, the touched evidence is stale: treat it as a debugger pass (§6) — increment `checkpoint.iteration`, re-run VERIFY (passing `args.changed_files`, since this is a repair pass), VALIDATE when the fix changed runtime behavior, and REVIEW when the fix touched implementation/test code rather than only a report/evidence file — `pantalla-reviewer`'s verdict was computed over the pre-fix evidence, so it goes stale the moment VERIFY/VALIDATE re-run over changed code, exactly like the VERIFY/VALIDATE evidence it consolidates. In practice this fires on every gate-applied fix: both auto-gates repair implementation/test code by design (`verify-pipelines-data-ultracode/SKILL.md` §5, `production-code-review/SKILL.md` §2), never blueprint or evidence alone. Then re-run BOTH gates, per the ORDER rule above.
- Push a checkpoint after each gate: `bash .orchestrator/scripts/phase-push.sh "GATE_DATA" "<ID>"` and `bash .orchestrator/scripts/phase-push.sh "GATE_PROD" "<ID>"`.

## 6. Debugger loop (DEVELOP repairs; re-run downstream)

DEVELOP is also the debugger: every phase result feeds you (the single writer), and on failure you repair in-thread, then re-run the affected phases. Maximum 3 iterations — enforced: increment the unit's `checkpoint.iteration` in `features.json` on EACH repair pass; the STATE GATE rejects `iteration > 3`, so past the cap the only honest moves are `blocked` (with reason and reproduction) or a human decision.

**Every re-run in this loop is a REPAIR pass: pass `args.changed_files`** (see §5, VERIFY). A repair should cost what the repair was worth — the lens set never shrinks, but a lens with nothing in scope should not re-read the repo to find that out. Only the first VERIFY of the unit and any pass where you cannot determine the changed files run as a baseline.

- **VERIFY fails** → debug (repair this unit + necessary support) → **re-run VERIFY**; when it passes, continue to VALIDATE.
- **VALIDATE fails** → debug → **re-run VERIFY and VALIDATE** (a code fix can invalidate the static evidence, so re-prove both).
- **REVIEW fails** → `pantalla-reviewer` returns a contractual FAIL against `acceptance[]`/`applies[]` → debug → **re-run VERIFY and VALIDATE, then REVIEW again**. Re-prove both upstream phases, not just REVIEW: the reviewer judges the consolidated evidence, so a repair that leaves the old VERIFY/VALIDATE artifacts in place would have it re-reading files that describe the code before the fix. This branch consumes an iteration like any other, and past the cap the unit goes `blocked` with the reviewer's exact objection as `blocked_reason`.

  It exists because its absence was the sharpest edge in this loop: §5.5 opens with *"After REVIEW passes"* and named no alternative, so a negative contractual verdict — the single most authoritative signal a unit produces — left the procedure with nothing to say and the conductor improvising at exactly the moment it should not. A gate whose failure path is undefined is not a gate.
- Each repair marks the touched-layer evidence **stale**; rewrite `result.json` from the fresh runs. Re-run only the affected phase(s), not the whole pipeline.
- A repair is a DEVELOP pass: push a `DEVELOP` checkpoint after it, then a fresh checkpoint for each re-run phase (re-VERIFY / re-VALIDATE), so `origin/main` tracks every iteration.
- **Fail-fast triage re-run (optional, and never evidence).** When you are re-running VERIFY to find out whether a repair actually landed, set `args.fail_fast = true` alongside `args.changed_files` **and** write `# triage: fail_fast` into the header of `logs/changed-files.txt` — both, for the same reason the changed-files list goes to disk: `args` has been measured not to arrive, and this is the parameter whose loss costs the most wall clock. It is the one that stops the serialized chain, so losing it means paying the whole chain to be told about a failure you already know about. The declared lens set is never shrunk — all 10 are still targeted — but the SERIALIZED chain stops launching the next lens as soon as one reports `verdict: fail`, instead of paying the rest of the chain to be told the same thing again. The parallel documentary half is unaffected. Detection reads the `verdict:` line the lens agents already declare, so it fires ONLY on an explicit fail: a missing or ambiguous verdict never stops the chain, and the saving is therefore best-effort — largest when the failure is early (`verify-frontend` runs first precisely because "it does not build" invalidates everything behind it), nil when it is late. The workflow returns `full_set:false`, `fail_fast_stopped_at` and `fail_fast_skipped[]`. **`fail_fast_skipped` is NOT `failed_lenses`**: those lenses were never launched, so the retry-once-then-block rule above does not apply to them — do not retry them and do not block the unit for them. A fail-fast pass may be written into `phase_runs[]` as a NON-CLOSING VERIFY entry ONLY when its own consolidated verdict is `fail` (a fail-fast pass exists to prove a repair did NOT work, never to claim it did): set `fail_fast:true` and `verdict:"fail"` on that entry, `iteration:<this unit's checkpoint.iteration>`, and cite every lens in `fail_fast_skipped[]` inside `carried_forward[]` exactly as the Scoped triage re-run below describes, pointing at the last complete VERIFY iteration. `validate-state.py` rejects a `fail_fast:true` entry that is either the closing one or not `verdict:"fail"`. The last VERIFY before the unit closes must still be a full, un-truncated 10-lens run with zero `carried_forward` and no `fail_fast` flag. Never use it on a first or closing pass.
- **Scoped triage re-run (optional, and never evidence).** When a repair touched only documentation or test scaffolding, re-running all 10 lenses to re-check it is the most expensive habit in this loop. You may pass `args.scope_to = [<lens names>]` to `verify-fanout.js` — and equally write `# triage: scope_to=<names>` into the `logs/changed-files.txt` header, since `args` may not arrive — to re-run just the lenses whose scope intersects the change; the workflow returns `full_set:false`, reports `scope_to_source` (`args` | `disk` | `none`) and logs that it was scoped. **A scoped pass may be written into `result.json.phase_runs[]` as a NON-CLOSING VERIFY entry, as long as it is honest about what it did not run.** Build its entry as `{phase:"VERIFY", workflow:"verify-fanout", mode:"workflow", iteration:<this unit's current checkpoint.iteration>, lenses:[<the lenses that ACTUALLY ran this pass>], carried_forward:[{lens:"<name>", from_iteration:<the iteration field of the last COMPLETE VERIFY entry already in phase_runs[]>} for every one of the 10 that did not run this pass]}`. `validate-state.py` checks this mechanically: for every VERIFY entry except the LAST one recorded, `lenses[]` union `carried_forward[*].lens` must equal the full 10-lens set, and every `carried_forward[*].from_iteration` must match the `iteration` of the most recent EARLIER entry that was itself complete (full native `lenses[]`, no `carried_forward`, no `fail_fast`) — a stale or missing citation fails the gate. **The LAST VERIFY entry recorded is the CLOSING one and is exempt from none of this**: full 10-lens set natively, nothing carried forward, whatever came before it. If you cannot honestly fill `carried_forward` — no earlier complete pass exists yet, or you are not sure a lens's prior verdict still holds — do not record this pass at all; that is still legal, exactly as before. Use it to find out fast whether a fix worked; earn `verified` with a full, carried_forward-free closing pass.

If the same failure repeats without progress across the iteration cap, mark `blocked` with a concrete reason, reproduction and next action.

## 7. Close

Write BOTH fields in the same `features.json` save — `status:"verified"` **and** `passes:true`. `passes` mirrors the status, it is not an extra judgment: the STATE GATE rejects `verified` with `passes:false`, and `/accept` requires `passes:true` as a precondition. Do this only when:

- every required check passed;
- `result.json.verdict == "PASS"`;
- failures are empty;
- required artifacts exist and are non-empty (no 0-byte/placeholder files);
- data checks are real or explicitly not applicable;
- every required `data_engine` assertion carries the observed literal value at each layer (`db_value`/`api_value`/`ui_value` plus `platform_values` when multi-client) and they are equal, proving canonical-store -> API/read-model -> client equality;
- `result.json` includes a `source_manifest` (path + sha256 of the unit's implementation files) so stale evidence is detectable after any later fix;
- `result.json.phase_runs[]` proves the full workflow cycle ran with complete lens sets (RESEARCH, EXPLORE, DEVELOP, VERIFY, VALIDATE when the unit owns a UI surface, REVIEW) — the STATE GATE rejects a PASS that skipped a fan-out workflow or ran a partial lens set;
- the two §5.5 auto-gates recorded their checks by id in `result.json.checks[]`, each `passed:true`: `CHK-<ID>-PRODUCTION-CODE-REVIEW` (always) and `CHK-<ID>-PIPELINES-DATA-ULTRACODE` (or, when the unit has no data engine, present with `required:false, passed:true, notes:"not applicable"`). Their ABSENCE means a gate never ran; `/accept` looks for them by id;
- `python3 .orchestrator/scripts/validate-state.py` passes.

**Harvest (do not lose what this screen learned).** Before closing, write back everything blueprint-relevant this unit produced, as the single writer:
- anything SHARED — a reusable component, a route pattern, an API convention, a shell/navigation piece, a helper other screens will need — goes into `blueprint/logic/shell.md` (component inventory `UI-SHELL-003`, navigation `UI-SHELL-002`, conventions);
- any OTHER discovery that belongs in the spec — an error case surfaced by VERIFY/VALIDATE, a state transition, a data constraint, a provider quirk, a new dependency — goes into its `logic/*.md` / `stack.md` per the Blueprint write-back discipline (structural facts directly, product decisions via CLARIFY).
Then run `python3 .orchestrator/scripts/lint-blueprint.py`. The next screen's RESEARCH and `verify-coherence` read the contract, not your memory: knowledge that exists only in code or chat is knowledge already being lost.

Then update the feature entry (`status:"verified"`, `passes:true`, and clear its `checkpoint` — the build is no longer in flight — but leave `total_repair_passes` untouched: it is a LIFETIME counter written only by the 4 REOPEN routes and must survive every close, which is the entire point of it), append `VERIFIED`, run `python3 .orchestrator/scripts/validate-state.py --emit-status` (refreshes `status.json` + `evidence/index.json` for external readers) and `bash .orchestrator/scripts/validate-structure.sh`, and stop with:

```text
Evidence: .orchestrator-state/evidence/<ID>/result.json
Auto-gates already run (Sonnet): pipelines/data + production review — see evidence/<ID>/reports/
Recommended next: /review-pantalla <ID> if the UI deserves an extra live-parity pass, then /accept <ID>.
When an /accept completes a journey (JOUR-*), /verify-app runs automatically on it.
```

Never start the next unit automatically — the one sanctioned exception is `/build-loop`, which is an outer loop that re-invokes this procedure with an explicit ID per iteration and still never accepts.
