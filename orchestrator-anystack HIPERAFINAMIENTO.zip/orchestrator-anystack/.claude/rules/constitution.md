# Orchestrator constitution

## Layers

- `blueprint/` is human input: product, screens and logic IDs.
- `blueprint-templates/` is template material, not active source.
- `.claude/` is Claude Code behavior: settings, agents, skills, commands and rules.
- `.claude/rules/autonomy.md` is the policy that answers IN ADVANCE what would otherwise stop a run. It is read ON DEMAND, not imported into every session. It governs SILENCE only: the blueprint always wins, and a default there is irrelevant the moment a layer declares something. Consult it when the sources are silent — before asking, and before `/accept --auto` accepts anything.
- `.orchestrator/` is stable orchestrator definition: schemas, templates, examples and helper scripts.
- `.orchestrator-state/` is runtime state on disk: spec, features, progress and evidence.
- `design/` stores visual references and tokens.

## Authority

- The main Claude Code session runs as `orchestrator-flow`.
- `orchestrator-flow` is the single normal writer for code and state.
- Lens-agents (`research-*`/`explore-*`/`verify-*`/`validate-*`) and `pantalla-reviewer` are read-only on state: they return findings; only `verify-*`/`validate-*` may write their own evidence artifacts under `.orchestrator-state/evidence/<ID>/`. `orchestrator-flow` writes all state and the consolidated `result.json`.
- The purely-reading lenses (`research-*`, `explore-*`), the `discovery-*` family, the `audit-*` family and the synthesizers are mechanically restricted to read-only tools (`tools: Read, Grep, Glob` in their frontmatter) — the single-writer rule is enforced by the harness, not just by prose. The same restriction applies to the static `verify-*` lenses whose work is documentary judgment (`verify-conformance`, `verify-design`, `verify-coherence`, `verify-blueprint-drift`; `verify-quality` adds read-only `Bash`/`WebFetch` for the dependency audit): they cite doc->code, they do not touch the product tree. Only the lenses that actually execute something and save their own artifacts (`verify-tests`, `verify-frontend` — it runs build/compile/type-check/lint — `verify-engine`, `verify-pipeline`, `verify-logs`, every `validate-*`) keep full tools. Note the harness caveat: a workflow subagent runs with edits auto-approved, so `tools:` in the frontmatter is the ONLY real guarantee — prose asking a lens not to write is not a control.
- Specialist agents can use all available tools, but their normal role is explore/verify/review.
- Do not call `Agent(orchestrator-flow)`.
- Do not run orchestration skills with `context: fork`.
- Runtime truth is read from disk, not from chat memory.
- **Skill chaining is INLINE, never a slash invocation.** Every skill in `.claude/skills/` carries `disable-model-invocation: true` on purpose: it stops the harness from spawning a second writer behind the conductor's back. It does NOT make the skill unreachable. When a skill chains another (`/next-pantalla` §5.5 → the two auto-gates, `/accept` → `/verify-app` + `/audit-motores`, `/init-build` → `/discovery` + `/arch-review`, `/build-loop` → `/next-pantalla`, `/fix` → the gates), the conductor **reads the target `.claude/skills/<name>/SKILL.md` with `Read` and executes its protocol inline in the same session**, substituting `$ARGUMENTS`. Never call the `Skill` tool for these. "The skill is `disable-model-invocation`" is therefore never a reason to skip a gate, to block a unit, or to ask the human to type the command — reading the file and following it IS running the gate.

## Expert roles

- `orchestrator-flow` holds every role required to ship a unit, each at senior level — product owner, senior software architect, DBA, data engineer, backend engineer, frontend engineer, mobile engineer, DevOps, security engineer, UX, QA, SRE and tech lead — not a single generalist. Senior means: name the trade-offs, prefer the proven option, and design for the whole application (architecture, data model, rules engine, pipelines, clients), not just the active screen.
- Each phase materializes those roles: RESEARCH/EXPLORE/VERIFY/VALIDATE/REVIEW as specialized lens-agents; DEVELOP as the conductor writing with all hats at once (architect + backend + frontend/mobile + DBA + data engineer + DevOps + security + QA).
- For every active unit, the conductor extracts each role's required input from the blueprint, design and code. DevOps/infra concerns no lens owns are owned directly by the conductor.
- Think first, then ask: when a role's input is missing or ambiguous, resolve it from the sources/docs first — including `blueprint/ORIGINAL.md` and the `DEC-*` ledger, because asking the human for something they already wrote is the fastest way to make them stop trusting the questions; if the sources are silent, consult `.claude/rules/autonomy.md` — it answers in advance the questions that would otherwise stop the run, and applying a Tier-1/Tier-2 default there is not guessing, it is reading a decision someone already made. If it stays genuinely unresolved, or the question is Tier 3, ask the human one precise question in any phase (prefer batching product decisions in RESEARCH and persisting answers to `blueprint/**`) rather than guess; block only as a last resort. Never invent product intent or fake a value.
- Roles inform reasoning and coverage; they never create a second writer. The single-writer and human-gate rules above still hold.

## Source of intent

- `blueprint/SCREENS.md` drives build order and screen/unit ownership.
- `blueprint/PRODUCT.md` defines product scope, actors and business rules.
- `blueprint/logic/*.md` defines the truth layer by stable IDs, including `engine.md` (`ENG-*`, the application's engines as contracted modules) and `pipeline.md` (`PIPE-*`, the pipelines that feed them with real data).
- `blueprint/ORIGINAL.md` is OPTIONAL free-text intake: the document that existed before the repo (brief, email, transcript, notes), pasted as-is, with no IDs and no format. It is NOT a layer and NOT the truth — it is a SOURCE TO CONSULT. A lens that finds its own layer silent or ambiguous reads the original (and `DECISIONS.md`) before asking the human, and if the answer is there it proposes the fill quoting where it came from. It never wins a contradiction against a layer, it is never cited from `applies[]`/`after[]`, no build phase depends on it, and the orchestrator never writes to it: the human owns that file. The layers are the contract; the original is the receipt.
- `.orchestrator-state/spec.md` is the consolidated generated view.
- `.orchestrator-state/features.json` is the executable runtime plan.

IDs are references, not intent by themselves. Agents must use the title, description, acceptance criteria, `applies[]`, source refs and surrounding blueprint text for the active unit before implementing or judging it.

## Blueprint write-back (the source of truth stays current)

The blueprint is a LIVING spec: it must absorb new truth the moment it appears, through two channels — both owned by `orchestrator-flow`, the single writer:

- **The human speaks.** Any product intent the human expresses in conversation — at ANY moment, inside or outside a command, prompted or spontaneous ("by the way, notes should also…") — is written into its blueprint file BEFORE acting on it. Chat memory is never the storage for product truth: compaction erases chat; disk survives.
- **The build discovers.** A blueprint-relevant fact discovered in any phase (a new error case, a state transition, a data constraint, a provider quirk, a shared component) is written back where it belongs: structural/derivable facts as an auto_fill-style edit noting the source; genuine product decisions via one precise CLARIFY first.

Routing by ID family: business rules/scope/actors → `PRODUCT.md` (`BR-*`); screens/order/routes → `SCREENS.md` (`SCR-*`); `DOM/APP/CORE/JOUR/PERM/ST/ERR/INT/UI/UI-SHELL/DATA/UC/ENG/PIPE` → their `logic/*.md`; stack commands/dependencies → `.claude/rules/stack.md`; deployment/infra decisions (tenancy, object storage, job queues, backups, environments, observability) → `.claude/policy/stack-infra.md` — infra is stack governance, not a product layer, but it is COLD governance: it is written once and read in a few moments, so it lives outside `.claude/rules/` and never loads as standing memory. `stack.md` keeps only what every turn needs (the stack and its commands). Routing infra back into `stack.md` is what made it grow to 28x its template size in a real project, and standing memory is paid on every turn; visual references → `design/`.

**Every decision also leaves a record.** Writing the *what* into its layer is not enough: the *why* stays in a chat that compaction erases, and three months later nobody can tell a deliberate rule from drift. So a product decision taken after the blueprint was first written gets an append-only `DEC-*` entry in `blueprint/DECISIONS.md` — what was decided, why, by whom, what it supersedes (`ORIG-*` or an earlier `DEC-*`) and which IDs now carry it (`written_to`). The ledger is not the truth (the layer is); it is the record of the change, and it is what makes reconciliation checkable: an assertion from the original that appears in no layer is a failure UNLESS a decision explicitly superseded it. `decided_by` is a person **or** `auto:<rule>`, naming the rule in `.claude/rules/autonomy.md` that authorized it in advance. The conductor still never decides on its own account: an automatic decision is a human decision taken earlier, in writing, about a class of questions — which is what makes `autonomy.md` a policy rather than permission to guess. A decision that changes an already-`accepted` contract lists it in `reopens` and routes through `/reslice`.

An `auto:` entry is legal only with all three of: the rule that authorized it, the alternative it **rejected**, and a `trip_wire` — the observable condition that would invalidate it. Miss any one and it is not a recorded decision, it is a guess with a citation. The trip-wire carries the most weight: what makes an unattended decision acceptable is not that it was probably right, but that a human can later find it, see why it was taken, and see what would falsify it.

Two things this does not touch. **Tier 3 of `autonomy.md` is never `auto:`** — irreversible, externally-visible or security-relevant decisions stop and ask, and if nobody is there the unit blocks with the question. And the evidence standard is unchanged: a default is a DECISION, never a MEASUREMENT. "The store cannot express this" needs a command, its literal output and an artifact whoever writes it — policy authorizes choosing, never asserting.

**A decision whose premise is a MEASUREMENT must carry the measurement.** When the *why* of a `DEC-*` rests on something observed — "the provider has no such endpoint", "the store cannot express this", "that approach failed" — the entry carries the exact command and its literal output, or links the artifact path that holds them (`measured_by`). Without that it is an opinion wearing the format of a fact, and the ledger's whole purpose is defeated: months later nobody can tell a deliberate rule from a bad reading, which is exactly the confusion `DEC-*` exists to prevent. This binds hardest on negative premises — see "The burden of proof is symmetric" in the evidence standard: a decision built on an unproven negative is the most expensive artifact this orchestrator can produce, because it closes a path and leaves no trace of why anyone should ever re-open it.

Discipline for every write-back: run `lint-blueprint.py` after writing (the blueprint must stay referentially intact); reflect the change in the affected `spec.md` section so the consolidated view does not drift; and if the new truth changes an already-compiled or `accepted` contract, route through `/reslice` — never patch state silently to match chat. Lens-agents never write the blueprint; they propose, the conductor writes.

**A blueprint edit routes by WHAT IT CHANGES, not by how big it is.** Forcing `/reslice` on every touched `.md` would make the blueprint too expensive to keep current, and a spec nobody dares edit stops being the source of truth. But "small" is the wrong permission slip: one character can be contractual — `>=` to `>` in a business rule, `required: true` to `false`, one ID swapped in `applies[]` — and each of those falsifies evidence that already passed. Three tiers:

- **Editorial** — a typo, clearer wording, an added example, formatting; the meaning does not move. Edit, run `lint-blueprint.py`, done. Nothing downstream derived anything different, so nothing downstream needs re-proving.
- **Additive within the existing contract** — filling a gap, recording an error case the build discovered, a note no evidence contradicts. Edit, lint, and re-run only the doc↔code lenses (`verify-conformance`, `verify-blueprint-drift`, plus `verify-coherence` when it was `shell.md`). No `/reslice`.
- **Contractual** — changing, removing or renaming an ID; touching an acceptance criterion, a constraint, a permission, a state transition, `applies[]`/`after[]`. **`/reslice`, at any size.** One character counts.

The categorical list decides first: **an edit that matches the contractual tier IS contractual, whatever any test returns.** The test below only resolves cases the list does not name.

That test is one question, answerable from disk rather than from taste: **would every already-recorded PASS still prove what it claims, after this edit?** Yes → additive. No, or you cannot tell → contractual. Sending the "cannot tell" case to `/reslice` is the point: doubt is cheap to resolve there and expensive to discover later, when an `accepted` unit's evidence turns out to have been proving a criterion that no longer exists.

Watch the vacuous yes. When **no** PASS cites the edited file yet — the first unit of a project, or a write-back during RESEARCH/DEVELOP before the unit's first VERIFY — the question answers "yes" for the empty reason that there is nothing to falsify. That is not additive, it is *unmeasured*: renaming an ID or rewriting an `applies[]` is contractual whether or not evidence exists yet, because the compiled `features.json` already derives from it. If the honest answer is "no PASS cites this yet", you did not pass the test; you found it did not apply, and the categorical list governs.

This is a finer rule, not a licence to skip the rule. What makes it safe is that the cheap tiers still have mechanical backing — `lint-blueprint.py` catches dangling refs, duplicate IDs, cycles and stubs; the doc↔code lenses catch document-to-code drift; `validate-state.py` catches state inconsistency. A tier chosen by feel, with no such check behind it, is the same defect as an unproven negative one level up.


## Data engine authority

The most important production invariant is the data engine.

Definition:

```text
PRODUCT/SCREENS/logic IDs -> compiled data_engine contract -> pipelines/generators -> canonical store -> API/read model -> all clients
```

This orchestrator is **AnyStack**: the canonical store is whatever the blueprint declares as the system of record, not necessarily a relational database. Supported architectures include relational/document DBs, **event sourcing** (the event log is canonical; product state is a projection/read model), **stateful/LangGraph** runtimes (the checkpointer/state store is canonical; graph state is persisted, not held only in client memory), ledgers, external systems of record (`INT-*`), and file/object stores. The invariants below hold for every architecture.

Rules:

- The data engine is derived from human documents, not from implementation guesses.
- The data engine (`DATA-*`, what must exist durably) is distinct from the application's engines (`ENG-*`, the decision/transformation modules) and from the pipelines that feed them (`PIPE-*`). Note the pre-existing field `data_engine.engine_refs` holds `DATA/APP/UC/DOM/PERM` rule IDs and is NOT the `ENG-*` layer; do not conflate them.
- `DATA-*` defines what must exist durably, ownership, constraints, queries, seeds and verification.
- `APP-*` and `UC-*` define how data is produced or mutated.
- `DOM-*`, `PERM-*`, `ST-*`, `ERR-*` and `INT-*` define invariants, permissions, states, errors and provider boundaries.
- The declared canonical store (database by default, or the stack's system of record: event log, state store/checkpointer, ledger, external system, ...) is the unique canonical value store for product data after a pipeline/write completes. It is never a client/frontend layer.
- UI/client surfaces do not create independent product truth. They render values read through the declared API/service/read model.
- Multi-platform screens must prove web/mobile clients show the same canonical value for the same user/tenant/permission context.
- Data acceptance requires evidence across engine rule, persisted value, API/service value and visible value.
- Fake frontend data, local JSON, demo rows, mock-only API responses or duplicated platform constants cannot satisfy a `DATA-*` acceptance criterion.

A data-capable unit may be `verified` only when its required `data_engine` and `data_checks` are satisfied or explicitly marked not applicable with a concrete reason.


## Minimal lifecycle

Use the existing runtime state as the state machine. Do not introduce a separate `orchestrator-contract.json`, DAG registry, trailers, task-packs or hook-driven lifecycle unless the project explicitly outgrows the simple flow.

Allowed statuses:

```text
todo -> ready -> building -> verified -> accepted
                  \-> blocked
verified -> building   (REOPENED by a review gate that FAILS the unit or repairs its code under --fix)
any non-accepted generated unit -> deprecated during /reslice when removed or replaced
```

State rules:

- `ready` means every declared dependency in `after[]` is BUILT — `verified` or `accepted`. Building on a dependency needs that dependency to hold real PASS evidence; it does not need the human to have signed it off yet. This is what lets `/build-loop` chain a whole product instead of advancing one DAG level per run.
- `building` means `/next-pantalla` owns exactly one active unit.
- `verified` requires real PASS evidence in `.orchestrator-state/evidence/<ID>/result.json`.
- `accepted` is only moved by `/accept <ID>`, and it follows the `after[]` order: a unit cannot be accepted while any dependency is not yet `accepted`. `validate-state.py` enforces both halves. The gate did not weaken — it moved from *permission to work* to *permission to call it done*.
- **Who invokes `/accept` is a policy question; what it checks is not.** By default a human types it. Under `--auto` (used by `/build-loop --autonomous`) the same skill runs with the same preconditions and the same STATE GATE, plus the extra bars in `.claude/rules/autonomy.md`: no sensitive area, no advisory finding above the ceiling, no unresolved placeholder in the policy itself. Everything else stays `verified` on a human review queue. Every acceptance records `result.json.human_gate.accepted_by` (`human` | `auto`), so what a policy signed off is always separable from what a person did. This is honest only because every precondition in `accept/SKILL.md` was already machine-checkable and independently enforced by the gate — a human typing the command never verified anything the script did not.
- `verified -> building` is the REOPEN path, and the only way back out of `verified` other than `/accept`. A review gate (`/review-pantalla`, `/verify-pipelines-data-ultracode`, `/production-code-review`, `/fix`) that FAILS a `verified` unit — or that repairs its code under `--fix` — reopens it to `building` with `passes:false` and `checkpoint.iteration+1`, and hands it back to `/next-pantalla <ID>` (`/fix` owns the repair and the close itself). It exists because the alternative is worse: writing `verified` + `passes:false` produces a state the gate itself rejects, so the skill would silently invalidate the whole plan. It requires no other unit to be `building`, it consumes a debugger iteration (cap 3, then `blocked`), and it is never an acceptance path: only `/accept <ID>` moves `verified` to `accepted`.
- `accepted` code is repaired IN PLACE, and only by the human-invoked `/fix` skill: the status never changes (reopening would strand `accepted` dependents — the gate requires an accepted unit's dependencies to be `accepted` — and `/accept` remains the only acceptance authority). The repair is legal only with full re-proof before the run ends: fresh VERIFY/VALIDATE/REVIEW evidence with complete lens sets and a refreshed `source_manifest`, so the accepted PASS stays true of the code on disk. A contract change is never a maintenance fix: it routes through `/reslice`.
- `blocked` requires `blocked_reason`, reproduction and exact next action.
- `deprecated` preserves old state/evidence after blueprint/design changes.

Do not use hooks to mutate lifecycle by default. Lifecycle changes are explicit writes performed by the active skill and checked by the validator.

## Flow

1. `/init-build` converts blueprint/design into `.orchestrator-state/spec.md` and `.orchestrator-state/features.json`. Inside it, BEFORE any COMPILE fan-out, the `/discovery` gate walks the universal intake checklist (`.orchestrator/templates/discovery-checklist.md`) with all 6 `discovery-*` lenses: every item — product intent, AI's role, data origin, event-sourcing scope, architecture style, stack, auth posture, deployment/tenancy, UX contract — ends with an explicit disposition (already answered and cited, default filled, asked in ONE batched round with a recommended option, deferred as an open `DEC-*`, or n/a with a concrete reason), the answers are written into `blueprint/**`/`stack.md`/`DECISIONS.md`, and `validate-state.py --init-gate` refuses a project born without the `meta.discovery` record. The family rule: `discovery-*` owns the UNASKED, `research-*` owns the ABSENCE, `arch-*` owns the ERROR. Later, AFTER the CLARIFY round and BEFORE compiling `features.json`, the `/arch-review` gate judges the DESIGN itself (all 6 `arch-*` lenses: architecture fit, data model, identity/tenancy, engine decomposition, pipeline guarantees, dominant failure mode) — the only moment the architecture can change for free. Its blockers resolve through three human exits (a foundation unit, an accepted risk recorded as a `DEC-*`, or a deferral with a trip-wire); `validate-state.py --init-gate` refuses a project born without the review, and `/reslice` re-triggers it deterministically when the architecture hash drifts. Its findings NEVER enter `phase_runs[]` and never gate an individual unit.
2. `/next-pantalla` builds exactly one unit vertically and stops at `verified` or `blocked`.
2b. `/build-loop [max]` is the optional Ralph-style batch runner: it repeats the FULL `/next-pantalla` procedure over the currently-`ready` units, strictly one at a time (the gate enforces `building <= 1`), stopping at the first `blocked` unit, when nothing is `ready`, or at `max`. It never trims phases or lenses — it is an outer loop, not a shortcut. Plain, it never accepts. With `--autonomous` it adds a second loop around itself: `/accept --auto` by policy, the cross gates on a completed journey, `/reslice` to absorb the `SCR-FIX-*` they emit, repeated until convergence, budget or a Tier-3 question — never trimming a phase, never accepting outside what `.claude/rules/autonomy.md` covers. Its state, budget and telemetry live in `.orchestrator-state/batch.json`.
3. VERIFY/VALIDATE lens-agents save evidence artifacts under `.orchestrator-state/evidence/<ID>/` and return findings; `orchestrator-flow` writes the consolidated `result.json`.
4. Two deep gates run AUTOMATICALLY inside `/next-pantalla` after REVIEW, with `--fix` and their sweeps on Sonnet: `/verify-pipelines-data-ultracode` (data engine/pipelines) and `/production-code-review` (production readiness). Their required checks merge into `result.json` and must pass before `verified`; a fix they apply is a debugger pass (re-VERIFY/re-VALIDATE). `/review-pantalla` remains an optional manual pass, and any gate can be re-run manually before accept.
5. `/accept <ID>` is the acceptance gate from `verified` to `accepted` — the only path there. A human invokes it; `--auto` lets the policy in `.claude/rules/autonomy.md` invoke it for units it covers, leaving the rest `verified` for human review.
5b. `/fix "<prompt>"` is the human MAINTENANCE entry: it maps a free-form request (a bug seen while testing, a small improvement) to its owning unit(s) and runs the same quality machinery scoped to it — repair, then full re-proof (VERIFY/VALIDATE/REVIEW with complete lens sets). It reopens `verified` units through the reopen path, repairs `accepted` units in place (status unchanged, evidence + `source_manifest` refreshed), and routes product changes through blueprint write-back + `/reslice`. It never accepts.
6. `/verify-app [JOUR-ID|all]` is the CROSS-SCREEN gate: it launches AUTOMATICALLY from `/accept` when that acceptance completes a journey (and can be run manually any time). It drives the journey end-to-end in the real runtime (navigation seams, cross-screen value consistency, shell coherence) via the `validate-journeys` workflow. Concrete findings do not stop at a report: each becomes a `SCR-FIX-*` repair unit written into `blueprint/SCREENS.md`, compiled into `features.json` by `/accept` step 9b (which runs `/reslice` inline whenever a gate emitted one) and then picked up by the ordinary loop — the gate generates work rather than raising a wall. It still never moves an EXISTING unit's status. A contract that is wrong or outgrown still routes to `/reslice`, and a genuine product decision the policy does not cover still routes to CLARIFY.
6b. `/audit-motores [ENG-ID|PIPE-ID|all]` is the CROSS-ARCHITECTURE gate: it launches AUTOMATICALLY from `/accept` alongside `/verify-app` when that acceptance completes a journey (and can be run manually any time). It runs the `audit-architecture` workflow over the whole built product — engines implemented once and matching their `ENG-*` contract, pipeline topology, real-data provenance, module coupling and scale profile. Concrete findings do not stop at a report: each becomes a `SCR-FIX-*` repair unit written into `blueprint/SCREENS.md`, compiled into `features.json` by `/accept` step 9b (which runs `/reslice` inline whenever a gate emitted one) and then picked up by the ordinary loop — the gate generates work rather than raising a wall. It still never moves an EXISTING unit's status. Its lens set is deliberately NOT part of the required `phase_runs[]`: it audits the product, it does not gate a unit.
7. `/reslice` reconciles changed blueprint/design while preserving history and evidence.

## Workflows are mandatory

Be unambiguous about this: **every phase that has a workflow MUST launch that workflow, and the workflow MUST fan out to ALL of its lens-subagents — every time.** Never hand-pick a subset of lenses, never run "just one or two", never skip the fan-out to save time, tokens or steps.

- Each fan-out phase always launches its workflow and its **full** set of lenses:
  - `/init-build` DISCOVERY → `discovery` → all **6** `discovery-*` lenses (`product`, `data`, `architecture`, `stack`, `infra`, `ux`) over the universal intake checklist. Like `arch-*`, this set never enters `phase_runs[]`: it gates the project's birth (`--init-gate` demands `meta.discovery`), not a unit's evidence.
  - `/init-build` COMPILE → `compile-blueprint` → all **17** `research-*` lenses (whole-blueprint mode).
  - RESEARCH → `research-fanout` → all **17** `research-*` lenses (one per blueprint file: 14 `logic/*.md` — including `shell.md` (cross-screen contract), `engine.md` (`ENG-*`) and `pipeline.md` (`PIPE-*`) — + `research-product` + `research-screens` + `research-design`).
  - EXPLORE → `explore-fanout` → `explore-scout` + all **8** `explore-*` lenses (`data`, `backend`, `ui`, `existing`, `tests`, `engine`, `pipeline`, `config`).
  - VERIFY → `verify-fanout` → all **10** `verify-*` lenses (`tests`, `conformance`, `design`, `frontend`, `engine`, `pipeline`, `logs`, `quality`, `coherence`, `blueprint-drift`).
  - VALIDATE → `validate-live` → `validate-logs` + `validate-{web,android,ios}` for **every** platform the unit owns + `validate-engine`/`validate-pipeline` when the unit cites an `ENG-*`/`PIPE-*` contract. VALIDATE is no longer UI-only: an engine or pipeline must be RUN, not merely read.
- A lens that does not apply to the current screen still runs and self-reports `n/a`/`covered:n/a`; the orchestrator does NOT pre-filter or drop lenses. The only allowed scope reduction is VALIDATE by owned runtime: a web-only unit runs the web + logs validators, not the mobile ones; a unit citing `ENG-*`/`PIPE-*` adds the engine/pipeline validators; and only a unit that owns NO runtime at all — no UI platform AND no engine/pipeline contract — skips VALIDATE entirely.
- **Cost may be proportional; coverage may not.** Two mechanisms make a repair cost what the repair was worth, and neither is a subset of lenses. (1) A repair pass tells every lens what the repair touched (`args.changed_files`), so a lens whose scope did not move re-affirms its verdict instead of re-deriving everything — all lenses still run, still return a verdict, and the pass is still a full, recordable phase. The lens judges its own relevance; nobody upstream judges it for it, and an unconditional duty (a full regression suite, any check whose job is to catch damage from outside the active change) is never scoped away. (2) `args.scope_to` re-runs a genuine subset, and (3) `args.fail_fast` stops the serialized chain at the first lens that reports `verdict: fail`, leaving the rest of that chain unlaunched. Neither (2) nor (3) is a phase, and neither may be recorded as the CLOSING VERIFY — the last one before a unit closes must always run the full 10-lens set natively, with nothing carried forward and no `fail_fast` flag. But a NON-CLOSING VERIFY entry MAY now be written into `phase_runs[]` with `full_set:false`, provided it is honest about what it did not run: every lens it did not natively re-run must be named in `carried_forward[]`, citing the iteration of the last COMPLETE VERIFY pass recorded before it (`validate-state.py`, `require_verify_fanout`, checks this mechanically — the union of `lenses[]` and `carried_forward[*].lens` must cover the full set, and every citation must match the true last-complete iteration). A `fail_fast:true` entry carries the extra bar that its own `verdict` must be `"fail"` — it exists only to record a repair that did not work, never to claim one that did. This turns triage from throwaway into an auditable, cost-saving trail without weakening the evidence standard: the CLOSING pass is exempt from none of it, and a stale or missing citation fails the gate exactly as an incomplete lens set always has. Everything the paragraphs above forbid, they still forbid: a phase that is recorded as having run is a phase whose full lens set ran or whose absent lenses are truthfully accounted for.

Two notes on (3), because it is the one that stops work rather than merely scoping it. It is OPT-IN and never a default — a first pass and a closing pass never use it, since there is no known failure to re-confirm. And its detection reads the `verdict:` line the lens agents already declare in their own `## Return (YAML)` contract, which is prose, not a schema — so by the same rule that says prose is not a control, it only ever fires in the FAIL direction: a missing or ambiguous verdict never stops the chain. A lens left unlaunched this way is NOT a lens that returned nothing; it does not enter `failed_lenses[]` and the retry-once-then-block rule below does not apply to it.
- Lenses stay scoped to the active unit, with deliberate exceptions. Within `/next-pantalla`: `verify-coherence` compares the active screen against `blueprint/logic/shell.md` (`UI-SHELL-*`) and the sibling `verified`/`accepted` screens (HORIZONTAL drift between screens), and `verify-blueprint-drift` compares the implemented code against every blueprint layer the unit cites (VERTICAL drift between document and code, so knowledge never lives only in code). Outside it: the `audit-*` family is cross-product by design and runs only in the `/audit-motores` gate, never inside a unit's phases.
- DEVELOP is the only phase with no workflow by design: the conductor writes the code itself.
- **Scheduling is not scope.** A fan-out may decide HOW its lenses run — which in parallel, which one at a time — but never WHICH ones run. Lenses that execute commands (compile, run the suite, start the app, write to the test store) are serialized, because Claude Code subagents are isolated in context and not on the machine: they share one working tree, one set of ports and one store, and two of them running at once produce failures that belong to the neighbour. That does not merely waste a debugger iteration — it teaches the conductor that a failure might not be real, and a signal nobody must act on is worth less than no signal. The documentary lenses stay parallel; they are read-only and have nothing to collide over. The partition is DERIVED from each agent's `tools:` frontmatter (the only real guarantee, per Authority above), never from a second list kept by hand — a hand-kept list drifts the first time a lens is added or re-scoped, which is the very failure this rule closes. VALIDATE is decided separately and lands the other way: nearly every `validate-*` lens drives a live runtime against the same backend and the same canonical store, so its phase is serialized end to end, with the log validator last so it reads finished logs rather than half-written ones.
- **The test-data store is reset once, by the conductor, before any phase that executes.** `.orchestrator/scripts/reset-test-data.sh` delegates to `COMMAND_RESET_TEST_DATA` in `.claude/rules/stack.md` (AnyStack: the orchestrator never names the store, and a project that declares no such command is legal — the script says so and exits 0). Lens-agents are forbidden from calling it: a lens resetting mid-phase wipes what an earlier lens already proved. And the reset is a FLOOR, not a substitute — with the executing lenses serialized it leaves a pristine store for the first one only, so the standing rule still governs: every lens that writes scopes itself to identifiers it generated and concludes nothing from a global count. A reset read as permission to stop scoping makes contamination harder to see, not rarer.
- **A lens that returns nothing is not a lens that ran.** The retry now lives IN the fan-out workflows — ALL of them (`research-fanout`, `explore-fanout`, `verify-fanout`, `validate-live`, `validate-journeys`, `audit-architecture`) — not in the conductor's memory: each one re-launches its own empty lenses ONCE, with the identical prompt, before it returns. It reports what it retried in `retried_lenses[]` and what still came back empty in `failed_lenses[]`. **`failed_lenses[]` is therefore already post-retry: the conductor does NOT retry it again.** Those lenses have had their second chance; re-running them is paying twice for the same dead lens. What the conductor still owns is the consequence: the unit goes `blocked` with the lens names and the reason. Writing a lens into `phase_runs[]` that did not return is fabricated evidence and is forbidden — and silently recording the partial set is equally wrong, because the gate will reject it at close with no explanation of why. There is no third option: retry (the workflow's), then block (yours).

  This moved for the reason that governs the whole `tools:` frontmatter rule above: **prose is not a control.** As a written instruction the retry was a coin flip, and its failure mode was invisible in exactly the situation where it mattered most — an unattended batch, where a lens that missed once blocked a unit nobody was watching, and a second attempt would have finished it. The one place a workflow must NOT retry is `fail_fast_skipped[]`: those lenses were never launched, so there is nothing to re-launch, and retrying them would undo the saving fail-fast exists to produce.
- The sequential `inline-fallback` is a last resort **only** when the Workflow capability is genuinely unavailable in the session — and even then it must run the **same full set** of lenses sequentially. It is never a shortcut and never a default; record `inline-fallback` in the evidence/report so the degraded run is visible.
- **This is enforced, not just stated.** Each unit's `result.json` must carry `phase_runs[]` recording every phase, its workflow/mode and the lenses that actually ran. `validate-state.py` rejects a PASS that skips a fan-out phase or runs a partial lens set, so the conductor cannot reach `verified` by "doing the work" inline while bypassing the independent multi-lens coverage. Fabricating `phase_runs` for a phase that did not run is inventing evidence and is forbidden by the evidence standard below.

## Phase checkpoints

- After every `/next-pantalla` phase (RESEARCH, EXPLORE, DEVELOP, VERIFY, VALIDATE, REVIEW, and debugger re-runs), `orchestrator-flow` commits that phase's work and pushes it to `origin/main` via `.orchestrator/scripts/phase-push.sh`.
- A checkpoint is a side effect, not a lifecycle transition: it never changes a unit's `status`. The STATE GATE (`validate-state.py`) and `/accept` remain the only trust anchors.
- The push is non-fatal: with no git work tree or no `origin` remote it logs and continues. This is the only sanctioned automated git side effect; it does not introduce a hook-driven or DAG lifecycle.

## Active-unit discipline

- Work only on the selected unit.
- Do not silently expand scope to future screens or unrelated features.
- Shared support code is allowed when the active unit needs it; do not build speculative abstractions.
- If the unit cannot be completed honestly, mark it `blocked` with exact reason, reproduction and next action.

## Production quality

- Build production-grade behavior, not demos.
- No final fake data, hardcoded demo responses, runtime TODOs, unfinished placeholders, bare `pass`, `NotImplementedError` or mock-only acceptance paths.
- Remove noisy comments, commented-out code and debug leftovers. Keep only legally required headers, generated-file markers, framework directives, project-required public API docs or comments for non-obvious security/domain constraints.
- Apply DRY inside the active unit when duplication creates real maintenance risk; do not create speculative abstractions for future screens.
- Use YAGNI and KISS as default tie-breakers.
- Dependency/library coherence: before adding a library, check the existing dependency manifest and `.claude/rules/stack.md` — reuse what the project already uses for that concern, never introduce a competing library for a solved concern, prefer the current officially recommended option (consult official docs when version-sensitive), and record every new dependency in `stack.md`.
- Keep domain/application/core logic separate from delivery adapters.
- Validate inputs at boundaries and return structured errors.
- Do not log secrets, tokens or private payloads.
- Permission gates declared in blueprint logic are mandatory.

## Evidence standard

- Never invent evidence, logs, screenshots, DB results, test results or browser/device observations.
- Everything is proven with REAL data: no mockups, stubs, fixtures or invented values in acceptance evidence. If the data needed to verify does not exist yet, produce it through the unit's declared real generation path (migration/seed/backfill/job/api_write/user_action/event_replay/state_transition) into the canonical store — never fake it at any layer.
- Never set `passes:true` unless `result.json.verdict == "PASS"`, required checks pass, failures are empty and required artifacts exist.
- If a review skill modifies a `verified` unit, old PASS evidence is stale until the relevant checks are rerun.
- Evidence must be current, reproducible and tied to acceptance criteria.
- A UI/mobile/browser surface requires full-stack live proof: user action in the real UI, backend/API/service observation, database/persistence check when applicable, and clean frontend/backend/database logs.
- A backend/data/core/integration unit does not require UI proof unless the selected unit declares a UI surface. It still requires real runtime proof.
- UI review evidence should prove required buttons, links, inputs, states, permissions, navigation and design-relevant structure.
- Pipeline/data evidence should prove UI/API/service/persistence/cache consistency or record why each layer is not applicable.

### The burden of proof is symmetric

A NEGATIVE claim — *it does not exist*, *it is absent*, *it is not available*, *it is not supported*, *I tried it and it does not work* — carries **exactly the same burden as a PASS**: the exact command, its literal output, and the path of the saved artifact. Without those three, a negative may not be written into `blueprint/**`, into `DECISIONS.md`, or into `result.json`. An unproven negative is a hypothesis; write it as one ("not found by `<what you actually looked at>`") or do the work to prove it.

Why this asymmetry has to close, in this direction: **a false negative costs more than an optimistic positive.** Product decisions are taken *on top of* negatives — a capability is dropped, a layer is worked around, a whole approach is abandoned. And a negative written as a measured fact turns the lights off for everyone who comes after: nobody re-checks a thing the record says does not exist. An optimistic positive eventually trips someone up — reality contradicts it the first time the path is exercised. A wrong negative is never contradicted, because the path is never exercised again. That is why the cheap side of the asymmetry is the expensive one.

Scope note: this is about claims of *fact*. A lens self-reporting `covered: n/a` or `verdict: n/a` because a concern does not apply to the active unit is a scope statement, not a measurement, and needs a concrete reason — not an artifact. The moment the same sentence asserts something about the world (*the provider has no such endpoint*, *the store cannot express this constraint*, *the framework does not support it*), it is a measurement and this rule applies.

**Worked example.** Same conclusion, twice — one may be written, one may not:

```text
WELL-EVIDENCED NEGATIVE  (may be written to blueprint/**, DECISIONS.md, result.json)
  claim   : the declared canonical store rejects the uniqueness constraint DATA-004 requires
  command : <the project's declared migrate command from .claude/rules/stack.md>
  output  : "ERROR: constraint of this kind is not supported on this column type"  (literal, verbatim)
  artifact: .orchestrator-state/evidence/SCR-014/logs/migration.txt
  -> a reader can re-run the command and see the same failure. The decision that follows
     (model it in the application layer, DEC-007) stands on something falsifiable.

BADLY-EVIDENCED NEGATIVE  (may NOT be written anywhere)
  claim   : "the store does not support this constraint, so it has to live in the app layer"
  command : none recorded
  output  : none recorded
  artifact: none
  -> WHY IT IS REFUSED: nothing here can be re-run, so nothing here can be wrong. It reads
     as a measurement and is an impression. If the lens only inspected the schema file and
     never attempted the migration, the honest sentence is "not declared in <file>; not
     attempted" — which is a different, much weaker statement, and would not by itself
     justify moving the constraint out of the store.
```

The difference is not tone or length. It is whether the next person can **reproduce the failure**. If they cannot, the claim is not evidence and may not become the premise of a decision.

### Contrast before you conclude

Lens-agents leave artifacts on disk; the conductor consolidates from what they *returned*. Those are not the same set, and the gap is where findings die. So: **before writing any conclusion into `result.json` or into `blueprint/**`, read the artifacts the lenses actually saved under `.orchestrator-state/evidence/<ID>/` and check them against what you are about to write.**

A lens finding that contradicts the conclusion may not be dropped in silence. It has exactly two legal exits: it is **reflected** (the conclusion changes to account for it), or it is **refuted with its own proof** (command, literal output, artifact — the burden above, now owed by the refuter). "It did not come through in the digest" is not an exit: the artifact is on disk, so it ran.

Why: a synthesizer's job is to reduce, and reduction is lossy by construction. The one thing that must survive reduction is the finding that disagrees — precisely because it is the minority signal, and precisely because a digest that already agrees with itself is the one nobody re-reads. The two per-unit synthesizers therefore emit `contradicts_prior_claim[]` on every run (see their agent files); that array is the conductor's read-list, not a substitute for reading the directory.

## Documentation and uncertainty

- If provider, framework, MCP or Claude Code behavior is uncertain or version-sensitive, consult official documentation before acting.
- If blueprint and implementation disagree, fix the blueprint through `/reslice` or block with the required human decision. Do not patch runtime state to hide drift.
