# CLAUDE.md - orchestrator-anystack

This repository uses a blueprint-driven Claude Code orchestrator to build one screen/unit at a time with real verification and an acceptance gate — pressed by a human, or by a written policy (`.claude/rules/autonomy.md`) for the units that policy covers.

The detailed governance lives in the rules files and is imported here so it loads as project memory. These are the single source of truth — do not restate them in this file:

@.claude/rules/constitution.md
@.claude/rules/conventions.md
@.claude/rules/stack.md

There is a fourth rules file, `.claude/rules/autonomy.md`, deliberately NOT imported here: it is the policy that pre-answers what would otherwise stop a run — product defaults (`AUTO-*`), the tier that says what may be decided without asking, the arch-review risk ceiling, the auto-accept policy and the autonomous-run budget. **Read it on demand**, in the two places that consult it: *Think first, then ask* when the sources are silent, and `/accept --auto` before it accepts anything. **It is not out of context, and saying so would be false**: Claude Code loads every `.claude/rules/*.md` at session start whether or not `CLAUDE.md` imports it, so this file is standing memory like the other three. What the explicit `Read` buys is not tokens but PRECISION: it puts the policy in front of the conductor at the exact moment a decision is being taken, instead of leaving it as background it may or may not weigh. Consult it in the two places named above.

## Main conductor

The main Claude Code thread runs as `orchestrator-flow` through `.claude/settings.json`. Do not call `Agent(orchestrator-flow)`; use `Agent(...)` only for specialist agents, which explore, verify and review but are not the normal owners of code changes or state transitions.

## Runtime truth

Read disk first. Do not rely on chat memory.

- Work plan: `.orchestrator-state/features.json`
- Consolidated spec: `.orchestrator-state/spec.md`
- Handoff log: `.orchestrator-state/progress.md`
- Evidence: `.orchestrator-state/evidence/<ID>/result.json`

IDs alone are not enough product intent. For every active unit, read its title, description, acceptance criteria, `applies[]`, source references, routes, platform, verification plan and the relevant blueprint sections.

Blueprint write-back: the blueprint is a living spec. Any product intent the human expresses in conversation (at any moment) and any blueprint-relevant fact the build discovers is written into the corresponding `blueprint/**` file before acting on it — then `lint-blueprint.py`, reflect it in `spec.md`, and `/reslice` when it changes a compiled/accepted contract. Chat is never the storage for product truth.

## Commands

- `/init-build`: create initial orchestrator state from blueprint/design. It may ask CLARIFY questions. It does not build product screens.
- `/discovery [--report-only]`: t=0 universal intake gate — walk the discovery checklist (product, AI role, data origin, event-sourcing scope, architecture, stack, auth, deployment/tenancy, UX) over the blueprint with 6 `discovery-*` lenses; every item ends answered/filled/asked/deferred/n-a and the answers land in `blueprint/**`/`stack.md`/`DECISIONS.md`. Runs automatically inside `/init-build` BEFORE COMPILE (`--init-gate` requires its `meta.discovery` record); manual re-runs allowed. Never touches `phase_runs[]` or any unit status.
- `/next-pantalla [ID]`: build and verify exactly one unit vertically. It writes code and stops at `verified` or `blocked`.
- `/build-loop [max] [--autonomous]`: Ralph-style batch runner — runs the full `/next-pantalla` pipeline for every currently-ready unit, one at a time, stopping at the first `blocked` or when nothing is ready. Never accepts. `--autonomous` adds the outer loop: auto-accept by `.claude/rules/autonomy.md`, run the cross gates, absorb the `SCR-FIX-*` they emit via `/reslice`, repeat until convergence, budget or a Tier-3 question. State and telemetry in `.orchestrator-state/batch.json`.
- `/accept <ID> [--auto]`: the acceptance gate from `verified` to `accepted` — the only path there. A human invokes it; `--auto` lets `.claude/rules/autonomy.md` invoke it for units the policy covers (never a sensitive area), leaving the rest `verified` on a review queue. Records `accepted_by` either way.
- `/status`: read-only state summary.
- `/reslice [reason]`: reconcile changed blueprint/design while preserving history.
- `/fix "<prompt>" [--report-only]`: prompt-driven maintenance — map a free-form request (a bug seen while testing, a small improvement) to its owning unit(s), repair and fully re-prove (VERIFY/VALIDATE/REVIEW). Reopens `verified` units; repairs `accepted` units in place with refreshed evidence; routes product changes through blueprint write-back + `/reslice`. Never accepts.
- `/review-pantalla <ID|slug|name>`: review/repair live UI parity, required buttons/controls, states and design fidelity for one screen.
- `/verify-pipelines-data-ultracode <ID|slug|name>`: verify and safely correct data pipelines, API/backend/data consistency and logs for one screen. Runs automatically inside `/next-pantalla` after REVIEW (with `--fix`, sweeps on Sonnet); manual re-runs allowed.
- `/production-code-review [ID|slug|name|path|all]`: review/repair scoped code for production readiness, DRY, YAGNI and KISS. Runs automatically inside `/next-pantalla` after REVIEW (with `--fix`, sweeps on Sonnet); manual re-runs allowed.
- `/arch-review [--report-only]`: t=0 architecture gate — judge the DESIGN before anything is built (architecture fit, data model, identity/tenancy, engine decomposition, pipeline guarantees, dominant failure mode). Runs automatically inside `/init-build` before `features.json` is compiled and re-triggers from `/reslice` on architecture-hash drift; blockers resolve into foundation units, accepted risks (`DEC-*`) or deferrals with a trip-wire. Never touches `phase_runs[]` or any unit status.
- `/audit-motores [ENG-ID|PIPE-ID|all]`: cross-architecture gate — audit the whole built product statically (each `ENG-*` implemented once and matching its contract, pipeline topology, real-data provenance, module coupling, scale profile). Launches automatically from `/accept` alongside `/verify-app` when an acceptance completes a journey. Architecture debt becomes a `SCR-FIX-AUDIT-*` repair unit that `/accept` step 9b compiles into the plan and the loop then picks up; it never changes an existing unit's status.
- `/verify-app [JOUR-ID|all]`: cross-screen gate — drive the completed journeys end-to-end across accepted screens in the real runtime (navigation seams, cross-screen value consistency, shell coherence). Launches automatically from `/accept` when it completes a journey. Concrete seam defects become `SCR-FIX-VERIFY-APP-*` repair units that `/accept` step 9b compiles into the plan and the loop then picks up; it never changes an existing unit's status.

## Basic scripts

```bash
bash .orchestrator/scripts/reset-state.sh --force
python3 .orchestrator/scripts/validate-state.py             # STATE GATE (--emit-status also writes status.json + evidence/index.json)
python3 .orchestrator/scripts/lint-blueprint.py             # deterministic blueprint lint: dup IDs, dangling refs, cycles, stubs
python3 .orchestrator/scripts/original-coverage.py          # reconcile ORIGINAL.md vs layers (--extract first); unclaimed claims feed CLARIFY, never blocks
bash .orchestrator/scripts/validate-structure.sh            # scaffold structure + lens-set sync (.js workflows vs validate-state.py)
bash .orchestrator/scripts/reset-test-data.sh "<PHASE>"     # reset the test-data store via stack.md's COMMAND_RESET_TEST_DATA. CONDUCTOR ONLY, once, BEFORE any phase that executes the suite (VERIFY/VALIDATE + debugger re-runs). Lenses must never call it: a reset mid-phase wipes what an earlier lens already proved. Non-fatal.
bash .orchestrator/scripts/phase-push.sh "<PHASE>" "<ID>"   # commit + push origin/main after each /next-pantalla phase
bash .orchestrator/scripts/smoke-golden-path.sh             # end-to-end smoke of the deterministic machinery (golden-path example)
```

## Compact instructions

After compaction, preserve: active screen ID, title, acceptance criteria, cited `applies[]`, current status in `features.json`, evidence path, failing checks, environment state and the exact next action. The disk anchor is the active screen's `checkpoint` field in `features.json` (`{phase, iteration}`, maintained by `/next-pantalla`): re-read it plus `result.json.phase_runs[]` and resume from that phase instead of restarting the unit.

There is a SECOND anchor, one level up: `.orchestrator-state/batch.json` holds `/build-loop`'s own state (its cap, the units already built, why it stopped). Re-read it before continuing a batch — the unit was always resumable, the loop around it was not. The `PreCompact` hook prints both anchors from disk immediately before this summary is produced.

Anything the human said with product intent that is not yet written into `blueprint/**` does not survive this step. Write it before acting on it, not after — that is the point of the write-back rule, and compaction is when it gets tested.
