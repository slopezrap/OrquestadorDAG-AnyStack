#!/usr/bin/env python3
"""Ask the STATE GATE, in advance and without effects, what it would reject if you closed now.

    python3 .orchestrator/scripts/rehearse-close.py [ID]

WHY THIS EXISTS.

The conductor discovers what the gate refuses at the worst possible moment: the instant it tries to
finish. Everything before that point runs a gate that CANNOT see the closing conditions — and that
is not a metaphor, it is this loop in `validate-state.py`:

    for screen in screens:
        if screen["status"] in PASS_STATUSES:      # <- verified / accepted
            result = validate_result(..., require_artifacts=True, screen=screen)

Every closing-only check — artifacts exist and are non-empty, `source_manifest` still hashes, the
acceptance and `applies[]` coverage, the two §5.5 `CHK-*`, the complete `phase_runs[]` — lives
behind that condition. A unit in `building` never reaches it. So `next-pantalla` §7's own
precondition ("`validate-state.py` passes"), run BEFORE the status flip, is green on a unit that
the same gate will reject one line later. This script closes that blind spot by asking the
question the only way it can be truthfully asked: **flip the status on a disposable copy and run
the real gate against it.**

HOW IT STAYS HONEST, and both halves matter:

  * It runs `validate-state.py` COMPLETELY UNMODIFIED, as a subprocess, with the working directory
    pointed at the copy. That file resolves everything from `ROOT = Path.cwd()`, so a different cwd
    is all it takes. Nothing here re-implements a single check — which is the repo's own rule: "a
    script that merely REPEATS a check the gate already makes, earlier, is not that, it is more
    surface for the same coverage." A rehearsal made of copied checks would drift from the gate and
    then lie in the safe-looking direction.
  * It is a STRICT SUBSET by construction. It cannot reject anything the real close would accept,
    because it IS the real close, run on the same bytes with the one field flipped that closing
    flips. A rehearsal that cries wolf gets ignored, and then it is ignored on the day it was right.

WHAT IT WRITES: nothing, anywhere, ever. The flip is applied inside a temporary directory that is
deleted on exit. The live tree is only read. (A plain `validate-state.py` run is already
side-effect free — only `--emit-status` writes — so the copy exists to construct a HYPOTHESIS,
not because the gate is unsafe to run.)

WHAT IT IS NOT: not evidence, not a phase, not a gate. It never enters `phase_runs[]`, `checks[]`
or `advisory_findings[]`, nothing reads its exit code, and it is deliberately NOT wired into
`.claude/hooks/validate-state.sh` or any fan-out. **Do not wire it into anything automatic.** The
write it previews is already enforced twice — by §7's own final gate run and by the PostToolUse
hook on the very next edit — so a third enforcement point would buy nothing and cost the one
property that makes a rehearsal useful: that asking is free and answering is honest.

DISCLOSED FIDELITY GAP, because a preview whose blind spot is undocumented gets trusted past it:
the sandbox symlinks every top-level entry except `.orchestrator-state`. `advise_standing_memory()`
resolves `CLAUDE.md` and `.claude/rules/**` to detect double-loaded memory, and through a symlink
it can under-report. It feeds `warn()` only and can never flip a verdict, so the prediction stands;
it is named here rather than papered over.

EXIT CONTRACT — the house 0/1/2 of `preflight-check.sh` and `adversary-check.py`, with one
difference stated plainly: those two STOP a flow, this one only answers a question.
  0  the gate would accept this unit as `verified` right now
  1  the gate would REJECT it — its own message is printed verbatim, with the reproduction
  2  not applicable, or the rehearsal could not run (see the silence rule below)
"""
from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parent.parent.parent
STATE = ROOT / ".orchestrator-state"
FEATURES = STATE / "features.json"
GATE = ROOT / ".orchestrator" / "scripts" / "validate-state.py"


def say(msg: str) -> None:
    print(f"rehearse-close: {msg}", file=sys.stderr)


def out(msg: str) -> None:
    print(f"rehearse-close: {msg}")


def not_applicable(msg: str) -> None:
    """Exit 2, kept distinct from exit 1 on purpose: "too early to ask" must never be
    confused with "would fail". They lead to opposite actions."""
    say(msg)
    raise SystemExit(2)


def load_unit(explicit_id: str | None) -> tuple[dict[str, Any], dict[str, Any]]:
    if not FEATURES.is_file():
        not_applicable(f"{FEATURES.relative_to(ROOT)} not found; there is no plan to rehearse.")
    try:
        data = json.loads(FEATURES.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, UnicodeDecodeError, OSError) as exc:
        not_applicable(f"{FEATURES.relative_to(ROOT)} could not be read ({exc}).")
    screens = data.get("screens") if isinstance(data, dict) else None
    if not isinstance(screens, list) or not screens:
        not_applicable("features.json carries no screens[]; nothing to rehearse.")
    if explicit_id:
        hits = [s for s in screens if isinstance(s, dict) and s.get("id") == explicit_id]
        if len(hits) != 1:
            not_applicable(f"{len(hits)} screens match id {explicit_id!r}; expected exactly one.")
        return data, hits[0]
    building = [s for s in screens if isinstance(s, dict) and s.get("status") == "building"]
    if len(building) != 1:
        not_applicable(f"{len(building)} screens are in status 'building' "
                       f"({[s.get('id') for s in building]}); pass the id explicitly: "
                       f"python3 .orchestrator/scripts/rehearse-close.py <ID>")
    return data, building[0]


# ---------------------------------------------------------------------------------------------
# THE SILENCE RULE. This is what decides whether the tool survives contact with a real build.
#
# A unit mid-build fails most closing conditions LEGITIMATELY: its evidence skeleton starts as FAIL
# with an empty checks[], no artifacts and no manifest, and phase_runs[] fills in one phase at a
# time. Reporting all of that on demand at iteration 0 is noise, and noise is what gets a control
# deleted. So the rehearsal declines to answer until the unit is far enough along that an unmet
# closing condition means something.
#
# The discriminator is `source_manifest`, and it is not a heuristic — it is the procedure's own
# ordering. §7 has the conductor refresh the manifest AFTER the last edit the unit will receive
# ("VERIFY -> consolidate -> refresh the manifest -> run the gate, with no code touched in
# between"). Its presence therefore means exactly one thing: the conductor believes it is done.
# Before that point every rejection is correctly-in-progress; after it, every rejection is real.
#
# A "has at least one passed check" heuristic was tried and falsified against staged fixtures of a
# real unit: it still answers at stages where the unmet conditions are simply not-yet-done.
# ---------------------------------------------------------------------------------------------
def check_ready(unit: dict[str, Any]) -> None:
    sid = unit.get("id")
    status = unit.get("status")
    if status != "building":
        not_applicable(f"{sid} is {status!r}, not 'building'. A rehearsal previews the close of a "
                       f"unit in flight; a unit already verified or accepted has closed, and one "
                       f"that is todo/ready/blocked has not started.")
    ev = STATE / "evidence" / str(sid) / "result.json"
    if not ev.is_file():
        not_applicable(f"{sid} has no {ev.relative_to(ROOT)} yet — the evidence skeleton is written "
                       f"in DEVELOP (§4). Too early to ask.")
    try:
        result = json.loads(ev.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, UnicodeDecodeError, OSError) as exc:
        not_applicable(f"{ev.relative_to(ROOT)} could not be read ({exc}).")
    # A REOPEN leaves the PRIOR close's manifest in place. constitution.md's reopen write-recipe
    # writes status/passes/checkpoint and appends a failing check — it does not touch
    # `source_manifest`, `checks[]` or `phase_runs[]`. So the instant a unit is reopened, before a
    # single repair edit, the manifest test above is already satisfied by leftover state from an
    # episode that closed once, and the rehearsal would speak: it would report "verdict is not
    # PASS", which is the most correctly-in-progress thing a reopened unit can be. That is the
    # cry-wolf failure this rule exists to prevent, reproduced by the rule itself.
    #
    # The verdict is the missing half. §7 consolidates a PASS and only THEN refreshes the manifest,
    # so requiring both is not a second heuristic — it is the same ordering read from both ends.
    # (The discarded "at least one passed check" alternative fails here too: a reopen leaves the
    # prior passed checks untouched as well.)
    if str(result.get("verdict", "")).strip().upper() != "PASS":
        not_applicable(
            f"{sid}'s evidence still reads verdict {result.get('verdict')!r}, not PASS. Every "
            f"closing condition it fails right now is correctly-in-progress — most of all after a "
            f"REOPEN, which leaves the previous episode's manifest and checks in place while the "
            f"repair has not even started. Consolidate a PASS first; that is when this answer "
            f"starts being about the close instead of about the repair you are in the middle of.")
    manifest = result.get("source_manifest") if isinstance(result, dict) else None
    if not manifest:
        not_applicable(
            f"{sid} has no `source_manifest` in its result.json yet. §7 has you refresh it AFTER "
            f"the last edit this unit will receive, so its absence means the unit is still in "
            f"flight and every closing condition it fails is correctly-in-progress, not a defect. "
            f"Ask again once the manifest is written — that is the moment this answer becomes "
            f"worth having.")


def build_sandbox(tmp: Path, data: dict[str, Any], unit_id: str) -> None:
    """A disposable tree that IS this repo, with `.orchestrator-state` copied so it can be doctored.

    Everything else is symlinked: the product files `source_manifest` hashes, `.claude`, the
    blueprint. They are only read, and symlinking keeps this cheap on a real product tree where a
    deep copy would mean node_modules.
    """
    for entry in ROOT.iterdir():
        if entry.name in {".git", "__pycache__"}:
            continue
        if entry.name != ".orchestrator-state":
            os.symlink(entry, tmp / entry.name)
            continue
        # Only `features.json` has to be a real, writable file — it is the one the flip rewrites.
        # Everything else under .orchestrator-state is symlinked like the rest of the tree, because
        # the gate only READS it. Deep-copying the whole thing would scale the cost of a rehearsal
        # with the size of the evidence tree, and evidence grows with every unit a project ships:
        # the tool would get slower exactly as the project it serves gets bigger.
        state_dir = tmp / entry.name
        state_dir.mkdir()
        for child in entry.iterdir():
            if child.name != "features.json":
                os.symlink(child, state_dir / child.name)

    # THE §7 FLIP, and nothing else. Exactly the three fields the procedure writes at close:
    # status, passes, and a cleared checkpoint.
    doctored = json.loads(json.dumps(data))
    for screen in doctored.get("screens", []):
        if isinstance(screen, dict) and screen.get("id") == unit_id:
            screen["status"] = "verified"
            screen["passes"] = True
            screen.pop("checkpoint", None)

    # ...plus the mechanical consequence of that flip, which the plan for this script missed and
    # the gate enforces with a hard fail(): `summary.<status>` must match the real counts
    # (validate-state.py, "summary.{status} mismatch"). Leaving it stale would make the rehearsal
    # report a summary arithmetic error that has nothing to do with whether the unit can close —
    # a false positive on its very first run, which is how a control earns its reputation.
    summary = doctored.get("summary")
    if isinstance(summary, dict):
        counts: dict[str, int] = {}
        for screen in doctored.get("screens", []):
            if isinstance(screen, dict):
                st = screen.get("status")
                counts[st] = counts.get(st, 0) + 1
        for key in list(summary):
            if key == "total":
                summary[key] = len(doctored.get("screens", []))
            elif isinstance(summary[key], int):
                summary[key] = counts.get(key, 0)

    (tmp / ".orchestrator-state" / "features.json").write_text(
        json.dumps(doctored, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def main() -> None:
    argv = sys.argv[1:]
    explicit_id = argv[0] if argv else None
    if not GATE.is_file():
        not_applicable(f"{GATE.relative_to(ROOT)} is missing; there is no gate to rehearse.")

    data, unit = load_unit(explicit_id)
    sid = str(unit.get("id"))
    check_ready(unit)

    # mkdtemp INSIDE the guarded block: a failure to create the sandbox is a "could not run" (2),
    # not a traceback. And the cleanup is a `finally`, not a per-branch call — the realistic case is
    # a Ctrl-C during the subprocess (which can take up to 300s), and a KeyboardInterrupt through a
    # per-branch cleanup leaves a populated copy of .orchestrator-state on disk, contradicting the
    # one promise this file makes in bold: it writes nothing, anywhere, ever.
    tmp: Path | None = None
    try:
        tmp = Path(tempfile.mkdtemp(prefix="rehearse-close-"))
        build_sandbox(tmp, data, sid)
        # The gate file itself, unmodified, with cwd inside the sandbox. `ROOT = Path.cwd()` in that
        # script is what makes this work, and it is why no flag had to be added there.
        run = subprocess.run([sys.executable, str(GATE)], cwd=str(tmp),
                             capture_output=True, text=True, timeout=300)
    except subprocess.TimeoutExpired:
        not_applicable("the gate did not finish within 300s on the sandbox copy.")
    except OSError as exc:
        not_applicable(f"could not build the sandbox ({exc}).")
    finally:
        if tmp is not None:
            shutil.rmtree(tmp, ignore_errors=True)

    # The gate names files by absolute path, which inside the sandbox is a temp directory that no
    # longer exists by the time anyone reads the message. Rewriting it back to the repo-relative
    # form is not cosmetics: the whole promise here is "what would fail, why, and how to reproduce
    # it", and a path pointing into a deleted /tmp tree breaks the third of those.
    # BOTH forms of the sandbox path. On macOS `mkdtemp()` hands back /var/folders/... while the
    # gate, resolving through Path.cwd(), prints /private/var/folders/... — the same directory by
    # two names. Replacing only the one we hold leaves the message pointing at a deleted tree,
    # which is the defect this function exists to remove.
    def relocate(text: str) -> str:
        # Longest first: /var/folders/... is a SUBSTRING of /private/var/folders/..., so replacing
        # the short form first eats the middle of the long one and leaves "/private.orchestrator-state".
        for base in sorted({str(tmp), str(tmp.resolve())}, key=len, reverse=True):
            text = text.replace(base + os.sep, "").replace(base, ".")
        return text

    if run.returncode == 0:
        warnings = [relocate(l) for l in run.stderr.splitlines() if l.startswith("state warning:")]
        out(f"{sid} WOULD CLOSE CLEANLY. The gate accepted it as `verified` on a copy with §7's "
            f"flip applied (status, passes, checkpoint cleared) and nothing else changed."
            + (f" {len(warnings)} warning(s), which do not block:" if warnings else ""))
        for w in warnings:
            print(f"    {w}", file=sys.stderr)
        raise SystemExit(0)

    # A gate that CRASHES also exits 1 (an unhandled traceback), and reporting that as "would be
    # rejected" sends the conductor hunting for a defect in the unit instead of in the gate. The
    # discriminator is the gate's own message prefix: every rejection it makes starts with
    # `state invalid:`. No such line means this was not a verdict.
    rejections = [l for l in run.stderr.splitlines() if l.startswith("state invalid:")]
    if run.returncode == 1 and not rejections:
        say(f"the gate exited 1 on the sandbox WITHOUT a `state invalid:` verdict — that is a crash, "
            f"not a rejection of {sid}. Its output follows; fix the gate, then rehearse again.")
        print(relocate(run.stderr.strip())[:2000], file=sys.stderr)
        raise SystemExit(2)

    if run.returncode == 1:
        say(f"{sid} WOULD BE REJECTED. The gate's own words:")
        for line in rejections:
            print(f"    {relocate(line)}", file=sys.stderr)
        say(f"Fix that, then ask again:\n"
            f"    python3 .orchestrator/scripts/rehearse-close.py {sid}\n"
            f"  This is a rehearsal: nothing was written and no iteration was spent. The same "
            f"message is what §7's own gate run will print once you flip the status for real.")
        raise SystemExit(1)

    say(f"the gate exited {run.returncode} on the sandbox, which is neither accept nor reject.")
    if run.stderr.strip():
        print(relocate(run.stderr.strip())[:2000], file=sys.stderr)
    raise SystemExit(2)


if __name__ == "__main__":
    main()
