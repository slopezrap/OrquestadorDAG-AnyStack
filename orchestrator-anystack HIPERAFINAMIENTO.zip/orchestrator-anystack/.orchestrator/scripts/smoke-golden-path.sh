#!/usr/bin/env bash
# End-to-end smoke test of the orchestrator's deterministic machinery, using the
# golden-path example (.orchestrator/examples/golden-path). Copies the scaffold to
# a temp dir, mounts the golden blueprint + canonical state, and checks:
#   POSITIVE: blueprint lint, state gate, --emit-status projections, structure +
#             lens-set sync, hook on a valid state.
#   NEGATIVE: the gate MUST reject — incomplete lens set, borrowed evidence,
#             cross-layer value drift, debugger cap exceeded, two units building,
#             missing artifact; and the hook MUST reject corrupted features.json.
# Exit 0 only if every expectation holds.
set -uo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
GP="$ROOT/.orchestrator/examples/golden-path"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT

WORK="$TMP/orch"
mkdir -p "$WORK"
cp -R "$ROOT/." "$WORK/"
rm -rf "$WORK/blueprint" "$WORK/.orchestrator-state"
cp -R "$GP/blueprint" "$WORK/blueprint"
cp -R "$GP/state" "$WORK/.orchestrator-state"
# An initialized project has its stack commands resolved; the golden path carries a resolved
# stack.md fixture so the gate's <COMMAND_*> backstop sees a real (finished) project, not the
# repo scaffold's placeholders.
cp "$GP/stack.md" "$WORK/.claude/rules/stack.md"
cd "$WORK"
# El hook resuelve el proyecto por CLAUDE_PROJECT_DIR: fijarlo al arbol temporal o,
# si viene heredado del entorno, el smoke validaria el repo real en vez de este.
export CLAUDE_PROJECT_DIR="$WORK"

pass=0; fail=0
ok()   { echo "PASS  $1"; pass=$((pass+1)); }
bad()  { echo "FAIL  $1"; fail=$((fail+1)); }
expect_ok()   { local d="$1"; shift; if "$@" >/dev/null 2>&1; then ok "$d"; else bad "$d"; fi; }
expect_fail() { local d="$1"; shift; if "$@" >/dev/null 2>&1; then bad "$d (debería haber fallado)"; else ok "$d"; fi; }
# Negativo con motivo: exigir que el gate falle POR el invariante que el caso dice
# probar, no por un daño colateral de la mutación (un expect_fail a secas se queda
# en verde aunque el invariante esté desactivado).
expect_fail_msg() {
  local d="$1" pat="$2"; shift 2
  local out rc
  out="$("$@" 2>&1)"; rc=$?
  if [ "$rc" -eq 0 ]; then bad "$d (debería haber fallado)"
  elif printf '%s' "$out" | grep -q "$pat"; then ok "$d"
  else bad "$d (falló por otro motivo: $out)"; fi
}
# Positivo con motivo: exigir que un script no-fatal salga 0 Y haya hecho lo que dice hacer.
# Un expect_ok a secas se queda en verde con un script que sale 0 sin actuar — que es
# exactamente el fallo que reset-test-data.sh podría tener y nadie notaría.
expect_ok_msg() {
  local d="$1" pat="$2"; shift 2
  local out rc
  out="$("$@" 2>&1)"; rc=$?
  if [ "$rc" -ne 0 ]; then bad "$d (salió $rc, debería salir 0)"
  elif printf '%s' "$out" | grep -qF "$pat"; then ok "$d"
  else bad "$d (salió 0 pero no hizo lo que dice: $out)"; fi
}
# Igual que el anterior pero insensible a mayusculas: para contratos que varias
# implementaciones cumplen con redacciones distintas.
expect_ok_imsg() {
  local d="$1" pat="$2"; shift 2
  local out rc
  out="$("$@" 2>&1)"; rc=$?
  if [ "$rc" -ne 0 ]; then bad "$d (salió $rc, debería salir 0)"
  elif printf '%s' "$out" | grep -qiF "$pat"; then ok "$d"
  else bad "$d (salió 0 pero no hizo lo que dice: $out)"; fi
}

FEAT=".orchestrator-state/features.json"
RES=".orchestrator-state/evidence/SCR-001/result.json"

echo "== golden path: positivos =="
expect_ok "lint-blueprint: blueprint golden sin errores" python3 .orchestrator/scripts/lint-blueprint.py
# --decidedness existia en 6 sitios que lo invocaban y en ninguno que lo implementara:
# el script no tenia argparse, asi que el flag se ignoraba en silencio y undecided_fields[]
# salia SIEMPRE vacio. Eso rompia la regla en las dos direcciones a la vez — /arch-review
# daba por decidido un blueprint entero sin decidir, y las lentes arch-* levantaban como
# blocker campos que solo eran el default de la plantilla. Un vacio indistinguible de
# "nada sin decidir" es justo la clase de defecto que la constitucion llama peligroso.
expect_ok "lint-blueprint: --decidedness --json emite JSON con undecided_fields[]" python3 -c "
import json, subprocess
out = subprocess.run(['python3', '.orchestrator/scripts/lint-blueprint.py', '--decidedness', '--json'],
                     capture_output=True, text=True, check=True).stdout
d = json.loads(out)
assert d['schema_version'] == 'orchestrator.blueprint-lint.v1', d['schema_version']
assert isinstance(d['undecided_fields'], list), type(d['undecided_fields'])
assert d['counts']['undecided_fields'] == len(d['undecided_fields']), d['counts']
for row in d['undecided_fields']:
    assert set(row) == {'file', 'block', 'key', 'value', 'reason', 'block_match_ratio'}, row
    assert row['reason'] in ('placeholder', 'template_default'), row
    # El ratio es la defensa contra el sobre-reporte: un template_default solo cuenta si el
    # BLOQUE entero sigue sin tocar. Un placeholder lo salta — es ausencia sin ambiguedad.
    assert row['reason'] == 'placeholder' or row['block_match_ratio'] >= 0.6, row
"
# El flag no debe alterar el comportamiento por defecto: 12 sitios lo invocan sin flags.
expect_ok_msg "lint-blueprint: sin flags se comporta como siempre" "blueprint lint OK" \
  python3 .orchestrator/scripts/lint-blueprint.py
# Y debe DISCRIMINAR: un blueprint sin tocar tiene mas silencio que uno relleno. Sin esto
# el flag podria devolver [] siempre y los dos asserts de arriba seguirian en verde.
expect_ok "lint-blueprint: distingue plantilla sin rellenar de blueprint decidido" python3 -c "
import json, subprocess, shutil, os
def undecided():
    out = subprocess.run(['python3', '.orchestrator/scripts/lint-blueprint.py', '--decidedness', '--json'],
                         capture_output=True, text=True).stdout
    return len(json.loads(out)['undecided_fields'])
filled = undecided()
tpl = next((t for t in sorted(os.listdir('blueprint-templates/logic'))
            if os.path.exists('blueprint/logic/' + t.replace('-template', ''))), None)
assert tpl, 'ninguna plantilla de logic/ tiene su capa correspondiente en el blueprint'
shutil.copy('blueprint-templates/logic/' + tpl, 'blueprint/logic/' + tpl.replace('-template', ''))
raw = undecided()
assert raw > filled, f'plantilla cruda ({raw}) deberia tener MAS campos sin decidir que el blueprint relleno ({filled})'
"
cp -R "$GP/blueprint/." blueprint/
# Integridad referencial BIDIRECCIONAL. El linter ya cazaba una cita a un ID que nadie define;
# el sentido contrario —una capa que declara related_screens: [SCR-X] mientras el applies[] de
# SCR-X no la cita de vuelta— quedaba invisible, y es el caro: TODA lente se acota a applies[],
# asi que una capa no citada no tiene dueno y la unidad cierra en verde sin haberse juzgado
# nunca contra ella. Cuando se escribio este check, el propio golden path traia dos (CORE-001 y
# PIPE-001 reclamaban SCR-001 sin que SCR-001 las citara); estan arregladas y esto lo sostiene.
expect_ok "lint-blueprint: el golden path no deja ninguna capa sin citar" python3 -c "
import json, subprocess
d = json.loads(subprocess.run(['python3', '.orchestrator/scripts/lint-blueprint.py', '--json'],
                              capture_output=True, text=True).stdout)
assert d['uncited_claims'] == [], d['uncited_claims']
assert d['counts']['uncited_claims'] == 0, d['counts']
"
# Y debe cazarlo cuando existe, como AVISO y no como error: SCREENS.md se escribe el ultimo
# (USO.md §3), asi que romper aqui dispararia en todo proyecto a medio escribir — y un check
# que rechaza estados validos acaba esquivado.
expect_ok "lint-blueprint: avisa (sin romper) de una capa que reclama una pantalla que no la cita" bash -c '
python3 - <<PY
import json, subprocess
from pathlib import Path
p = Path("blueprint/SCREENS.md")
p.write_text(p.read_text().replace("applies: [BR-001, CORE-001,", "applies: [BR-001,"))
r = subprocess.run(["python3", ".orchestrator/scripts/lint-blueprint.py", "--json"],
                   capture_output=True, text=True)
d = json.loads(r.stdout)
assert [x for x in d["uncited_claims"]
        if x["block"] == "CORE-001" and x["screen"] == "SCR-001"], d["uncited_claims"]
assert d["counts"]["errors"] == 0, "debe ser aviso, no error"
assert r.returncode == 0, r.returncode
assert all(x["reason"] == "not_cited_back" for x in d["uncited_claims"]), d["uncited_claims"]
PY
'
cp -R "$GP/blueprint/." blueprint/
# Dos huecos del propio check, ambos silenciosos hasta que se probaron:
#  (a) un ID reclamado que SI esta definido pero NO como bloque ```screen``` no lo cazaba nadie —
#      el bucle de referencias colgantes solo habla cuando el token no esta en NINGUN bloque, y
#      este no tiene applies[] contra el que comparar. La reclamacion sigue rota: una capa no
#      puede estar "relacionada con" algo que no es una unidad.
#  (b) `related_screens: [SCR-001, SCR-001]` es UNA reclamacion escrita dos veces; cada fila de
#      uncited_claims[] acaba siendo una pregunta CLARIFY, y preguntar N veces lo mismo es como
#      una ronda de preguntas deja de leerse.
expect_ok "lint-blueprint: caza una reclamacion a un ID que existe pero no es una pantalla, y no duplica" bash -c '
python3 - <<PY
import json, subprocess
from pathlib import Path
p = Path("blueprint/logic/data.md")
p.write_text(p.read_text() + """
### DATA-900 — reclamante de prueba

\\x60\\x60\\x60logic
id: DATA-900
related_screens: [DATA-001, SCR-001, SCR-001]
\\x60\\x60\\x60
""")
r = subprocess.run(["python3", ".orchestrator/scripts/lint-blueprint.py", "--json"],
                   capture_output=True, text=True)
d = json.loads(r.stdout)
rows = [x for x in d["uncited_claims"] if x["block"] == "DATA-900"]
kinds = sorted(x["reason"] for x in rows)
assert kinds == ["not_cited_back", "target_is_not_a_screen"], rows
assert r.returncode == 0, r.returncode
PY
'
cp -R "$GP/blueprint/." blueprint/
expect_ok "state gate: estado canónico valida" python3 .orchestrator/scripts/validate-state.py
# Los gates cruzados dejaron de producir informes huerfanos: emiten SCR-FIX-* que el bucle
# recoge. `remediates` es una lista de referencias como after/applies, asi que el linter debe
# resolverla — una unidad de reparacion no puede citar una pantalla que nadie define.
expect_ok "lint-blueprint: acepta un SCR-FIX-* con remediates[] resoluble" bash -c '
cat >> blueprint/SCREENS.md <<EOF

### SCR-FIX-SMOKE-001 — reparacion emitida por un gate

\`\`\`screen
id: SCR-FIX-SMOKE-001
kind: fix
platforms: [web]
order: 99
after: [SCR-001]
applies: [JOUR-001]
remediates: [SCR-001]
status: draft
acceptance:
  - "el contador de la cabecera muestra el valor canonico al volver de detalle"
\`\`\`
EOF
python3 .orchestrator/scripts/lint-blueprint.py'
expect_fail_msg "lint-blueprint: rechaza un SCR-FIX-* que remedia una pantalla inexistente" "references undefined ID SCR-999" bash -c '
python3 - <<PY
from pathlib import Path
p = Path("blueprint/SCREENS.md")
p.write_text(p.read_text().replace("remediates: [SCR-001]", "remediates: [SCR-999]"))
PY
python3 .orchestrator/scripts/lint-blueprint.py'
cp -R "$GP/blueprint/." blueprint/
expect_ok "emit-status: escribe proyecciones" python3 .orchestrator/scripts/validate-state.py --emit-status
expect_ok "status.json: 2 accepted + 1 verified, SCR-001 esperando accept" python3 -c "
import json
d = json.load(open('.orchestrator-state/status.json'))
assert d['schema_version'] == 'orchestrator.status.v1'
assert d['counts']['accepted'] == 2 and d['counts']['verified'] == 1
assert d['verified_awaiting_accept'] == ['SCR-001'] and d['building'] is None
"
expect_ok "evidence/index.json: 3 unidades con sus fases" python3 -c "
import json
d = json.load(open('.orchestrator-state/evidence/index.json'))
assert len(d['screens']) == 3
scr = next(s for s in d['screens'] if s['screen_id'] == 'SCR-001')
assert {p['phase'] for p in scr['phases']} == {'RESEARCH','EXPLORE','DEVELOP','VERIFY','VALIDATE','REVIEW'}
"
expect_ok "estructura + sincronía de lentes .js↔.py" bash .orchestrator/scripts/validate-structure.sh
# `args` llega como CADENA JSON en este build, no como objeto: medido, typeof args === "string".
# Eso hacia que args.screen_id (y changed_files, scope_to, fail_fast) fueran undefined en los 9
# workflows. No rompio nada porque cada uno cae a su default disk-first y resuelve la unidad
# correcta de disco -- pero TODO argumento opcional dejo de funcionar en silencio, incluida la
# optimizacion de alcance de reparaciones entera. Un fallo que apunta al lado seguro es el que
# mas tarda en verse, asi que se prueba el normalizador, no solo que el flag exista.
expect_ok "workflows: args normalizado (objeto, cadena JSON, cadena no-JSON, ausente)" node -e "
const norm = (args) => { const log = () => {};
  if (args === undefined || args === null) return {};
  if (typeof args === 'object') return args;
  if (typeof args === 'string') { const raw = args.trim(); if (!raw) return {};
    try { const p = JSON.parse(raw); return (p && typeof p === 'object') ? p : {}; } catch (e) { return {}; } }
  return {}; };
const eq = (a, b, m) => { if (a !== b) { console.error(m, a, '!==', b); process.exit(1); } };
eq(norm({screen_id:'SCR-001'}).screen_id, 'SCR-001', 'objeto');
eq(norm(JSON.stringify({screen_id:'SCR-001'})).screen_id, 'SCR-001', 'cadena JSON');
eq(norm('SCR-001').screen_id, undefined, 'cadena no-JSON');
eq(norm(undefined).screen_id, undefined, 'ausente');
eq(norm('').screen_id, undefined, 'cadena vacia');
eq(norm('[1,2]').length, 2, 'array JSON');
"
# Y que NINGUN workflow lea `args` crudo: el normalizador solo sirve si todos pasan por el.
expect_ok "workflows: ninguno accede a args crudo fuera del normalizador" python3 -c "
import re, pathlib, sys
bad = []
for f in sorted(pathlib.Path('.claude/workflows').glob('*.js')):
    src = f.read_text(encoding='utf-8')
    assert 'const ARGS = (() =>' in src, f'{f.name}: sin normalizador'
    for i, l in enumerate(src.splitlines(), 1):
        if l.strip().startswith('//') or 'args.trim()' in l: continue
        for m in re.finditer(r'(?<![A-Za-z_.])args\.[a-z_]+', l):
            pre = l[:m.start()]
            if pre.count(chr(96)) % 2 or pre.count(chr(39)) % 2 or pre.count(chr(34)) % 2: continue
            bad.append(f'{f.name}:{i}')
assert not bad, bad
"
# El alcance de reparacion (changed_files + las dos directivas de triage) viaja por `args`, y
# `args` se ha medido que NO llega al script a veces: sin error, el global sale undefined y no
# hay forma de distinguir "no me pasaron nada" de "me pasaron algo y se perdio". Por eso tambien
# se escribe a disco. Esto prueba el CONTRATO del fichero que verify-fanout pide leer al loader:
# cabecera con la iteracion (guarda de frescura) + directivas opcionales + rutas literales.
expect_ok "changed-files.txt: contrato de cabecera parseable y con guarda de frescura" python3 -c "
import re
sample = '''# iteration: 2
# command: git diff --name-only HEAD~1..HEAD
# triage: fail_fast
# triage: scope_to=verify-tests,verify-design
src/app/notes.py
src/ui/list.tsx
'''
lines = sample.splitlines()
it = int(re.match(r'# iteration:\s*(-?\d+)', lines[0]).group(1))
ff = any(l.strip() == '# triage: fail_fast' for l in lines)
sc = next((m.group(1).split(',') for l in lines for m in [re.match(r'# triage:\s*scope_to=(.+)', l.strip())] if m), [])
paths = [l for l in lines if l.strip() and not l.startswith('#')]
assert it == 2, it
assert ff is True
assert sc == ['verify-tests', 'verify-design'], sc
assert paths == ['src/app/notes.py', 'src/ui/list.tsx'], paths
# Guarda de frescura: un alcance de la iteracion 2 NO puede aplicarse a la 3. Un alcance viejo
# es peor que ninguno — la propia skill lo dice: 'diez lentes se lo van a creer'.
for now in (0, 1, 3):
    assert not (it == now and now > 0), f'iteracion {now} no deberia honrar un fichero de la {it}'
assert (it == 2 and 2 > 0), 'la iteracion que coincide SI debe honrarse'
# Y sin cabecera de iteracion no se honra nada: ausencia = baseline, nunca 'aplicalo igual'.
assert re.match(r'# iteration:', 'src/app/notes.py') is None
"
# Ambas directivas fuerzan full_set:false, que el conductor no puede registrar en phase_runs[]
# y que el gate rechaza como VERIFY incompleto. Esa es la razon por la que leerlas de disco es
# aceptable: una directiva olvidada cuesta una pasada, no un PASS falso.
# Copia PROPIA: $TMP/res.bak todavia no existe en este punto del smoke (se crea mas abajo),
# asi que restaurar desde ahi dejaria el estado mutado para todas las pruebas siguientes.
cp "$RES" "$TMP/res-triage.bak"
expect_fail_msg "el gate rechaza un VERIFY truncado por triage (set incompleto)" "verify-fanout" bash -c '
python3 - <<PY
import json
p = ".orchestrator-state/evidence/SCR-001/result.json"
d = json.load(open(p))
for run in d["phase_runs"]:
    if run["phase"] == "VERIFY":
        run["lenses"] = [l for l in run["lenses"] if l not in ("verify-design", "verify-tests")]
json.dump(d, open(p, "w"), indent=2)
PY
python3 .orchestrator/scripts/validate-state.py'
cp "$TMP/res-triage.bak" "$RES"
# V2: full_set:false es legal en una entrada VERIFY que NO es la de cierre (triage real, con
# carried_forward[]). Pero este fixture solo registra UNA entrada VERIFY, así que es a la vez
# primera y última -- sigue siendo la de cierre. Marcarla full_set:false (con carried_forward de
# los dos lenses que se omitieron) debe seguir siendo ILEGAL, ahora por el motivo nuevo: la de
# cierre exige full_set:true explícito, no basta con listar lo que se "arrastró".
cp "$RES" "$TMP/res-triage2.bak"
expect_fail_msg "rechaza full_set:false en la entrada VERIFY de cierre (aunque traiga carried_forward)" "closing VERIFY entry" bash -c '
python3 - <<PY
import json
p = ".orchestrator-state/evidence/SCR-001/result.json"
d = json.load(open(p))
for run in d["phase_runs"]:
    if run["phase"] == "VERIFY":
        run["lenses"] = [l for l in run["lenses"] if l not in ("verify-design", "verify-tests")]
        run["full_set"] = False
        run["carried_forward"] = [{"lens": "verify-design", "from_iteration": 0}, {"lens": "verify-tests", "from_iteration": 0}]
json.dump(d, open(p, "w"), indent=2)
PY
python3 .orchestrator/scripts/validate-state.py'
cp "$TMP/res-triage2.bak" "$RES"
# Positivo: la secuencia REAL de una reparación -- baseline completa (iteration 0), luego una
# pasada de triage (full_set:false + carried_forward citándola), luego la de cierre completa.
# El orden importa y es parte del contrato: un triage no puede preceder a toda pasada completa,
# porque entonces no habría nada de donde arrastrar. Sin este test, el código nuevo solo estaría
# probado por el lado del rechazo.
cp "$RES" "$TMP/res-triage3.bak"
expect_ok "acepta baseline completa -> triage (full_set:false, citando iteration 0) -> cierre completa" bash -c '
python3 - <<PY
import copy, json
p = ".orchestrator-state/evidence/SCR-001/result.json"
d = json.load(open(p))
closing = next(r for r in d["phase_runs"] if r["phase"] == "VERIFY")
baseline = copy.deepcopy(closing)
baseline["iteration"] = 0
triage = copy.deepcopy(closing)
triage["iteration"] = 1
triage["lenses"] = [l for l in triage["lenses"] if l not in ("verify-design", "verify-tests")]
triage["full_set"] = False
triage["carried_forward"] = [{"lens": "verify-design", "from_iteration": 0}, {"lens": "verify-tests", "from_iteration": 0}]
closing["full_set"] = True
closing["iteration"] = 1
idx = d["phase_runs"].index(closing)
d["phase_runs"][idx:idx] = [baseline, triage]
json.dump(d, open(p, "w"), indent=2)
PY
python3 .orchestrator/scripts/validate-state.py'
cp "$TMP/res-triage3.bak" "$RES"
# fail_fast: la prosa (next-pantalla §6, constitution.md, result.schema.json) promete DOS reglas
# --- una pasada fail-fast no puede ser la de cierre, y su verdict debe ser "fail". Estuvieron sin
# respaldo mecanico hasta que una revision de regresion lo probo; estos dos casos existen para que
# no vuelva a pasar desapercibido.
cp "$RES" "$TMP/res-ff.bak"
expect_fail_msg "rechaza fail_fast:true en la entrada VERIFY de cierre" "CLOSING VERIFY entry" bash -c '
python3 - <<PY
import json
p = ".orchestrator-state/evidence/SCR-001/result.json"
d = json.load(open(p))
next(r for r in d["phase_runs"] if r["phase"] == "VERIFY")["fail_fast"] = True
json.dump(d, open(p, "w"), indent=2)
PY
python3 .orchestrator/scripts/validate-state.py'
cp "$TMP/res-ff.bak" "$RES"
expect_fail_msg "rechaza fail_fast:true cuyo verdict no es fail" "verdict is" bash -c '
python3 - <<PY
import copy, json
p = ".orchestrator-state/evidence/SCR-001/result.json"
d = json.load(open(p))
closing = next(r for r in d["phase_runs"] if r["phase"] == "VERIFY")
ff = copy.deepcopy(closing); ff["fail_fast"] = True; ff["verdict"] = "pass"
d["phase_runs"].insert(d["phase_runs"].index(closing), ff)
json.dump(d, open(p, "w"), indent=2)
PY
python3 .orchestrator/scripts/validate-state.py'
cp "$TMP/res-ff.bak" "$RES"
# cap_override y layers_not_applicable: dos exenciones portadas desde maser-onda junto con el
# codigo que las implementa. Se traen SUS pruebas, no solo la funcion: una exencion sin el caso
# negativo que la acota es indistinguible de haber quitado el control.
cp "$FEAT" "$TMP/feat-cap.bak"
expect_fail_msg "rechaza cap_override vacio (sin decided_by/reason)" "cap_override" bash -c '
python3 - <<PY
import json
p = ".orchestrator-state/features.json"
d = json.load(open(p))
next(s for s in d["screens"] if s["id"] == "SCR-001")["checkpoint"] = {
    "phase": "VERIFY", "iteration": 4, "cap_override": {"decided_by": "", "reason": ""}}
json.dump(d, open(p, "w"), ensure_ascii=False, indent=2)
PY
python3 .orchestrator/scripts/validate-state.py'
cp "$TMP/feat-cap.bak" "$FEAT"
expect_ok "acepta cap_override con decided_by y reason reales" bash -c '
python3 - <<PY
import json
p = ".orchestrator-state/features.json"
d = json.load(open(p))
next(s for s in d["screens"] if s["id"] == "SCR-001")["checkpoint"] = {
    "phase": "VERIFY", "iteration": 4,
    "cap_override": {"decided_by": "El dueno", "reason": "cada pasada hallo un defecto distinto"}}
json.dump(d, open(p, "w"), ensure_ascii=False, indent=2)
PY
python3 .orchestrator/scripts/validate-state.py'
cp "$TMP/feat-cap.bak" "$FEAT"
cp "$RES" "$TMP/res-lna.bak"
expect_fail_msg "rechaza exencion de capa que la feature NO declara n/a" "does not mark that layer" bash -c '
python3 - <<PY
import json
p = ".orchestrator-state/evidence/SCR-001/result.json"
d = json.load(open(p))
a = d["data_engine_assertions"][0]
a.pop("ui_value", None)
a["layers_not_applicable"] = {"client": "inventada: la feature SI declara ui_field real"}
json.dump(d, open(p, "w"), ensure_ascii=False, indent=2)
PY
python3 .orchestrator/scripts/validate-state.py'
cp "$TMP/res-lna.bak" "$RES"
expect_ok "hook: comando Bash sobre estado válido pasa" bash -c 'echo "{\"tool_input\":{\"command\":\"cat .orchestrator-state/features.json\"}}" | bash .claude/hooks/validate-state.sh'

# PreCompact: la compactacion borra el chat, y el ancla de reanudacion vive en disco. El hook
# no decide ni muta ciclo de vida (constitution: "Do not use hooks to mutate lifecycle") —
# refresca las proyecciones e imprime el ancla. Debe ser SIEMPRE no-fatal: un hook que pueda
# fallar aqui convierte "el contexto se hizo largo" en "la tirada murio".
expect_ok_msg "precompact: imprime el ancla de reanudacion desde disco" "resume anchor" \
  bash .claude/hooks/precompact-checkpoint.sh
expect_ok_msg "precompact: nombra la unidad activa y su checkpoint" "resume at phase VERIFY, iteration 2" \
  bash -c '
python3 - <<PY
import json
p=".orchestrator-state/features.json"; d=json.load(open(p))
s=next(x for x in d["screens"] if x["id"]=="SCR-001")
s["status"]="building"; s["passes"]=False; s["checkpoint"]={"phase":"VERIFY","iteration":2}
c={}
for x in d["screens"]: c[x["status"]]=c.get(x["status"],0)+1
for k in d["summary"]:
    if k!="total": d["summary"][k]=c.get(k,0)
json.dump(d,open(p,"w"),indent=2)
PY
bash .claude/hooks/precompact-checkpoint.sh'
expect_ok_msg "precompact: nombra el batch en vuelo, no el recuento recordado" "BATCH IN FLIGHT" \
  bash -c '
echo "{\"schema_version\":\"orchestrator.batch.v1\",\"mode\":\"build-loop\",\"started_at\":\"2026-01-01T00:00:00Z\",\"status\":\"running\",\"max_requested\":5,\"units_built\":[\"SCR-FOUNDATION-SCHEMA\"]}" > .orchestrator-state/batch.json
bash .claude/hooks/precompact-checkpoint.sh'
# Un batch.json corrupto no puede tumbar la compactacion: degrada a aviso y sigue.
expect_ok_msg "precompact: batch.json corrupto avisa pero no rompe" "does not parse" \
  bash -c 'echo "esto no es json" > .orchestrator-state/batch.json; bash .claude/hooks/precompact-checkpoint.sh'
rm -f .orchestrator-state/batch.json
cp "$TMP/feat.bak" "$FEAT" 2>/dev/null || cp "$GP/state/features.json" "$FEAT"

echo "== golden path: negativos (el gate debe rechazar) =="
cp "$RES" "$TMP/res.bak"; cp "$FEAT" "$TMP/feat.bak"

python3 - <<'PY'
import json
p = '.orchestrator-state/evidence/SCR-001/result.json'
d = json.load(open(p))
for run in d['phase_runs']:
    if run['phase'] == 'VERIFY':
        run['lenses'] = [l for l in run['lenses'] if l != 'verify-coherence']
json.dump(d, open(p, 'w'), ensure_ascii=False, indent=2)
PY
expect_fail "rechaza VERIFY con set de lentes incompleto (sin verify-coherence)" python3 .orchestrator/scripts/validate-state.py
cp "$TMP/res.bak" "$RES"

# EXPLORE debe dejar su plan en disco (phase_runs[EXPLORE].plan -> evidence/<ID>/plan.md).
# La seccion que lo produce se llama "Explore AND PLAN": el plan es el entregable de EXPLORE,
# no una fase aparte. Vivia solo en el contexto del conductor, y de ahi salian tres cosas: una
# compactacion a mitad de DEVELOP lo re-derivaba, nadie podia preguntar "¿se construyo lo que
# se planeo?", y un criterio sin respuesta a "¿como se prueba?" no se veia hasta gastar el
# abanico de VERIFY. Se comprueba igual que cualquier artefacto: existe y no pesa 0 bytes.
python3 - <<'PY'
import json
p = '.orchestrator-state/evidence/SCR-001/result.json'
d = json.load(open(p))
for run in d['phase_runs']:
    if run['phase'] == 'EXPLORE':
        run.pop('plan', None)
json.dump(d, open(p, 'w'), ensure_ascii=False, indent=2)
PY
expect_fail_msg "rechaza un EXPLORE sin plan[] en una unidad aun en vuelo" "has no .plan." \
  python3 .orchestrator/scripts/validate-state.py
cp "$TMP/res.bak" "$RES"

python3 - <<'PY'
import json
p = '.orchestrator-state/evidence/SCR-001/result.json'
d = json.load(open(p))
for run in d['phase_runs']:
    if run['phase'] == 'EXPLORE':
        run['plan'] = '.orchestrator-state/evidence/SCR-001/plan-que-no-existe.md'
json.dump(d, open(p, 'w'), ensure_ascii=False, indent=2)
PY
expect_fail_msg "rechaza un plan citado que no es un fichero real" "which is not a file" \
  python3 .orchestrator/scripts/validate-state.py
cp "$TMP/res.bak" "$RES"

# CONTENCION del plan. Sin ella el check solo prueba que EXISTE algun fichero no vacio en alguna
# parte: `ROOT / "/etc/hosts"` descarta ROOT entero (pathlib tira el operando izquierdo ante uno
# absoluto) y suficientes `../` se salen del arbol, asi que cualquier fichero legible de la maquina
# satisfacia "EXPLORE escribio su plan". Y ademas cierra el hueco de evidencia prestada que
# validate_result ya cierra para result.json: citar el plan.md de OTRA unidad tambien pasaba.
for bad in "/etc/hosts" "../../../../../../../../etc/hosts" ".orchestrator-state/evidence/SCR-FOUNDATION-SCHEMA/plan.md"; do
  python3 - "$bad" <<'PY'
import json, sys
p = '.orchestrator-state/evidence/SCR-001/result.json'
d = json.load(open(p))
for run in d['phase_runs']:
    if run['phase'] == 'EXPLORE':
        run['plan'] = sys.argv[1]
json.dump(d, open(p, 'w'), ensure_ascii=False, indent=2)
PY
  expect_fail_msg "rechaza un plan fuera del directorio de evidencia de la unidad ($bad)" \
    "must be a repo-relative path inside this" \
    python3 .orchestrator/scripts/validate-state.py
  cp "$TMP/res.bak" "$RES"
done

# `"plan": null` TIENE la clave, asi que dict.get(k, "") no aplica el default y str(None)=="None"
# se colaba hasta el chequeo de fichero, dando "points at None" — que se lee como un problema de
# ruta en vez de como un plan ausente. Mismo fallo, mensaje que manda al sitio equivocado.
python3 - <<'PY'
import json
p = '.orchestrator-state/evidence/SCR-001/result.json'
d = json.load(open(p))
for run in d['phase_runs']:
    if run['phase'] == 'EXPLORE':
        run['plan'] = None
json.dump(d, open(p, 'w'), ensure_ascii=False, indent=2)
PY
expect_fail_msg "un plan a null se reporta como plan AUSENTE, no como ruta rota" "has no .plan." \
  python3 .orchestrator/scripts/validate-state.py
cp "$TMP/res.bak" "$RES"

# Retroactividad, igual que source_manifest: una unidad que un humano ya ACEPTO no se invalida
# por un requisito que no existia cuando la firmo — reabrir `accepted` esta prohibido en otro
# sitio de este mismo gate, asi que fallar aqui no dejaria ninguna jugada legal. Avisa y sigue.
cp "$GP/state/evidence/SCR-FOUNDATION-SCHEMA/result.json" "$TMP/res-schema.bak"
python3 - <<'PY'
import json
p = '.orchestrator-state/evidence/SCR-FOUNDATION-SCHEMA/result.json'
d = json.load(open(p))
for run in d['phase_runs']:
    if run['phase'] == 'EXPLORE':
        run.pop('plan', None)
json.dump(d, open(p, 'w'), ensure_ascii=False, indent=2)
PY
expect_ok "una unidad ya accepted sin plan solo AVISA (no invalida evidencia firmada)" bash -c '
out=$(python3 .orchestrator/scripts/validate-state.py 2>&1); rc=$?
[ "$rc" -eq 0 ] && printf "%s" "$out" | grep -q "SCR-FOUNDATION-SCHEMA.phase_runs\[EXPLORE\] has no"'
cp "$TMP/res-schema.bak" ".orchestrator-state/evidence/SCR-FOUNDATION-SCHEMA/result.json"

python3 - <<'PY'
import json
p = '.orchestrator-state/evidence/SCR-001/result.json'
d = json.load(open(p)); d['screen_id'] = 'SCR-FOUNDATION-SHELL'
json.dump(d, open(p, 'w'), ensure_ascii=False, indent=2)
PY
expect_fail "rechaza evidencia prestada (screen_id de otra pantalla)" python3 .orchestrator/scripts/validate-state.py
cp "$TMP/res.bak" "$RES"

python3 - <<'PY'
import json
p = '.orchestrator-state/evidence/SCR-001/result.json'
d = json.load(open(p)); d['data_engine_assertions'][0]['ui_value'] = 'Comprar té'
json.dump(d, open(p, 'w'), ensure_ascii=False, indent=2)
PY
expect_fail "recomputa same_value: deriva db/ui ('café' vs 'té')" python3 .orchestrator/scripts/validate-state.py
cp "$TMP/res.bak" "$RES"

python3 - <<'PY'
import json
p = '.orchestrator-state/features.json'
d = json.load(open(p))
next(s for s in d['screens'] if s['id'] == 'SCR-001')['checkpoint'] = {'phase': 'VERIFY', 'iteration': 4}
json.dump(d, open(p, 'w'), ensure_ascii=False, indent=2)
PY
expect_fail "rechaza debugger loop pasado del tope (iteration 4 > 3)" python3 .orchestrator/scripts/validate-state.py
cp "$TMP/feat.bak" "$FEAT"

python3 - <<'PY'
import json
p = '.orchestrator-state/features.json'
d = json.load(open(p))
for sid in ('SCR-FOUNDATION-SCHEMA', 'SCR-FOUNDATION-SHELL'):
    s = next(x for x in d['screens'] if x['id'] == sid)
    s['status'] = 'building'; s['passes'] = False
# El resto del estado queda coherente para que el UNICO fallo posible sea el
# invariante `building <= 1`: las dos unidades quedan independientes (si SHELL
# siguiera dependiendo de SCHEMA fallaria por la dependencia) y el summary se
# recalcula. Verificado: neutralizando el invariante, el gate vuelve a pasar.
next(x for x in d['screens'] if x['id'] == 'SCR-FOUNDATION-SHELL')['after'] = []
if isinstance(d.get('summary'), dict):
    counts = {}
    for s in d['screens']:
        counts[s['status']] = counts.get(s['status'], 0) + 1
    for k in d['summary']:
        if k != 'total':
            d['summary'][k] = counts.get(k, 0)
json.dump(d, open(p, 'w'), ensure_ascii=False, indent=2)
PY
expect_fail_msg "rechaza dos unidades en building a la vez" "more than one unit is building" \
  python3 .orchestrator/scripts/validate-state.py
cp "$TMP/feat.bak" "$FEAT"

mv .orchestrator-state/evidence/SCR-001/screenshots/success.png "$TMP/shot.bak"
expect_fail "rechaza PASS con artefacto ausente (screenshot borrado)" python3 .orchestrator/scripts/validate-state.py
# El screenshot vuelve ANTES de los dos casos siguientes: si no, el gate falla por el
# artefacto que falta y ambos se quedarian en verde sin probar su propio invariante.
mv "$TMP/shot.bak" .orchestrator-state/evidence/SCR-001/screenshots/success.png
cp "$RES" "$TMP/res-optional.bak"
# LA FIRMA: un guarda escrito como "si el campo esta, compruebalo" se apaga omitiendo el campo,
# y un guarda apagado produce exactamente la misma salida que uno satisfecho. Ya paso una vez
# aqui (platforms[] vacio hacia que el gate se saltara VALIDATE entera, validate-state.py:178).
# Estos dos casos cierran los que quedaban.
python3 - <<'PYX'
import json
p = ".orchestrator-state/evidence/SCR-001/result.json"
d = json.load(open(p)); d.pop("source_manifest", None)
json.dump(d, open(p, "w"), indent=2)
PYX
expect_fail_msg "rechaza un PASS sin source_manifest (el guarda anti-rancio no puede correr)" \
  "indistinguishable from a manifest that passes" python3 .orchestrator/scripts/validate-state.py
cp "$TMP/res-optional.bak" "$RES"
python3 - <<'PYX'
import json
p = ".orchestrator-state/evidence/SCR-001/result.json"
d = json.load(open(p)); d.pop("expected_ui_values", None)
json.dump(d, open(p, "w"), indent=2)
PYX
expect_fail_msg "rechaza un PASS con valor de cliente y sin expected_ui_values[]" \
  "derives-from assertion was vacuous" python3 .orchestrator/scripts/validate-state.py
cp "$TMP/res-optional.bak" "$RES"
mv "$TMP/shot.bak" .orchestrator-state/evidence/SCR-001/screenshots/success.png

# VALIDATE dejó de ser solo-UI: una unidad que cita PIPE-* (o ENG-*) debe PROBAR que el
# pipeline/motor corrió de verdad. Verificarlo estáticamente ya no basta para llegar a verified.
python3 - <<'PY'
import json
p = '.orchestrator-state/evidence/SCR-001/result.json'
d = json.load(open(p))
for run in d['phase_runs']:
    if run['phase'] == 'VALIDATE':
        run['lenses'] = [l for l in run['lenses'] if l != 'validate-pipeline']
json.dump(d, open(p, 'w'), ensure_ascii=False, indent=2)
PY
expect_fail "rechaza unidad que cita PIPE-001 sin validate-pipeline en vivo" python3 .orchestrator/scripts/validate-state.py
cp "$TMP/res.bak" "$RES"

echo 'esto ya no es json' > "$FEAT"
if echo "{\"tool_input\":{\"file_path\":\"$WORK/$FEAT\"}}" | bash .claude/hooks/validate-state.sh >/dev/null 2>&1; then
  bad "hook rechaza features.json corrupto (debería haber fallado)"
else
  ok "hook rechaza features.json corrupto"
fi
cp "$TMP/feat.bak" "$FEAT"

# Ralph: build-loop encadena sin aceptar. Construir sobre una dependencia `verified` es LEGAL
# (permiso para trabajar); aceptar saltandose el orden de after[] NO lo es (permiso para dar por
# bueno). Sin el primero, /build-loop solo avanzaba un nivel del DAG por ejecucion.
python3 - <<'PY'
import json
p = '.orchestrator-state/features.json'
d = json.load(open(p))
for s in d['screens']:
    if s['status'] == 'accepted':
        s['status'] = 'verified'
counts = {}
for s in d['screens']:
    counts[s['status']] = counts.get(s['status'], 0) + 1
for k in d['summary']:
    if k != 'total':
        d['summary'][k] = counts.get(k, 0)
json.dump(d, open(p, 'w'), ensure_ascii=False, indent=2)
PY
expect_ok "permite construir sobre dependencias solo verified (cadena entera sin accepts)" python3 .orchestrator/scripts/validate-state.py
expect_ok "status.json separa lo aceptable-ya de lo que espera orden" python3 -c "
import json, subprocess
subprocess.run(['python3', '.orchestrator/scripts/validate-state.py', '--emit-status'], check=True, capture_output=True)
d = json.load(open('.orchestrator-state/status.json'))
assert d['acceptable_now'] == ['SCR-FOUNDATION-SCHEMA'], d['acceptable_now']
waiting = {r['id'] for r in d['verified_blocked_by_accept_order']}
assert waiting == {'SCR-FOUNDATION-SHELL', 'SCR-001'}, waiting
"
cp "$TMP/feat.bak" "$FEAT"

python3 - <<'PY'
import json
p = '.orchestrator-state/features.json'
d = json.load(open(p))
# SCR-001 aceptado mientras su dependencia SHELL sigue solo verified: la puerta humana
# debe seguir el orden del DAG aunque construir por delante este permitido.
next(s for s in d['screens'] if s['id'] == 'SCR-FOUNDATION-SHELL')['status'] = 'verified'
next(s for s in d['screens'] if s['id'] == 'SCR-001')['status'] = 'accepted'
json.dump(d, open(p, 'w'), ensure_ascii=False, indent=2)
PY
expect_fail "rechaza aceptar saltandose el orden de after[] (dependencia solo verified)" python3 .orchestrator/scripts/validate-state.py
cp "$TMP/feat.bak" "$FEAT"

# /accept --auto solo es honesto contra una politica RESUELTA. Espejo exacto del backstop de
# <COMMAND_*> en stack.md: una politica con placeholders no ha autorizado nada, y leer
# <AUTO_ACCEPT_SEVERITY_CEILING> como permiso produciria unidades "aceptadas por politica"
# donde no habia politica. Solo se comprueba cuando alguien reclama aceptacion automatica.
# Variable PROPIA: $RES es global y apunta a SCR-001. Reasignarla haria que los
# `cp "$TMP/res.bak" "$RES"` posteriores escribieran la evidencia de una pantalla en la
# ruta de otra — justo el "evidencia prestada" que el gate rechaza tres casos mas arriba.
RES_SCHEMA=".orchestrator-state/evidence/SCR-FOUNDATION-SCHEMA/result.json"
cp "$RES_SCHEMA" "$TMP/res-schema.bak"
cp .claude/rules/autonomy.md "$TMP/autonomy.bak"
mark_auto() { python3 - "$1" <<'PY'
import json, sys
p = ".orchestrator-state/evidence/SCR-FOUNDATION-SCHEMA/result.json"
d = json.load(open(p))
d.setdefault("human_gate", {}).update(
    {"accepted": True, "accepted_by": "auto",
     "policy_rule": None if sys.argv[1] == "sin-regla" else "AUTO-003"})
# Una aceptacion automatica completa declara advisory_findings, aunque sea vacio: --auto
# comprueba los hallazgos contra el techo de severidad, y un array AUSENTE no es "no hay
# hallazgos", es "nadie los escribio". El caso sin el se prueba aparte, mas abajo.
if sys.argv[1] != "sin-hallazgos":
    d["advisory_findings"] = []
else:
    d.pop("advisory_findings", None)
json.dump(d, open(p, "w"), indent=2)
PY
}
expect_ok "politica con placeholders no molesta si nadie acepto por politica" python3 .orchestrator/scripts/validate-state.py
mark_auto con-regla
expect_fail_msg "rechaza auto-aceptacion contra una politica sin resolver" "an unfilled policy authorizes nothing" \
  python3 .orchestrator/scripts/validate-state.py
python3 - <<'PY'
import re
from pathlib import Path
p = Path('.claude/rules/autonomy.md')
p.write_text(re.sub(r'<[A-Z][A-Z0-9_]{2,}>', 'resuelto', p.read_text(encoding='utf-8')), encoding='utf-8')
PY
expect_ok "acepta auto-aceptacion contra una politica resuelta" python3 .orchestrator/scripts/validate-state.py
mark_auto sin-regla
expect_fail_msg "rechaza auto-aceptacion que no nombra la regla que la autorizo" "no policy_rule" \
  python3 .orchestrator/scripts/validate-state.py
# La ausencia del array no puede leerse como "no hay hallazgos". Mismo defecto que el
# manifiesto ausente y que --decidedness devolviendo []: un guarda apagado y un guarda
# satisfecho no pueden producir la misma salida.
mark_auto sin-hallazgos
expect_fail_msg "rechaza auto-aceptacion sin advisory_findings[] declarado" "an absent array is not the same as an empty one" \
  python3 .orchestrator/scripts/validate-state.py
cp "$TMP/res-schema.bak" "$RES_SCHEMA"
cp "$TMP/autonomy.bak" .claude/rules/autonomy.md

# El otro sentido de la regla de `ready`: una unidad que DEBERIA estar ready y nadie promovio.
# El gate ya rechazaba la promocion indebida (ready con deps sin construir); esto cubre el
# fallo simetrico y silencioso — todo con deps construidas, nada ready, nada building: el
# bucle recomputa, no encuentra nada y reporta "no queda ready", que se lee como "terminado".
# Es warn() y no fail() a proposito: la promocion es perezosa por diseño y un todo promovible
# es legal mientras el conductor tenga trabajo en la mano. Solo es sospechoso cuando no hay
# nada ready NI building, que es justo el instante en que el bucle decide que ha acabado.
python3 - <<'PY'
import json
p = '.orchestrator-state/features.json'
d = json.load(open(p))
# Todo aceptado salvo una unidad huerfana en todo cuyas dependencias ya estan construidas.
for s in d['screens']:
    s['status'] = 'accepted'
# Derivada de una unidad real del fixture para heredar TODOS los campos obligatorios
# (verify, data_engine, ...): una unidad escrita a mano falla el gate por su forma, no
# por el invariante que este caso quiere probar.
import copy
huerfana = copy.deepcopy(next(s for s in d['screens'] if s['id'] == 'SCR-001'))
huerfana.update({
    "id": "SCR-TODO-HUERFANA", "slug": "huerfana",
    "title": "Unidad promovible no promovida",
    "order": 99, "status": "todo", "after": ["SCR-001"], "passes": False,
    "evidence_path": ".orchestrator-state/evidence/SCR-TODO-HUERFANA/result.json",
})
huerfana.pop('checkpoint', None)
d['screens'].append(huerfana)
counts = {}
for s in d['screens']:
    counts[s['status']] = counts.get(s['status'], 0) + 1
d['summary']['total'] = len(d['screens'])
for k in d['summary']:
    if k != 'total':
        d['summary'][k] = counts.get(k, 0)
json.dump(d, open(p, 'w'), ensure_ascii=False, indent=2)
PY
expect_ok_msg "avisa (sin romper) de un todo promovible cuando nada esta ready ni building" \
  "they should have been promoted to ready" \
  python3 .orchestrator/scripts/validate-state.py
expect_ok "status.json expone promotable_todo para que el bucle no lea 'nada ready' como 'terminado'" python3 -c "
import json, subprocess
subprocess.run(['python3', '.orchestrator/scripts/validate-state.py', '--emit-status'], check=True, capture_output=True)
d = json.load(open('.orchestrator-state/status.json'))
assert d['promotable_todo'] == ['SCR-TODO-HUERFANA'], d['promotable_todo']
assert d['next_ready'] is None, d['next_ready']
"
cp "$TMP/feat.bak" "$FEAT"

# Un DIRECTORIO no es evidencia: `exists()` lo daba por bueno y el guard `is_file()` del
# control de 0 bytes lo dejaba pasar limpiamente. Renombrar un .txt a .png ya no basta.
mv .orchestrator-state/evidence/SCR-001/screenshots/success.png "$TMP/shot2.bak"
mkdir .orchestrator-state/evidence/SCR-001/screenshots/success.png
expect_fail_msg "rechaza un DIRECTORIO haciendose pasar por artefacto" "non-file artifact" \
  python3 .orchestrator/scripts/validate-state.py
rmdir .orchestrator-state/evidence/SCR-001/screenshots/success.png
mv "$TMP/shot2.bak" .orchestrator-state/evidence/SCR-001/screenshots/success.png

# La fuente de verdad nunca es un cliente. Antes se comparaba la CADENA ENTERA contra el set
# de capas cliente, asi que anadir una palabra ("UI store") burlaba el invariante que la
# constitucion declara no negociable.
python3 - <<'PY'
import json
p = '.orchestrator-state/features.json'
d = json.load(open(p))
s = next(x for x in d['screens'] if x['id'] == 'SCR-001')
s['data_engine']['canonical_store']['source_of_truth'] = 'UI store'
json.dump(d, open(p, 'w'), ensure_ascii=False, indent=2)
PY
expect_fail_msg "rechaza un cliente como fuente de verdad ('UI store')" "client layer as system of record" \
  python3 .orchestrator/scripts/validate-state.py
cp "$TMP/feat.bak" "$FEAT"

# Trazabilidad: un ID que no define ningun fichero del blueprint pasaba gate Y linter.
python3 - <<'PY'
import json
p = '.orchestrator-state/features.json'
d = json.load(open(p))
next(x for x in d['screens'] if x['id'] == 'SCR-001')['applies'].append('DATA-999')
json.dump(d, open(p, 'w'), ensure_ascii=False, indent=2)
PY
expect_fail_msg "rechaza un ID que ningun fichero del blueprint define (DATA-999)" "no blueprint file defines" \
  python3 .orchestrator/scripts/validate-state.py
cp "$TMP/feat.bak" "$FEAT"

# El fan-out obligatorio era comparacion de cadenas: una lente inventada satisfacia el set.
python3 - <<'PY'
import json
p = '.orchestrator-state/evidence/SCR-001/result.json'
d = json.load(open(p))
for run in d['phase_runs']:
    if run['phase'] == 'VERIFY':
        run['lenses'].append('verify-lente-totalmente-inventada')
json.dump(d, open(p, 'w'), ensure_ascii=False, indent=2)
PY
expect_fail_msg "rechaza una lente que no existe en el roster de agentes" "not in the agent roster" \
  python3 .orchestrator/scripts/validate-state.py
cp "$TMP/res.bak" "$RES"

# El read_path es una DIRECCION (almacen -> transporte -> cliente): invertido pasaba, porque
# se buscaban subcadenas sobre la concatenacion de todos los pasos en vez de por posicion.
python3 - <<'PY'
import json
p = '.orchestrator-state/features.json'
d = json.load(open(p))
rp = next(x for x in d['screens'] if x['id'] == 'SCR-001')['data_engine']['pipeline']['read_path']
rp.reverse()
json.dump(d, open(p, 'w'), ensure_ascii=False, indent=2)
PY
expect_fail_msg "rechaza un read_path invertido (cliente -> almacen)" "must START at the canonical store" \
  python3 .orchestrator/scripts/validate-state.py
cp "$TMP/feat.bak" "$FEAT"

# Gate de arquitectura /arch-review: NO retroactivo (un estado sin meta.architecture_review
# sigue siendo valido — el golden path no la trae y todos los positivos de arriba pasan),
# pero --init-gate SI la exige (un proyecto no puede NACER sin el gate), y si la clave
# existe, su forma se valida con dureza: blockers abiertos o set de lentes parcial rompen.
expect_fail_msg "--init-gate exige meta.architecture_review para nacer" "must run /arch-review" \
  python3 .orchestrator/scripts/validate-state.py --init-gate
expect_fail_msg "--init-gate exige meta.discovery para nacer" "must run /discovery" \
  python3 .orchestrator/scripts/validate-state.py --init-gate

# Orden de obra: la comprobacion de cimiento-sin-consumidor es ADVISORY en toda corrida normal
# (un orden raro puede ser una decision humana con razones que el gate no ve) pero BLOQUEANTE en
# --init-gate, que es el unico momento en que reordenar cuesta una edicion. Medido: el mismo
# defecto dejado pasar costo 4x (307 lanzamientos contra 78). El golden path esta bien ordenado,
# asi que primero se comprueba que NO dispara — un check que salta siempre no es un check.
expect_ok "orden de obra: el golden path no dispara el aviso de cimiento sin consumidor" bash -c '
out=$(python3 .orchestrator/scripts/validate-state.py 2>&1)
! printf "%s" "$out" | grep -q "foundation unit(s) have no"'
cp "$FEAT" "$TMP/feat-order.bak"
python3 - <<'PY'
import json
p = '.orchestrator-state/features.json'
d = json.load(open(p))
d['screens'].append({
    'id': 'SCR-FOUNDATION-HUERFANO', 'slug': 'huerfano',
    'title': 'cimiento que nada ejercita', 'kind': 'foundation', 'platforms': [],
    'order': 1, 'after': [], 'status': 'todo', 'passes': False,
    'acceptance': ['existe el andamiaje'], 'verify': {},
    'evidence_path': '.orchestrator-state/evidence/SCR-FOUNDATION-HUERFANO/result.json',
    'blocked_reason': None, 'notes': '',
})
d['summary']['total'] += 1
d['summary']['todo'] = d['summary'].get('todo', 0) + 1
json.dump(d, open(p, 'w'), ensure_ascii=False, indent=2)
PY
expect_ok "orden de obra: el gate normal AVISA de un cimiento huerfano y no rompe" bash -c '
out=$(python3 .orchestrator/scripts/validate-state.py 2>&1); rc=$?
[ "$rc" -eq 0 ] && printf "%s" "$out" | grep -q "foundation unit(s) have no"'
# El patron NO puede empezar por '--': expect_fail_msg usa `grep -q "$pat"` y grep lo tomaria
# por una opcion suya. Se ancla igualmente al prefijo que solo emite la rama de --init-gate.
expect_fail_msg "orden de obra: --init-gate lo convierte en fallo duro" \
  "init-gate: 1 foundation unit(s) have no" \
  python3 .orchestrator/scripts/validate-state.py --init-gate
cp "$TMP/feat-order.bak" "$FEAT"

python3 - <<'PY'
import json
p = '.orchestrator-state/features.json'
d = json.load(open(p))
d.setdefault('meta', {})['architecture_review'] = {
    'status': 'clear',
    'lenses': ['arch-fit', 'arch-data-model', 'arch-identity', 'arch-engines',
               'arch-pipelines', 'arch-risk'],
    'failed_lenses': [],
    'open_blockers': [{'finding_id': 'ARCH-001', 'detail': 'tenancy sin decidir'}],
    'report_sha256': 'deadbeef',
}
json.dump(d, open(p, 'w'), ensure_ascii=False, indent=2)
PY
expect_fail_msg "rechaza architecture_review con blockers abiertos" "open_blockers is non-empty" \
  python3 .orchestrator/scripts/validate-state.py
cp "$TMP/feat.bak" "$FEAT"

python3 - <<'PY'
import json
p = '.orchestrator-state/features.json'
d = json.load(open(p))
d.setdefault('meta', {})['architecture_review'] = {
    'status': 'clear',
    'lenses': ['arch-fit'],  # set parcial: mismo pecado que un fan-out a medias
    'failed_lenses': [], 'open_blockers': [], 'report_sha256': 'deadbeef',
}
json.dump(d, open(p, 'w'), ensure_ascii=False, indent=2)
PY
expect_fail_msg "rechaza architecture_review con set de lentes parcial" "full arch set" \
  python3 .orchestrator/scripts/validate-state.py
cp "$TMP/feat.bak" "$FEAT"

# Gate de descubrimiento /discovery: misma disciplina que architecture_review — NO retroactivo
# (un estado sin meta.discovery sigue siendo valido), pero si la clave existe su forma se valida
# con dureza: items sin disposicion o set de lentes parcial rompen.
python3 - <<'PY'
import json
p = '.orchestrator-state/features.json'
d = json.load(open(p))
d.setdefault('meta', {})['discovery'] = {
    'status': 'complete',
    'lenses': ['discovery-product', 'discovery-data', 'discovery-architecture',
               'discovery-stack', 'discovery-infra', 'discovery-ux'],
    'failed_lenses': [], 'unresolved': ['Q-UX-07'],  # un item sin disposicion
    'checklist_version': 1, 'items_total': 62,
    'dispositions': {'answered': 30, 'filled': 20, 'asked': 8, 'na': 4, 'deferred': 0},
    'report_sha256': 'deadbeef',
}
json.dump(d, open(p, 'w'), ensure_ascii=False, indent=2)
PY
expect_fail_msg "rechaza discovery con items sin disposicion" "unresolved is non-empty" \
  python3 .orchestrator/scripts/validate-state.py
cp "$TMP/feat.bak" "$FEAT"

python3 - <<'PY'
import json
p = '.orchestrator-state/features.json'
d = json.load(open(p))
d.setdefault('meta', {})['discovery'] = {
    'status': 'complete',
    'lenses': ['discovery-product'],  # set parcial: mismo pecado que un fan-out a medias
    'failed_lenses': [], 'unresolved': [],
    'checklist_version': 1, 'items_total': 62,
    'dispositions': {'answered': 30, 'filled': 20, 'asked': 8, 'na': 4, 'deferred': 0},
    'report_sha256': 'deadbeef',
}
json.dump(d, open(p, 'w'), ensure_ascii=False, indent=2)
PY
expect_fail_msg "rechaza discovery con set de lentes parcial" "full discovery set" \
  python3 .orchestrator/scripts/validate-state.py
cp "$TMP/feat.bak" "$FEAT"

# Backstop determinista: un proyecto inicializado que conserve <COMMAND_*> sin resolver en
# stack.md no puede validar — sin comandos reales los verificadores no tienen nada que correr.
cp .claude/rules/stack.md "$TMP/stack.bak"
printf '\n# leftover\n<COMMAND_TEST>\n' >> .claude/rules/stack.md
expect_fail_msg "rechaza proyecto inicializado con <COMMAND_*> sin resolver" "unresolved command placeholders" \
  python3 .orchestrator/scripts/validate-state.py
cp "$TMP/stack.bak" .claude/rules/stack.md

# reset-test-data.sh: contrato de delegación a stack.md. Prueba los TRES estados, porque el
# fallo silencioso que importa aquí es un script que sale 0 sin hacer nada y parece correcto.
# Positivo real: sobre el stack.md resuelto del golden path DEBE resolver la clave y delegar.
echo "== reset-test-data: contrato de delegación =="
expect_ok_imsg "resuelve COMMAND_RESET_TEST_DATA y delega el comando declarado" \
  "python3 manage.py migrate" \
  bash .orchestrator/scripts/reset-test-data.sh VERIFY
# No fatal: el comando delegado falla aquí (el golden path no trae manage.py) y aun así sale 0
# — preparar datos nunca puede bloquear una fase; el conductor decide qué hacer con el aviso.
expect_ok_imsg "no es fatal cuando el comando delegado falla" \
  "fail" \
  bash .orchestrator/scripts/reset-test-data.sh VERIFY
# Estado "no declarada" distinguible de estado "declarada sin resolver": colapsarlos ocultaría
# un hueco real de configuración detrás del mismo mensaje.
grep -v "COMMAND_RESET_TEST_DATA" "$TMP/stack.bak" > .claude/rules/stack.md
expect_ok_imsg "reporta clave no declarada sin romper" \
  "not declared" \
  bash .orchestrator/scripts/reset-test-data.sh VERIFY
printf '\n# reset (COMMAND_RESET_TEST_DATA)\n<COMMAND_RESET_TEST_DATA>\n' >> .claude/rules/stack.md
expect_ok_imsg "distingue placeholder sin resolver de clave ausente" \
  "placeholder" \
  bash .orchestrator/scripts/reset-test-data.sh VERIFY
cp "$TMP/stack.bak" .claude/rules/stack.md

expect_ok "estado restaurado: el gate vuelve a pasar" python3 .orchestrator/scripts/validate-state.py

echo
echo "golden-path smoke: $pass PASS, $fail FAIL"
[ "$fail" -eq 0 ]
