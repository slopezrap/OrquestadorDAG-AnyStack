# PLAN SCR-FOUNDATION-SHELL — Shell compartida

- **verification_route**: web. Se renderiza una ruta real dentro de la shell y se leen
  consola y red; no hay dato canónico propio que probar.
- **consumer** (quién ejerce esta unidad): **`SCR-001`**, la siguiente unidad del orden.
  La shell es el caso donde esto más importa: es un contrato transversal (`UI-SHELL-*`)
  que toda pantalla posterior hereda, así que un defecto aquí no se paga una vez sino
  una vez por pantalla. Que su consumidor vaya inmediatamente detrás es deliberado.

## Mapa de aceptación

| criterio | IDs que lo rigen | ficheros a tocar | cómo se prueba | artefacto |
|---|---|---|---|---|
| AC-SCR-FOUNDATION-SHELL-001 shell | UI-SHELL-001, UI-SHELL-002 | `web/shell.html`, `web/shell.js` | abrir una ruta real y ver header + navegación | `screenshots/shell-success.png` |
| AC-SCR-FOUNDATION-SHELL-002 tokens | UI-SHELL-003 | `web/shell.css`, `design/tokens.css` | ningún color/tipografía/espaciado hardcodeado: todo vía token | `logs/test-output.txt` |

## Orden vertical

1. layout y navegación (`UI-SHELL-001`, `UI-SHELL-002`)
2. enganche con `design/tokens.css` (`UI-SHELL-003`)
3. test que falla si aparece un valor de diseño hardcodeado

## Riesgos asumidos

- El inventario de componentes (`UI-SHELL-003`) nace con lo mínimo que `SCR-001` necesita.
  **Trip-wire**: la segunda pantalla que invente un componente compartido lo devuelve a
  `shell.md` en el harvest de su cierre, o el conocimiento se queda solo en el código.

## Entrega

| criterio | estado | nota |
|---|---|---|
| AC-SCR-FOUNDATION-SHELL-001 | entregado | sin desviación |
| AC-SCR-FOUNDATION-SHELL-002 | entregado | sin desviación |
